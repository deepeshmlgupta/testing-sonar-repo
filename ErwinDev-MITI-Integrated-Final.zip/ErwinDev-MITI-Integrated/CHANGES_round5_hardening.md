# Round 5 — hardening, concurrency, multi-user, dedup

Base: the round-4 tree (`ErwinDev-feature_new-fixed.zip`) with the 14 Sep
MAX_PATH / UDP-mirror changes ported on top. 284 tests pass · ruff 0 · bandit 0 ·
coverage 79.9 %. A 4-worker isolated run on the two real LDMs reproduces the
same V1/V2/V3 numbers as the sequential run.

## Ported from the laptop tree (14 Sep)
| Change | Where |
|---|---|
| Short report names: `<short>_v1_fidelity_report.xlsx`, `…_v2_udp_mapping_report.xlsx`, `…_v3_fidelity_report.xlsx`, `<short>_migration.log`; report folder = `short_model_name()` (repository hash + extraction id stripped, 60-char cap) | `reporting/report_layout.py`, `model_log.py`, `promote_model.py` |
| UDP classification written as `classification.json` (per-model workdir; legacy name still read) | `validation/udp_bridge.py` |
| `sappdmodels/*` mirrored to `app/udp_tool/input_erwin_models/{cdm,ldm,pdm}` (copy-if-newer, atomic replace, `--no-mirror` / `MIRROR_MODELS_TO_UDP_INPUT`) | `orchestration/directory_setup.py` |

## Concurrency (`MAX_WORKERS > 1`)
* **Race fixed** — the UDP-tool bridge and the PDM-validator bridge each rewrote
  `sys.path` / `sys.modules` under their own lock; an LDM worker and a PDM
  worker loading at the same moment could erase each other's path insertion
  mid-import. One shared re-entrant `IMPORT_LOCK` now guards every isolated
  import (`app/common/isolated_import.py`, ~120 duplicated lines removed from
  the two bridges). Test: 32 threads × both bridges, `sys.path` unchanged.
* **Pre-flight before the pool starts** (`orchestration/concurrency.preflight`):
  rejects two models with the same stem (`x.ldm` + `x.cdm` → same stage files,
  UDP workdir and report folder) or the same short report name; probes every
  output root for write access; detects a live ledger lock held by another
  run. Rejections are listed at the end of the run and never executed.
* **Stall watchdog** (`batch_runner._run_threaded`): when no model finishes for
  `BATCH_STALL_TIMEOUT_SECONDS` (1800) the runner logs every worker thread's
  stack (`concurrency.stall_report`) and keeps waiting; `BATCH_ABORT_ON_STALL`
  / `--abort-on-stall` makes it a hard stop for unattended jobs.
* **Lock-ordering audit** documented in `concurrency.py`: four locks, none held
  while acquiring another, every external wait (COM, subprocess) has a timeout
  → no lock cycle is possible.
* Tests: `tests/test_concurrency_safety.py` (10), 5-model / 4-worker vs
  sequential equivalence in `tests/test_batch_pipeline.py`.

## Multi-user (`orchestration/run_context.py`)
* `--isolate` (or `ENABLE_SESSION_ISOLATION=true`) puts **every** output under
  `sessions/<user>_<timestamp>_<id>/` — erwinmodels stages, reports, batch
  summary + ledger, UDP workdirs and workbooks, scratch. Previously only the
  erwinmodels folder was scoped; reports, `data/udp` and the summary were still
  shared and would collide between two users.
* Inputs stay shared; an isolated run still finds XML V1 / .erwin exports in
  the shared `erwinmodels/` tree (`StagePaths._shared`).
* `--user`, `--session-id` (and `FORCE_USERNAME` / `FORCE_SESSION_ID`, which
  existed but were never read) let `run_v1` → `run_udp` → `run_v3` share one
  session folder. Identity is sanitised to one path component (`CORP\user` →
  `CORP_user`).
* All four entry points take the same flags (`--workers`, `--max-models`,
  `--stall-timeout`, `--abort-on-stall`, `--no-mirror`, `--log-level`,
  `--isolate/--no-isolate`, `--user`, `--session-id`); values land in
  `settings`, so no downstream module knows a CLI exists.
* `setup.py` rewritten: folder tree incl. `sessions/` and the UDP input tiers,
  `--dev`, `--no-tests`, `--multi-user` (session root, OS user, file-lock
  probe), Windows long-path / OneDrive warnings, correct run instructions
  (from the checkout root, never `cd app`). SETUP.md / QUICK_START.md / README
  updated; dead `settings.get_session_*` helpers and unused `tqdm` removed.
* Tests: `tests/test_run_context.py` (7) incl. two isolated runs on one checkout
  writing disjoint trees.

## Dedup / optimisation (behaviour-preserving)
| Removed | Replaced by |
|---|---|
| `cdm_reconcile/cardinality.py` ≡ `ldm_reconcile/cardinality.py` (350 lines each, one import line different) | `validation/relationship_cardinality.py`; both packages are one-line re-export shims |
| 5 copies of `_local/_children/_first_child/_descendants` (CDM, LDM, PDM parsers, extended_properties, udp_fidelity) | `common/xml_helpers.py`, `local_name` memoised — it was the hottest Python function in a profiled run (2.3 M calls) |
| 4 copies of `_tier_config`, 4 of `_cfg` | `common/config_helpers.tier_config / cfg` (module made import-light to avoid cycles) |
| Two isolated-import loaders | `common/isolated_import.IsolatedLoader` |
| `report_layout` deriving the repo root from the (now rebindable) `REPORTING_ROOT` | `_REPO_ROOT` constant |

Net: −1 492 / +2 257 lines including ~700 lines of new tests and docs.

## Also folded in
The 14 Sep sample-model fixes that the round-4 zip lacked (severity-ordered findings cap, COUNTIF cell-reference criteria in the UDP summary sheets, PDM report path following the moved artefact) and their test `tests/test_sample_model_fixes.py`.

## Not changed (deliberately)
* CDM/LDM engine duplication beyond byte-identical modules (parsers,
  comparators, report generators differ by 120–460 lines each) — a merge is
  its own round with real regression risk.
* Unused trailing parameters flagged by vulture (`len2`, `prec2`,
  `validator_config`) — signature contracts, harmless.
* UDP tool workbook names (`<fullname>_UDP_Migration_Report.xlsx`) are still
  ~250 characters on the OneDrive checkout; move the checkout or enable Windows
  long paths (`setup.py` now warns).
