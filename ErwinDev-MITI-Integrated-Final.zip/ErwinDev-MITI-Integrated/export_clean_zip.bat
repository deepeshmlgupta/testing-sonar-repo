@echo off
REM ==========================================================================
REM  export_clean_zip.bat — Package clean repository zip without local .venv
REM ==========================================================================
cd /d "%~dp0"

echo.
echo ==========================================================================
echo  Creating clean distribution zip: migration-platform-dist.zip
echo ==========================================================================

python create_clean_zip.py

pause
