| Engine | Object | Property | Result | Finding(s) | Note |
|---|---|---|---|---|---|
| LDM | Entity | Name | ✅ VALIDATED | DIAGRAM_SYMBOLS, ENTITY_EXTRA, ENTITY_MISSING, RELATIONSHIP_EXTRA, RELATIONSHIP_MISSING | renamed → missing/extra |
| LDM | Entity | Definition/Comment | ✅ VALIDATED | DEFINITION_MISMATCH |  |
| LDM | Entity | Definition lost | ✅ VALIDATED | DEFINITION_LOSS |  |
| LDM | Entity | Extended attribute (UDP) value | ❌ NOT VALIDATED | — | scored by udp_fidelity (UDP component), not a finding |
| LDM | Entity | Subject area / package membership | ❌ NOT VALIDATED | — | PACKAGE_CONTENTS fires when contents differ (next Package rows); when the ONLY subject area loses all its Entity_Ref the export is indistinguishable from one that never writes contents |
| LDM | Attribute | Name | ✅ VALIDATED | BUSINESS_NAME |  |
| LDM | Attribute | Code / physical name | ✅ VALIDATED | FALLBACK_MATCH |  |
| LDM | Attribute | Definition | ✅ VALIDATED | DEFINITION_MISMATCH |  |
| LDM | Attribute | Data type | ✅ VALIDATED | DATA_TYPE |  |
| LDM | Attribute | Length | ✅ VALIDATED | LENGTH_PRECISION |  |
| LDM | Attribute | Precision / scale | ✅ VALIDATED | LENGTH_PRECISION |  |
| LDM | Attribute | Mandatory / optional | ✅ VALIDATED | MANDATORY |  |
| LDM | Attribute | Domain assignment | ✅ VALIDATED | ATTRIBUTE_DOMAIN | ATTRIBUTE_DOMAIN (extended_properties) |
| LDM | Attribute | Domain binding lost | ✅ VALIDATED | ATTRIBUTE_DOMAIN | ATTRIBUTE_DOMAIN |
| LDM | Attribute | Default value | ✅ VALIDATED | ATTRIBUTE_DEFAULT | ATTRIBUTE_DEFAULT (extended_properties) |
| LDM | Attribute | Default value lost | ✅ VALIDATED | ATTRIBUTE_DEFAULT | ATTRIBUTE_DEFAULT |
| LDM | Attribute | Extended attribute (UDP) | ❌ NOT VALIDATED | — | UDP component |
| LDM | Attribute | Order / sequence | ❌ NOT VALIDATED | — | CHECK_ATTRIBUTE_ORDER=False by default |
| LDM | Identifier | PK membership | ✅ VALIDATED | PRIMARY_IDENTIFIER |  |
| LDM | Identifier | AK membership | ✅ VALIDATED | ALTERNATE_IDENTIFIER |  |
| LDM | Identifier | AK member order | ✅ VALIDATED | IDENTIFIER_MEMBER_ORDER | IDENTIFIER_MEMBER_ORDER (extended_properties) |
| LDM | Identifier | Name | ✅ VALIDATED | IDENTIFIER_NAME | IDENTIFIER_NAME (extended_properties) |
| LDM | Identifier | PK lost | ✅ VALIDATED | ALTERNATE_IDENTIFIER, PRIMARY_IDENTIFIER |  |
| LDM | Relationship | Name / verb phrase | ✅ VALIDATED | ROLE_NAME | ROLE_NAME |
| LDM | Relationship | Inverse role | ✅ VALIDATED | ROLE_NAME |  |
| LDM | Relationship | Definition | ✅ VALIDATED | DEFINITION_MISMATCH |  |
| LDM | Relationship | Cardinality (many end) | ✅ VALIDATED | CARDINALITY |  |
| LDM | Relationship | Mandatory parent (optionality) | ✅ VALIDATED | OPTIONALITY, RELATIONSHIP_SEMANTIC_MISMATCH |  |
| LDM | Relationship | Identifying flag | ✅ VALIDATED | RELATIONSHIP_SEMANTIC_MISMATCH |  |
| LDM | Relationship | Parent / child entity | ✅ VALIDATED | RELATIONSHIP_EXTRA, RELATIONSHIP_MISSING |  |
| LDM | Relationship | Referential integrity (update rule) | ✅ VALIDATED | RELATIONSHIP_RI_RULE | RELATIONSHIP_RI_RULE (extended_properties); erwin code map is provisional |
| LDM | Relationship | Referential integrity (rule lost) | ✅ VALIDATED | RELATIONSHIP_RI_RULE | no per-relationship rule and no model default → reported as not carried |
| LDM | Relationship | Referential integrity (delete rule) | ✅ VALIDATED | RELATIONSHIP_RI_RULE | RELATIONSHIP_RI_RULE |
| LDM | Relationship | Dominance | ❌ NOT VALIDATED | — | PD DominantRole not read; erwin has no dominance field |
| LDM | Inheritance | Parent entity | ✅ VALIDATED | FALLBACK_MATCH |  |
| LDM | Inheritance | Child entities | ✅ VALIDATED | INHERITANCE_EXTRA, INHERITANCE_STRUCTURE, MODEL_QUALITY |  |
| LDM | Inheritance | Complete / incomplete | ✅ VALIDATED | INHERITANCE_CONSTRAINT |  |
| LDM | Inheritance | Mutually exclusive | ✅ VALIDATED | INHERITANCE_CONSTRAINT |  |
| LDM | Inheritance | Name | ✅ VALIDATED | INHERITANCE_NAME | INHERITANCE_NAME (extended_properties) |
| LDM | Domain | Data type | ✅ VALIDATED | DOMAIN_MISMATCH |  |
| LDM | Domain | Length | ✅ VALIDATED | DOMAIN_LENGTH | DOMAIN_LENGTH (extended_properties) |
| LDM | Domain | Definition | ✅ VALIDATED | DEFINITION_MISMATCH |  |
| LDM | Domain | Default value | ✅ VALIDATED | DOMAIN_DEFAULT | DOMAIN_DEFAULT (extended_properties) |
| LDM | Domain | Check parameters (low/high/list/format) | ✅ VALIDATED | DOMAIN_CHECK_PARAMS | DOMAIN_CHECK_PARAMS (extended_properties): PD Low/High/List/Format vs erwin Min/Max/Valid_Value_Rule_Ref |
| LDM | Domain | Check parameters (high value changed) | ✅ VALIDATED | DOMAIN_CHECK_PARAMS | DOMAIN_CHECK_PARAMS |
| LDM | Domain | Name | ✅ VALIDATED | DOMAIN_NAME | matched by code → name mismatch not itself compared; here code also carries |
| LDM | Business Rule | Name | ✅ VALIDATED | BUSINESS_NAME |  |
| LDM | Business Rule | Expression | ✅ VALIDATED | BUSINESS_RULE_EXPRESSION |  |
| LDM | Business Rule | Type | ✅ VALIDATED | BUSINESS_RULE_TYPE | BUSINESS_RULE_TYPE (extended_properties) |
| LDM | Business Rule | Definition | ✅ VALIDATED | DEFINITION_MISMATCH |  |
| LDM | Package | Name | ✅ VALIDATED | SUBJECT_AREA |  |
| LDM | Package | Hierarchy (parent changed) | ✅ VALIDATED | SUBJECT_AREA |  |
| LDM | Package | Hierarchy (parent lost → root) | ❌ NOT VALIDATED | — | PACKAGE_HIERARCHY fires only when the export still carries Parent_Subject_Area somewhere; with one nested package the loss is indistinguishable from an export that never writes parents |
| LDM | Package | Contents (entities) | ✅ VALIDATED | PACKAGE_CONTENTS | PACKAGE_CONTENTS (extended_properties) |
| LDM | Package | Definition | ✅ VALIDATED | PACKAGE_DEFINITION | PACKAGE_DEFINITION (extended_properties) |
| LDM | Diagram | Name | ✅ VALIDATED | DIAGRAM_MISSING | DIAGRAM_MISSING (extended_properties); only when the export carries Stored_Display |
| LDM | Diagram | Symbols displayed | ✅ VALIDATED | DIAGRAM_SYMBOLS | DIAGRAM_SYMBOLS (extended_properties); erwin drawing-object tag names unverified |
| LDM | Model | Name | ✅ VALIDATED | MODEL_METADATA | the EMX:Model name attribute is read first; probe changes both via two anchors below |
| LDM | Model | Definition | ✅ VALIDATED | MODEL_DEFINITION | MODEL_DEFINITION (extended_properties) |
| CDM | Entity | Name | ✅ VALIDATED | DIAGRAM_SYMBOLS, ENTITY_EXTRA, ENTITY_MISSING, RELATIONSHIP_EXTRA, RELATIONSHIP_MISSING | renamed → missing/extra |
| CDM | Entity | Definition/Comment | ✅ VALIDATED | DEFINITION, DEFINITION_MISMATCH |  |
| CDM | Entity | Definition lost | ✅ VALIDATED | DEFINITION_LOSS |  |
| CDM | Entity | Extended attribute (UDP) value | ❌ NOT VALIDATED | — | scored by udp_fidelity (UDP component), not a finding |
| CDM | Entity | Subject area / package membership | ❌ NOT VALIDATED | — | PACKAGE_CONTENTS fires when contents differ (next Package rows); when the ONLY subject area loses all its Entity_Ref the export is indistinguishable from one that never writes contents |
| CDM | Attribute | Name | ✅ VALIDATED | BUSINESS_NAME |  |
| CDM | Attribute | Code / physical name | ✅ VALIDATED | FALLBACK_MATCH |  |
| CDM | Attribute | Definition | ✅ VALIDATED | DEFINITION, DEFINITION_MISMATCH |  |
| CDM | Attribute | Data type | ✅ VALIDATED | DATA_TYPE |  |
| CDM | Attribute | Length | ✅ VALIDATED | LENGTH_PRECISION |  |
| CDM | Attribute | Precision / scale | ✅ VALIDATED | LENGTH_PRECISION |  |
| CDM | Attribute | Mandatory / optional | ✅ VALIDATED | MANDATORY |  |
| CDM | Attribute | Domain assignment | ✅ VALIDATED | ATTRIBUTE_DOMAIN | ATTRIBUTE_DOMAIN (extended_properties) |
| CDM | Attribute | Domain binding lost | ✅ VALIDATED | ATTRIBUTE_DOMAIN | ATTRIBUTE_DOMAIN |
| CDM | Attribute | Default value | ✅ VALIDATED | ATTRIBUTE_DEFAULT | ATTRIBUTE_DEFAULT (extended_properties) |
| CDM | Attribute | Default value lost | ✅ VALIDATED | ATTRIBUTE_DEFAULT | ATTRIBUTE_DEFAULT |
| CDM | Attribute | Extended attribute (UDP) | ❌ NOT VALIDATED | — | UDP component |
| CDM | Attribute | Order / sequence | ❌ NOT VALIDATED | — | CHECK_ATTRIBUTE_ORDER=False by default |
| CDM | Identifier | PK membership | ✅ VALIDATED | PRIMARY_IDENTIFIER |  |
| CDM | Identifier | AK membership | ✅ VALIDATED | ALTERNATE_IDENTIFIER |  |
| CDM | Identifier | AK member order | ✅ VALIDATED | IDENTIFIER_MEMBER_ORDER | IDENTIFIER_MEMBER_ORDER (extended_properties) |
| CDM | Identifier | Name | ✅ VALIDATED | IDENTIFIER_NAME | IDENTIFIER_NAME (extended_properties) |
| CDM | Identifier | PK lost | ✅ VALIDATED | ALTERNATE_IDENTIFIER, PRIMARY_IDENTIFIER |  |
| CDM | Relationship | Name / verb phrase | ✅ VALIDATED | ROLE_NAME | ROLE_NAME |
| CDM | Relationship | Inverse role | ✅ VALIDATED | ROLE_NAME |  |
| CDM | Relationship | Definition | ✅ VALIDATED | DEFINITION, DEFINITION_MISMATCH |  |
| CDM | Relationship | Cardinality (many end) | ✅ VALIDATED | CARDINALITY |  |
| CDM | Relationship | Mandatory parent (optionality) | ✅ VALIDATED | OPTIONALITY, RELATIONSHIP_SEMANTIC_MISMATCH |  |
| CDM | Relationship | Identifying flag | ✅ VALIDATED | RELATIONSHIP_SEMANTIC_MISMATCH |  |
| CDM | Relationship | Parent / child entity | ✅ VALIDATED | RELATIONSHIP_EXTRA, RELATIONSHIP_MISSING |  |
| CDM | Relationship | Referential integrity (update rule) | ✅ VALIDATED | RELATIONSHIP_RI_RULE | RELATIONSHIP_RI_RULE (extended_properties); erwin code map is provisional |
| CDM | Relationship | Referential integrity (rule lost) | ✅ VALIDATED | RELATIONSHIP_RI_RULE | no per-relationship rule and no model default → reported as not carried |
| CDM | Relationship | Referential integrity (delete rule) | ✅ VALIDATED | RELATIONSHIP_RI_RULE | RELATIONSHIP_RI_RULE |
| CDM | Relationship | Dominance | ❌ NOT VALIDATED | — | PD DominantRole not read; erwin has no dominance field |
| CDM | Inheritance | Parent entity | ✅ VALIDATED | FALLBACK_MATCH |  |
| CDM | Inheritance | Child entities | ✅ VALIDATED | INHERITANCE_EXTRA, INHERITANCE_STRUCTURE, MODEL_QUALITY |  |
| CDM | Inheritance | Complete / incomplete | ✅ VALIDATED | INHERITANCE_CONSTRAINT |  |
| CDM | Inheritance | Mutually exclusive | ✅ VALIDATED | INHERITANCE_CONSTRAINT |  |
| CDM | Inheritance | Name | ✅ VALIDATED | INHERITANCE_NAME | INHERITANCE_NAME (extended_properties) |
| CDM | Domain | Data type | ✅ VALIDATED | DOMAIN_MISMATCH |  |
| CDM | Domain | Length | ✅ VALIDATED | DOMAIN_LENGTH | DOMAIN_LENGTH (extended_properties) |
| CDM | Domain | Definition | ✅ VALIDATED | DEFINITION, DEFINITION_MISMATCH |  |
| CDM | Domain | Default value | ✅ VALIDATED | DOMAIN_DEFAULT | DOMAIN_DEFAULT (extended_properties) |
| CDM | Domain | Check parameters (low/high/list/format) | ✅ VALIDATED | DOMAIN_CHECK_PARAMS | DOMAIN_CHECK_PARAMS (extended_properties): PD Low/High/List/Format vs erwin Min/Max/Valid_Value_Rule_Ref |
| CDM | Domain | Check parameters (high value changed) | ✅ VALIDATED | DOMAIN_CHECK_PARAMS | DOMAIN_CHECK_PARAMS |
| CDM | Domain | Name | ✅ VALIDATED | DOMAIN_NAME | matched by code → name mismatch not itself compared; here code also carries |
| CDM | Business Rule | Name | ✅ VALIDATED | BUSINESS_NAME |  |
| CDM | Business Rule | Expression | ✅ VALIDATED | BUSINESS_RULE_EXPRESSION |  |
| CDM | Business Rule | Type | ✅ VALIDATED | BUSINESS_RULE_TYPE | BUSINESS_RULE_TYPE (extended_properties) |
| CDM | Business Rule | Definition | ✅ VALIDATED | DEFINITION, DEFINITION_MISMATCH |  |
| CDM | Package | Name | ✅ VALIDATED | SUBJECT_AREA |  |
| CDM | Package | Hierarchy (parent changed) | ✅ VALIDATED | SUBJECT_AREA |  |
| CDM | Package | Hierarchy (parent lost → root) | ❌ NOT VALIDATED | — | PACKAGE_HIERARCHY fires only when the export still carries Parent_Subject_Area somewhere; with one nested package the loss is indistinguishable from an export that never writes parents |
| CDM | Package | Contents (entities) | ✅ VALIDATED | PACKAGE_CONTENTS | PACKAGE_CONTENTS (extended_properties) |
| CDM | Package | Definition | ✅ VALIDATED | PACKAGE_DEFINITION | PACKAGE_DEFINITION (extended_properties) |
| CDM | Diagram | Name | ✅ VALIDATED | DIAGRAM_MISSING | DIAGRAM_MISSING (extended_properties); only when the export carries Stored_Display |
| CDM | Diagram | Symbols displayed | ✅ VALIDATED | DIAGRAM_SYMBOLS | DIAGRAM_SYMBOLS (extended_properties); erwin drawing-object tag names unverified |
| CDM | Model | Name | ✅ VALIDATED | MODEL_METADATA | the EMX:Model name attribute is read first; probe changes both via two anchors below |
| CDM | Model | Definition | ✅ VALIDATED | MODEL_DEFINITION | MODEL_DEFINITION (extended_properties) |
| PDM | Table | Code / physical name | ✅ VALIDATED | DIAGRAM_SYMBOLS, FOREIGN_KEY, TABLE |  |
| PDM | Table | Name (logical) | ✅ VALIDATED | TABLE_LOGICAL_NAME | TABLE_LOGICAL_NAME (extended_properties) |
| PDM | Table | Owner / schema | ✅ VALIDATED | TABLE_OWNER | TABLE_OWNER (extended_properties) |
| PDM | Table | Definition / comment | ❌ NOT VALIDATED | — | documentation sheet only (report-only, unscored) |
| PDM | Table | Tablespace assignment | ✅ VALIDATED | TABLE_TABLESPACE | TABLE_TABLESPACE (extended_properties) |
| PDM | Table | Extended attributes (UDP) | ❌ NOT VALIDATED | — | udp_fidelity component |
| PDM | Column | Code / physical name | ✅ VALIDATED | COLUMN |  |
| PDM | Column | Name (logical) | ✅ VALIDATED | COLUMN_LOGICAL_NAME | COLUMN_LOGICAL_NAME (extended_properties) |
| PDM | Column | Data type | ✅ VALIDATED | DATA_TYPE |  |
| PDM | Column | Length | ✅ VALIDATED | DATA_TYPE |  |
| PDM | Column | Precision | ✅ VALIDATED | DATA_TYPE |  |
| PDM | Column | Nullable flag | ✅ VALIDATED | NULLABILITY |  |
| PDM | Column | Default value | ✅ VALIDATED | DEFAULT |  |
| PDM | Column | Domain binding | ✅ VALIDATED | COLUMN_DOMAIN | COLUMN_DOMAIN (extended_properties) |
| PDM | Column | Check constraint | ✅ VALIDATED | COLUMN_CHECK_CONSTRAINT | COLUMN_CHECK_CONSTRAINT (extended_properties): a rule / min / max must exist on the erwin column |
| PDM | Column | Identity / auto-increment | ✅ VALIDATED | COLUMN_IDENTITY | COLUMN_IDENTITY (extended_properties) |
| PDM | Column | Definition / comment | ❌ NOT VALIDATED | — | documentation sheet only |
| PDM | Key | PK membership | ✅ VALIDATED | PRIMARY_KEY |  |
| PDM | Key | PK name | ✅ VALIDATED | KEY_NAME | KEY_NAME (extended_properties) |
| PDM | Key | AK (unique key) membership | ✅ VALIDATED | INDEX | via index-signature comparison |
| PDM | Key | AK uniqueness flag | ✅ VALIDATED | INDEX | U:/I: signature prefix |
| PDM | Reference | Parent / child table | ✅ VALIDATED | FOREIGN_KEY |  |
| PDM | Reference | Join columns | ✅ VALIDATED | FOREIGN_KEY |  |
| PDM | Reference | Name / constraint name | ✅ VALIDATED | REFERENCE_NAME | REFERENCE_NAME (extended_properties) |
| PDM | Reference | Referential integrity (update) | ✅ VALIDATED | REFERENCE_RI_RULE | REFERENCE_RI_RULE (extended_properties); erwin code map is provisional |
| PDM | Reference | Referential integrity (delete) | ✅ VALIDATED | REFERENCE_RI_RULE | REFERENCE_RI_RULE |
| PDM | Reference | Cardinality / optionality | ✅ VALIDATED | REFERENCE_CARDINALITY | REFERENCE_CARDINALITY (extended_properties): PD Cardinality / ParentMandatory vs erwin Cardinality / Null_Option_Type |
| PDM | Index | Member columns | ✅ VALIDATED | INDEX |  |
| PDM | Index | Unique flag | ✅ VALIDATED | INDEX |  |
| PDM | Index | Name | ✅ VALIDATED | INDEX_NAME | INDEX_NAME (extended_properties) |
| PDM | Index | Column sort order | ✅ VALIDATED | INDEX_SORT_ORDER | INDEX_SORT_ORDER (extended_properties) |
| PDM | View | Code | ✅ VALIDATED | VIEW |  |
| PDM | View | SQL definition | ✅ VALIDATED | VIEW |  |
| PDM | View | Columns | ✅ VALIDATED | VIEW_COLUMNS | VIEW_COLUMNS (extended_properties) |
| PDM | View | Definition / comment | ✅ VALIDATED | VIEW_DEFINITION | VIEW_DEFINITION (extended_properties) |
| PDM | Procedure | Code | ✅ VALIDATED | PROCEDURE |  |
| PDM | Procedure | Body | ✅ VALIDATED | PROCEDURE |  |
| PDM | Procedure | Parameters | ❌ NOT VALIDATED | — | PD parameters not read; erwin has no parameter element parsed |
| PDM | Procedure | Definition / comment | ✅ VALIDATED | PROCEDURE_DEFINITION | PROCEDURE_DEFINITION (extended_properties) |
| PDM | Function | Code | ✅ VALIDATED | PROCEDURE | pooled with procedures |
| PDM | Function | Body | ✅ VALIDATED | PROCEDURE |  |
| PDM | Trigger | Code | ✅ VALIDATED | TRIGGER |  |
| PDM | Trigger | Body (small literal change) | ❌ NOT VALIDATED | — | SQL bodies compared with a >=90% similarity tolerance (compare_sql); a small literal edit passes |
| PDM | Trigger | Body (rewritten) | ✅ VALIDATED | TRIGGER |  |
| PDM | Trigger | Event / timing | ✅ VALIDATED | TRIGGER_EVENT | TRIGGER_EVENT (extended_properties); erwin flag tag names unverified |
| PDM | Trigger | Owning table | ❌ NOT VALIDATED | — | TRIGGER_TABLE (extended_properties): trigger re-parented under another table is flagged — exercised by tests/test_property_coverage.py (multi-line move, not a single-line probe) |
| PDM | Sequence | Code | ✅ VALIDATED | SEQUENCE |  |
| PDM | Sequence | Start value | ✅ VALIDATED | SEQUENCE_PARAMS | SEQUENCE_PARAMS (extended_properties) |
| PDM | Sequence | Increment | ✅ VALIDATED | SEQUENCE_PARAMS | SEQUENCE_PARAMS |
| PDM | Sequence | Min / max | ✅ VALIDATED | SEQUENCE_PARAMS | SEQUENCE_PARAMS; erwin Min_Value / Max_Value tag names unverified |
| PDM | Tablespace | Code | ✅ VALIDATED | TABLESPACE, TABLE_TABLESPACE |  |
| PDM | Domain | Existence | ✅ VALIDATED | DOMAIN_OBJECT | DOMAIN_OBJECT (extended_properties) |
| PDM | Domain | Data type | ✅ VALIDATED | DOMAIN_OBJECT | DOMAIN_OBJECT |
| PDM | Business Rule | Existence / expression | ✅ VALIDATED | BUSINESS_RULE_OBJECT | BUSINESS_RULE_OBJECT (extended_properties) |
| PDM | Default | Existence / value | ✅ VALIDATED | DEFAULT_OBJECT | DEFAULT_OBJECT (extended_properties) |
| PDM | Data Format | Existence | ❌ NOT VALIDATED | — | erwin has no Data Format object — reported as a VERIFIED census row (DATA_FORMAT_NOT_REPRESENTABLE), never scored |
| PDM | Database Target | DBMS | ✅ VALIDATED | DATABASE_TARGET | DATABASE_TARGET (extended_properties) |
| PDM | Database Target | DBMS not set | ✅ VALIDATED | DATABASE_TARGET | DATABASE_TARGET |
| PDM | Diagram | Name / symbols | ✅ VALIDATED | DIAGRAM_MISSING | DIAGRAM_MISSING (extended_properties) |
| PDM | Diagram | Symbols displayed | ✅ VALIDATED | DIAGRAM_SYMBOLS | DIAGRAM_SYMBOLS |
| PDM | Package | Code | ✅ VALIDATED | PACKAGE |  |
| PDM | Package | Contents (tables) | ✅ VALIDATED | PACKAGE_CONTENTS | PACKAGE_CONTENTS (extended_properties) |

161 / 180 probes detected
