# Post-Fix Verification Audit — SAP PowerDesigner → Quest erwin

**Date:** 2026-09-15 · **Scope:** independent second pass over the previous remediation. The previous pass's own results were treated as claims to be checked, not as evidence.

**Verdict: the previous pass was NOT sufficient.** Eight further defects were found, seven of them manufacturing false positives or unverifiable numbers, one of them (§6) presenting a stage that had never run as a measured total loss. All are fixed. Four areas were verified correct and left alone. Nine gaps remain genuinely open and are listed in §11 — none of them has been papered over.

Gate: **589 tests pass** (was 555), 0 failures · ruff **8 findings, all pre-existing** in one vendored standalone script · bandit **4 medium, all pre-existing** · **no new D/E complexity functions**.

---

## 1. Code fabrication in the erwin parsers — CONFIRMED, contained

`_code()` in both `erwin_ldm_parser.py` and `erwin_cdm_parser.py` still ends in `or _name(elem)`.

**It is not a bug, and removing it would be one.** Verified directly against both supplied erwin exports:

| | Physical_Name elements | Name elements |
|---|---|---|
| `modeling_and_simulation` (1_initial + 2_preprocessed) | **0** | 339 |
| `real_estate` (1_initial + 2_preprocessed) | **0** | 877 |

erwin's logical export has no physical-name property at all, so the fallback is not an edge case — it is the only branch that ever fires. A blank code would leave every erwin object unmatchable and turn a clean migration into a report of total loss. What must never happen is treating the derived value as erwin's own.

The five states the brief asked for:

| State | Where it lives |
|---|---|
| `SOURCE_CODE` | `pd_attr.code` from the SAP PD parser |
| `TARGET_CODE` | erwin's code **only when** `_erwin_has_own_code(obj)` is true |
| `TARGET_CODE_NOT_AVAILABLE` | the `CODE_NOT_CARRIED` finding key |
| `TARGET_CODE_DERIVED` | the same predicate, now documented as a contract in both parsers' `_code()` docstrings |
| `EXPECTED_TRANSFORMATION` | the remediation text on every `CODE_NOT_CARRIED` row: *approved mapping, SAP PD Code → PD_Code UDP* |

**Defect found:** the guard existed at ENTITY level on both tiers and at ATTRIBUTE level on **LDM only**. The CDM attribute path emitted `FALLBACK_MATCH` (INFO, 0.05 penalty each) for every attribute whose code differed from its name — charging fidelity once per attribute for one systemic export limitation, and scoring the same source model differently at the two tiers. **Fixed:** `_erwin_has_own_code` added to the CDM comparator with `CODE_NOT_CARRIED` at `SOURCE_PRE_EXISTING`. A test asserts both tiers' predicates now answer identically.

`ADDRESS → ADDRSS` is treated as expected **only** when erwin carries no code of its own *and* the two NAMES agree. If the names differ it is still a `FALLBACK_MATCH` — a possible rename, reported. There is no generic "all code differences are expected" rule.

---

## 2. PD Code preservation — traced end to end

```
PD Code  →  pd_*_parser (a:Code)  →  udp_bridge._append_code_rows  →  PD_Code UDP row
         →  property_manifest.json  →  erwin_load.py injection  →  read-back
         →  udp_evidence (SHA-256 of both files)  →  comparison
         →  CODE_NOT_CARRIED / EXPECTED_TRANSFORMATION
```

Entity-level `PD_Code` works. **Attribute-level does not** — `app/udp_tool/erwin_load.py:359` resolves injection targets by entity name only and cannot address an attribute. This is listed as an open gap (§11), not claimed as working. `real_estate`'s 42 `CODE_NOT_CARRIED` rows are attribute-level and are honestly reported as not yet in erwin.

`sappdmodels/cdm/` and `sappdmodels/pdm/` are **empty** in this checkout, so the CDM and PDM legs of this path are covered by fixtures and probes, not by a real model pair.

---

## 3–4. Primary identifier / PK — all four cases, all three tiers

| Case | LDM | CDM | PDM |
|---|---|---|---|
| **A** PD has PK, erwin lost it → genuine loss | `PRIMARY_IDENTIFIER` **CRITICAL** | `PRIMARY_IDENTIFIER` **CRITICAL** | `PRIMARY_KEY` **CRITICAL** |
| **B** PD lacks PK, erwin has one → unexpected transformation | `UNEXPECTED_TRANSFORMATION` WARNING | `UNEXPECTED_TRANSFORMATION` WARNING | `PRIMARY_KEY_PD_ONLY` INFO |
| **C** neither side → source-pre-existing | `MODEL_QUALITY` @ `SOURCE_PRE_EXISTING` | `MODEL_QUALITY` @ `SOURCE_PRE_EXISTING` | `PRIMARY_KEY_ABSENT_BOTH` @ `SOURCE_PRE_EXISTING` |
| **D** both → matched | `IDENTIFIER_VERIFIED` | `IDENTIFIER_VERIFIED` | `KEY_VERIFIED` |

Case B is a **different finding key** from case A on every tier, so a report grouped by category can tell a fabrication from a loss — they need opposite remedies. Case C is **visible and weighted at zero**; it was not deleted. Before reaching B, both conceptual tiers first test `_identity_is_inherited` and emit `INHERITED_IDENTITY` for a subtype identified by its supertype or an associative entity identified by what it joins — the two tools recording the same fact in different places, not a fabrication.

On `real_estate`, case C accounts for **105 of the 147** non-scoring rows.

---

## 5. PDM parity — was invisible, now explicit

`PRIMARY_KEY_ABSENT_BOTH` used to emit **nothing at all**, so a PDM table with no PK anywhere was indistinguishable in the report from one where PK validation never ran. It now emits at `SOURCE_PRE_EXISTING`: visible, weight zero.

The vocabulary is distinguishable: `KEY_VERIFIED` (matched) · `PRIMARY_KEY` (missing in erwin) · `PRIMARY_KEY_PD_ONLY` (unexpected in erwin) · `PRIMARY_KEY_ABSENT_BOTH` (source pre-existing) · an unmatched table emits `TABLE_MISSING`/`TABLE_EXTRA` before PK comparison is reached, so "not applicable" is never confused with "no PK".

**Two further PDM defects found and fixed:**

* `pdm_documentation._strip_rtf` was the framework's worst RTF handler — see §7. It made **every** RTF-wrapped PDM comment report MISMATCH however perfectly it migrated.
* `_parse_entity_key_groups` was **defined twice** in `pdm_erwin_validator/erwin_parser.py`. The dead first copy unpacked a 2-tuple from a function returning a dict and would have raised `ValueError` the moment the two were reordered. Removed; a test now asserts no shadowed top-level definitions.

---

## 6. A stage that had not run was scored as a measured 0 %

Found by running the two real models, not by reading the code.

```
V2 fidelity 75.00%  (structural=100.00%, documentation=100.00%, udp=0.00%)
stage_state, same run:  UDP = WAITING_FOR_MANUAL_INPUT
```

The score said *measured, everything lost*; the state file said *has not run*. Both cannot be true. `0.5×100 + 0.25×100 + 0.25×0 = 75.00` — a hard 75 % ceiling on every model with UDPs, regardless of how well it migrated.

**Fixed** with a third state, `fidelity_stages.UDP_NOT_MEASURED`, distinct by identity from both `None` ("no override") and `0.0` ("measured, all lost"). It is reached **only** on the recorded fact that the UDP stage has not executed (`stage_state.STAGE_UDP` is `WAITING_FOR_MANUAL_INPUT` or unrecorded). Once the stage has run, whatever it measured stands — including 0 % — so a genuine injection failure is still scored as the loss it is.

| Model | before | after |
|---|---|---|
| `modeling_and_simulation` V2 | 74.61 % (udp=0.00) | **99.48 %** (udp=n/a) |
| `real_estate` V2 | 75.00 % (udp=0.00) | **100.00 %** (udp=n/a) |

This is not an inflation: the components are unchanged, the unmeasurable one is dropped and the remaining weights renormalised, and the stage note says so in the workbook.

---

## 7. RTF normalisation — three implementations that disagreed

The framework had **three** independent RTF strippers, and the two sides of a single comparison were normalised by different ones: the Comment→Note injector writes the erwin side with the LDM tokenizer, while the CDM and PDM comparators stripped the SAP PD side with their own regex chains.

| Input | LDM / injector | CDM (old) | PDM (old) |
|---|---|---|---|
| `Caf\'e9 \'93quoted\'94` | `Café “quoted”` | `Café \x93quoted\x94` | `Caf quoted` |
| `C:\\Users\\x` | `C:\Users\x` | `C:\ and` ← **"Users" and "x" deleted** | `C:\ \ ` |
| `\u8364 ?100` | `€100` | `€ ?100` | `?100` |
| real PD comment with `{\fonttbl}` + `\*\generator` | `Owner: \nAuthor: …` | `Owner: \n\nAuthor: …` | `Times New Roman; \* Riched20 10.0.22000 Owner: …` |

Consequences, none of them migration defects:

* **CDM** decoded `\'xx` as a Unicode *code point* instead of a cp1252 *byte* — so a Word smart quote came out as control character U+0093 while the erwin Note held `“`. Identical text, reported MISMATCH at a depressed similarity.
* **CDM** did not recognise `\\` as an escaped backslash, so the next backslash started a control-word match and **ate the following word** — content deleted from a field that is compared and reported.
* **CDM**'s docstring claimed the function was report-only and changed no validation result. `_description()` calls it directly, so these defects were scoring DEFINITION findings.
* **PDM** left the font table and generator string in the compared text and replaced every `\'xx` with a space, so *every* RTF-wrapped PDM comment mismatched.

**Fixed:** one implementation, `app/common/rtf_text.py` — the tokenizer already verified against the real SAP PD models, moved rather than rewritten. CDM, PDM and the injector delegate to it. A parametrised test asserts all four agree on 8 cases covering `\b \b0 \i \i0 \par \pard`, font tables, `\'xx`, `\uNNNN`, escaped braces and backslashes, picture hex, hyperlink fields and plain text.

Also fixed: the keyword alternation was built from a `set` sorted by length only, so the compiled pattern differed between interpreter runs (verified across three `PYTHONHASHSEED` values). Output was stable; the pattern was not auditable. Sort key pinned.

**Parity findings not changed, with reasons in §11:** CDM has no `definition_field` provenance; the PDM structural comparator reads no table/column definitions; PDM business rules are structurally unvalidated; erwin PDM references carry no cardinality. One CDM ordering defect **was** fixed — `erwin_cdm_parser` ignored `Key_Group_Member_Order`, erwin's actual spelling, which the LDM and PDM parsers read first.

---

## 8. Fidelity formula — pure, no ML anywhere

Full-repo sweep for `regression`, `LinearRegression`, `RandomForest`, `sklearn`, `statsmodels`, `polyfit`, `torch`, `tensorflow`, `prediction`, `historical score`, `training score`: **11 hits, none in scoring code** — doc prose, or pytest "regression test". No ML import exists; `requirements.txt` is `defusedxml, lxml, openpyxl, pytest, pywin32`.

```
comparable = entities + attributes + relationships + identifiers + inheritances   (SAP PD side)
penalty    = critical×1.0 + warning×0.35 + info×0.05
penalty    = min(penalty, comparable × 1.0)
structural = 100 × (1 − penalty / comparable)
overall    = Σ(component × weight) / Σ(weight of MEASURABLE components)
             structural 0.50 · documentation 0.25 · udp 0.25
```

Exempt from the penalty: `VERIFIED`, `SOURCE_PRE_EXISTING`, `IGNORE`. Both clamps (`V1_UDP_BASELINE_WHEN_UNMIGRATED`, `NO_UDP_FIDELITY_CAP`) are `None` — off. `carry_history` copies already-measured stage scores between result objects for reporting only, using `setdefault`, so a carried value never replaces a fresh measurement. Locked by a test.

---

## 9. Scores reconstructed independently — and now reconstructible from the report

| Model | comparable | penalty | structural | reported | verdict |
|---|---|---|---|---|---|
| `modeling_and_simulation` | 18+82+22+19+0 = **141** | 1×1.0 + 0×0.35 + 2×0.05 = **1.10** | **99.22** | 99.22 | AGREES |
| `real_estate` | 105+42+130+0+2 = **279** | **0** | **100.00** | 100.0 | AGREES |

`real_estate` keeps **509 finding rows**, of which **147 are `SOURCE_PRE_EXISTING`** (42 `CODE_NOT_CARRIED` + 105 `MODEL_QUALITY`) and 362 `VERIFIED`. They were reclassified, **not deleted** — that is the entire basis on which the score improved, and a test fails if they ever stop being emitted.

**New:** `SCORE_RECONCILIATION` sheet (`app/reporting/score_audit.py`), now in every V3 workbook. It rebuilds the number from the workbook's own FINDINGS rows and prints:

1. every severity with its weight, and for each non-scoring one **why** it is excluded;
2. the denominator, the penalty terms, the cap, the formula with numbers substituted;
3. recomputed vs reported, with an explicit **AGREES / DISAGREES** verdict;
4. the staged weighted mean written out — `(99.22 × 0.5 + 100.00 × 0.25) / (0.5 + 0.25) = 99.48`;
5. every category, scoring and non-scoring, with a yes/no penalty column.

If scoring logic ever drifts from the rows it claims to summarise, the sheet says so in the deliverable rather than leaving it to be discovered.

---

## 10. True positives survived

`modeling_and_simulation`, after the new normalisation and classification:

* **1 CRITICAL `DATA_TYPE`** — present.
* **2 INFO definition findings** (`DEFINITION_PARTIAL`, `MODEL_DEFINITION`) — present.
* `result.critical_count = 1`, `info_count = 2` — exactly the penalty of 1.10.

Locked by `test_genuine_defects_on_modeling_and_simulation_are_still_reported`. Definition findings also carry field provenance — 95 rows read `[compared SAP PD Comment against erwin Note_List (Notes tab)]`, so a reader can see that a PD Comment was compared against an erwin Note rather than two Definitions.

---

## 11. Model identity — negative test added

`test_swapping_two_models_erwin_exports_is_rejected_not_scored` reconciles each SAP PD model against **the other model's** erwin export and asserts `_same_model` refuses both pairings — with the correctly paired control in the same test, so the guard is shown to be discriminating rather than always-refusing.

Identity is enforced at each hop: XML V1 and XML V3 are refused when they share no entity with the SAP source (`FAILED`, with a next action); stored UDP evidence is refused on model mismatch, on SAP source change (SHA-256), on schema drift and on staleness; a UDP comparison workbook naming entities that exist in no part of this model is ignored rather than scored as 0 %. Reading evidence for a model that has none returns `REJECT_ABSENT`, never 0 %.

---

## 12–13. Flow and manual handoffs

**Verified:** every manual artefact records an explicit `WAITING_FOR_MANUAL_INPUT` with an operator instruction and a fingerprint of where it was looked for. A missing XML V3 is a hard stop — not scored, gate not evaluated. An artefact that exists but is invalid is `FAILED`, deliberately distinct from "not done yet". No silent zero, no silent pass.

**Documentation corrections** (the code is right, the diagram is not): `1_initial/*.xml` is an *input* to `run_v1`, not its output; `run_v1` also writes `2_preprocessed/<model>.xml`, which is what the operator opens in erwin; there is a **V2** stage; the `.erwin` handoff tries erwin COM before falling back to manual; there is **no single combined V1+UDP/V3 number** — combination happens *within* each stage.

**Late finding — the one that mattered most.** `FINAL_XML_FALLBACK_TO_PREPROCESSED` is `"true"` in `app/config/settings.py:62`, while every call site reads it as `get_setting(..., False)` and every docstring calls it off-by-default. The call-site default is dead. So in a stock checkout, with no manual XML V3 present, **V3 was measured against the same preprocessed XML as V2** and the progression sheet captioned that row *"SAP PD vs the FINAL manually validated erwin XML"* — while `stage_state` recorded `V3_XML_EXPORT = WAITING_FOR_MANUAL_INPUT` in the same run.

The value was **not** changed — flipping it would hard-stop a pipeline that is currently producing reports, and that is the operator's decision. What changed is that it cannot be missed:

* `run_v3` prints an explicit `FALLBACK:` line and logs a warning naming the model;
* the V3 row now reads *"FALLBACK — no manually validated erwin XML V3 exists for this model … the V3 number is NOT evidence about the final erwin model"*;
* a delta between stages measured on **different component sets** is labelled *"not directly comparable — different components measured"*, because part of such a change comes from weight renormalisation rather than from the migration. `modeling_and_simulation`'s V1 → V2 jump of +58.53 is flagged: V1 scores a UDP component, V2 drops it.

To get a real V3: export the enriched `.erwin` from erwin as XML into `final_xml_models/<tier>/<model>.xml`. To make a missing one a hard stop: `FINAL_XML_FALLBACK_TO_PREPROCESSED=false`.

---

## Still open — not fixed, not hidden

Full detail in `COVERAGE_MATRIX.md` §8.4.

1. **Description → erwin `<Definition>` injection.** `modeling_and_simulation`'s export carries 2 erwin-authored `<Definition>` elements (model level and one entity); `real_estate`'s carries 0. Not enough to derive the format for attributes, relationships or domains. Writing it blind would be inventing erwin's format.
2. **Attribute-level `PD_Code`.** `erwin_load.py:359` resolves targets by entity name only. Fixing it means either a code-preservation ledger or modifying `app/udp_tool` — a Windows-only COM path that cannot be tested here, against a stated invariant. Your call which.
3. **CDM lacks `definition_field` provenance** that LDM has. No CDM sample model exists here to verify a change against.
4. **PDM structural comparator reads no table/column definitions**; PDM documentation is covered only by its separate sheet. PDM comments parsed at `pd_parser.py:117` have no consumer at all.
5. **PDM business rules are structurally unvalidated** — neither PDM parser reads `o:BusinessRule` / `Validation_Rule`.
6. **erwin PDM references carry no cardinality or identifying flag.** No PDM erwin sample here to confirm the properties exist to read.
7. **28 `UNVERIFIED_ERWIN_TAGS`** — a spelling mismatch makes a check silently not fire rather than report.
8. **LDM does not apply CDM's `Is_Unique=false` inversion-entry rule.** Adding it would suppress findings, and neither export carries `Is_Unique`, so it could not be verified against real data. Documented rather than applied.
9. **`sappdmodels/cdm/` and `sappdmodels/pdm/` are empty.** Every CDM and PDM row in the coverage matrix rests on synthetic fixtures. **The CDM/LDM/PDM × Simple/Medium/Complex grid is complete only for LDM** — the two real models are both LDM. Closing this needs one real CDM pair and one real PDM pair.
