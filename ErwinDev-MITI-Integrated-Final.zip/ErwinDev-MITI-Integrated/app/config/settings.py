import os
from pathlib import Path

# Base directory of the project
BASE_DIR = Path(__file__).resolve().parent.parent.parent


def _env(name: str, default):
    """Environment override for any path/threshold, so nothing is hard-coded."""
    raw = os.environ.get(name)
    return raw if raw not in (None, "") else default


# ─── INPUT / OUTPUT DIRECTORIES ───────────────────────────────────────────────
# Every path below is relative to BASE_DIR unless it is absolute, and every one
# can be overridden from the environment. A 100+ model batch can therefore be
# pointed at a different drive without editing a single line of code.

SAMPLES_DIR = _env("SAP_PD_MODELS_DIR", os.path.join(BASE_DIR, "sappdmodels"))
OUTPUT_DIR = _env("ERWIN_MODELS_DIR", os.path.join(BASE_DIR, "erwinmodels"))

# Output Subdirectories (kept for backwards compatibility with existing callers)
JSON_OUT_DIR = os.path.join(OUTPUT_DIR, "json")
ERWIN_OUT_DIR = os.path.join(OUTPUT_DIR, "erwin")
XML_OUT_DIR = os.path.join(OUTPUT_DIR, "xml")
REPORTS_OUT_DIR = os.path.join(OUTPUT_DIR, "reports")
LOGS_OUT_DIR = os.path.join(OUTPUT_DIR, "logs")

# ─── THE V3 FRAMEWORK'S TWO INPUT PATHS ───────────────────────────────────────
# The V3 reconciliation compares each SAP PD model against its FINAL, manually
# validated erwin XML export. Those two paths are the only inputs V3 needs:
#
#   1. SAP_PD_MODELS_DIR   sappdmodels/{cdm,ldm,pdm}   (.cdm / .ldm / .pdm)
#   2. FINAL_XML_DIR       the Final XML Models folder
#
# FINAL_XML_DIR is populated by hand (the manual erwin export/validation step)
# and is deliberately NOT erwinmodels/3_final/xml: that folder is a pipeline
# OUTPUT written by the promotion gate, so reading V3 inputs from it would make
# the gate feed itself.
#
# Sub-folders are searched too, so either layout works at scale:
#     final_xml_models/<model>.xml
#     final_xml_models/{cdm,ldm,pdm}/<model>.xml
FINAL_XML_DIR = _env("FINAL_XML_DIR", os.path.join(BASE_DIR, "final_xml_models"))

# Extensions accepted in FINAL_XML_DIR, in preference order.
FINAL_XML_EXTENSIONS = (".xml",)

# Optional model -> final-XML-filename map for estates where the export is not
# named after the source model. JSON ({"<model>": "<file>"}) or a two-column
# CSV. Empty = resolve by name.
FINAL_XML_MAP = _env("FINAL_XML_MAP", "")

# When a model has no separately exported final erwin XML, V3 is measured
# against the commented XML in erwinmodels/2_preprocessed.
#
# OFF by default, and deliberately so. It used to default to "true" while every
# call site read it as get_setting(..., False) and every docstring called it
# off-by-default, so a stock checkout silently measured V3 against the SAME
# artefact as V2 and the report captioned that row "SAP PD vs the FINAL manually
# validated erwin XML" — while stage_state recorded V3_XML_EXPORT as
# WAITING_FOR_MANUAL_INPUT in the same run. A number presented as final
# validation that was never measured against the final model is the worst thing
# this framework can produce, so the default is now the safe one: a missing
# final export is a HARD STOP and the model is recorded as waiting.
#
# Turning it on is legitimate for a dry run, and is then loud rather than
# silent: run_v3 prints a FALLBACK line, the artefact map records
# "fallback (commented XML)", the FIDELITY_PROGRESSION row says the V3 number is
# NOT evidence about the final erwin model, and the model is NOT promoted to
# 3_final however high it scores.
FINAL_XML_FALLBACK_TO_PREPROCESSED = _env("FINAL_XML_FALLBACK_TO_PREPROCESSED", "false").lower() in ("true", "1", "yes")

# ─── STAGE ARTEFACT LAYOUT ────────────────────────────────────────────────────
# The two erwin-side conversions are AUTOMATED when erwin COM is on the host
# and fall back to a guided manual hand-off when it is not (see
# app/erwin/erwin_handoff.py). The stage folders are FLAT (no xml/ erwin/
# sub-folders):
#
#   XML V1     erwin's export of the imported model        erwinmodels/1_initial/<m>.xml          MANUAL
#   XML V2     Step 1: PD comments injected as Notes       erwinmodels/2_preprocessed/<m>.xml     run_v1.py
#   .ERWIN V1  the .erwin made from XML V2                 app/udp_tool/input_erwin_models/<m>.erwin  AUTO | MANUAL
#   .ERWIN V2  Step 2: UDPs injected (erwin COM, Windows)  erwinmodels/2_preprocessed/<m>.erwin   run_udp.py
#   XML V3     erwin's export of .ERWIN V2                 final_xml_models/<cdm|ldm|pdm>/<m>.xml AUTO | MANUAL
#   .ERWIN V3  the gate's PASS output (+ <m>.xml)          erwinmodels/3_final/<m>.erwin          run_v3.py
#
# READ THE FOLDER NAMES AS PHASES, NOT AS FILE TYPES. 2_preprocessed/ holds
# BOTH of the enrichment artefacts, which is why the rows above never name a
# stage by its folder alone:
#
#   erwinmodels/2_preprocessed/<m>.xml     = XML V2     Step 1 OUTPUT, Step 2 INPUT
#   erwinmodels/2_preprocessed/<m>.erwin   = .ERWIN V2  Step 2 OUTPUT
#
# The extension is the discriminator. .ERWIN V1 — the un-enriched binary Step 2
# consumes — deliberately lives in the UDP tool's own input folder instead, so
# that an input can never be confused with, or overwritten by, an output.
# Say "XML V2" and ".ERWIN V2"; never "the preprocessed model", which is
# ambiguous between the two.
#
# app/orchestration/stage_paths.py owns this mapping. LEGACY_STAGE_FALLBACK
# additionally searches the folders older layouts used (1_initial/xml,
# 2_preprocessed/erwin, the retired six-folder 1_xml_v1 … 6_erwin_v3 names)
# when an INPUT artefact is not in its flat folder, so runs laid out the old
# way still resolve. STAGE_FOLDERS is kept only for that legacy search.
#
# ─── CANONICAL FOLDER NAMES ───────────────────────────────────────────────────
# The three flat stage folder names and the two top-level model folder names are
# defined ONCE, here. They used to be re-declared as literals in
# stage_paths.py, pdm_flow.py, model_record.py, migration_audit.py and
# promote_model.py; five copies of the same string is five chances for a rename
# to be applied in four places. Every one of those modules now derives its own
# constant from these, keeping its existing public name as an alias, so callers
# and tests are unaffected. Defaults are exactly the values those literals had.
#
# ⚠️ TWO FILES OUTSIDE PYTHON ALSO SPELL THESE NAMES OUT and cannot read settings:
#       .gitignore                 !erwinmodels/1_initial/ … !erwinmodels/3_final/
#       sonar-project.properties   sonar.exclusions=…,erwinmodels/**,sappdmodels/**,…
# Overriding a stage folder name therefore needs a matching hand-edit in both, or the
# renamed folder is committed to git and scanned by SonarQube. There is no way to make
# those two read from here; keeping the list short and documented is the mitigation.
STAGE_INITIAL_DIRNAME = _env("STAGE_INITIAL_DIR", "1_initial")
STAGE_PREPROCESSED_DIRNAME = _env("STAGE_PREPROCESSED_DIR", "2_preprocessed")
STAGE_FINAL_DIRNAME = _env("STAGE_FINAL_DIR", "3_final")

ERWIN_MODELS_DIRNAME = _env("ERWIN_MODELS_DIRNAME", "erwinmodels")
SAP_PD_MODELS_DIRNAME = _env("SAP_PD_MODELS_DIRNAME", "sappdmodels")
MANUAL_REVIEW_REPORTS_DIRNAME = _env("MANUAL_REVIEW_REPORTS_DIRNAME", "manual_review_reports")

STAGE_FOLDERS = {
    "xml_v1":   _env("STAGE_XML_V1_DIR",   "1_xml_v1"),
    "xml_v2":   _env("STAGE_XML_V2_DIR",   "2_xml_v2"),
    "erwin_v1": _env("STAGE_ERWIN_V1_DIR", "3_erwin_v1"),
    "erwin_v2": _env("STAGE_ERWIN_V2_DIR", "4_erwin_v2"),
    "xml_v3":   _env("STAGE_XML_V3_DIR",   "5_xml_v3"),
    "erwin_v3": _env("STAGE_ERWIN_V3_DIR", "6_erwin_v3"),
}
LEGACY_STAGE_FALLBACK = _env("LEGACY_STAGE_FALLBACK", "true").lower() in ("true", "1", "yes")

# ─── POWERDESIGNER REPOSITORY EXTRACTION ID ───────────────────────────────────
# The last-resort default used when a model's own header does not carry an
# ExtractionId and sow_classify recorded none. It is only ever a fallback: the
# real header value wins wherever it is known, because PD_SourceExtraction
# exists to prove provenance. Previously declared three times independently
# (validation_config.UDP_TOOL_EXTRACTION_ID, erwin_prepare.LEGACY_EXTRACTION_ID,
# udp_flow.DEFAULT_EXTRACTION_ID); all three now resolve to this one value.
UDP_EXTRACTION_ID = _env("UDP_EXTRACTION_ID", "46603045")

# ─── ERWIN CONVERSIONS ────────────────────────────────────────────────────────
# app/erwin/erwin_converter.py drives erwin's SCAPI (Windows + erwin Data
# Modeler + pywin32 + an open erwin window) to convert XML <-> .erwin, and
# app/erwin/erwin_handoff.py is the gate Step 2 goes through to obtain
# .ERWIN V1 and .ERWIN V2.
#
# ON by default. On a host WITHOUT erwin COM this setting changes nothing —
# the gate finds no COM, says so, and falls through to the manual path — so
# leaving it on costs a host without erwin exactly one importlib check and
# gives a host WITH erwin the whole Step 2 conversion for free. It was off
# while no caller existed; run_udp.py stopping at EXTRACTED with no output
# file is what that default cost.
#
# Set false to force the manual hand-off even on a Windows erwin workstation
# (useful when an operator wants to control what erwin opens).
ERWIN_CONVERT_ENABLED = _env("ERWIN_CONVERT_ENABLED", "true").lower() in ("true", "1", "yes")
ERWIN_CONVERT_TIMEOUT_SECONDS = int(_env("ERWIN_CONVERT_TIMEOUT_SECONDS", 900))

# When erwin COM is NOT available and a person is at the terminal, the hand-off
# gate prints what to make, writes the same text beside the target as a
# <model>.<artefact>.HOWTO.txt file, and waits at a prompt until they confirm.
# It never prompts from a worker thread, a redirected stdin or a scheduled run;
# those poll for MANUAL_EXPORT_WAIT_SECONDS instead and then record WAITING.
ERWIN_MANUAL_PROMPT_ENABLED = _env("ERWIN_MANUAL_PROMPT_ENABLED", "true").lower() in ("true", "1", "yes")
ERWIN_MANUAL_PROMPT_ATTEMPTS = int(_env("ERWIN_MANUAL_PROMPT_ATTEMPTS", 10))

# Accept a hand-made artefact saved under the SHORT model name (real_estate)
# rather than the pipeline key (<hash>_<extraction id>_real_estate). Resolving
# one is always logged as a warning, because two extracts of the same model
# share a short name. Set false to require the exact spelling.
SHORT_NAME_HANDOFF_FALLBACK = _env("SHORT_NAME_HANDOFF_FALLBACK", "true").lower() in ("true", "1", "yes")

# ─── PIPELINE LEDGER ──────────────────────────────────────────────────────────
# One JSON line per model per run, appended under batch_summary/audit/, so
# the artefact lineage (which XML V3 was scored, where .ERWIN V3 went) is
# recorded by the pipeline itself rather than only by the standalone audit.
PIPELINE_LEDGER_ENABLED = _env("PIPELINE_LEDGER_ENABLED", "true").lower() in ("true", "1", "yes")
PIPELINE_LEDGER_FILENAME = "pipeline_ledger.jsonl"

# General Settings
LOG_LEVEL = _env("LOG_LEVEL", "WARNING")

# ─── PROMOTION GATE (shared by CDM, LDM and PDM) ──────────────────────────────
# A model is promoted to erwinmodels/3_final only at or above this MEASURED
# fidelity. Below it, the model and its final report are routed to that model's
# own app/reporting/<tier>_reports/<model>/manual_review_report folder.
PROMOTION_FIDELITY_THRESHOLD = float(_env("PROMOTION_FIDELITY_THRESHOLD", 90.0))

# Which number the gate tests.
#   "overall"     result.fidelity_score - the V3 staged score (default)
#   "structural"  result.structural_fidelity_score - reconciliation only
PROMOTION_FIDELITY_BASIS = "overall"

# How many bands the gate uses.
#   "two"   (default)  fidelity >= threshold -> PASS -> erwinmodels/3_final
#                      fidelity <  threshold -> FAIL -> manual_review_report
#   "three"            PASS / WARN (held in 2_preprocessed) / FAIL, using
#                      REVIEW_FIDELITY_FLOOR below.
PROMOTION_BANDS = "two"

# Where a sub-threshold model is routed when no per-model folder is supplied.
MANUAL_REVIEW_DIR = "manual_review"

# Honoured only when PROMOTION_BANDS = "three".
REVIEW_FIDELITY_FLOOR = 60.0
REJECTED_SUBDIR = "rejected"          # relative to erwinmodels/2_preprocessed

# Block promotion outright on any CRITICAL / WARNING finding, independently of
# the fidelity score.
PROMOTION_BLOCK_ON_CRITICAL = False
PROMOTION_BLOCK_ON_WARNING = False

# ─── BATCH SCALE ──────────────────────────────────────────────────────────────
# Each model's three reports are written as soon as that model finishes, and the
# heavy objects it held (findings, parsed models, documentation rows) are then
# released. Only a lightweight summary row per model is kept for
# Pass_Fail_Summary.xlsx, so a 100+ model batch does not grow without bound.
RELEASE_RESULTS_AFTER_REPORTING = True

# Process at most this many models in one run (0 = no limit). Useful for
# smoke-testing a large estate before committing to the full batch.
MAX_MODELS_PER_RUN = int(_env("MAX_MODELS_PER_RUN", 0))

# ─── MODEL COMPLEXITY ─────────────────────────────────────────────────────────
# Simple / Medium / Complex is a label for reporting and triage only; every
# model receives the same validation regardless. Classified from the SAP PD
# side's own object counts (entities/tables, attributes/columns, relationships)
# — the thresholds below are inclusive upper bounds for SIMPLE and MEDIUM.
COMPLEXITY_SIMPLE_MAX_OBJECTS = int(_env("COMPLEXITY_SIMPLE_MAX_OBJECTS", 25))       # entities or tables
COMPLEXITY_SIMPLE_MAX_MEMBERS = int(_env("COMPLEXITY_SIMPLE_MAX_MEMBERS", 200))      # attributes or columns
COMPLEXITY_MEDIUM_MAX_OBJECTS = int(_env("COMPLEXITY_MEDIUM_MAX_OBJECTS", 100))
COMPLEXITY_MEDIUM_MAX_MEMBERS = int(_env("COMPLEXITY_MEDIUM_MAX_MEMBERS", 1000))

# Number of parallel worker threads for multi-model migration (1 = sequential, >1 = multithreaded)
MAX_WORKERS = int(_env("MAX_WORKERS", 4))

# Stall watchdog for the threaded batch. When no model has finished for this
# many seconds the runner logs every worker's stack (where it is waiting: erwin
# COM, a subprocess, a lock) and keeps waiting; with BATCH_ABORT_ON_STALL the
# run stops instead, so a wedged erwin session cannot pin a scheduled job.
# 0 disables the watchdog.
BATCH_STALL_TIMEOUT_SECONDS = float(_env("BATCH_STALL_TIMEOUT_SECONDS", 1800))
BATCH_ABORT_ON_STALL = _env("BATCH_ABORT_ON_STALL", "false").lower() in ("true", "1", "yes")

# Mirror every discovered SAP PD model into app/udp_tool/input_erwin_models/{cdm,ldm,pdm}.
MIRROR_MODELS_TO_UDP_INPUT = _env("MIRROR_MODELS_TO_UDP_INPUT", "true").lower() in ("true", "1", "yes")

# Seconds to poll for a manually produced erwin XML export before giving up on
# a model (0 = one-shot check, current/default behaviour — no waiting).
# Opt in with MANUAL_EXPORT_WAIT_SECONDS so an operator can start main.py,
# then perform the manual erwin exports while the batch is running.
MANUAL_EXPORT_WAIT_SECONDS = int(_env("MANUAL_EXPORT_WAIT_SECONDS", 0))
MANUAL_EXPORT_POLL_INTERVAL_SECONDS = float(_env("MANUAL_EXPORT_POLL_INTERVAL_SECONDS", 5.0))

# ─── PDM PIPELINE ─────────────────────────────────────────────────────────────
# A PDM is only promoted to 3_final at (or above) this measured fidelity.
# Tied to the shared promotion threshold above.
PDM_FIDELITY_TARGET = PROMOTION_FIDELITY_THRESHOLD

# Run the PowerDesigner-driven remediation (missing columns / PK members /
# FK joins) when the first validation pass falls short of the target.
PDM_PREPROCESS_ENABLED = True

# After a successful promotion, keep a copy in 2_preprocessed as well
# (False = move the remediated files to 3_final).
PDM_KEEP_PREPROCESSED_COPY = False

# Filename of the PDM Excel workbook under app/reporting/pdm_reports/.
PDM_REPORT_FILENAME = "pdm_validation_report.xlsx"

# ─── MULTI-USER / SESSION ISOLATION ────────────────────────────────────────────
# With isolation on, EVERY output of a run (stage artefacts, reports, UDP
# workdirs, batch summary, ledger) lands under one folder:
#
#     <SESSIONS_DIR>/<user>_<YYYYMMDD_HHMMSS>_<uuid8>/
#
# so several people — or several scheduled jobs — can run the same checkout
# concurrently without touching each other's files. Inputs stay shared:
# sappdmodels/, final_xml_models/ and the shared erwinmodels/ stage folders
# (an isolated run still finds XML V1 / .erwin exports dropped there by hand).
# See app/orchestration/run_context.py; the CLI flags --isolate / --no-isolate,
# --user and --session-id override these settings per run.
#
# Off by default so a single-user checkout keeps its deterministic layout.
ENABLE_SESSION_ISOLATION = _env("ENABLE_SESSION_ISOLATION", "false").lower() in ("true", "1", "yes")
SESSIONS_DIR = _env("SESSIONS_DIR", os.path.join(BASE_DIR, "sessions"))

# How long a blocked writer waits between non-blocking lock attempts. Only the
# retry cadence; the overall wait is still bounded by each caller's timeout.
FILE_LOCK_POLL_INTERVAL_SECONDS = float(_env("FILE_LOCK_POLL_INTERVAL_SECONDS", 0.05))

# Optional: Force a specific session ID instead of generating one.
# Leave empty to auto-generate. Format: timestamp_uuid (e.g., 20250912_143022_a1b2c3d4)
FORCE_SESSION_ID = _env("FORCE_SESSION_ID", "")

# Optional: Force a specific username instead of detecting one.
# Leave empty to detect current user automatically.
FORCE_USERNAME = _env("FORCE_USERNAME", "")

# ─── MIT BRIDGE INTEGRATION ──────────────────────────────────────────────────
# Optional integration with erwin's MIT Bridge SAP PowerDesigner import tool.
# MIT Bridge becomes an optional upstream layer when licensed, feeding its
# output into the existing validation pipeline. All existing functionality
# is preserved; MIT Bridge is advisory, not a blocker.
#
# MIT Bridge output is audited against the original PD source for:
#   - File integrity (SHA-256 hashes for lineage)
#   - Preservation metrics (comments, UDPs, entities, relationships)
#   - Issues and warnings
#   - Verdict (PASS/WARN/FAIL)
#
# Configuration:
#   MITI_BRIDGE_LICENSED         Enable MIT Bridge (requires license + Windows erwin)
#   MITI_BRIDGE_AUTO_IMPORT      Automatically invoke MIT Bridge import
#   MITI_BRIDGE_OUTPUT_FORMAT    "xml" or "erwin" (default: "xml")
#   MITI_BRIDGE_TIMEOUT_SECONDS  Per-model timeout (default: 300)
#   MITI_BRIDGE_AUDIT_REPORTS    Generate comparison reports (default: True)
#
# When disabled (default), the pipeline works exactly as before, expecting
# manual erwin exports. When enabled, MIT Bridge output feeds into the
# existing comment injection, UDP enrichment, and reconciliation pipeline.
# Nothing is lost; everything is preserved.

MITI_BRIDGE_LICENSED = _env("MITI_BRIDGE_LICENSED", "false").lower() in ("true", "1", "yes")
MITI_BRIDGE_AUTO_IMPORT = _env("MITI_BRIDGE_AUTO_IMPORT", "true").lower() in ("true", "1", "yes")
MITI_BRIDGE_OUTPUT_FORMAT = _env("MITI_BRIDGE_OUTPUT_FORMAT", "xml")
MITI_BRIDGE_TIMEOUT_SECONDS = int(_env("MITI_BRIDGE_TIMEOUT_SECONDS", 300))
MITI_BRIDGE_AUDIT_REPORTS = _env("MITI_BRIDGE_AUDIT_REPORTS", "true").lower() in ("true", "1", "yes")
