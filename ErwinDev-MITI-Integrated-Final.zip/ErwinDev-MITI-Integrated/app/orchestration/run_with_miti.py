"""
MIT Bridge Orchestration - Workflow Management for Optional MIT Bridge Integration

Orchestrates MIT Bridge import workflow when licensed. Handles license checking,
batch model discovery, audit orchestration, and JSON report generation. Works
seamlessly with or without MIT Bridge license for backward compatibility.
"""

import json
import logging
import os
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import List, Dict, Optional, Any

from app.validation.miti_bridge_auditor import MitiAuditResult, audit_miti_import

logger = logging.getLogger(__name__)


@dataclass
class MitiBridgeContext:
    """State container for MIT Bridge migration run."""

    licensed: bool
    auto_import: bool
    output_format: str
    timeout_seconds: int
    audit_results: List[MitiAuditResult] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)

    def summary(self) -> Dict[str, Any]:
        """Return summary of audit results."""
        return {
            "total_models": len(self.audit_results),
            "passed": sum(1 for r in self.audit_results if r.verdict == "PASS"),
            "warned": sum(1 for r in self.audit_results if r.verdict == "WARN"),
            "failed": sum(1 for r in self.audit_results if r.verdict == "FAIL"),
            "errors": len(self.errors),
        }


def check_miti_availability() -> bool:
    """Check if MIT Bridge is available on this system."""
    try:
        # Try to import pywin32 (required for COM)
        import win32com.client  # noqa: F401
        logger.info("MIT Bridge: pywin32 available, COM invocation possible")
        return True
    except ImportError:
        logger.warning("MIT Bridge: pywin32 not available, COM invocation not possible")
        return False


def invoke_miti_bridge(
    pd_model_path: str,
    output_dir: str,
    output_format: str = "xml",
    timeout_seconds: int = 300,
) -> Optional[str]:
    """
    Invoke MIT Bridge COM interface to import SAP PD model.

    Note: This is stubbed pending implementation with win32com.client.
    A real implementation would:
    1. Create erwin COM object
    2. Invoke MITI Bridge import function
    3. Write output to specified location
    4. Return path to generated file

    Args:
        pd_model_path: Path to SAP PowerDesigner model
        output_dir: Directory to write output
        output_format: "xml" or "erwin"
        timeout_seconds: Timeout for import operation

    Returns:
        Path to generated output file, or None if import failed
    """
    logger.info(f"MIT Bridge: Importing {pd_model_path}")
    logger.warning("MIT Bridge: invoke_miti_bridge() is stubbed pending implementation")

    # Stub implementation
    # In production, this would:
    # - Instantiate erwin COM object
    # - Call MITI Bridge import
    # - Poll for completion within timeout
    # - Return output path

    return None  # Placeholder


def run_miti_migration(
    pd_source_dir: str,
    output_dir: str,
    miti_config: Optional[Dict[str, Any]] = None,
) -> MitiBridgeContext:
    """
    Orchestrate MIT Bridge migration workflow for a batch of models.

    Args:
        pd_source_dir: Directory containing SAP PD models
        output_dir: Directory for MIT Bridge output
        miti_config: Configuration dict with keys:
            - licensed (bool): Is MIT Bridge licensed?
            - auto_import (bool): Auto-invoke for import?
            - output_format (str): "xml" or "erwin"
            - timeout_seconds (int): Per-model timeout

    Returns:
        MitiBridgeContext with audit results
    """
    if miti_config is None:
        miti_config = {}

    context = MitiBridgeContext(
        licensed=miti_config.get("licensed", False),
        auto_import=miti_config.get("auto_import", False),
        output_format=miti_config.get("output_format", "xml"),
        timeout_seconds=miti_config.get("timeout_seconds", 300),
    )

    logger.info(f"MIT Bridge orchestration starting (licensed={context.licensed})")

    if not context.licensed:
        logger.info("MIT Bridge: Not licensed; skipping import orchestration")
        return context

    # Verify COM availability if auto-import is enabled
    if context.auto_import and not check_miti_availability():
        context.errors.append("MIT Bridge licensed but COM not available")
        logger.warning("MIT Bridge: Auto-import requested but COM unavailable")
        return context

    # Discover models
    models = _discover_models(pd_source_dir)
    logger.info(f"MIT Bridge: Discovered {len(models)} model(s)")

    # Import each model
    for model_path in models:
        try:
            model_name = Path(model_path).stem
            model_type = Path(model_path).suffix.upper().lstrip(".")

            if context.auto_import:
                # Invoke MIT Bridge import
                output_path = invoke_miti_bridge(
                    model_path,
                    output_dir,
                    context.output_format,
                    context.timeout_seconds,
                )
            else:
                # Look for pre-imported XML
                output_path = _find_preimported_output(model_name, output_dir)

            if not output_path:
                logger.warning(f"MIT Bridge: No output found for {model_name}")
                context.errors.append(f"No output for {model_name}")
                continue

            # Audit the import
            result = audit_miti_import(
                model_path,
                output_path,
                model_name,
                model_type,
            )
            context.audit_results.append(result)

        except Exception as e:
            logger.error(f"MIT Bridge: Error processing {model_path}: {e}")
            context.errors.append(str(e))

    logger.info(f"MIT Bridge orchestration complete: {context.summary()}")
    return context


def write_audit_report(
    context: MitiBridgeContext,
    output_path: str,
) -> None:
    """Write batch audit report to JSON file."""
    report = {
        "audit_timestamp": _timestamp_now(),
        "miti_config": {
            "licensed": context.licensed,
            "auto_import": context.auto_import,
            "output_format": context.output_format,
            "timeout_seconds": context.timeout_seconds,
        },
        "results": [asdict(r) if isinstance(r, MitiAuditResult) else r.to_dict()
                   for r in context.audit_results],
        "summary": context.summary(),
    }

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, "w") as f:
        json.dump(report, f, indent=2)

    logger.info(f"Audit report written to {output_path}")


def _discover_models(root_dir: str) -> List[str]:
    """Discover all SAP PD models under a directory."""
    models = []
    extensions = (".ldm", ".cdm", ".pdm")

    for root, dirs, files in os.walk(root_dir):
        for filename in files:
            if filename.lower().endswith(extensions):
                models.append(os.path.join(root, filename))

    return sorted(models)


def _find_preimported_output(model_name: str, output_dir: str) -> Optional[str]:
    """Find pre-imported XML output for a model."""
    output_file = os.path.join(output_dir, f"{model_name}.xml")
    if os.path.exists(output_file):
        return output_file
    return None


def _timestamp_now() -> str:
    """Return current timestamp in ISO format."""
    from datetime import datetime
    return datetime.utcnow().isoformat() + "Z"
