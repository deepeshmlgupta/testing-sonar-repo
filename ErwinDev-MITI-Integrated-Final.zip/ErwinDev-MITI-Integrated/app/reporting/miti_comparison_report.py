"""
MIT Bridge Comparison Reports - Side-by-Side Analysis of SAP PD vs MIT Bridge Output

Generates per-model and batch comparison reports in Excel and JSON formats,
showing preservation metrics with color-coding and issue/warning extraction.
"""

import json
import logging
import os
from dataclasses import dataclass
from pathlib import Path
from typing import List, Dict, Optional, Any

from app.validation.miti_bridge_auditor import MitiAuditResult

logger = logging.getLogger(__name__)


@dataclass
class MitiComparisonReport:
    """Per-model comparison report."""

    model_name: str
    model_type: str
    audit_result: MitiAuditResult

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "model_name": self.model_name,
            "model_type": self.model_type,
            "audit": self.audit_result.to_dict(),
        }

    def to_json(self, output_path: str) -> None:
        """Write to JSON file."""
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        with open(output_path, "w") as f:
            json.dump(self.to_dict(), f, indent=2)
        logger.info(f"JSON report written: {output_path}")

    def to_excel(self, output_path: str) -> None:
        """
        Write to Excel workbook with color-coded metrics.

        Requires openpyxl. If not available, logs warning and skips.
        """
        try:
            import openpyxl
            from openpyxl.styles import PatternFill, Font, Alignment
        except ImportError:
            logger.warning("openpyxl not available; skipping Excel report")
            return

        # Create workbook
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Comparison"

        # Header
        ws["A1"] = f"MIT Bridge Comparison Report - {self.model_name}"
        ws["A1"].font = Font(size=14, bold=True)

        # Metadata
        ws["A3"] = "Model Name:"
        ws["B3"] = self.model_name
        ws["A4"] = "Model Type:"
        ws["B4"] = self.model_type
        ws["A5"] = "Verdict:"
        ws["B5"] = self.audit_result.verdict
        ws["B5"].font = Font(bold=True, color="FFFFFF")

        # Apply verdict color
        verdict_color = self._verdict_color(self.audit_result.verdict)
        ws["B5"].fill = PatternFill(start_color=verdict_color, end_color=verdict_color, fill_type="solid")

        # Metrics table
        ws["A7"] = "Metric"
        ws["B7"] = "PD Count"
        ws["C7"] = "Erwin Count"
        ws["D7"] = "Preservation %"
        ws["E7"] = "Status"

        metrics = [
            ("Comments", self.audit_result.comment_count_pd, self.audit_result.comment_count_erwin,
             self.audit_result.comment_preservation_pct, 95.0),
            ("UDPs", self.audit_result.udp_count_pd, self.audit_result.udp_count_erwin,
             self.audit_result.udp_preservation_pct, 95.0),
            ("Entities", self.audit_result.entity_count_pd, self.audit_result.entity_count_erwin,
             self.audit_result.entity_preservation_pct, 99.0),
            ("Relationships", self.audit_result.relationship_count_pd, self.audit_result.relationship_count_erwin,
             self.audit_result.relationship_preservation_pct, 99.0),
        ]

        row = 8
        for name, pd_count, erwin_count, pct, threshold in metrics:
            ws[f"A{row}"] = name
            ws[f"B{row}"] = pd_count
            ws[f"C{row}"] = erwin_count
            ws[f"D{row}"] = f"{pct:.1f}%"

            status = "✓ PASS" if pct >= threshold else "✗ LOW"
            ws[f"E{row}"] = status

            # Color code
            status_color = "00B050" if pct >= threshold else "FF0000"  # Green or Red
            ws[f"E{row}"].fill = PatternFill(start_color=status_color, end_color=status_color, fill_type="solid")
            ws[f"E{row}"].font = Font(color="FFFFFF")

            row += 1

        # Issues and warnings
        if self.audit_result.issues or self.audit_result.warnings:
            ws[f"A{row + 1}"] = "Issues & Warnings"
            ws[f"A{row + 1}"].font = Font(bold=True)
            row += 2

            for issue in self.audit_result.issues:
                ws[f"A{row}"] = "⚠ ISSUE"
                ws[f"B{row}"] = issue
                ws[f"A{row}"].fill = PatternFill(start_color="FF0000", end_color="FF0000", fill_type="solid")
                ws[f"A{row}"].font = Font(color="FFFFFF")
                row += 1

            for warning in self.audit_result.warnings:
                ws[f"A{row}"] = "! WARNING"
                ws[f"B{row}"] = warning
                ws[f"A{row}"].fill = PatternFill(start_color="FFC000", end_color="FFC000", fill_type="solid")
                ws[f"A{row}"].font = Font(color="FFFFFF")
                row += 1

        # Auto-width columns
        ws.column_dimensions["A"].width = 20
        ws.column_dimensions["B"].width = 15
        ws.column_dimensions["C"].width = 15
        ws.column_dimensions["D"].width = 15
        ws.column_dimensions["E"].width = 15

        # Save
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        wb.save(output_path)
        logger.info(f"Excel report written: {output_path}")

    @staticmethod
    def _verdict_color(verdict: str) -> str:
        """Map verdict to color code."""
        colors = {
            "PASS": "00B050",  # Green
            "WARN": "FFC000",  # Orange
            "FAIL": "FF0000",  # Red
        }
        return colors.get(verdict, "808080")  # Gray default


def generate_miti_comparison_reports(
    audit_results: List[MitiAuditResult],
    output_dir: str,
    formats: Optional[List[str]] = None,
) -> None:
    """
    Generate per-model comparison reports for a batch.

    Args:
        audit_results: List of MitiAuditResult objects
        output_dir: Directory to write reports
        formats: List of formats ("json", "excel"); default: both
    """
    if formats is None:
        formats = ["json", "excel"]

    logger.info(f"Generating comparison reports for {len(audit_results)} model(s)")

    for result in audit_results:
        try:
            # Sanitize model name for filename
            safe_name = result.model_name.replace(" ", "_").replace("/", "_")
            base_path = os.path.join(output_dir, f"{safe_name}_{result.model_type}_comparison")

            report = MitiComparisonReport(
                model_name=result.model_name,
                model_type=result.model_type,
                audit_result=result,
            )

            if "json" in formats:
                report.to_json(f"{base_path}.json")

            if "excel" in formats:
                report.to_excel(f"{base_path}.xlsx")

        except Exception as e:
            logger.error(f"Error generating report for {result.model_name}: {e}")
