# Round 4 — object × property coverage (client requirement)

What the client asked: every listed object type covered and thoroughly tested; PD samples extended with Views, Triggers, Procedures …; a matrix showing per object type what is supported, migrated, validated, intentionally excluded, and planned.

## Deliverables

| File | What |
|---|---|
| `COVERAGE_MATRIX.md` | The inventory (§2 object types, §3 property tables, §4 exclusions + alternatives, §5 test models, §6 code changes). Also copied into the repo root. |
| `property_probe_matrix.md` / `.json` | Generated row-by-row evidence: 180 mutation probes, 161 detected, finding category per row. Regenerate with `python -m tests.coverage_probe`. |
| `coverage_matrix_sample_reports/` | V1 + V3 workbooks for the full-coverage LDM fixture with three properties deliberately broken (attribute default lost, RI rule changed, identifier renamed) — shows the new INFO rows on the FINDINGS sheet. |
| `coverage_matrix_round.diff` | Only this round's code changes. `all_changes.diff` is cumulative (rounds 1–4). |
| `ErwinDev-feature_new-fixed.zip` | Full tree, all four rounds. |

## Code (what changed and where)

**New: `app/validation/extended_properties.py`** (≈820 lines, 92 % test-covered). Re-reads the PD XML and the erwin XML with two small generic indexers (`PdDoc`: every `o:*` object by Id with its `a:*` attributes and `c:*` collections; `ErDoc`: every element with an `id`, its `*Props`, children, and model-level props) and runs 24 checks:

CDM/LDM: attribute default · attribute domain binding · domain name / length / default / check parameters · identifier name · identifier member order · relationship RI update/delete rule · inheritance name · business-rule type · package definition / hierarchy / contents · diagram missing / symbols · model definition.
PDM: table logical name / owner / tablespace · column logical name / domain / check constraint / identity · key name · index name / sort order · reference name / RI rule / cardinality · view columns · trigger event / owning table · sequence parameters · domain / business rule / default objects · data format (census) · DBMS target · view / procedure / trigger / sequence / tablespace comments.

Rules every check obeys: INFO severity (0.05 weight, never fails a model); runs only when the erwin export carries the vocabulary (`ErDoc.carries`); one model-level `<CHECK>_NOT_CARRIED` row instead of N rows when erwin has none of an element type; switchable per check (`EXTENDED_PROPERTY_CHECKS`) and globally (`CHECK_EXTENDED_PROPERTIES`); `apply()` never raises. On the real vessel pair it emits nothing.

**Hooks** (one call each, before scoring): `ldm_reconcile/comparator.py` and `cdm_reconcile/comparator.py` before `result.finalise()`; `pdm_reconcile/pdm_erwin_validator/comparator.py` before `compute_status()/compute_score()`.

**Config** (`app/config/validation_config.py`): the toggles above; `PD_RI_RULE_CODES` (PD metamodel: 0 None, 1 Restrict, 2 Cascade, 3 Set null, 4 Set default); `ERWIN_RI_RULE_CODES` — **provisional**, derived from the model defaults in the real export (identifying 10000/10004, non-identifying 10002/10006, subtype 10001/10005) plus erwin's documented default actions. A code outside either map is reported as `*_RI_RULE_UNMAPPED`, never as a mismatch. `ERWIN_ATTRIBUTE_NULL_OPTION_CODES` moved from the LDM class to `_Semantic` so CDM inherits it.

**Bug fixes found by the probes**
- `cdm_reconcile/erwin_cdm_parser.py::_is_mandatory` ignored erwin's numeric `Null_Option_Type` → every CDM attribute parsed as optional → the `MANDATORY` check could never fire on a real export. Ported the LDM code path.
- `cdm_reconcile/pd_cdm_parser.py` now also accepts `LogicalAttribute.Mandatory`.
- Fixture inconsistencies surfaced by the new checks were corrected in `tests/fixtures_extended.py` (RI codes aligned with the map, domain min/max, subject-area definition + contents, tablespace definition, sequence min/max, reference cardinality, diagram drawing objects).

**Tests**
- `tests/test_property_coverage.py` (new, 14 tests): every `expect=True` probe must be detected, every `expect=False` probe must NOT be (so a documented gap that silently closes forces the matrix to be updated); coverage floor ≥ 85 %; guard / toggle / RI-fallback / unmapped-code / trigger-move / thin-export behaviours; findings land in both the LDM `ValidationResult` and the PDM one with the right severity and object type, PDM count identities still reconcile.
- `tests/test_end_to_end_reports.py::ExtendedFixtureReportTests`: new categories reach the V3 FINDINGS sheet, status stays PASS.
- `tests/coverage_probe.py`: 180 probes (was 169), notes updated to name the category that now validates each property.

Totals: 290 tests pass · ruff 0 · coverage 78.8 % (71.2 % before).

## What the client still has to provide / decide

1. **One real PDM export** containing view, procedure, trigger, sequence, tablespace, domain, default, index, identity column, package, diagram — to confirm the erwin tag names listed in `extended_properties.UNVERIFIED_ERWIN_TAGS`. Until then those checks are correct-or-silent, never wrong.
2. **RI rule semantics**: set one relationship's update/delete action by hand in erwin, export, and confirm the codes in `ERWIN_RI_RULE_CODES`.
3. **Diagrams**: the vessel PD model has 2 diagrams, the erwin export has 0 `Stored_Display`. Confirm in erwin whether the import dropped them or Save-As-XML omits them; the check is ready either way.
4. Whether table/column comments in PDM should become scored findings (today: DOCUMENTATION sheet, report-only, by the PDM engine's design).
5. Whether Step 1 (comment injection) should be extended to views / procedures / triggers / packages (today their comment loss is *reported* as `*_DEFINITION` INFO, not fixed).
