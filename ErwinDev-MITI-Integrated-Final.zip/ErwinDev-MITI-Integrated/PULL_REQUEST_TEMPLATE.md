## Description
<!-- Provide a short summary of the changes. Why are they necessary? -->

## Related Issues
<!-- Link to relevant issues or discussions. Example: Closes #123 -->

## Type of changes
- [ ] Bug fixed (non-breaking change which fixes an issue)
- [ ] Feature added (non-breaking change which adds functionality)
- [ ] Breaking change (fix or feature that would cause existing functionality to not work as expected)
- [ ] Refactoring
- [ ] Documentation updated

## Screenshots (if applicable)
<!-- Add screenshots to clarify UI changes, if relevant -->

## Dependencies

<!-- Please list any new or updated dependencies for this code to run. API changes, .env updates, etc... -->
<!-- Otherwise, you can remove this section from the PR text. -->

## Checklist
- [ ] I have performed a self-review of my own code
- [ ] Code follows project guidelines
- [ ] I have added tests that prove my fix is effective or that my feature works
- [ ] New and existing unit tests pass locally with my changes
- [ ] My changes generate no new warnings
- [ ] I have made corresponding changes to the documentation

## Additional Notes
<!-- Any other information reviewers should know -->