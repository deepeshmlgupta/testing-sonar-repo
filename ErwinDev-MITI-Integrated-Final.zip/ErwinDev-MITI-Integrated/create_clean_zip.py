import shutil
import zipfile
from pathlib import Path


def clean_and_zip():
    root = Path(__file__).parent.resolve()
    zip_name = root / "migration-platform-dist.zip"

    if zip_name.exists():
        try:
            zip_name.unlink()
        except Exception as e:
            print(f"Warning: Could not remove existing zip file: {e}")

    print(f"Cleaning workspace at {root}...")

    # Ensure required input/output directory structures exist with .gitkeep
    keep_dirs = [
        "sappdmodels/cdm", "sappdmodels/ldm", "sappdmodels/pdm",
        "final_xml_models/cdm", "final_xml_models/ldm", "final_xml_models/pdm",
        "erwinmodels/1_initial", "erwinmodels/2_preprocessed", "erwinmodels/3_final",
        "erwinmodels/1_xml_v1", "erwinmodels/2_xml_v2", "erwinmodels/3_erwin_v1",
        "erwinmodels/4_erwin_v2", "erwinmodels/5_xml_v3", "erwinmodels/6_erwin_v3",
        "batch_summary/audit", "batch_summary/summary_report",
        "app/udp_tool/input_erwin_models/cdm", "app/udp_tool/input_erwin_models/ldm",
        "app/udp_tool/input_erwin_models/pdm", "sessions"
    ]
    for kd in keep_dirs:
        d = root / kd
        d.mkdir(parents=True, exist_ok=True)
        gitkeep = d / ".gitkeep"
        if not gitkeep.exists():
            try:
                gitkeep.touch()
            except Exception:
                pass

    # One-time agent report markdown files to remove and exclude
    agent_report_files = {
        "CHANGELOG_v008_MERGE.md",
        "DOCUMENTATION_INDEX.md",
        "SHARING_SUMMARY.md",
        "ZIP_SHARING_GUIDE.md",
        "00_START_HERE.md",
        "COMPLETE_SUMMARY.md",
        "MULTI_USER_IMPLEMENTATION_SUMMARY.md",
        "MULTI_USER_IMPLEMENTATION.md",
        "UDP_FINDINGS_AND_FIXES.md",
        "PDM_FIX_NOTES.md"
    }

    # Directory/File names to EXCLUDE from ZIP archive (do not attempt to delete local repository/env dirs)
    exclude_dirs = {".git", ".venv", "venv", ".pytest_cache", ".ruff_cache", ".vscode", "__pycache__",
                    "sessions", "data"}
    exclude_extensions = {".pyc", ".pyo", ".log", ".tmp"}
    exclude_files = {"migration-platform-dist.zip"}.union(agent_report_files)

    # Relative paths for generated report output directories to clean local files before zipping
    clean_out_dirs = [
        root / "erwinmodels",
        root / "batch_summary",
        root / "manual_review_reports",
        root / "app" / "reporting" / "ldm_reports",
        root / "app" / "reporting" / "cdm_reports",
        root / "app" / "reporting" / "pdm_reports",
        root / "app" / "udp_tool" / "output_excel_reports",
        root / "app" / "udp_tool" / "output_jsons",
        root / "app" / "udp_tool" / "input_erwin_models",
        root / "sessions",
        root / "data",
    ]

    # Clean local agent report files (DISABLED / COMMENTED OUT to preserve agent files)
    # for path in list(root.rglob("*.md")):
    #     if path.name in agent_report_files or path.name.endswith(".agent.md"):
    #         try:
    #             path.unlink()
    #             print(f"  Removed one-time agent report: {path.relative_to(root)}")
    #         except Exception as e:
    #             print(f"  Could not remove file {path.relative_to(root)}: {e}")

    # Clean local cache directories/files that are safe to delete locally
    for path in list(root.rglob("*")):
        if path.is_file() and (path.suffix in exclude_extensions or path.name.endswith(".log")):
            try:
                path.unlink()
                print(f"  Removed local temp/cache file: {path.relative_to(root)}")
            except Exception as e:
                print(f"  Could not remove file {path.relative_to(root)}: {e}")
        elif path.is_dir() and path.name in {"__pycache__", ".pytest_cache"}:
            try:
                shutil.rmtree(path)
                print(f"  Removed local cache dir: {path.relative_to(root)}")
            except Exception as e:
                print(f"  Could not remove cache dir {path.relative_to(root)}: {e}")

    # Remove generated output report files except .gitkeep
    for out_dir in clean_out_dirs:
        if out_dir.exists():
            for p in list(out_dir.rglob("*")):
                if p.is_file() and p.name != ".gitkeep":
                    try:
                        p.unlink()
                        print(f"  Removed generated output: {p.relative_to(root)}")
                    except Exception as e:
                        print(f"  Warning: Could not remove generated file {p.relative_to(root)}: {e}")

    print("\nPackaging into clean ZIP archive...")
    added_count = 0

    with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for path in root.rglob("*"):
            try:
                rel_path = path.relative_to(root)
            except ValueError:
                continue

            parts = set(rel_path.parts)

            # Skip excluded root or nested dirs / files
            if parts.intersection(exclude_dirs):
                continue
            if path.name in exclude_files:
                continue
            if path.is_file() and path.suffix in exclude_extensions:
                continue

            # Skip generated excel reports in reporting directories if any remain
            if path.is_file() and path.suffix in {".xlsx", ".xls", ".jsonl"} and any(r in rel_path.parts for r in ["erwinmodels", "batch_summary", "ldm_reports", "cdm_reports", "pdm_reports", "manual_review_reports"]):
                continue

            if path.is_file():
                try:
                    zipf.write(path, rel_path)
                    added_count += 1
                except Exception as e:
                    print(f"  Warning: Could not add {rel_path} to zip: {e}")

    print(f"\n[SUCCESS] Created clean archive '{zip_name.name}' with {added_count} files.")

if __name__ == "__main__":
    clean_and_zip()

