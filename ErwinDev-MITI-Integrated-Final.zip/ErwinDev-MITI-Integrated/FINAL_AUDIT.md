# Final technical audit — flow alignment (round 7)

**Repository:** `ErwinDev-feature_new` · **Date:** 2026-09-15 · **Verification:** `ruff check .` 0 findings · `pytest` **381 passed** (was 309 at the start of the round, 17 of which failed on the laptop copy) · line coverage 81.8 %.

Method: inspect → identify gaps → modify → test → audit, in that order. Nothing was rewritten from scratch; every engine, report writer, UDP tool module, session-isolation and MAX_PATH feature of rounds 1–6 is still in place and covered by its original tests.

---

## A. What was found

| # | Finding | Evidence |
|---|---|---|
| A1 | **Two incompatible layouts in one tree.** Round-5 files (`run_context`, `batch_runner`, `stage_paths`, their tests) implemented a six-folder `erwinmodels/1_xml_v1 … 6_erwin_v3` layout; the later "flat stages" files (`directory_setup`, `conceptual_workflow`, `run_v1/run_v3`, `promotion_routing`, `udp_flow`) used `1_initial / 2_preprocessed / 3_final`. 17 tests failed because of it. | `CHANGES_pdm_comment_injection.md` §"Still failing"; `pytest` on the laptop copy |
| A2 | **An automated erwin bridge was assumed.** `run_udp.py` called `erwin_converter.ensure_artifact()` to convert XML V2 → `.erwin` via SCAPI, and waited for it; `settings.ERWIN_CONVERT_ENABLED` defaulted to `true`; docs described "XML<->.erwin via erwin SCAPI". No such bridge is available. | old `app/run_udp.py`, `settings.py`, `PROJECT_STRUCTURE_AND_FLOW.md` §2 |
| A3 | **`run_v3.py` fell back silently.** `get_setting("FINAL_XML_FALLBACK_TO_PREPROCESSED", True)` — a missing XML V3 was scored against the commented XML and reported as V3 (the setting's own default was `false`, the script overrode it). It also re-ran Step 1 itself instead of reusing the file the operator had loaded into erwin, and wrote no ledger line. | old `app/run_v3.py` lines 70–79 |
| A4 | **`run_v1.py` did not run Step 1.** It produced only the V1 report; the commented XML (the thing the operator needs to open in erwin next) was only produced by `run_v3`. It also mirrored PD models into the UDP input folder without saying so. | old `app/run_v1.py` |
| A5 | **No model-identity check on V3.** Any `final_xml_models/<tier>/<name>.xml` was scored; an export of another model with the same file name would have been attributed to this model. Same for the PDM flow (`_validate_final`). | `conceptual_workflow`, `pdm_flow._validate_final` |
| A6 | **UDP "nothing verified" scored as 0 %.** When the UDP tool could not read the `.erwin` (no COM on this host, stand-in file) the comparison workbook listed every value as MISSING; the next stage read that workbook back and produced `udp=0.00%`, dragging V2/V3 from ~97 % to 72.5 % and failing the gate. `UdpStageOutcome.pass_rate` already returned `None` for that case, but the fallback to the on-disk workbook bypassed it. | `test_batch_pipeline::test_full_pass_run…` failure; `udp_helpers.udp_engine_pass_rate`; `report_layout.udp_comparison_counts` |
| A7 | **No hand-off tracking.** `stage_state` persisted only the V1 report path and score; nothing recorded whether the `.erwin` had been handed off, whether XML V3 had been exported, what the operator had to do next, or which exact file (hash) a stage had scored. Complexity (Simple/Medium/Complex) did not exist. | `app/orchestration/stage_state.py` (old) |
| A8 | **PDM flow promoted without XML V3.** `run_pdm_flow` evaluated the gate on the V2 result when no validated export existed and moved files to `3_final` / manual review — a "final" verdict without the final artefact. | `pdm_flow.run_pdm_flow` |
| A9 | **`udp_bridge` had its own copy of the isolated loader** (diverged from `IsolatedLoader`), breaking `test_concurrent_bridge_loads_leave_interpreter_state_intact`. | `app/validation/udp_bridge.py` |
| A10 | **Tests wrote into the real tree.** `tests/test_end_to_end_reports._make_dirs` built `stages` without a `final_xml_dir`, so XML V3 fixtures landed in the repository's `final_xml_models/` (three stray files found). | `final_xml_models/fleet_full.xml`, `m.xml`, `synthetic_model.xml` |
| A11 | **Docs described the wrong flow** (six folders, SCAPI conversions, `run_v1` → `.erwin`, V3 fallback, "auto-created session-scoped erwinmodels"). | README, SETUP, QUICK_START, REQUIREMENTS, PROJECT_STRUCTURE_AND_FLOW, settings comments |
| A12 | **Datatype fidelity was sound but untested as such.** Both engines already report a changed base type (CRITICAL) and a changed size (LDM: `LENGTH_PRECISION` WARNING; PDM: `DATA_TYPE_LENGTH`) with both values; no test pinned the specific cases the programme named. | engines unchanged; see B-tests |
| A13 | **COVERAGE_MATRIX.md** was narrative-only; it lacked the requested column layout and the status vocabulary, and the PDM comment rows still said "report-only". | `COVERAGE_MATRIX.md` (round 4) |
| A14 | Fidelity scoring is already deterministic and property-level (`fidelity_stages`: weighted mean of measured components, renormalised; every finding carries object/property/PD value/erwin value/severity/remediation). No regression, ML, historical prediction or count-only scoring exists anywhere in `app/`. | `app/validation/fidelity_stages.py`, comparators — confirmed by reading, not changed |

## B. What was changed

| File | Change | Reason | Impact |
|---|---|---|---|
| `app/orchestration/stage_paths.py` | Rewritten for the flat layout: `xml_v1/xml_v2/erwin_v2/erwin_v3` → `1_initial / 2_preprocessed / 2_preprocessed / 3_final`; `erwin_v1` → `app/udp_tool/input_erwin_models`; `xml_v3` → `final_xml_models/<tier>`; same `StagePaths` API (`expected/find_*/describe/ensure_folders`); legacy search (six-folder names, `1_initial/xml`, `2_preprocessed/erwin`) for **inputs** only. | A1 | Every caller/test resolves the same paths; older checkouts still readable. |
| `app/orchestration/directory_setup.py` | `setup_directories(context)` accepts `RunContext` / `SessionContext` / None again (round-5 isolation re-integrated), returns `reports_root`, `udp_input`, `udp_work`, `udp_reports`, `stages`, `shared_stages`; creates only the three flat folders. | A1 | `--isolate` works with the flat layout; shared inputs still found. |
| `app/orchestration/stage_state.py` | Hand-off ledger: `STATUS_*` vocabulary (`AUTOMATED / MANUAL / WAITING_FOR_MANUAL_INPUT / VALIDATED / FAILED / READY_FOR_NEXT_STAGE`), stage names, `NEXT_ACTION`, `artifact_record()` (path, kind, parent, size, mtime, SHA-256), `record_stage()`, `stage_status()`, `history()`, `pending_actions()`; `save_v1` merges instead of overwriting. | A7 | `batch_summary/stage_state/<model>.json` shows every stage of every model with timestamps, user, artefact identity and next action. |
| `app/orchestration/model_record.py`, `app/config/settings.py` | `source_counts`, `classify_complexity` (SIMPLE ≤ 25 objects & 200 members, MEDIUM ≤ 100 & 1000, else COMPLEX; UNKNOWN when nothing counted), `ModelRecord.complexity`; thresholds `COMPLEXITY_*`. | A7 | Complexity in summary sheet, ledger and stage state; a label only — never changes a score (tested). |
| `app/reporting/summary_report.py`, `app/orchestration/pipeline_ledger.py` | "Complexity" column; ledger entry gains `complexity` and `artefact_hashes` (SHA-256 / size / mtime of every artefact that exists). | A7, lineage | Verdicts are provably tied to files. |
| `app/workflows/conceptual_workflow.py` | Shared helpers used by `run_v1/run_udp/run_v3` and `main`: `locate_xml_v1` (wait/validate/record), `measure_v1`, `inject_comments` (reuses a newer existing XML V2; records ERWIN_HANDOFF WAITING/VALIDATED), **`validate_erwin_binary`**, **`run_step2`** (hand-off validation, UDP phase, UDP stage status, V3_XML hand-off status), `measure_v2`, `locate_xml_v3` (hard stop by default), `measure_v3` (**identity check**: no entity in common → FAILED, not scored). `process_conceptual_model(..., session_context)` restored. | A2, A3, A5, A7 | One implementation of the flow for both entry styles. |
| `app/workflows/pdm_workflow.py` | Rewritten on the same helpers: `locate_xml_v1`, `run_step2` (or `run_udp=False` for `run_v3`), `run_pdm_flow(require_final_xml=not fallback)`, stage-state records, ledger skips, `session_context`. | A2, A5, A7, A8 | PDM traceable stage by stage; no promotion without XML V3. |
| `app/validation/pdm_reconcile/pdm_flow.py` | `require_final_xml` parameter (gate not evaluated, nothing moved, `waiting_for_final_xml=True`); `_validate_final` refuses an export with no table in common (`FAILED … different model`) and an unparseable one; `final_xml_validated` flag. Default behaviour unchanged for existing callers/tests. | A5, A8 | |
| `app/workflows/promotion_routing.py` | `route_model(record, promote_source, dirs, stages=None, erwin_source=None)`: copies (never moves) the scored XML V3 and the `.erwin` from `2_preprocessed` into `3_final`; records `artefacts["erwin_v3"/"final_xml"]`; tolerant of bare test records. FAIL leaves the model in `2_preprocessed`. | user requirement (3 folders, ≥ 90 % → 3_final) | |
| `app/orchestration/udp_helpers.py` | `run_udp_phase(..., erwin_in, erwin_out)` uses `dirs["udp_reports"]/<tier>` and `dirs["udp_work"]`; **`udp_engine_pass_rate`**: a live outcome that compared but could not support a verdict returns `None` (n/a) instead of falling back to the workbook it just wrote. | A6 | UDP component is n/a, not 0 %, when nothing was verified. |
| `app/reporting/report_layout.py` | `udp_comparison_counts` reads the udp_tool's Summary **Verdict**; a literal `NOT VERIFIED …` verdict → `None` (nothing measured). | A6 (cross-process case) | `run_v3` after a `run_udp` without COM no longer scores 0 %. |
| `app/validation/udp_flow.py` | `DEFAULT_ERWIN_INPUT_DIRS = (udp_tool/input_erwin_models, erwinmodels/1_initial)`; explicit `erwin_in` wins; refuses `erwin_out == erwin_in`; `outcome.erwin_in`; WAITING_FOR_MANUAL_INPUT message when no `.erwin`. | A2, inputs never overwritten | |
| `app/validation/udp_bridge.py` | Uses the shared `IsolatedLoader`. | A9 | |
| `app/run_v1.py` | Rewritten: `locate_xml_v1` → V1 → **Step 1** (CDM/LDM via `inject_comments`; PDM via `pdm_flow._inject_comments`) → V1 report → stage state (V1_XML, V1_FIDELITY + complexity, COMMENTS_TO_NOTES, ERWIN_HANDOFF WAITING) → prints the manual next action. Produces **no `.erwin`**. `--isolate/--user/--session-id` supported. | A2, A4 | |
| `app/run_udp.py` | Rewritten: no converter; `run_step2` on the handed-off `.erwin`; WAITING when absent (mapping reports still produced); READY + V3_XML WAITING when `2_preprocessed/<m>.erwin` written; FAILED with remedy when injection impossible on this host. | A2 | |
| `app/run_v3.py` | Rewritten: reuses `2_preprocessed/<m>.xml`; V1 read back from stage state; V2; `locate_xml_v3` **hard stop** by default (dry run only with `FINAL_XML_FALLBACK_TO_PREPROCESSED=true`, noted in the report); `measure_v3` identity check; gate → `3_final`; ledger line; PDM via `process_pdm_model(run_udp=False)`. | A3, A5 | |
| `app/main.py` | Docstring describes the real flow; `process_pdm_model` gets `session_context` (batch_runner). | A11 | |
| `app/config/settings.py` | Stage-layout comment rewritten for the flat layout and manual hand-offs; `ERWIN_CONVERT_ENABLED` default **false** (optional utility, not used by the flow). | A2, A11 | |
| `tests/test_manual_handoff.py` (**new**, 18 tests) | The three scripts in sequence with the hand-offs played by the test (LDM and PDM); negatives: corrupt XML V1, empty `.erwin`, XML V3 of another model (LDM and PDM), corrupt XML V3, rerun keeps Step 1 output, wrong tier folder; input hashes unchanged; ledger hashes; complexity thresholds / vocabularies / label-only. | tests | |
| `tests/test_datatype_fidelity.py` (**new**, 46 cases) | VARCHAR(500), VARCHAR(255), DECIMAL(18,2), DECIMAL(38,10), DATE, TIMESTAMP, CHAR, INTEGER, BIGINT through both engines' type classifiers and the LDM comparator: same → verified; base type changed → `DATA_TYPE` CRITICAL; size changed → `LENGTH_PRECISION` WARNING (LDM) / non-match (PDM); PD short codes (`VA500`, `A10`). | A12 | |
| `tests/test_run_v3_stage_history.py` (rewritten, 5) | New `run_v3` structure: hard stop, dry-run fallback, V1/V2 history carried, real override path, refusal of another model's export. | A3, A5 | |
| `tests/test_run_context.py`, `tests/test_end_to_end_reports.py`, `tests/test_batch_pipeline.py`, `tests/test_flow_alignment.py` | Retargeted to the flat layout; e2e helper no longer writes into the repository's `final_xml_models/`; converter test opts in explicitly and asserts the stage scripts never reference the converter. | A1, A10 | |
| `tests/coverage_matrix_rows.py` (**new**), `tests/test_coverage_matrix.py` (**new**, 5) | 148-row canonical matrix in the requested columns, rendered into `COVERAGE_MATRIX.md`; tests: status vocabulary, no duplicates, remediation on every excluded/partial row, document in step with the table, every named validation category exists in `app/validation`, probes agree, datatype rows backed by tests. | A13 | |
| `COVERAGE_MATRIX.md` | §2 canonical matrix (generated) with the requested columns and statuses; narrative sections renumbered; flow context paragraph; stale `1_xml_v1` / SCAPI references corrected. | A13, A11 | |
| `README.md`, `SETUP.md`, `QUICK_START.md`, `REQUIREMENTS.md`, `PROJECT_STRUCTURE_AND_FLOW.md` | Flow rewritten as the actual operating flow (two manual hand-offs, three flat folders, `run_v1 → run_udp → run_v3`, statuses, hard stop, identity check, ledger, fidelity formula, platform table). | A11 | |

## C. What was NOT changed (and why)

* **Reconciliation engines** (`cdm_reconcile`, `ldm_reconcile`, `pdm_reconcile/pdm_erwin_validator`), `extended_properties`, `fidelity_stages`, `promotion_gate`, report writers (`v1/v2/v3_report`, `report_layout` MAX_PATH budget), `migration_audit`, `session_manager`, `concurrency`, `run_context`, `batch_runner` (except passing `session_context` to the PDM route), Step 1 injector, UDP tool modules — working functionality, covered by their original tests; the directive was to align, not rewrite.
* **`app/erwin/erwin_converter.py`** kept as an opt-in utility (`ERWIN_CONVERT_ENABLED=false`); it is no longer referenced by any stage script (asserted by a test). Removing it would have deleted a working module a Windows user with erwin might still want.
* **`STAGE_FOLDERS` setting** kept only as the legacy-search names; documented as such.
* **PD-model mirror into `app/udp_tool/input_erwin_models/<tier>/`** (`mirror_models_to_udp_input`) kept — the UDP tool needs the PD source; it copies `.cdm/.ldm/.pdm` only, never a `.erwin`.
* **PDM two-band routing / manual_review move** kept for the case where XML V3 exists and the gate fails (round-3 behaviour); it simply no longer runs before XML V3 exists.
* **UDP tool report naming** (`output_excel_reports/<tier>/<full name>_UDP_…xlsx`, ≈ 252 chars on the OneDrive root) — noted in round 4, still not changed.
* **Deleting the six-folder directories on the laptop** (`erwinmodels/1_xml_v1 …`) — the code no longer writes there; removing existing folders is the operator's decision (they may contain files). Only `1_initial`, `2_preprocessed`, `3_final` are created.

## D. Flow verification

| Step | Kind | Verified by |
|---|---|---|
| PD `.cdm/.ldm/.pdm` → `run_v1.py` → Fidelity V1 → `2_preprocessed/<m>.xml` (comments → notes) | AUTOMATED | `test_manual_handoff` (LDM + PDM sequence): V1 report exists, XML V2 carries `Note_List`, `1_initial` hash unchanged, no `.erwin` anywhere in the tree |
| `2_preprocessed/<m>.xml` → **manual** erwin save → `udp_tool/input_erwin_models/<m>.erwin` | MANUAL | `ERWIN_HANDOFF` = WAITING with next action until the file exists; VALIDATED with SHA-256 afterwards; empty file → FAILED |
| `run_udp.py` → `2_preprocessed/<m>.erwin` | AUTOMATED (Windows + COM) | UDP stage WAITING (no hand-off) / FAILED with remedy (no COM) / READY; input `.erwin` hash unchanged; `erwin_out == erwin_in` refused (`test_flow_alignment`) |
| `2_preprocessed/<m>.erwin` → **manual** erwin Save As XML → `final_xml_models/<tier>/<m>.xml` | MANUAL | `V3_XML_EXPORT` = WAITING; `run_v3` returns None, `3_final` empty (LDM, PDM, `test_run_v3_stage_history`, `test_batch_pipeline`) |
| `run_v3.py` → V2, V3 (V1 read back), gate → `3_final/<m>.xml + .erwin` | AUTOMATED | PASS copies (hash-equal) into `3_final`, input left in place; ledger line with `artefact_hashes` for source, xml_v1, xml_v2, erwin_v2, xml_v3, final_xml; V1/V2/V3 all on the V3 result |
| Model identity | — | XML V3 of another model → `FAILED … different model`, not scored, `3_final` empty (LDM + PDM) |
| Statuses in the model ledger | — | every event has stage, status ∈ vocabulary, manual flag, model, model_type, complexity, timestamp, user, artefact record, next_action |
| `python -m app.main` | one process | `test_batch_pipeline` (full PASS, hard stops, threaded == sequential), `test_run_context` (isolated runs share only inputs) |
| No fake automation | — | `test_converter_is_off_by_default_and_never_called_by_the_stage_scripts`; smoke run of `python -m app.run_v1` on an empty tree: "No models found", nothing written |

## E. Test results

```
ruff check .                      All checks passed!
pytest                            381 passed in 16 s   (coverage 81.8 % of app/)
```

New this round: `test_manual_handoff.py` 18 · `test_datatype_fidelity.py` 46 · `test_coverage_matrix.py` 5 · `test_run_v3_stage_history.py` 5 (rewritten) · 1 converter guard. Repaired: 17 previously failing tests (layout fork), `test_batch_pipeline::test_full_pass…` (UDP 0 % → n/a), `test_concurrent_bridge_loads…`.

Negative cases covered: missing XML V1 · corrupt XML V1 · missing `.erwin` hand-off · empty `.erwin` · missing XML V3 (LDM, PDM, batch) · corrupt XML V3 · XML V3 of another model (LDM, PDM) · XML V3 in the wrong tier folder with legacy search off · rerun must not overwrite Step 1 output · UDP output path equal to input · UDP workbook naming another model · UDP workbook with `NOT VERIFIED` verdict · datatype base/size changes for all nine requested types.

## F. Coverage gaps and open items

1. **UDP injection needs a Windows host with erwin Data Modeler** (COM). On any other host `run_udp` records the UDP stage `FAILED` with the remedy and still produces the extraction/mapping reports. The read-back of a real `.erwin` written by erwin has been exercised only on the laptop in earlier rounds; the stand-in binaries in the tests exercise the "unreadable" path.
2. **`NOT_YET_TESTED` rows** in the coverage matrix (diagram `Stored_Display`, trigger `Trigger_Fire_On_*`, sequence min/max, RI-rule code map): the checks exist and are silent until one real full PDM export confirms erwin's tag names — same request as round 4.
3. **`PARTIALLY_SUPPORTED`**: SQL bodies of views / procedures / triggers are compared at ≥ 90 % similarity (`SQL_SIMILARITY_THRESHOLD`); domain list-of-values / format as present/absent; package comment validated but not injected.
4. **`FUTURE_ENHANCEMENT`**: physical DBMS options (index clustering, fill factor, tablespace files); Step 1 for Subject_Area comments.
5. **`NOT_SUPPORTED_BY_ERWIN`**: relationship dominance, PD Data Format, procedure parameters as objects — each with its alternative in the matrix; none is silently dropped (census rows / body comparison).
6. The hand-off ledger records the OS user; there is no sign-off field yet — "VALIDATED" means the framework validated the artefact's shape and identity, not that a reviewer approved it. A `MANUALLY_VALIDATED` status is in the vocabulary for that purpose but no stage emits it.
7. Old six-folder directories on the laptop (if any) are left in place; they are searched as legacy input locations only.
