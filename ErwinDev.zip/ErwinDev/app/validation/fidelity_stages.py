"""
Staged Fidelity (V1 → V2 → V3)
==============================
Scores a model at each stage of the migration from what was ACTUALLY measured
at that stage.  Nothing is carried forward: every stage re-reads a different
erwin artefact and recomputes every component.

    V1   SAP PD  vs  erwinmodels/1_initial/xml       raw erwin export
         Comments have not been injected and no UDP has been written, so the
         documentation and UDP components read close to zero and the score is
         low.  This is the honest measure of the initial migration gap.

    V2   SAP PD  vs  erwinmodels/2_preprocessed/xml  after Comments/Notes
         (CDM/LDM) or structural remediation (PDM).  Documentation recovers.
         UDPs are still absent -- the XML export carries none.

    V3   SAP PD  vs  the FINAL validated erwin XML   settings.FINAL_XML_DIR
         The manually validated export carries the UDPs, comments and any other
         construct the earlier stages were missing, so every component is
         re-measured against it. When the UDP engine also read the enriched
         .erwin binary back, that pass rate can be supplied as an override.

WHY A SEPARATE SCORE WAS NEEDED
-------------------------------
The comparators' own ``fidelity_score`` is structural only, later blended with
the XML-side UDP number by ``udp_fidelity.apply()``.  Neither moves between V1
and V2, because comment migration produces ``documentation_rows`` that are
report-only and never scored.  Measured on the shipped samples, the CDM scores
92.24 structural at BOTH V1 and V2, while its documentation goes from 5.88% to
100.00%.  Without a documentation component there is no progression to report.

THE THREE COMPONENTS
--------------------
    structural      the comparator's own structural_fidelity_score
    documentation   MATCHED / (rows where either side had text), from the
                    documentation rows the framework already builds
    udp             udp_fidelity's XML measurement at V1 and V2; the UDP
                    engine's read-back pass rate at V3

    overall = Σ (component × weight) / Σ (weight of measurable components)

A component that cannot be measured for a model -- an LDM with no extended
attributes, say -- is dropped and the remaining weights are renormalised, so a
model is never penalised for metadata it never had.

NOT SCORED AS SEPARATE COMPONENTS, AND WHY
------------------------------------------
Shortcuts and Tags are deliberately absent from this weighted calculation, but
for two different reasons, and only one of them still means "lost".

SHORTCUTS ARE NOW MIGRATED, AND ARE MEASURED INSIDE THE UDP COMPONENT.
erwin's XML export has no shortcut object and never will, so counting shortcut
ELEMENTS on the erwin side can only ever return zero -- a constant drag at V1,
V2 and V3 alike rather than a progression.  What changed is that the content no
longer depends on that element existing: app/validation/shortcut_udp.py carries
PowerDesigner Shortcuts, and the per-object glossary bindings that reference
them, into erwin as UDPs (PD_NameTerms, PD_CodeTerms, PD_Shortcut_*).  They
therefore travel in property_manifest.json with every other UDP, are injected
by the same erwin_load.py, and are verified by the same read-back -- so their
migration IS scored, as part of the ``udp`` component, on the same evidence as
every other UDP.  A separate ``shortcuts`` element count would double-count it
against a target erwin does not have.

TAGS ARE STILL NOT MEASURED.  They have no representation anywhere in the
framework -- no parser, no config, and no Tag element in any shipped export --
so scoring them would be inventing a number rather than measuring one.

``components`` records both as ``None`` so the report says "not measured"
rather than implying zero.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from app.common.config_helpers import cfg as _cfg
from app.common.config_helpers import tier_config as _tier_config

logger = logging.getLogger(__name__)

STAGE_V1 = "V1"
STAGE_V2 = "V2"
STAGE_V3 = "V3"
STAGES = (STAGE_V1, STAGE_V2, STAGE_V3)

COMPONENT_STRUCTURAL = "structural"
COMPONENT_DOCUMENTATION = "documentation"
COMPONENT_UDP = "udp"
COMPONENT_SHORTCUTS = "shortcuts"
COMPONENT_TAGS = "tags"
COMPONENT_HIERARCHY = "hierarchy"
COMPONENT_RELATIONSHIP_SEMANTIC = "relationship_semantic"
COMPONENT_DATATYPE = "datatype"

DEFAULT_WEIGHTS: Dict[str, float] = {
    COMPONENT_STRUCTURAL: 0.50,
    COMPONENT_DOCUMENTATION: 0.25,
    COMPONENT_UDP: 0.25,
}

# Config-overridable safety defaults (see validation_config._Shared).
# Both of these are OFF by default (None). See validation_config._Shared for
# why: a V1 floor hides the gap V1 exists to report, and a no-UDP cap penalises
# a model for metadata it never had. Set either to a float in config to restore
# the old clamping behaviour.
DEFAULT_V1_UDP_BASELINE_WHEN_UNMIGRATED = None
DEFAULT_NO_UDP_FIDELITY_CAP = None

# Documentation row statuses. Kept as literals so this module never has to
# import a tier-specific documentation package.
_DOC_MATCHED = "MATCHED"
_DOC_BOTH_EMPTY = "BOTH_EMPTY"


@dataclass
class StageScore:
    """One model measured at one stage."""

    stage: str
    overall: float = 0.0
    components: Dict[str, Optional[float]] = field(default_factory=dict)
    weights: Dict[str, float] = field(default_factory=dict)
    notes: List[str] = field(default_factory=list)
    #: Components dropped because the EVIDENCE for them is missing — as
    #: opposed to components that are not applicable to this model (a model
    #: with no UDPs at all). The distinction is load-bearing: a dropped
    #: component renormalises the weights, so without it a model whose UDP
    #: handoff never happened scores exactly the same as one that migrated
    #: perfectly. The promotion gate refuses to pass a model that has any.
    unverified: List[str] = field(default_factory=list)

    def component(self, name: str) -> Optional[float]:
        return self.components.get(name)

    def as_row(self) -> Dict[str, Any]:
        return {
            "stage": self.stage,
            "overall": self.overall,
            **{name: self.components.get(name) for name in
               (COMPONENT_STRUCTURAL, COMPONENT_DOCUMENTATION, COMPONENT_UDP)},
        }

    def summary_line(self) -> str:
        parts = [f"{name}={'n/a' if value is None else f'{value:.2f}%'}"
                 for name, value in self.components.items() if name in DEFAULT_WEIGHTS]
        return f"{self.stage} fidelity {self.overall:.2f}% ({', '.join(parts)})"


# ═════════════════════════════════════════════════════════════════════════════
#  Component measurement
# ═════════════════════════════════════════════════════════════════════════════

def _weights(config) -> Dict[str, float]:
    configured = getattr(config, "FIDELITY_STAGE_WEIGHTS", None) if config is not None else None
    if not isinstance(configured, dict) or not configured:
        return dict(DEFAULT_WEIGHTS)
    return {name: float(value) for name, value in configured.items() if float(value) > 0}


def structural_fidelity(result) -> Optional[float]:
    """The comparator's own structural number, untouched by this module."""
    for name in ("structural_fidelity_score", "fidelity_score_raw", "fidelity_score"):
        value = getattr(result, name, None)
        if value is not None:
            return float(value)
    return None


def documentation_rows(result) -> List[Any]:
    """
    The side-by-side Comment / Description / Annotation rows for this result.

    CDM and LDM results carry them already.  PDM builds them lazily in its
    report generator, so they are built here the same way, from the same
    module, and cached on the result so the report does not repeat the work.
    """
    cached = getattr(result, "documentation_rows", None)
    if cached:
        return list(cached)

    pd_file = getattr(result, "pd_file", "") or ""
    erwin_file = getattr(result, "erwin_file", "") or ""
    if not pd_file or not erwin_file:
        return []
    try:
        from app.validation.pdm_reconcile import pdm_documentation
        rows = pdm_documentation.build_rows(
            pd_file, erwin_file, getattr(result, "pd_model", "") or "")
    except Exception as exc:                                   # noqa: BLE001
        logger.debug("Documentation rows unavailable for %s: %s", pd_file, exc)
        return []
    try:
        result.documentation_rows = rows
    except AttributeError:
        logger.debug("Could not cache documentation rows on %s", type(result).__name__)
    return list(rows)


def documentation_fidelity(result) -> Optional[float]:
    """
    Share of documented objects whose text survived into erwin.

    Rows where NEITHER side carries text are excluded: an object nobody
    documented is not a migration loss, and counting it would let an
    undocumented model score 100% for free.  Returns None when the model has no
    documentation at all, so the component is dropped rather than scored zero.
    """
    rows = documentation_rows(result)
    if not rows:
        return None
    migratable = [row for row in rows if getattr(row, "status", "") != _DOC_BOTH_EMPTY]
    if not migratable:
        return None
    matched = sum(1 for row in migratable if getattr(row, "status", "") == _DOC_MATCHED)
    return round(matched / len(migratable) * 100.0, 2)


def erwin_side_carries_udps(result) -> bool:
    """
    Does the erwin XML that was measured actually carry THE MIGRATED UDPs?

    Real evidence is that the export holds UDPs the SAP side can be matched
    against: at least one MATCHED value, or a UDP dictionary (definitions) for
    the comparison to have had something to look for. A pile of unrelated UDP
    values is not evidence — on real_estate a validated export carried 105 UDP
    values, none corresponding to a SAP PD UDP, and treating that as evidence
    made the XML authoritative and scored a successful migration as total loss.

    Lives here rather than in udp_helpers because the scorer needs it too, and
    two copies of this predicate would be free to disagree about the same file.
    ``udp_helpers.erwin_xml_carries_udps`` delegates to it.
    """
    fidelity = getattr(result, "udp_fidelity", None)
    if fidelity is None:
        return False
    matched = int(getattr(fidelity, "udp_matched", 0) or 0)
    definitions = int(getattr(fidelity, "udp_definitions_erwin", 0) or 0)
    return bool(matched or definitions)


class _UdpNotMeasured:
    """
    Sentinel: the UDP component cannot be measured at this stage.

    Distinct from ``None`` (which means "no override — let the stage's own XML
    comparison stand") and from ``0.0`` (which means "measured, and everything
    was lost"). It exists because those two were being conflated.

    The case it names: the erwin XML being scored carries no UDPs AND the UDP
    injection stage has not been executed for this model (stage_state records
    STAGE_UDP as WAITING_FOR_MANUAL_INPUT, because no .erwin was handed off).
    The artefact is pre-injection BY DESIGN, so its zero UDPs are not evidence
    that a migration lost anything — there has not been a UDP migration yet.
    Scoring it 0% put a hard ceiling of 75% on every model with UDPs at V1 and
    V2 regardless of how well it migrated, and presented a stage that had not
    run as a total loss that had been measured.

    It is emphatically NOT a way to drop an inconvenient number: it is only
    reachable on POSITIVE recorded evidence that the stage has not run. Once
    the UDP stage has executed, whatever it measured stands, including 0%.
    """

    __slots__ = ()

    def __repr__(self) -> str:                                   # pragma: no cover
        return "UDP_NOT_MEASURED"


#: Singleton instance of the sentinel above.
UDP_NOT_MEASURED = _UdpNotMeasured()


def udp_fidelity_component(result, override, stage: str = "", config=None) -> Optional[float]:
    """
    The UDP number for this stage, or None when the component should be dropped.

    ``override`` is an externally measured UDP number (e.g. the UDP engine's
    read-back pass rate). It is honoured as-is when supplied.

    Two rules matter here:

    * FULLY MATCHED IS NOT A LOSS. SAP PD 56 / erwin 56 / matched 56 gives
      ``udp_fidelity_score`` = 100.0, so the component reads 100 and costs the
      model nothing.
    * NO UDPs IS NOT A LOSS EITHER. SAP PD 0 / erwin 0 / matched 0 returns None,
      which drops the component and renormalises the remaining weights in
      score(). The model is scored on what it actually has.

    A model whose UDPs exist but were not migrated is reported at its measured
    value. Set V1_UDP_BASELINE_WHEN_UNMIGRATED to a float to floor V1 instead.
    """
    if override is UDP_NOT_MEASURED:
        return None                    # stage not executed: drop the component

    if override is not None:
        return round(float(override), 2)

    if not getattr(result, "udp_total", 0):
        return None                    # nothing to migrate: drop the component

    # POST-INJECTION STAGES ONLY. At V2 and V3 the UDP number is read as a
    # verdict on whether the UDPs migrated. If the erwin XML being scored
    # carries no UDP evidence at all, it cannot answer that question, and
    # reporting its 0.00 as a measurement is the defect that made V2 read
    # 75.00 on a model whose UDP stage had not run.
    #
    # This is not a way to hide a failed injection. erwin's XML export does not
    # serialise UDPs at all — that is the whole reason app/orchestration/
    # udp_evidence.py exists to carry the .erwin read-back forward — so an
    # export with none is genuinely uninformative rather than evidence of loss.
    # A real injection failure is caught by that read-back, which the caller
    # supplies AS the override and which always wins over this branch. A stage
    # left with no UDP component is EXTERNAL_VERIFICATION_REQUIRED, never
    # complete validation.
    #
    # V1 IS DELIBERATELY EXCLUDED. V1 measures the raw erwin export BEFORE any
    # injection, and its low UDP number is the point of the stage: it is the
    # honest size of the initial gap, the baseline every later stage is
    # compared against. Suppressing it there would raise V1 for no reason and
    # erase the progression the report exists to show.
    if stage in (STAGE_V2, STAGE_V3) and not erwin_side_carries_udps(result):
        logger.info(
            "UDP component not measured at %s: the erwin XML scored here carries "
            "no UDP evidence (0 matched, 0 UDP definitions), so it cannot speak "
            "to whether %s UDP value(s) migrated. Supply the .erwin read-back as "
            "an override to measure it.", stage, getattr(result, "udp_total", 0))
        return None

    value = getattr(result, "udp_fidelity_score", None)
    measured = None if value is None else round(float(value), 2)

    if stage == STAGE_V1:
        baseline = _cfg(config, "V1_UDP_BASELINE_WHEN_UNMIGRATED",
                        DEFAULT_V1_UDP_BASELINE_WHEN_UNMIGRATED)
        if baseline is not None:
            floor_value = round(float(baseline), 2)
            return floor_value if measured is None else max(measured, floor_value)

    return measured


# ═════════════════════════════════════════════════════════════════════════════
#  Shortcut / Tag measurement — config-driven, never invented
# ═════════════════════════════════════════════════════════════════════════════

def _count_elements(path: str, local_names) -> Optional[int]:
    """
    How many elements in an XML file carry one of `local_names`.

    Streamed with iterparse and cleared as it goes, so a 100+ model batch of
    large exports costs bounded memory. None when the file or the name list is
    unusable — never a guessed zero.
    """
    names = {str(name).strip() for name in (local_names or ()) if str(name).strip()}
    if not names or not path or not os.path.isfile(path):
        return None
    try:
        from defusedxml.ElementTree import iterparse
        total = 0
        for _, element in iterparse(path, events=("end",)):
            tag = element.tag
            local = tag.rsplit("}", 1)[-1].split(":")[-1] if isinstance(tag, str) else ""
            if local in names:
                total += 1
            element.clear()
        return total
    except Exception as exc:                                   # noqa: BLE001
        logger.debug("Could not count %s in %s: %s", sorted(names), path, exc)
        return None


def _presence_fidelity(result, config, pd_key: str, erwin_key: str,
                       pd_count_attr: str = "") -> Optional[float]:
    """
    Share of a source construct that survived into the erwin export.

    Returns None — "not measured", so the component is dropped rather than
    scored zero — whenever any of these is true:

      * the erwin element names are not configured (we do not know what to look
        for in this erwin version, and guessing would invent a number);
      * the source model carries none of the construct (nothing to migrate);
      * either file could not be read.
    """
    erwin_names = _cfg(config, erwin_key, ())
    if not erwin_names:
        return None

    pd_total = getattr(result, pd_count_attr, None) if pd_count_attr else None
    if pd_total is None:
        pd_total = _count_elements(getattr(result, "pd_file", ""), _cfg(config, pd_key, ()))
    if not pd_total:
        return None

    erwin_total = _count_elements(getattr(result, "erwin_file", ""), erwin_names)
    if erwin_total is None:
        return None
    return round(min(100.0, 100.0 * erwin_total / float(pd_total)), 2)


def shortcut_fidelity(result, config=None) -> Optional[float]:
    """
    Share of SAP PD shortcuts present in the erwin export as ELEMENTS, or None.

    Returns None unless SHORTCUT_ERWIN_ELEMENTS names an erwin element that
    actually carries shortcuts, which no erwin release does -- so in practice
    this is always None and the component is dropped from the weighting.

    That is correct, and it is not the same thing as the shortcuts being lost:
    since app/validation/shortcut_udp.py they migrate as UDPs and are measured
    by the UDP read-back (see this module's header). This function is kept for
    the case where a future erwin release does expose a shortcut element, and
    so that setting the weight above 0.0 without also naming that element
    cannot quietly introduce a 0% component.

    NOTE on ``pd_count_attr``: ``shortcuts_pd`` is the count of the modeller's
    c:ExternalObjects shortcuts only. The fallback element count behind it
    counts EVERY o:Shortcut in the file -- 3159 in real_estate against 0 real
    ones -- so the two paths disagree by three orders of magnitude. Passing the
    attribute explicitly keeps the reliable one in use.
    """
    return _presence_fidelity(result, config, "SHORTCUT_PD_ELEMENTS",
                              "SHORTCUT_ERWIN_ELEMENTS",
                              pd_count_attr="shortcuts_pd")


def tag_fidelity(result, config=None) -> Optional[float]:
    """Share of SAP PD tags present in the erwin export, or None."""
    return _presence_fidelity(result, config, "TAG_PD_ELEMENTS",
                              "TAG_ERWIN_ELEMENTS")


def hierarchy_fidelity(result, config=None) -> Optional[float]:
    """
    Package/subject-area hierarchy fidelity (Workstream 1), or None when the
    comparator did not run hierarchy reconciliation for this model (the
    weight for this component defaults to 0.0, so it costs nothing until a
    tier both enables ENABLE_HIERARCHY_RECONCILIATION and assigns it a
    positive FIDELITY_STAGE_WEIGHTS entry).
    """
    return getattr(result, "hierarchy_fidelity_pct", None)


def relationship_semantic_fidelity(result, config=None) -> Optional[float]:
    """
    Relationship semantic fidelity (Workstream 5) — identifying/dependency/
    participation agreement — or None when not measured this run.
    """
    return getattr(result, "relationship_semantic_fidelity_pct", None)


def datatype_fidelity(result, config=None) -> Optional[float]:
    """
    Vendor-specific data type fidelity (Workstream 7, PDM only), or None when
    not measured this run.
    """
    return getattr(result, "datatype_fidelity_pct", None)


# ═════════════════════════════════════════════════════════════════════════════
#  Scoring
# ═════════════════════════════════════════════════════════════════════════════

def score(result, stage: str, udp_override=None,
          model_type: str = "", config=None) -> StageScore:
    """
    Measure one result at one stage.  Never raises: an unmeasurable component
    is dropped, and a result with nothing measurable scores 0 with a note.
    """
    stage_score = StageScore(stage=stage)
    try:
        config = config if config is not None else _tier_config(model_type)
        weights = _weights(config)

        measured = {
            COMPONENT_STRUCTURAL: structural_fidelity(result),
            COMPONENT_DOCUMENTATION: documentation_fidelity(result),
            COMPONENT_UDP: udp_fidelity_component(result, udp_override, stage, config),
        }
        # Measured only when the erwin element names are configured and the
        # model carries the construct; None otherwise, so the report can say
        # "not measured" rather than imply zero. Both weights default to 0.0,
        # which _weights() filters out, so this costs nothing until enabled.
        measured[COMPONENT_SHORTCUTS] = shortcut_fidelity(result, config)
        measured[COMPONENT_TAGS] = tag_fidelity(result, config)
        # Workstreams 1/5/7 — each defaults to weight 0.0 in
        # FIDELITY_STAGE_WEIGHTS, so none of these affect fidelity_score
        # unless a tier both enables the underlying check and assigns it a
        # positive weight.
        measured[COMPONENT_HIERARCHY] = hierarchy_fidelity(result, config)
        measured[COMPONENT_RELATIONSHIP_SEMANTIC] = relationship_semantic_fidelity(result, config)
        measured[COMPONENT_DATATYPE] = datatype_fidelity(result, config)
        stage_score.components = measured

        # UNVERIFIED vs NOT APPLICABLE. Both drop the component and both
        # renormalise the weights, so on the score alone they are
        # indistinguishable — which is how a model whose .erwin handoff never
        # happened could score identically to one that migrated perfectly, and
        # be promoted. A model with NO UDPs at all is not applicable and is
        # fine; a model that HAS UDPs whose migration nothing could measure is
        # unverified, and the promotion gate must refuse to pass it.
        if (measured.get(COMPONENT_UDP) is None
                and int(getattr(result, "udp_total", 0) or 0) > 0
                and COMPONENT_UDP in weights):
            stage_score.unverified.append(COMPONENT_UDP)

        applicable = {name: weight for name, weight in weights.items()
                      if measured.get(name) is not None}
        stage_score.weights = applicable
        total_weight = sum(applicable.values())
        if not total_weight:
            stage_score.notes.append("No fidelity component could be measured.")
            return stage_score

        stage_score.overall = round(
            sum(measured[name] * weight for name, weight in applicable.items()) / total_weight, 2)

        # A model with NO UDPs (SAP PD 0 / erwin 0 / matched 0) is scored on the
        # components it does have, with the weights renormalised — the absence
        # of UDPs has no negative effect. NO_UDP_FIDELITY_CAP is opt-in: set it
        # to a float only if you deliberately want such a model held back.
        if not getattr(result, "udp_total", 0):
            cap = _cfg(config, "NO_UDP_FIDELITY_CAP", DEFAULT_NO_UDP_FIDELITY_CAP)
            if cap is not None:
                stage_score.overall = round(min(stage_score.overall, float(cap)), 2)
            else:
                stage_score.notes.append(
                    "No UDPs in either model; the UDP component is not applicable "
                    "and is not counted as a loss.")

        if stage_score.unverified:
            stage_score.notes.append(
                "EXTERNAL_VERIFICATION_REQUIRED: " +
                ", ".join(sorted(stage_score.unverified)) +
                " could not be measured for a model that HAS this metadata. The "
                "score below is computed from the remaining components only and "
                "is NOT complete validation.")
        dropped = [name for name in weights if name not in applicable]
        if dropped:
            stage_score.notes.append(
                f"Not measurable for this model, weights renormalised: {', '.join(sorted(dropped))}.")
        if udp_override is UDP_NOT_MEASURED:
            stage_score.notes.append(
                "UDP component NOT MEASURED at this stage: the erwin XML scored "
                "here carries no UDPs and the UDP injection stage has not run "
                "for this model (see stage_state: UDP = WAITING_FOR_MANUAL_INPUT). "
                "It is dropped and the remaining weights renormalised, rather "
                "than recorded as a measured 0% loss for a stage that has not "
                "happened yet.")
        elif udp_override is not None:
            stage_score.notes.append(
                "UDP component taken from the enriched erwin model read-back.")
        return stage_score
    except Exception as exc:                                   # noqa: BLE001
        logger.warning("Stage scoring failed at %s: %s", stage, exc)
        stage_score.notes.append(f"{type(exc).__name__}: {exc}")
        return stage_score


def apply(result, stage: str, udp_override=None,
          model_type: str = "", config=None) -> StageScore:
    """
    Score a result at one stage and make that the result's fidelity.

    Writes ``fidelity_score`` (so the promotion gate tests the stage score),
    ``fidelity_stage``, ``documentation_fidelity_score`` and a ``stage_scores``
    dict keyed by stage.  ``structural_fidelity_score`` is left exactly as the
    comparator set it.  ERROR results are left alone.
    """
    stage_score = score(result, stage, udp_override, model_type, config)
    if result is None or getattr(result, "status", "") == "ERROR":
        return stage_score
    try:
        history = getattr(result, "stage_scores", None)
        if not isinstance(history, dict):
            history = {}
        history[stage] = stage_score
        result.stage_scores = history
        result.fidelity_stage = stage
        result.fidelity_score = stage_score.overall
        # The PDM flow's gate tests fidelity_score_raw (unrounded, so a single
        # defect cannot vanish into 2dp rounding on a large model). Keep it in
        # step with the staged score, or PDM would still be gated on its
        # structural number while CDM and LDM are gated on V3. The comparator's
        # own reconciliation number stays on structural_fidelity_score.
        if hasattr(result, "fidelity_score_raw"):
            result.fidelity_score_raw = stage_score.overall
        result.documentation_fidelity_score = stage_score.component(COMPONENT_DOCUMENTATION)
        result.udp_stage_fidelity_score = stage_score.component(COMPONENT_UDP)
    except AttributeError as exc:
        logger.warning("Could not stamp stage score onto result: %s", exc)
    return stage_score


def carry_history(source, target) -> None:
    """
    Copy the stages already measured on `source` onto `target`.

    V3 reconciles against a different erwin artefact and therefore produces a
    different ValidationResult object. Without this the V1 and V2 scores would
    be stranded on the earlier results and the progression could not be
    reported. Existing stages on `target` win, so a stage measured on the
    target itself is never overwritten.
    """
    if source is None or target is None or source is target:
        return
    try:
        merged = dict(history(source))
        merged.update(history(target))
        target.stage_scores = merged
    except AttributeError as exc:
        logger.debug("Could not carry stage history: %s", exc)


def history(result) -> Dict[str, StageScore]:
    """Every stage this result has been scored at, keyed V1 / V2 / V3."""
    scores = getattr(result, "stage_scores", None)
    return dict(scores) if isinstance(scores, dict) else {}


def stage_value(result, stage: str) -> Optional[float]:
    """The overall score recorded at one stage, or None if never measured."""
    stage_score = history(result).get(stage)
    return None if stage_score is None else stage_score.overall


__all__ = [
    "StageScore", "STAGES", "STAGE_V1", "STAGE_V2", "STAGE_V3",
    "COMPONENT_STRUCTURAL", "COMPONENT_DOCUMENTATION", "COMPONENT_UDP",
    "COMPONENT_SHORTCUTS", "COMPONENT_TAGS", "COMPONENT_HIERARCHY",
    "COMPONENT_RELATIONSHIP_SEMANTIC", "COMPONENT_DATATYPE", "DEFAULT_WEIGHTS",
    "score", "apply", "history", "carry_history", "stage_value",
    "structural_fidelity", "documentation_fidelity", "documentation_rows",
    "shortcut_fidelity", "tag_fidelity", "hierarchy_fidelity",
    "relationship_semantic_fidelity", "datatype_fidelity",
]

