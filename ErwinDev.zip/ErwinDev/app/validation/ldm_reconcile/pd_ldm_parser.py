import logging
import xml.etree.ElementTree as ET  # nosec B405
from typing import Any, Dict, List, Optional, Tuple

from defusedxml.ElementTree import parse as safe_parse

from app.common import rtf_text
from app.config.validation_config import LDM_CONFIG as config

from . import normalizers
from .cardinality import is_mandatory, normalize_cardinality
from .ldm_model import (
    Attribute,
    BusinessRule,
    Domain,
    Entity,
    Identifier,
    Inheritance,
    LDMModel,
    Package,
    Relationship,
    RelationshipEnd,
)

logger = logging.getLogger(__name__)

TRUE_TOKENS = {"1", "true", "yes", "y", "t"}


# ─── LOW-LEVEL XML HELPERS ────────────────────────────────────────────────────

def _local(tag: Any) -> str:
    """Local name of an element tag, namespace stripped."""
    if not isinstance(tag, str):
        return ""
    return tag.rsplit("}", 1)[-1]


def _children(elem: ET.Element, local_name: str) -> List[ET.Element]:
    """Direct children whose local name matches (namespace-agnostic)."""
    return [child for child in elem if _local(child.tag) == local_name]


def _first_child(elem: ET.Element, *local_names: str) -> Optional[ET.Element]:
    if elem is None:
        return None
    for name in local_names:
        for child in elem:
            if _local(child.tag) == name:
                return child
    return None


def _descendants(elem: ET.Element, local_name: str) -> List[ET.Element]:
    return [node for node in elem.iter() if _local(node.tag) == local_name]


def _attr(elem: ET.Element, *names: str, default: str = "") -> str:
    """
    Value of the first matching ``a:<name>`` child element, falling back to an
    XML attribute of the same name.  Accepts several candidate field names so
    the same helper serves both the CDM-style ``Mandatory`` and the LDM-style
    ``LogicalAttribute.Mandatory`` without the caller needing to know which
    export produced the file.
    """
    for name in names:
        child = _first_child(elem, name)
        if child is not None and child.text and child.text.strip():
            return child.text.strip()
    for name in names:
        value = elem.get(name)
        if value and value.strip():
            return value.strip()
    return default


def _flag(elem: ET.Element, *names: str, default: bool = False) -> bool:
    raw = _attr(elem, *names)
    if not raw:
        return default
    return raw.strip().lower() in TRUE_TOKENS


def _definitions(container: Optional[ET.Element], local_name: str) -> List[ET.Element]:
    """Child objects that are definitions (carry Id), not pointers (carry Ref)."""
    if container is None:
        return []
    return [child for child in _children(container, local_name)
            if child.get("Ref") is None]


def _ref_ids(container: Optional[ET.Element], local_name: Optional[str] = None) -> List[str]:
    """Ref ids of pointer children inside a collection, in declaration order."""
    if container is None:
        return []
    if not local_name:
        return [child.get("Ref") for child in container.iter() if child.get("Ref")]
    return [child.get("Ref") for child in _descendants(container, local_name)
            if child.get("Ref")]


def _first_ref(elem: ET.Element, collection: str, *object_names: str) -> str:
    """First Ref id found under ``elem/<collection>/<object_name>``."""
    container = _first_child(elem, collection)
    if container is None:
        return ""
    if not object_names:
        refs = _ref_ids(container)
        return refs[0] if refs else ""
    for obj_name in object_names:
        refs = _ref_ids(container, obj_name)
        if refs:
            return refs[0]
    refs = _ref_ids(container)
    return refs[0] if refs else ""


# ─── RICH TEXT ────────────────────────────────────────────────────────────────
#
# The RTF tokenizer that used to live here is now app/common/rtf_text.py, so
# the CDM and PDM tiers normalise SAP PD rich text with the SAME code instead
# of three regex chains that disagreed with it (and with each other) about
# smart quotes, escaped backslashes and font tables. Nothing about the
# behaviour on this tier changed — the module IS this implementation, moved.
# The private alias is kept because it is the name this module's callers and
# its regression tests already use.
_strip_rtf = rtf_text.strip_rtf




def _pd_comment(elem: ET.Element) -> str:
    """SAP PD <a:Comment> - the field that maps to an erwin Note."""
    return _strip_rtf(_attr(elem, "Comment"))


def _pd_definition(elem: ET.Element) -> str:
    """
    SAP PD <a:Description> - the Description sub-tab of the Definition tab.
    This is the field that maps to an erwin Definition.

    Annotation is NOT accepted as a fallback here. The two sub-tabs land in
    different erwin fields (Description -> Definition, Annotation -> Extended
    Notes), so folding them together labelled an Annotation as a Description
    and then reported it lost, because erwin's Definition was legitimately
    empty. ``_pd_annotation`` carries Annotation on its own mapping instead.
    """
    return _strip_rtf(_attr(elem, "Description"))


def _pd_annotation(elem: ET.Element) -> str:
    """SAP PD <a:Annotation> - the field that maps to erwin Extended Notes."""
    return _strip_rtf(_attr(elem, "Annotation"))


#: The SAP PD fields that can hold a business definition, in the order the
#: framework accepts them. Kept as a named constant so the resolver and the
#: provenance reporter can never disagree about the order.
PD_DEFINITION_FIELDS = ("Comment", "Description", "Annotation", "Definition")


def _description_with_field(elem: ET.Element):
    """
    (text, field_name) for the SAP PD business definition.

    PowerDesigner splits business meaning across Comment, Description and
    Annotation depending on how the modeller worked, so all are accepted —
    but WHICH one supplied the text is evidence, not an implementation
    detail. Without it the framework could compare a PD *Description*
    against an erwin *Note* and report a plain "definition matches", which
    is how definition, comment and note quietly became interchangeable.
    Returning the field name lets the finding say what was actually compared.
    """
    for field_name in PD_DEFINITION_FIELDS:
        value = _attr(elem, field_name)
        if value:
            return _strip_rtf(value), field_name
    return "", ""


def _description(elem: ET.Element) -> str:
    """Definition text only; see _description_with_field for its provenance."""
    return _description_with_field(elem)[0]


# ─── DOMAINS ──────────────────────────────────────────────────────────────────

def _parse_domain(elem: ET.Element) -> Domain:
    return Domain(
        oid        = elem.get("Id", ""),
        name       = _attr(elem, "Name"),
        code       = _attr(elem, "Code") or _attr(elem, "Name"),
        data_type  = _attr(elem, "DataType"),
        length     = _attr(elem, "Length"),
        precision  = _attr(elem, "Precision"),
        definition = _description(elem),
        definition_field = _description_with_field(elem)[1],
    )


# ─── ATTRIBUTES ───────────────────────────────────────────────────────────────

def _parse_attribute(elem: ET.Element,
                     order: int,
                     domains_by_oid: Dict[str, Domain]) -> Attribute:
    name = _attr(elem, "Name")
    code = _attr(elem, "Code")

    data_type = _attr(elem, "DataType")
    length    = _attr(elem, "Length")
    precision = _attr(elem, "Precision")
    definition, definition_field = _description_with_field(elem)

    domain_name = ""
    domain_oid = _first_ref(elem, "Domain", "Domain")
    if domain_oid and domain_oid in domains_by_oid:
        domain = domains_by_oid[domain_oid]
        domain_name = domain.name or domain.code
        if not data_type:
            data_type = domain.data_type
            length    = length    or domain.length
            precision = precision or domain.precision

    name = name or code
    code = code or name

    # LDM writes the mandatory flag as <a:LogicalAttribute.Mandatory> — a
    # different element name from a CDM's <a:Mandatory>.  Both are accepted so
    # a hand-edited or downgraded export still parses correctly.
    mandatory = _flag(elem, "LogicalAttribute.Mandatory", "Mandatory")

    return Attribute(
        oid          = elem.get("Id", ""),
        name         = name,
        code         = code,
        data_type    = data_type,
        length       = length,
        precision    = precision,
        mandatory    = mandatory,
        is_primary   = _flag(elem, "PrimaryIdentifier"),
        domain       = domain_name,
        definition   = definition,
        definition_field = definition_field,
        # report-only; does not affect any comparison
        doc_comment    = _pd_comment(elem),
        doc_definition = _pd_definition(elem),
        doc_annotation = _pd_annotation(elem),
        multiplicity = _attr(elem, "Multiplicity"),
        order        = order,
    )


# ─── IDENTIFIERS ──────────────────────────────────────────────────────────────

def _parse_identifier(elem: ET.Element,
                      attr_code_by_oid: Dict[str, str]) -> Identifier:
    container = _first_child(elem, "Identifier.Attributes", "Attributes")
    member_oids = _ref_ids(container, "EntityAttribute")

    columns = [attr_code_by_oid.get(oid, oid) for oid in member_oids]

    return Identifier(
        oid        = elem.get("Id", ""),
        name       = _attr(elem, "Name"),
        code       = _attr(elem, "Code") or _attr(elem, "Name"),
        is_primary = False,          # set by the caller from c:PrimaryIdentifier
        attributes = [c for c in columns if c],
    )


# ─── ENTITIES ─────────────────────────────────────────────────────────────────

def _parse_entity_attributes(elem: ET.Element, entity: Entity,
                             domains_by_oid: Dict[str, Domain]) -> Dict[str, str]:
    """Parse and append attributes; return an oid→code map for identifiers."""
    attr_container = _first_child(elem, "Attributes")
    attr_code_by_oid: Dict[str, str] = {}

    for index, attr_elem in enumerate(_definitions(attr_container, "EntityAttribute"), start=1):
        attribute = _parse_attribute(attr_elem, index, domains_by_oid)
        if normalizers.is_excluded_attribute(attribute.name, attribute.code):
            continue
        entity.attributes.append(attribute)
        if attribute.oid:
            attr_code_by_oid[attribute.oid] = attribute.code
    return attr_code_by_oid


def _parse_entity_identifiers(elem: ET.Element, entity: Entity,
                              attr_code_by_oid: Dict[str, str]) -> Dict[str, Identifier]:
    ident_container = _first_child(elem, "Identifiers")
    identifiers_by_oid: Dict[str, Identifier] = {}

    for ident_elem in _definitions(ident_container, "Identifier"):
        identifier = _parse_identifier(ident_elem, attr_code_by_oid)
        entity.identifiers.append(identifier)
        if identifier.oid:
            identifiers_by_oid[identifier.oid] = identifier
    return identifiers_by_oid


def _resolve_primary_identifier(elem: ET.Element, entity: Entity,
                                identifiers_by_oid: Dict[str, Identifier]) -> None:
    # The primary identifier is a pointer (c:PrimaryIdentifier), not a flag on
    # the identifier itself — confirmed present on every entity in the file.
    primary_oid = _first_ref(elem, "PrimaryIdentifier", "Identifier")
    if primary_oid and primary_oid in identifiers_by_oid:
        identifiers_by_oid[primary_oid].is_primary = True
    elif entity.identifiers:
        _infer_primary_from_attributes(entity)


def _infer_primary_from_attributes(entity: Entity) -> None:
    primary_attrs = {a.code.upper() for a in entity.attributes if a.is_primary}
    if not primary_attrs:
        return
    for identifier in entity.identifiers:
        if {c.upper() for c in identifier.attributes} == primary_attrs:
            identifier.is_primary = True
            break


def _mark_primary_attributes(entity: Entity) -> None:
    primary = entity.primary_identifier
    if not primary:
        return
    members = {c.upper() for c in primary.attributes}
    for attribute in entity.attributes:
        if attribute.code.upper() in members:
            attribute.is_primary = True


def _parse_entity(elem: ET.Element,
                  subject_area: str,
                  domains_by_oid: Dict[str, Domain]) -> Entity:
    name = _attr(elem, "Name")
    code = _attr(elem, "Code") or name

    entity = Entity(
        oid          = elem.get("Id", ""),
        name         = name,
        code         = code,
        definition   = _description(elem),
        definition_field = _description_with_field(elem)[1],
        # report-only; does not affect any comparison
        doc_comment    = _pd_comment(elem),
        doc_definition = _pd_definition(elem),
        doc_annotation = _pd_annotation(elem),
        subject_area = subject_area,
    )

    attr_code_by_oid = _parse_entity_attributes(elem, entity, domains_by_oid)
    identifiers_by_oid = _parse_entity_identifiers(elem, entity, attr_code_by_oid)
    _resolve_primary_identifier(elem, entity, identifiers_by_oid)
    _mark_primary_attributes(entity)

    return entity


# ─── RELATIONSHIPS ────────────────────────────────────────────────────────────

def _build_relationship_end(elem: ET.Element, entity_code_by_oid: Dict[str, str],
                            oid: str, role_attr: str, card_attr: str,
                            mand_attr: str, default_many: bool) -> RelationshipEnd:
    mandatory_flag = _flag(elem, mand_attr)
    end = RelationshipEnd(
        entity      = entity_code_by_oid.get(oid, oid or "UNKNOWN"),
        role        = _attr(elem, role_attr),
        cardinality = normalize_cardinality(_attr(elem, card_attr), mandatory=mandatory_flag),
        mandatory   = mandatory_flag,
        dependent   = False,
    )
    if not end.cardinality:
        end.cardinality = normalize_cardinality("", mandatory=mandatory_flag, many=default_many)
    # PowerDesigner LDM exports normally omit the explicit ...RoleMandatory
    # flag and express participation purely through the cardinality's lower
    # bound ("1..1", "1..n").  The erwin parser derives `mandatory` from the
    # lower bound, so derive it the same way here; otherwise every PD end
    # reads as optional and the semantic scorer reports a participation
    # mismatch on every mandatory relationship in the model.
    end.mandatory = bool(mandatory_flag) or is_mandatory(end.cardinality)
    return end


def _dependent_end_from_role(elem: ET.Element) -> int:
    """
    Which end PowerDesigner marks as dependent via <a:DependentRole>, or 0.

    The LDM export stores the dependent side as the role letter "A" / "B"
    rather than as a per-end boolean; the letter-to-end mapping is
    configurable (PD_DEPENDENT_ROLE_ENDS) and defaults to the convention
    verified against erwin's own Type=2 (identifying) flag.
    """
    letter = _attr(elem, "DependentRole").strip().upper()
    if not letter:
        return 0
    mapping = getattr(config, "PD_DEPENDENT_ROLE_ENDS", {"B": 1, "A": 2}) or {}
    try:
        return int(mapping.get(letter, 0))
    except (TypeError, ValueError):
        return 0


def _resolve_parent_child_oids(elem: ET.Element, oid1: str, oid2: str,
                               identifier_owner_by_oid: Dict[str, str]) -> Tuple[str, str]:
    """Return (parent_entity_oid, child_entity_oid) or ('', '') when unknown."""
    parent_ident_oid = _first_ref(elem, "ParentIdentifier", "Identifier")
    parent_entity_oid = identifier_owner_by_oid.get(parent_ident_oid, "")
    if parent_entity_oid == oid1:
        return parent_entity_oid, oid2
    if parent_entity_oid == oid2:
        return parent_entity_oid, oid1
    return parent_entity_oid, ""


def _pk_codes_overlap(entities_by_oid: Dict[str, Entity],
                      parent_entity_oid: str, child_entity_oid: str) -> bool:
    """True when the child's PK shares any attribute code with the parent's PK."""
    parent_entity = entities_by_oid.get(parent_entity_oid)
    child_entity  = entities_by_oid.get(child_entity_oid)
    parent_pk = parent_entity.primary_identifier if parent_entity else None
    child_pk  = child_entity.primary_identifier if child_entity else None
    if not (parent_pk and child_pk):
        return False
    parent_codes = {c.upper() for c in parent_pk.attributes}
    child_codes  = {c.upper() for c in child_pk.attributes}
    return bool(parent_codes & child_codes)


def _apply_identifying(elem: ET.Element, oid1: str, oid2: str,
                       end1: RelationshipEnd, end2: RelationshipEnd,
                       entities_by_oid: Dict[str, Entity],
                       identifier_owner_by_oid: Dict[str, str]) -> bool:
    """
    Decide whether the relationship is identifying and set the dependent flag on
    the child end.  Returns the identifying verdict.
    """
    # PowerDesigner's own declaration wins when present: <a:DependentRole>
    # is written only on relationships the modeller marked as dependent
    # (identifying).  The PK-overlap heuristic below cannot work on a model
    # whose entities carry no primary identifiers at all (the Vessel LDM has
    # none), which left every PD relationship non-identifying while erwin
    # exported five of them as Type=2.
    declared_end = _dependent_end_from_role(elem)
    if declared_end == 1:
        end1.dependent = True
        return True
    if declared_end == 2:
        end2.dependent = True
        return True

    parent_entity_oid, child_entity_oid = _resolve_parent_child_oids(
        elem, oid1, oid2, identifier_owner_by_oid)
    if not (parent_entity_oid and child_entity_oid):
        return False

    identifying = _pk_codes_overlap(entities_by_oid, parent_entity_oid, child_entity_oid)
    if child_entity_oid == oid1:
        end1.dependent = identifying
    else:
        end2.dependent = identifying
    return identifying


def _parse_relationship(elem: ET.Element,
                        entity_code_by_oid: Dict[str, str],
                        entities_by_oid: Dict[str, Entity],
                        identifier_owner_by_oid: Dict[str, str]) -> Relationship:
    """
    Build a canonical Relationship from an o:Relationship element.

    Convention (confirmed against SD_O2C_LDM_WC.ldm):
    ``Entity1ToEntity2RoleCardinality`` is stored on end 1 and states how many
    *end 2* instances relate to one end 1 instance.  The canonical model
    preserves that convention exactly so the erwin parser can align to it.

    Identifying-ness (verified against the real file, not assumed):
    ``c:ParentIdentifier`` is present on EVERY relationship in this LDM — it
    names which identifier of the "one" side the join uses, not whether the
    relationship is identifying. The actual, verified signal is whether the
    CHILD entity's own primary identifier contains attribute(s) inherited
    from the PARENT entity's primary identifier (i.e. the foreign key was
    migrated into the child's own identity, not just into its attribute
    list). Cross-checked against the erwin side's Relationship <Type> for
    every one of the 10 relationships in this model with 100% agreement:
    exactly the 3 relationships where this condition holds are erwin Type=2
    (IDENTIFYING); the other 7 are erwin Type=7 (NON_IDENTIFYING).
    """
    oid1 = _first_ref(elem, "Object1", "Entity", "Shortcut", "Association")
    oid2 = _first_ref(elem, "Object2", "Entity", "Shortcut", "Association")

    end1 = _build_relationship_end(
        elem, entity_code_by_oid, oid1, "Entity1ToEntity2Role",
        "Entity1ToEntity2RoleCardinality", "Entity1ToEntity2RoleMandatory",
        default_many=True)
    end2 = _build_relationship_end(
        elem, entity_code_by_oid, oid2, "Entity2ToEntity1Role",
        "Entity2ToEntity1RoleCardinality", "Entity2ToEntity1RoleMandatory",
        default_many=False)

    identifying = _apply_identifying(
        elem, oid1, oid2, end1, end2, entities_by_oid, identifier_owner_by_oid)

    return Relationship(
        oid         = elem.get("Id", ""),
        name        = _attr(elem, "Name"),
        code        = _attr(elem, "Code") or _attr(elem, "Name"),
        definition  = _description(elem),
        end1        = end1,
        end2        = end2,
        kind        = "RELATIONSHIP",
        identifying = identifying,
    )


# ─── INHERITANCES ─────────────────────────────────────────────────────────────

def _parse_inheritance(elem: ET.Element,
                       entity_code_by_oid: Dict[str, str]) -> Inheritance:
    parent_oid = (_first_ref(elem, "ParentEntity", "Entity")
                  or _first_ref(elem, "Object1", "Entity"))

    child_oids: List[str] = []
    children_container = _first_child(elem, "Children")
    link_scope = children_container if children_container is not None else elem

    for link in _descendants(link_scope, "InheritanceLink"):
        oid = (_first_ref(link, "Object2", "Entity")
               or _first_ref(link, "ChildEntity", "Entity")
               or _first_ref(link, "Object1", "Entity"))
        if oid and oid != parent_oid:
            child_oids.append(oid)

    if not child_oids and children_container is not None:
        child_oids = [oid for oid in _ref_ids(children_container, "Entity")
                      if oid != parent_oid]

    return Inheritance(
        oid      = elem.get("Id", ""),
        name     = _attr(elem, "Name"),
        code     = _attr(elem, "Code") or _attr(elem, "Name"),
        parent   = entity_code_by_oid.get(parent_oid, parent_oid or "UNKNOWN"),
        children = [entity_code_by_oid.get(oid, oid) for oid in child_oids],
        complete = _flag(elem, "Complete"),
        mutually_exclusive = _flag(elem, "MutuallyExclusive", default=True),
        generate_parent    = _flag(elem, "GenerateParent", default=True),
    )


# ─── BUSINESS RULES ───────────────────────────────────────────────────────────

def _parse_business_rule(elem: ET.Element) -> BusinessRule:
    return BusinessRule(
        oid        = elem.get("Id", ""),
        name       = _attr(elem, "Name"),
        code       = _attr(elem, "Code") or _attr(elem, "Name"),
        rule_type  = _attr(elem, "RuleType") or _attr(elem, "Type"),
        expression = (_attr(elem, "ServerExpression")
                      or _attr(elem, "ClientExpression")
                      or _attr(elem, "Expression")),
        definition = _description(elem),
        definition_field = _description_with_field(elem)[1],
    )


# ─── SCOPE WALKER ─────────────────────────────────────────────────────────────

def _walk_scope(scope: ET.Element,
                subject_area: str,
                model: LDMModel,
                domains_by_oid: Dict[str, Domain],
                entity_elements: List[tuple]) -> None:
    """
    Collect entity elements from a model or package scope, recursing into
    nested packages so subject-area membership and package hierarchy are preserved.
    """
    entity_container = _first_child(scope, "Entities")
    pkg_entities = []
    for entity_elem in _definitions(entity_container, "Entity"):
        entity_elements.append((entity_elem, subject_area))
        ename = _attr(entity_elem, "Code") or _attr(entity_elem, "Name")
        if ename:
            pkg_entities.append(ename)

    package_container = _first_child(scope, "Packages")
    for package_elem in _definitions(package_container, "Package"):
        package_name = _attr(package_elem, "Name") or _attr(package_elem, "Code")
        if package_name and package_name not in model.subject_areas:
            model.subject_areas.append(package_name)

        pkg_obj = Package(
            oid=_attr(package_elem, "Id") or package_elem.get("Id", ""),
            name=_attr(package_elem, "Name"),
            code=_attr(package_elem, "Code") or _attr(package_elem, "Name"),
            parent=subject_area,
            definition=_description(package_elem),
            definition_field=_description_with_field(package_elem)[1],
        )
        model.packages.append(pkg_obj)
        _walk_scope(package_elem, package_name, model, domains_by_oid, entity_elements)


# ─── PUBLIC API ───────────────────────────────────────────────────────────────


# PowerDesigner class GUIDs a shortcut can point at.  Only the ones seen in
# real estates are named; anything else renders as "Object" (still reported).
_SHORTCUT_TARGET_CLASSES = {
    "186C8AC3-D3DC-11D3-881C-00508B03C75C": "Model",
    "CD2F5C71-2CA9-4B74-9BBA-50786D1D88EF": "Category",
    "EBE946CF-7218-4FAC-B85E-4AB922930494": "Term",
}

# A model file contains <o:Shortcut> elements in three different collections,
# and only ONE of them is what PowerDesigner shows in Model Properties →
# "List of Shortcuts":
#
#   c:ExternalObjects          ← THE list of shortcuts (what the modeller made)
#   c:TermObjects              glossary terminology links, created automatically
#                              when a glossary is attached; PD does not list
#                              these as shortcuts and neither do we
#   c:ExtendedModelDefinitions the .xem extension reference (e.g. "BIM-core")
#
# Counting all three is what made a model with an EMPTY List of Shortcuts
# report dozens of them.  The census therefore reads c:ExternalObjects only,
# so the report's count always equals the number of rows the modeller sees.
_SHORTCUT_COLLECTION = "ExternalObjects"


def _collect_shortcut_target_models(model_elem: ET.Element) -> Tuple[Dict[str, str], str]:
    """
    Resolve shortcut owner models.  Returns (claimed_by_oid, fallback_model).

    PD resolves the "Target Model" column through the repository, which a
    single file cannot do.  Two things are available here: shortcuts a
    <o:TargetModel> block claims explicitly, and — failing that — the one
    attached model that is not the .xem extension, which is the owner whenever
    a model attaches a single shared model (the usual case).
    """
    claimed: Dict[str, str] = {}
    attached: List[str] = []
    for tm in _descendants(model_elem, "TargetModel"):
        if tm.get("Ref") is not None or not tm.get("Id"):
            continue
        tm_name = _attr(tm, "Name") or _attr(tm, "Code")
        if not _attr(tm, "TargetModelURL").lower().endswith(".xem"):
            attached.append(tm_name)
        for ref in _descendants(tm, "Shortcut"):
            oid = ref.get("Ref")
            if oid:
                claimed[oid] = tm_name
    fallback_model = attached[0] if len(attached) == 1 else ""
    return claimed, fallback_model


def _shortcut_row(elem: ET.Element, claimed: Dict[str, str],
                  fallback_model: str) -> Dict[str, str]:
    class_id = _attr(elem, "TargetClassID").upper()
    return {
        "name": _attr(elem, "Name"),
        "code": _attr(elem, "Code") or _attr(elem, "Name"),
        "type": _SHORTCUT_TARGET_CLASSES.get(class_id, "Object"),
        "target_model": claimed.get(elem.get("Id", ""), fallback_model),
        "target_package": _attr(elem, "TargetPackagePath"),
        "target_stereotype": _attr(elem, "TargetStereotype"),
    }


def _parse_shortcuts(model_elem: ET.Element, model,
                     entity_code_by_oid: Optional[Dict[str, str]] = None,
                     entities_by_oid: Optional[Dict[str, Entity]] = None) -> None:
    """
    Collect PowerDesigner's "List of Shortcuts" — references to objects OWNED
    BY ANOTHER MODEL (a glossary category, an entity of a shared model).

    A model with no shortcuts yields an empty list, and the report then says
    nothing about shortcuts at all — which is the correct answer for it.
    """
    container = _first_child(model_elem, _SHORTCUT_COLLECTION)
    if container is None:
        return

    claimed, fallback_model = _collect_shortcut_target_models(model_elem)

    for elem in container:
        if elem.tag.rsplit("}", 1)[-1] != "Shortcut":
            continue
        if elem.get("Ref") is not None or not elem.get("Id"):
            continue
        s_row = _shortcut_row(elem, claimed, fallback_model)
        model.shortcuts.append(s_row)
        s_oid = elem.get("Id", "")
        s_code = s_row.get("code", "")
        s_name = s_row.get("name", "")
        if entity_code_by_oid is not None and s_oid:
            entity_code_by_oid[s_oid] = s_code or s_name
        if entities_by_oid is not None and s_oid:
            entities_by_oid[s_oid] = Entity(oid=s_oid, name=s_name, code=s_code)


def _parse_ldm_header(root: ET.Element, model_elem: ET.Element, model: LDMModel) -> None:
    model.model_name = _attr(model_elem, "Name") or _attr(root, "Name")
    model.model_code = _attr(model_elem, "Code") or model.model_name
    declared_type = _attr(model_elem, "ModelType")
    if declared_type:
        model.model_type = declared_type


def _parse_ldm_domains(model_elem: ET.Element, model: LDMModel,
                       domains_by_oid: Dict[str, Domain]) -> None:
    for elem in _descendants(model_elem, "Domain"):
        if elem.get("Ref") is not None or not elem.get("Id"):
            continue
        domain = _parse_domain(elem)
        domains_by_oid[domain.oid] = domain
        key = (domain.code or domain.name).upper()
        if key:
            model.domains[key] = domain


def _collect_entity_elements(root: ET.Element, model_elem: ET.Element,
                             model: LDMModel,
                             domains_by_oid: Dict[str, Domain]) -> List[tuple]:
    """Gather (entity_elem, subject_area) pairs, with a non-standard fallback."""
    entity_elements: List[tuple] = []
    _walk_scope(model_elem, "", model, domains_by_oid, entity_elements)

    if entity_elements:
        return entity_elements

    seen_ids = set()
    for elem in _descendants(root, "Entity"):
        if elem.get("Ref") is not None or not elem.get("Id"):
            continue
        if elem.get("Id") in seen_ids:
            continue
        seen_ids.add(elem.get("Id"))
        entity_elements.append((elem, ""))
    if entity_elements:
        model.parse_warnings.append(
            "Entities found outside the expected c:Entities collection — "
            "file may be a non-standard export."
        )
    return entity_elements


def _register_entity_lookups(entity: Entity,
                             entity_code_by_oid: Dict[str, str],
                             entities_by_oid: Dict[str, Entity],
                             identifier_owner_by_oid: Dict[str, str]) -> None:
    if not entity.oid:
        return
    entity_code_by_oid[entity.oid] = entity.code
    entities_by_oid[entity.oid] = entity
    for identifier in entity.identifiers:
        if identifier.oid:
            identifier_owner_by_oid[identifier.oid] = entity.oid


def _parse_ldm_entities(entity_elements: List[tuple], model: LDMModel,
                        domains_by_oid: Dict[str, Domain],
                        entity_code_by_oid: Dict[str, str],
                        entities_by_oid: Dict[str, Entity],
                        identifier_owner_by_oid: Dict[str, str]) -> None:
    seen_entity_ids: set = set()
    for entity_elem, subject_area in entity_elements:
        elem_id = entity_elem.get("Id")
        if elem_id:
            if elem_id in seen_entity_ids:
                continue
            seen_entity_ids.add(elem_id)

        entity = _parse_entity(entity_elem, subject_area, domains_by_oid)
        if normalizers.is_excluded_entity(entity.name, entity.code):
            continue

        model.add_entity(entity)
        _register_entity_lookups(entity, entity_code_by_oid,
                                 entities_by_oid, identifier_owner_by_oid)


def _parse_ldm_relationships(model_elem: ET.Element, model: LDMModel,
                             entity_code_by_oid: Dict[str, str],
                             entities_by_oid: Dict[str, Entity],
                             identifier_owner_by_oid: Dict[str, str]) -> None:
    for elem in _descendants(model_elem, "Relationship"):
        if elem.get("Ref") is not None or not elem.get("Id"):
            continue
        model.relationships.append(
            _parse_relationship(elem, entity_code_by_oid, entities_by_oid,
                               identifier_owner_by_oid)
        )


def _collect_inheritance_children(model_elem: ET.Element) -> Dict[str, List[str]]:
    children_by_inheritance: Dict[str, List[str]] = {}
    for link in _descendants(model_elem, "InheritanceLink"):
        if link.get("Ref") is not None:
            continue
        owner = _first_ref(link, "Object1", "Inheritance")
        child = _first_ref(link, "Object2", "Entity")
        if owner and child:
            children_by_inheritance.setdefault(owner, []).append(child)
    return children_by_inheritance


def _parse_ldm_inheritances(model_elem: ET.Element, model: LDMModel,
                            entity_code_by_oid: Dict[str, str]) -> None:
    children_by_inheritance = _collect_inheritance_children(model_elem)

    for elem in _descendants(model_elem, "Inheritance"):
        if elem.get("Ref") is not None or not elem.get("Id"):
            continue
        inheritance = _parse_inheritance(elem, entity_code_by_oid)
        if not inheritance.children:
            linked = children_by_inheritance.get(elem.get("Id", ""), [])
            inheritance.children = [entity_code_by_oid.get(oid, oid) for oid in linked
                                    if entity_code_by_oid.get(oid, oid) != inheritance.parent]
        if inheritance.parent and inheritance.children:
            model.inheritances.append(inheritance)


def _parse_ldm_business_rules(model_elem: ET.Element, model: LDMModel) -> None:
    for elem in _descendants(model_elem, "BusinessRule"):
        if elem.get("Ref") is not None or not elem.get("Id"):
            continue
        model.business_rules.append(_parse_business_rule(elem))


def parse_ldm(filepath: str) -> LDMModel:
    """
    Parse a PowerDesigner .ldm file into an :class:`LDMModel`.

    Never raises for malformed input: a parse failure is recorded on the
    returned model so a single bad file cannot abort a large batch.
    """
    model = LDMModel(source_file=filepath, source_tool="PowerDesigner",
                     model_type="Logical")

    try:
        root = safe_parse(filepath).getroot()
    except ET.ParseError as exc:
        logger.error("XML parse error in %s: %s", filepath, exc)
        model.parse_error = f"XML parse error: {exc}"
        return model
    except OSError as exc:
        logger.error("Cannot read %s: %s", filepath, exc)
        model.parse_error = f"File read error: {exc}"
        return model

    model_elements = [node for node in _descendants(root, "Model")
                      if node.get("Ref") is None and node.get("Id")]
    model_elem = model_elements[0] if model_elements else root

    _parse_ldm_header(root, model_elem, model)

    domains_by_oid: Dict[str, Domain] = {}
    _parse_ldm_domains(model_elem, model, domains_by_oid)

    entity_code_by_oid: Dict[str, str] = {}
    entities_by_oid: Dict[str, Entity] = {}
    identifier_owner_by_oid: Dict[str, str] = {}

    _parse_shortcuts(model_elem, model, entity_code_by_oid, entities_by_oid)

    entity_elements = _collect_entity_elements(root, model_elem, model, domains_by_oid)

    _parse_ldm_entities(entity_elements, model, domains_by_oid,
                        entity_code_by_oid, entities_by_oid, identifier_owner_by_oid)

    _parse_ldm_relationships(model_elem, model, entity_code_by_oid,
                             entities_by_oid, identifier_owner_by_oid)
    _parse_ldm_inheritances(model_elem, model, entity_code_by_oid)
    _parse_ldm_business_rules(model_elem, model)

    logger.debug("Parsed %s -> %s", filepath, model.stats())
    return model
