"""
documentation.py — Comments → Notes and Definition → Definition mapping
=======================================================================

Builds the rows behind the CDM report's DESCRIPTION sheet.

WHY THIS IS SEPARATE FROM THE COMPARATOR
----------------------------------------
The comparator's DEFINITION check reads a single ``definition`` string that
each parser resolves by first-match-wins across several source fields.  That
behaviour is deliberately left untouched here so every existing CDM finding,
the fidelity score and the PASS/WARN/FAIL status stay exactly as they were.

This module answers a different question, one the findings list cannot: for
every object, *which specific field* holds the documentation on each side, did
it survive the migration, and what does each side actually say?  It reports
matches as well as mismatches — a findings list only ever shows what went
wrong, so there was previously no way to tell "verified identical" apart from
"never checked".

THE THREE MAPPINGS
------------------
    SAP PD <a:Comment>      →  erwin Note_List_Array/Note_List  (field 6)
    SAP PD <a:Description>  →  erwin <Definition>
    SAP PD <a:Annotation>   →  erwin Extended_Notes  (…/Extended_NotesProps/Comment)

These are the pairings confirmed in the two tools' UIs, and each is validated
against the field the text is actually visible in.

The first is the pairing the framework's preprocessing stage creates:
``app/preprocessing/scripts/pd_comment_to_erwin_note.py`` writes each PD
Comment into an erwin Note.  Reporting on it is how you confirm preprocessing
actually landed, per object, rather than trusting the run log.  erwin's own
Comment field also receives the PD Comment during import, but Notes is the
carrier the erwin UI shows, so Notes is what is validated here.

The last two are the two sub-tabs of PowerDesigner's Definition tab, and they
land in DIFFERENT erwin fields.  They are reported separately because folding
Annotation into Description (the parser's previous fallback) labelled an
Annotation as a Description and then reported it lost, when erwin had in fact
carried it correctly into Extended Notes.

STATUS VALUES
-------------
    MATCHED             both sides carry equivalent text
    MISMATCH            both sides populated, text differs
    MISSING_IN_ERWIN    SAP PD has text, erwin does not  ← migration loss
    MISSING_IN_SAP_PD   erwin has text, SAP PD does not  ← added downstream
    BOTH_EMPTY          neither side documents the object

Equivalence uses the same ``normalizers.definitions_match`` the comparator
uses, so this sheet and the DEFINITION findings agree on what "same" means.
"""

from dataclasses import dataclass
from typing import Dict, List, Optional

from app.validation import comment_resolution_engine

from . import normalizers

# ─── STATUS CONSTANTS ─────────────────────────────────────────────────────────
MATCHED = "MATCHED"
MISMATCH = "MISMATCH"
MISSING_IN_ERWIN = "MISSING_IN_ERWIN"
MISSING_IN_SAP_PD = "MISSING_IN_SAP_PD"
BOTH_EMPTY = "BOTH_EMPTY"

# Mapping identifiers, used as the "Mapping" column value.
# Longest text written into a report cell before truncation.
VALUE_DISPLAY_LIMIT = 500

COMMENT_TO_NOTE = "Comment → Note"
DESCRIPTION_TO_DEFINITION = "Description → Definition"
ANNOTATION_TO_EXTENDED_NOTES = "Annotation → Extended Notes"


@dataclass
class DocumentationRow:
    """One object, one mapping, both sides."""
    model: str = ""
    object_type: str = ""          # ENTITY | ATTRIBUTE
    object_name: str = ""          # entity name, or "Entity.Attribute"
    object_code: str = ""
    mapping: str = ""              # one of the COMMENT_/DEFINITION_ constants
    source_field: str = ""         # e.g. "SAP PD Comment"
    target_field: str = ""         # e.g. "erwin Note"
    source_value: str = ""
    target_value: str = ""
    status: str = ""
    similarity: float = 0.0        # 0-100, only meaningful when both populated
    # Comment -> Note fallback resolution (Tasks 5/6): where the text was
    # actually found when it was not in the primary target field, and why a
    # genuinely missing comment is missing. Blank for every other mapping.
    located_in: str = ""
    root_cause: str = ""

    @property
    def is_problem(self) -> bool:
        return self.status in (MISMATCH, MISSING_IN_ERWIN, MISSING_IN_SAP_PD)


# ─── COMPARISON ───────────────────────────────────────────────────────────────

def _classify(source_text: str, target_text: str) -> tuple:
    """Return (status, similarity) for one side-by-side pair."""
    source_text = (source_text or "").strip()
    target_text = (target_text or "").strip()

    if not source_text and not target_text:
        return BOTH_EMPTY, 0.0
    if source_text and not target_text:
        return MISSING_IN_ERWIN, 0.0
    if target_text and not source_text:
        return MISSING_IN_SAP_PD, 0.0

    if normalizers.definitions_match(source_text, target_text):
        return MATCHED, 100.0

    similarity = normalizers.definition_similarity(source_text, target_text)
    return MISMATCH, round(similarity * 100, 2)


def _resolve_comment_fallback(source_text: str, target_text: str,
                              erwin_object) -> tuple:
    """
    A Comment -> Note mapping that reads MISSING_IN_ERWIN may still have the
    text in erwin's Definition or Extended Notes field instead. Returns
    (status, similarity, located_in, root_cause); status/similarity are the
    inputs unchanged when nothing resolves the gap.
    """
    resolution = comment_resolution_engine.classify(
        source_text, target_text,
        definition=getattr(erwin_object, "doc_definition", "") if erwin_object else "",
        property_text=getattr(erwin_object, "doc_extended_notes", "") if erwin_object else "",
    )
    if resolution.located:
        return MATCHED, 100.0, resolution.located_in, resolution.root_cause
    return MISSING_IN_ERWIN, 0.0, resolution.located_in, resolution.root_cause


def _row(model: str, object_type: str, object_name: str, object_code: str,
         mapping: str, source_field: str, target_field: str,
         source_text: str, target_text: str, *, erwin_object=None) -> DocumentationRow:
    status, similarity = _classify(source_text, target_text)
    located_in, root_cause = "", ""
    if mapping == COMMENT_TO_NOTE and status == MISSING_IN_ERWIN:
        status, similarity, located_in, root_cause = _resolve_comment_fallback(
            source_text, target_text, erwin_object)
    return DocumentationRow(
        model=model,
        object_type=object_type,
        object_name=object_name,
        object_code=object_code,
        mapping=mapping,
        source_field=source_field,
        target_field=target_field,
        source_value=normalizers.truncate(source_text or "", VALUE_DISPLAY_LIMIT),
        target_value=normalizers.truncate(target_text or "", VALUE_DISPLAY_LIMIT),
        status=status,
        similarity=similarity,
        located_in=located_in,
        root_cause=root_cause,
    )


def _pairs_for(pd_object, erwin_object) -> List[tuple]:
    """
    The three mappings for one matched object, as
    (mapping, source_field, target_field, source_text, target_text).

    These are the mappings confirmed at the UI level between the two tools:

        SAP PD Comment      →  erwin Note            (Notes tab)
        SAP PD Description  →  erwin Definition      (Definition tab)
        SAP PD Annotation   →  erwin Extended Notes  (Extended Notes tab)

    The Comment → Note pairing is the one the framework's preprocessing stage
    creates (``app/preprocessing/scripts/pd_comment_to_erwin_note.py``), and
    Notes is where the text is actually visible in the erwin UI, so that is
    what is validated for CDM and LDM.
    """
    return [
        (COMMENT_TO_NOTE, "SAP PD Comment", "erwin Note",
         getattr(pd_object, "doc_comment", "") if pd_object else "",
         getattr(erwin_object, "doc_note", "") if erwin_object else ""),
        (DESCRIPTION_TO_DEFINITION, "SAP PD Description", "erwin Definition",
         getattr(pd_object, "doc_definition", "") if pd_object else "",
         getattr(erwin_object, "doc_definition", "") if erwin_object else ""),
        (ANNOTATION_TO_EXTENDED_NOTES, "SAP PD Annotation",
         "erwin Extended Notes",
         getattr(pd_object, "doc_annotation", "") if pd_object else "",
         getattr(erwin_object, "doc_extended_notes", "") if erwin_object else ""),
    ]


# ─── ENTITY PAIRING ───────────────────────────────────────────────────────────

class _ErwinEntityPool:
    """
    erwin entities indexed by normalised name and code, handed out one-to-one.

    Pairing must be one-to-one. Both models legitimately contain entities whose
    name and code are crossed — e.g. one entity named 'UNIT_OF_MEASURE' with
    code 'UNIT OF MEASURES', and a second named 'Unit Of Measure' with code
    'UNIT_OF_MEASURE'. Every one of those values normalises to the same key, so
    a dictionary that returns the same entity twice hands the documented twin to
    both SAP PD entities. The undocumented one then reads as MISSING_IN_SAP_PD
    against text that SAP PD does in fact carry — on its sibling.
    """

    def __init__(self, erwin_entities: List):
        self.by_name: Dict[str, List] = {}
        self.by_code: Dict[str, List] = {}
        self.claimed = set()
        for entity in erwin_entities:
            if entity.name:
                self.by_name.setdefault(
                    normalizers.normalize_name(entity.name), []).append(entity)
            if entity.code:
                self.by_code.setdefault(
                    normalizers.normalize_name(entity.code), []).append(entity)

    def take(self, key: str):
        """First erwin entity under `key` that no SAP PD entity has claimed yet."""
        if not key:
            return None
        for bucket in (self.by_name.get(key), self.by_code.get(key)):
            for candidate in bucket or ():
                if id(candidate) not in self.claimed:
                    return candidate
        return None

    def claim(self, entity) -> None:
        self.claimed.add(id(entity))

    def is_claimed(self, entity) -> bool:
        return id(entity) in self.claimed


def _match_erwin_entity(pd_entity, entity_pairs, pool: _ErwinEntityPool):
    """
    The erwin entity for one SAP PD entity: the comparator's pairing first,
    then normalised name, then normalised code — the comparator's own bases.
    """
    erwin_entity = None
    if entity_pairs and pd_entity.name in entity_pairs:
        erwin_entity = pool.take(
            normalizers.normalize_name(entity_pairs[pd_entity.name]))
    if erwin_entity is None and pd_entity.name:
        erwin_entity = pool.take(normalizers.normalize_name(pd_entity.name))
    if erwin_entity is None and pd_entity.code:
        erwin_entity = pool.take(normalizers.normalize_name(pd_entity.code))
    return erwin_entity


def _index_attributes(erwin_entity) -> Dict[str, object]:
    """erwin attributes by normalised name and code; empty when no entity matched."""
    erwin_attrs: Dict[str, object] = {}
    if erwin_entity is None:
        return erwin_attrs
    for attribute in getattr(erwin_entity, "attributes", []) or []:
        if attribute.name:
            erwin_attrs.setdefault(
                normalizers.normalize_name(attribute.name), attribute)
        if attribute.code:
            erwin_attrs.setdefault(
                normalizers.normalize_name(attribute.code), attribute)
    return erwin_attrs


# ─── ROW BUILDERS ─────────────────────────────────────────────────────────────

def _entity_rows(model_name: str, pd_entity, erwin_entity) -> List[DocumentationRow]:
    return [
        _row(model_name, "ENTITY", pd_entity.name, pd_entity.code,
             mapping, src_field, tgt_field, src, tgt, erwin_object=erwin_entity)
        for mapping, src_field, tgt_field, src, tgt in _pairs_for(pd_entity, erwin_entity)
    ]


def _attribute_rows(model_name: str, pd_entity, erwin_entity) -> List[DocumentationRow]:
    """Rows for every attribute of one SAP PD entity against its erwin twin."""
    erwin_attrs = _index_attributes(erwin_entity)
    rows: List[DocumentationRow] = []
    for pd_attribute in getattr(pd_entity, "attributes", []) or []:
        erwin_attribute = (
            erwin_attrs.get(normalizers.normalize_name(pd_attribute.name or ""))
            or erwin_attrs.get(normalizers.normalize_name(pd_attribute.code or ""))
        )
        label = f"{pd_entity.name}.{pd_attribute.name or pd_attribute.code}"
        for mapping, src_field, tgt_field, src, tgt in _pairs_for(
                pd_attribute, erwin_attribute):
            rows.append(_row(model_name, "ATTRIBUTE", label,
                             pd_attribute.code, mapping, src_field,
                             tgt_field, src, tgt, erwin_object=erwin_attribute))
    return rows


def _erwin_only_rows(model_name: str, erwin_entities: List,
                     pool: _ErwinEntityPool) -> List[DocumentationRow]:
    """erwin-only entities: documentation added downstream of SAP PD."""
    rows: List[DocumentationRow] = []
    for erwin_entity in erwin_entities:
        if pool.is_claimed(erwin_entity):
            continue
        for mapping, src_field, tgt_field, _src, tgt in _pairs_for(None, erwin_entity):
            if not (tgt or "").strip():
                continue
            rows.append(_row(model_name, "ENTITY", erwin_entity.name,
                             erwin_entity.code, mapping, src_field, tgt_field,
                             "", tgt))
    return rows


# ─── PUBLIC API ───────────────────────────────────────────────────────────────

def build_rows(pd_model, erwin_model,
               entity_pairs: Optional[Dict[str, str]] = None
               ) -> List[DocumentationRow]:
    """
    Produce every documentation row for one validated model pair.

    ``entity_pairs`` optionally maps SAP PD entity key → erwin entity key, as
    resolved by the comparator's matcher.  When omitted, entities are paired on
    normalised name then code — the same basis the comparator's first two
    passes use — so the sheet lines up with the findings.
    """
    model_name = getattr(pd_model, "model_name", "") or ""
    rows: List[DocumentationRow] = []

    pd_entities = _entity_list(pd_model)
    erwin_entities = _entity_list(erwin_model)
    pool = _ErwinEntityPool(erwin_entities)

    for pd_entity in pd_entities:
        erwin_entity = _match_erwin_entity(pd_entity, entity_pairs, pool)
        if erwin_entity is not None:
            pool.claim(erwin_entity)
        rows.extend(_entity_rows(model_name, pd_entity, erwin_entity))
        rows.extend(_attribute_rows(model_name, pd_entity, erwin_entity))

    rows.extend(_erwin_only_rows(model_name, erwin_entities, pool))
    return rows


def summarise(rows: List[DocumentationRow]) -> Dict[str, Dict[str, int]]:
    """Per-mapping counts of each status, for the sheet's header block."""
    summary: Dict[str, Dict[str, int]] = {}
    for row in rows:
        bucket = summary.setdefault(row.mapping, {
            MATCHED: 0, MISMATCH: 0, MISSING_IN_ERWIN: 0,
            MISSING_IN_SAP_PD: 0, BOTH_EMPTY: 0,
        })
        bucket[row.status] = bucket.get(row.status, 0) + 1
    return summary


# ─── HELPERS ──────────────────────────────────────────────────────────────────

def _entity_list(model) -> List:
    """Entities as a list, whether the model stores them as dict or list."""
    entities = getattr(model, "entities", None)
    if entities is None:
        return []
    if isinstance(entities, dict):
        return list(entities.values())
    return list(entities)
