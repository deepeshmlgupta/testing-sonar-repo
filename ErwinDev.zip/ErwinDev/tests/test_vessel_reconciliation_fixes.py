"""
Regression tests for the false-positive fixes found on the Vessel LDM
(24 relationships, 22 entities, no primary identifiers, comments migrated
into erwin Notes).

Each test pins one defect that, together, took a perfectly migrated model
from 74% structural fidelity down to 37% overall:

  * erwin <Cardinality> -2 is "One or More", not "Zero, One or More"
  * a PD LDM <a:DependentRole> marks the identifying end
  * PD ends derive `mandatory` from the cardinality lower bound
  * relationship semantics are compared on ALIGNED ends, not positionally
  * the comparator's entity-rename pass keeps the `identifying` flag
  * a migrated Note_List counts as erwin's definition
  * a udp_tool workbook that names none of the model's entities is ignored
"""

import os
import sys
import tempfile
import textwrap
import unittest
from dataclasses import dataclass, field

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.config.validation_config import LDM_CONFIG
from app.orchestration import udp_helpers
from app.validation import relationship_semantic_score as sem
from app.validation.ldm_reconcile import cardinality as card
from app.validation.ldm_reconcile import comparator as ldm_comparator
from app.validation.ldm_reconcile import erwin_ldm_parser, pd_ldm_parser
from app.validation.ldm_reconcile.ldm_model import Relationship, RelationshipEnd

# ─── fixtures ────────────────────────────────────────────────────────────────

PD_LDM = textwrap.dedent("""\
    <?xml version="1.0" encoding="UTF-8"?>
    <?PowerDesigner AppLocale="UTF16" ExtractionId="46576598" Name="Vessel"?>
    <Model xmlns:a="attribute" xmlns:c="collection" xmlns:o="object">
    <o:RootObject Id="o1"><c:Children>
    <o:Model Id="o2"><a:Name>Vessel</a:Name><a:Code>VESSEL</a:Code>
    <c:Entities>
      <o:Entity Id="o10"><a:ObjectID>E1</a:ObjectID><a:Name>Survey Question</a:Name><a:Code>SRVY_QSTN</a:Code>
        <a:Comment>A question that is part of a survey.</a:Comment></o:Entity>
      <o:Entity Id="o11"><a:ObjectID>E2</a:ObjectID><a:Name>Survey Template</a:Name><a:Code>SRVY_TMPLT</a:Code>
        <a:Comment>The design of the survey.</a:Comment></o:Entity>
      <o:Entity Id="o12"><a:ObjectID>E3</a:ObjectID><a:Name>Risk Area</a:Name><a:Code>RSK_AR</a:Code>
        <a:Comment>Reference list.</a:Comment></o:Entity>
    </c:Entities>
    <c:Relationships>
      <o:Relationship Id="o20"><a:ObjectID>R1</a:ObjectID><a:Name>contains</a:Name><a:Code>CONTAINS</a:Code>
        <a:Entity1ToEntity2RoleCardinality>1..n</a:Entity1ToEntity2RoleCardinality>
        <a:Entity2ToEntity1RoleCardinality>1..1</a:Entity2ToEntity1RoleCardinality>
        <a:DependentRole>B</a:DependentRole>
        <a:Entity1ToEntity2Role>contains</a:Entity1ToEntity2Role>
        <c:Object1><o:Entity Ref="o10"/></c:Object1>
        <c:Object2><o:Entity Ref="o11"/></c:Object2>
      </o:Relationship>
    </c:Relationships>
    </o:Model></c:Children></o:RootObject></Model>
""")

ERWIN_XML = textwrap.dedent("""\
    <?xml version="1.0" encoding="UTF-8"?>
    <erwin xmlns="http://www.erwin.com/dm" xmlns:EMX="http://www.erwin.com/dm/data">
    <EMX:Model id="{M}+00000001" name="Vessel" xmlns="http://www.erwin.com/dm/data">
    <ModelProps><Name>Vessel</Name><Type>1</Type></ModelProps>
    <Entity id="{E1}+00000000" name="Survey Question"><EntityProps><Name>Survey Question</Name>
      <Note_List_Array><Note_List HandleNonPrintableChar="Y" index="0">1\\#x1F2026\\#x1FBot\\#x1F2026\\#x1FBot\\#x1F\\#x1FA question that is part of a survey.\\#x1FF\\#x1F\\#x1F\\#x1F{N1}\\#x1F</Note_List></Note_List_Array>
    </EntityProps></Entity>
    <Entity id="{E2}+00000000" name="Survey Template"><EntityProps><Name>Survey Template</Name>
      <Note_List_Array><Note_List HandleNonPrintableChar="Y" index="0">1\\#x1F2026\\#x1FBot\\#x1F2026\\#x1FBot\\#x1F\\#x1FThe design of the survey.\\#x1FF\\#x1F\\#x1F\\#x1F{N2}\\#x1F</Note_List></Note_List_Array>
    </EntityProps></Entity>
    <Entity id="{E3}+00000000" name="Risk Area"><EntityProps><Name>Risk Area</Name>
      <Note_List_Array><Note_List HandleNonPrintableChar="Y" index="0">1\\#x1F2026\\#x1FBot\\#x1F2026\\#x1FBot\\#x1F\\#x1FReference list.\\#x1FF\\#x1F\\#x1F\\#x1F{N3}\\#x1F</Note_List></Note_List_Array>
    </EntityProps></Entity>
    <Relationship id="{R1}+00000000" name="contains"><RelationshipProps><Name>contains</Name>
      <Type>2</Type><Null_Option_Type>101</Null_Option_Type><Cardinality>-2</Cardinality>
      <Parent_To_Child_Verb_Phrase>contains</Parent_To_Child_Verb_Phrase>
      <Parent_Entity_Ref>{E2}+00000000</Parent_Entity_Ref>
      <Child_Entity_Ref>{E1}+00000000</Child_Entity_Ref>
    </RelationshipProps></Relationship>
    </EMX:Model></erwin>
""")


def _write(tmpdir, name, text):
    path = os.path.join(tmpdir, name)
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(text)
    return path


@dataclass
class _End:
    entity: str = ""
    mandatory: bool = False
    dependent: bool = False


@dataclass
class _Rel:
    name: str = ""
    identifying: bool = False
    end1: _End = field(default_factory=_End)
    end2: _End = field(default_factory=_End)


# ─── tests ───────────────────────────────────────────────────────────────────

class ErwinCardinalityCodeTests(unittest.TestCase):
    def test_minus_two_is_one_or_more(self):
        self.assertEqual("1,n", LDM_CONFIG.ERWIN_CARDINALITY_CODES["-2"])
        self.assertEqual(("1,n", True), erwin_ldm_parser.resolve_erwin_cardinality("-2"))

    def test_minus_three_and_minus_one_unchanged(self):
        self.assertEqual(("0,n", True), erwin_ldm_parser.resolve_erwin_cardinality("-3"))
        self.assertEqual(("0,1", True), erwin_ldm_parser.resolve_erwin_cardinality("-1"))


class PdLdmRelationshipParsingTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.model = pd_ldm_parser.parse_ldm(_write(self.tmp.name, "v.ldm", PD_LDM))
        self.rel = self.model.relationships[0]

    def tearDown(self):
        self.tmp.cleanup()

    def test_dependent_role_b_marks_entity1_as_identifying_child(self):
        self.assertTrue(self.rel.identifying)
        self.assertTrue(self.rel.end1.dependent)
        self.assertFalse(self.rel.end2.dependent)

    def test_mandatory_is_derived_from_cardinality_lower_bound(self):
        self.assertEqual("1,n", self.rel.end1.cardinality)
        self.assertTrue(self.rel.end1.mandatory)
        self.assertEqual("1,1", self.rel.end2.cardinality)
        self.assertTrue(self.rel.end2.mandatory)


class SemanticScoreAlignmentTests(unittest.TestCase):
    def test_reversed_end_order_is_not_a_participation_mismatch(self):
        # PD lists child first (0,n optional) then parent (1,1 mandatory);
        # erwin lists parent first. Same rule, opposite order.
        pd_rel = _Rel("assessed in", end1=_End("ASSESSMENT"), end2=_End("REQUEST", mandatory=True))
        erwin_rel = _Rel("assessed in", end1=_End("Request", mandatory=True), end2=_End("Assessment"))
        finding = sem.classify_pair(pd_rel, erwin_rel)
        self.assertTrue(finding.participation_match)
        self.assertEqual(100.0, finding.semantic_score_pct)

    def test_real_participation_difference_still_reported(self):
        pd_rel = _Rel("covers", end1=_End("VESSEL", mandatory=True), end2=_End("AGREEMENT"))
        erwin_rel = _Rel("covers", end1=_End("Vessel"), end2=_End("Agreement"))
        finding = sem.classify_pair(pd_rel, erwin_rel)
        self.assertFalse(finding.participation_match)

    def test_aligned_ends_helper_swaps_by_entity(self):
        pd_rel = _Rel(end1=_End("A"), end2=_End("B"))
        erwin_rel = _Rel(end1=_End("b"), end2=_End("a"))
        e1, e2 = sem.aligned_erwin_ends(pd_rel, erwin_rel)
        self.assertEqual(("a", "b"), (e1.entity, e2.entity))


class EndToEndVesselShapedReconciliationTests(unittest.TestCase):
    """A one-relationship model shaped like the Vessel LDM must reconcile clean."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        pd_model = pd_ldm_parser.parse_ldm(_write(self.tmp.name, "v.ldm", PD_LDM))
        erwin_model = erwin_ldm_parser.parse_erwin_ldm(_write(self.tmp.name, "v.xml", ERWIN_XML))
        self.result = ldm_comparator.compare(pd_model, erwin_model)
        self.categories = {(f.severity, f.category) for f in self.result.findings}

    def tearDown(self):
        self.tmp.cleanup()

    def test_no_cardinality_optionality_or_semantic_warnings(self):
        warnings = {c for s, c in self.categories if s in ("WARNING", "CRITICAL")}
        for category in ("OPTIONALITY", "CARDINALITY", "RELATIONSHIP_SEMANTIC_MISMATCH",
                         "DEPENDENCY", "DEFINITION_LOSS"):
            self.assertNotIn(category, warnings, f"{category} should not fire: {warnings}")

    def test_relationship_verified_and_identifying_carried_through_rename(self):
        self.assertIn(("VERIFIED", "RELATIONSHIP_VERIFIED"), self.categories)
        self.assertEqual(100.0, self.result.relationship_semantic_fidelity_pct)
        self.assertEqual(["MATCHED"], [r.status for r in self.result.relationship_records])

    def test_note_list_counts_as_definition(self):
        self.assertIn(("VERIFIED", "DEFINITION_EXACT"), self.categories)

    def test_pre_existing_orphan_is_info_not_warning(self):
        orphan = [f for f in self.result.findings
                  if f.category == "MODEL_QUALITY" and "no relationship" in f.message]
        self.assertTrue(orphan)
        self.assertTrue(all(f.severity == "INFO" for f in orphan))

    def test_name_match_on_tool_without_code_is_not_a_rename(self):
        self.assertNotIn("FALLBACK_MATCH", {c for _, c in self.categories})


class ErwinDefinitionFallbackTests(unittest.TestCase):
    def test_translate_keeps_identifying(self):
        rel = Relationship(oid="1", name="r", code="R", definition="",
                           end1=RelationshipEnd("A", "", "1,n", True, True),
                           end2=RelationshipEnd("B", "", "1,1", True, False),
                           identifying=True)
        self.assertTrue(ldm_comparator._translate(rel, {}).identifying)

    def test_dominance_uses_aligned_ends(self):
        # PD: child A first (dependent), parent B second; erwin: parent first.
        pd_rel = Relationship(oid="1", name="r", code="R", definition="",
                              end1=RelationshipEnd("A", "", "0,n", False, True),
                              end2=RelationshipEnd("B", "", "1,1", True, False),
                              identifying=True)
        erwin_rel = Relationship(oid="2", name="r", code="R", definition="",
                                 end1=RelationshipEnd("B", "", "1,1", True, False),
                                 end2=RelationshipEnd("A", "", "0,n", False, True),
                                 identifying=True)
        self.assertFalse(card.ends_aligned(pd_rel, erwin_rel))
        result = ldm_comparator.ValidationResult(pd_file="p", erwin_file="e")
        ldm_comparator._compare_relationship_pair(result, pd_rel, erwin_rel, "name")
        self.assertEqual("MATCHED", result.relationship_records[0].status)


class StaleUdpWorkbookGuardTests(unittest.TestCase):
    class _Record:
        def __init__(self, name, code):
            self.pd_name, self.pd_code = name, code

    class _Result:
        def __init__(self, names):
            self.entity_records = [StaleUdpWorkbookGuardTests._Record(n, n.upper()) for n in names]

    def test_workbook_for_another_model_is_rejected(self):
        counts = {"entities": {"country", "commodity", "sanction"}}
        self.assertFalse(udp_helpers.workbook_belongs_to_model(counts, self._Result(["Vessel", "Waterway"])))

    def test_workbook_naming_this_models_entities_is_accepted(self):
        counts = {"entities": {"vessel", "waterway"}}
        self.assertTrue(udp_helpers.workbook_belongs_to_model(counts, self._Result(["Vessel", "Waterway"])))

    def test_silent_sides_are_trusted(self):
        self.assertTrue(udp_helpers.workbook_belongs_to_model({"entities": set()}, self._Result(["Vessel"])))
        self.assertTrue(udp_helpers.workbook_belongs_to_model({"entities": {"x"}}, self._Result([])))


if __name__ == "__main__":
    unittest.main()
