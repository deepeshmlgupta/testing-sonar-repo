"""
End-to-end report generation for a small synthetic model, on both the LDM and
the CDM engine: parse -> compare -> stage scores -> V1 / V2 / V3 workbooks ->
Pass_Fail_Summary -> per-model log -> pipeline ledger.

This is the coverage backbone for app/reporting and the tier report
generators, which no unit test exercised before. It also pins the CDM engine
to the same false-positive-free verdict the LDM engine gives on an identical
model (the two engines are copies and must not drift apart).
"""

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from openpyxl import load_workbook

from app.orchestration import pipeline_ledger
from app.orchestration.model_record import DEST_FINAL, DEST_MANUAL_REVIEW, ModelRecord
from app.orchestration.stage_paths import StagePaths, stage_folders
from app.reporting import model_log, model_reports, summary_report
from app.validation import fidelity_stages
from app.validation.cdm_reconcile import compare as compare_cdm
from app.validation.cdm_reconcile import parse_cdm
from app.validation.cdm_reconcile import parse_erwin as parse_erwin_cdm
from app.validation.ldm_reconcile.comparator import compare as compare_ldm
from app.validation.ldm_reconcile.erwin_ldm_parser import parse_erwin_ldm
from app.validation.ldm_reconcile.pd_ldm_parser import parse_ldm
from tests.test_vessel_reconciliation_fixes import ERWIN_XML, PD_LDM

# The erwin export BEFORE comments were injected: same model, no Note_List.
ERWIN_XML_RAW = "\n".join(line for line in ERWIN_XML.splitlines() if "Note_List" not in line)


def _make_dirs(root: Path):
    dirs = {
        "initial": root / "1_initial", "preprocessed": root / "2_preprocessed",
        "final": root / "3_final", "final_xml": root / "final_xml_models",
        "summary": root / "batch_summary",
        "stages": stage_folders(root, root / "final_xml_models", root / "input_erwin_models"),
    }
    for path in dirs["stages"].values():
        path.mkdir(parents=True, exist_ok=True)
    (dirs["summary"] / "summary_report").mkdir(parents=True, exist_ok=True)
    (dirs["summary"] / "audit").mkdir(parents=True, exist_ok=True)
    return dirs


class _ReportPipeline(unittest.TestCase):
    """Shared driver; subclasses pick the tier."""

    model_type = "LDM"
    pd_suffix = ".ldm"

    def _parse_and_compare(self, pd_path, xml_path):
        if self.model_type == "CDM":
            return compare_cdm(parse_cdm(str(pd_path)), parse_erwin_cdm(str(xml_path)))
        return compare_ldm(parse_ldm(str(pd_path)), parse_erwin_ldm(str(xml_path)))

    def run_pipeline(self, tmp: Path):
        dirs = _make_dirs(tmp)
        stages = StagePaths(dirs)
        name = "synthetic_model"

        pd_path = tmp / f"{name}{self.pd_suffix}"
        pd_path.write_text(PD_LDM, encoding="utf-8")
        stages.xml_v1(name).write_text(ERWIN_XML_RAW, encoding="utf-8")
        stages.xml_v2(name).write_text(ERWIN_XML, encoding="utf-8")
        stages.xml_v3(name).write_text(ERWIN_XML, encoding="utf-8")

        record = ModelRecord(base_name=name, model_type=self.model_type)
        record.initial_result = self._parse_and_compare(pd_path, stages.xml_v1(name))
        fidelity_stages.apply(record.initial_result, "V1", model_type=self.model_type)
        record.v2_result = self._parse_and_compare(pd_path, stages.xml_v2(name))
        fidelity_stages.apply(record.v2_result, "V2", model_type=self.model_type)
        record.result = self._parse_and_compare(pd_path, stages.xml_v3(name))
        record.final_xml = str(stages.xml_v3(name))
        fidelity_stages.carry_history(record.initial_result, record.result)
        fidelity_stages.carry_history(record.v2_result, record.result)
        fidelity_stages.apply(record.result, "V3", model_type=self.model_type)
        record.destination = DEST_FINAL if record.result.fidelity_score >= 90 else DEST_MANUAL_REVIEW
        record.notes.append("V3 measured against synthetic_model.xml (existing)")

        # Keep every report inside the temp tree.
        reports_root = tmp / "reports"
        with patch("app.reporting.report_layout.model_dir",
                   side_effect=lambda t, n: (reports_root / t / n).mkdir(parents=True, exist_ok=True) or (reports_root / t / n)), \
             patch("app.reporting.report_layout.manual_review_dir",
                   side_effect=lambda t, n: reports_root / t / n / "manual_review_report"), \
             patch("app.reporting.model_reports.SCRATCH_REPORT_DIR", tmp / "scratch"):
            (tmp / "scratch").mkdir(exist_ok=True)
            model_reports.generate_model_reports(record, dirs)

        rows = [summary_report.summary_row(record)]
        summary_report.generate_summary_report(rows, dirs["summary"])
        ledger = pipeline_ledger.record_model(record, dirs, {"xml_v3": record.final_xml, "xml_v3_how": "existing"})
        return record, dirs, stages, ledger

    def check_common(self, record, dirs, stages, ledger):
        # Scores: comments recovered between V1 and V2, every relationship intact.
        v1, v2, v3 = (fidelity_stages.history(record.result)[s] for s in ("V1", "V2", "V3"))
        self.assertEqual(0.0, v1.component("documentation"))
        self.assertEqual(100.0, v2.component("documentation"))
        self.assertEqual(v2.overall, v3.overall)
        self.assertEqual(0, record.result.warning_count, [f.message for f in record.result.findings
                                                           if f.severity == "WARNING"])
        self.assertEqual(1, record.result.relationships_matched)

        # Three workbooks + log exist and carry the expected sheets. (No UDP
        # source workbooks are set up in this synthetic fixture, so V2 is not
        # generated here.)
        for path in (record.v1_report_path, record.v3_report_path, record.log_path):
            self.assertTrue(path and Path(path).is_file(), path)
        v3 = load_workbook(record.v3_report_path, read_only=True)
        for sheet in ("SUMMARY", "FIDELITY_PROGRESSION", "FINDINGS", "RELATIONSHIPS"):
            self.assertIn(sheet, v3.sheetnames)
        # UDP_RECONCILIATION does not exist (removed from both V2 and V3).
        self.assertNotIn("UDP_RECONCILIATION", v3.sheetnames)
        progression = list(v3["FIDELITY_PROGRESSION"].iter_rows(values_only=True))
        stage_rows = {r[0]: r for r in progression if r and r[0] in ("V1", "V2", "V3")}
        self.assertEqual({"V1", "V2", "V3"}, set(stage_rows))
        v3.close()

        # Pass/Fail summary and ledger.
        summary = dirs["summary"] / "summary_report" / "Pass_Fail_Summary.xlsx"
        self.assertTrue(summary.is_file())
        entry = json.loads(Path(ledger).read_text().splitlines()[-1])
        self.assertEqual(record.base_name, entry["model"])
        self.assertEqual(record.status, entry["status"])
        self.assertTrue(entry["reports"]["v3"].endswith("_v3_fidelity_report.xlsx"))

        # Reports live under app/reporting only; promotion to 3_final is route_model's job
        # (covered by test_batch_pipeline / test_flow_alignment), not the report writers'.
        self.assertFalse((stages.folder("erwin_v3") / "reports").exists())

        # The narrative log names the V3 source.
        text = Path(record.log_path).read_text(encoding="utf-8")
        self.assertIn("V3", text)


class LdmEndToEndReportTests(_ReportPipeline):
    model_type, pd_suffix = "LDM", ".ldm"

    def test_ldm_reports(self):
        with tempfile.TemporaryDirectory() as tmp:
            self.check_common(*self.run_pipeline(Path(tmp)))


class CdmEndToEndReportTests(_ReportPipeline):
    model_type, pd_suffix = "CDM", ".cdm"

    def test_cdm_reports(self):
        with tempfile.TemporaryDirectory() as tmp:
            self.check_common(*self.run_pipeline(Path(tmp)))


class ModelLogTests(unittest.TestCase):
    def test_log_mentions_manual_review_on_fail(self):
        with tempfile.TemporaryDirectory() as tmp:
            record = ModelRecord(base_name="m", model_type="LDM", destination=DEST_MANUAL_REVIEW)
            record.result = type("R", (), {"status": "FAIL", "fidelity_score": 40.0, "findings": [],
                                           "critical_count": 0, "warning_count": 5, "info_count": 0,
                                           "stage_scores": {}, "promotion_note": "FAIL: below threshold"})()
            with patch("app.reporting.report_layout.manual_review_dir",
                       side_effect=lambda t, n: Path(tmp) / "mr"):
                path = model_log.write_model_log(record, Path(tmp))
            self.assertTrue(Path(path).is_file())


if __name__ == "__main__":
    unittest.main()


class ExtendedFixtureReportTests(unittest.TestCase):
    """
    The FULL fixture (every client object type) through the LDM report
    pipeline, with a handful of extended properties broken on the erwin side:
    the new INFO categories must reach the FINDINGS sheet without disturbing
    the PASS verdict or the progression sheet.
    """

    def test_extended_findings_reach_the_v3_workbook(self):
        from tests.fixtures_extended import ERWIN_LDM_FULL, PD_LDM_FULL, mutate, strip_definitions
        broken = ERWIN_LDM_FULL
        broken = mutate(broken, "<Default_Value>'ACTIVE'</Default_Value>", "")
        broken = mutate(broken, "<Parent_Update_Rule>10000</Parent_Update_Rule>", "<Parent_Update_Rule>10002</Parent_Update_Rule>")
        broken = mutate(broken, "<Name>AK Vessel Name</Name><Physical_Name>AK_VESSEL_NAME</Physical_Name>",
                        "<Name>AK Something</Name><Physical_Name>AK_X</Physical_Name>")
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp = Path(tmpdir)
            dirs = _make_dirs(tmp)
            stages = StagePaths(dirs)
            name = "fleet_full"
            pd_path = tmp / f"{name}.ldm"
            pd_path.write_text(PD_LDM_FULL, encoding="utf-8")
            stages.xml_v1(name).write_text(strip_definitions(ERWIN_LDM_FULL), encoding="utf-8")
            stages.xml_v3(name).write_text(broken, encoding="utf-8")

            record = ModelRecord(base_name=name, model_type="LDM")
            record.initial_result = compare_ldm(parse_ldm(str(pd_path)), parse_erwin_ldm(str(stages.xml_v1(name))))
            fidelity_stages.apply(record.initial_result, "V1", model_type="LDM")
            record.result = compare_ldm(parse_ldm(str(pd_path)), parse_erwin_ldm(str(stages.xml_v3(name))))
            record.final_xml = str(stages.xml_v3(name))
            fidelity_stages.carry_history(record.initial_result, record.result)
            fidelity_stages.apply(record.result, "V3", model_type="LDM")
            record.destination = DEST_FINAL

            reports_root = tmp / "reports"
            with patch("app.reporting.report_layout.model_dir",
                       side_effect=lambda t, n: (reports_root / t / n).mkdir(parents=True, exist_ok=True) or (reports_root / t / n)), \
                 patch("app.reporting.report_layout.manual_review_dir",
                       side_effect=lambda t, n: reports_root / t / n / "manual_review_report"), \
                 patch("app.reporting.model_reports.SCRATCH_REPORT_DIR", tmp / "scratch"):
                (tmp / "scratch").mkdir(exist_ok=True)
                model_reports.generate_model_reports(record, dirs)

            categories = {f.category for f in record.result.findings}
            self.assertTrue({"ATTRIBUTE_DEFAULT", "RELATIONSHIP_RI_RULE", "IDENTIFIER_NAME"} <= categories, categories)
            self.assertEqual("PASS", record.result.status)

            wb = load_workbook(record.v3_report_path, read_only=True)
            cells = " ".join(str(c) for row in wb["FINDINGS"].iter_rows(values_only=True) for c in row if c)
            wb.close()
            for cat in ("ATTRIBUTE_DEFAULT", "RELATIONSHIP_RI_RULE", "IDENTIFIER_NAME"):
                self.assertIn(cat, cells)
            sample = Path(os.environ.get("ERWIN_SAMPLE_REPORT_DIR", "")) if os.environ.get("ERWIN_SAMPLE_REPORT_DIR") else None
            if sample:
                sample.mkdir(parents=True, exist_ok=True)
                for p in (record.v1_report_path, record.v3_report_path):
                    (sample / Path(p).name).write_bytes(Path(p).read_bytes())
