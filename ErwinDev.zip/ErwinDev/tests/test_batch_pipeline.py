"""
The batch orchestration on the synthetic model, end to end:
setup_directories -> find_models -> run_batch (conceptual workflow, reports,
ledger) -> Pass_Fail_Summary, with every path redirected into a temp tree.

Covers orchestration/directory_setup.py, batch_runner.py and the parts of
workflows/conceptual_workflow.py that the unit tests leave out (real
preprocessing subprocess, real report generation, hard stop and PASS routing).
"""

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.config import settings
from app.orchestration import concurrency, directory_setup
from app.orchestration.batch_runner import run_batch
from app.orchestration.stage_paths import StagePaths
from app.reporting.summary_report import generate_summary_report
from tests.test_vessel_reconciliation_fixes import ERWIN_XML, PD_LDM

ERWIN_XML_RAW = "\n".join(line for line in ERWIN_XML.splitlines() if "Note_List" not in line)


class BatchPipelineTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        self.root = root
        (root / "sappdmodels" / "ldm").mkdir(parents=True)
        (root / "sappdmodels" / "cdm").mkdir(parents=True)
        (root / "sappdmodels" / "pdm").mkdir(parents=True)
        (root / "sappdmodels" / "ldm" / "synthetic.ldm").write_text(PD_LDM, encoding="utf-8")
        reports_root = root / "reports_out"
        self.patches = [
            patch.object(settings, "BASE_DIR", root),
            patch.object(settings, "SAMPLES_DIR", str(root / "sappdmodels")),
            patch.object(settings, "OUTPUT_DIR", str(root / "erwinmodels")),
            patch.object(settings, "FINAL_XML_DIR", str(root / "final_xml_models")),
            patch.object(settings, "MAX_WORKERS", 1),
            patch.object(settings, "PROMOTION_FIDELITY_THRESHOLD", 90.0),
            patch.object(settings, "ERWIN_CONVERT_ENABLED", False),
            patch.object(settings, "MANUAL_EXPORT_WAIT_SECONDS", 0),
            # strict hand-off flow for these tests: a missing XML V3 is a hard stop
            patch.object(settings, "FINAL_XML_FALLBACK_TO_PREPROCESSED", False),
            # UDP_INPUT_MODELS_DIR is computed from settings.BASE_DIR at IMPORT
            # time, so patching BASE_DIR alone leaves it pointing at the real
            # checkout and the run writes into the operator's own hand-off
            # folder. Harmless while nothing was written there; the Step 2
            # hand-off gate writes a <model>.erwin_v1.HOWTO.txt beside a missing
            # .erwin, which made the leak visible as six stray files in
            # app/udp_tool/input_erwin_models/.
            patch.object(directory_setup, "UDP_INPUT_MODELS_DIR", root / "udp_input"),
            patch.object(directory_setup, "SCRATCH_REPORT_DIR", root / "scratch"),
            patch("app.reporting.model_reports.SCRATCH_REPORT_DIR", root / "scratch"),
            patch("app.reporting.report_layout.model_dir",
                  side_effect=lambda t, n, create=True: (reports_root / t / n).mkdir(parents=True, exist_ok=True) or (reports_root / t / n)),
            patch("app.reporting.report_layout.manual_review_dir",
                  side_effect=lambda t, n, create=True: reports_root / t / n / "manual_review_report"),
            patch("app.reporting.report_layout.tier_dir", side_effect=lambda t: reports_root / t),
            patch("app.common.config_helpers.udp_reports_dir", side_effect=lambda t: reports_root / "udp" / t),
        ]
        for p in self.patches:
            p.start()
        concurrency.clear_skipped_models()

    def tearDown(self):
        for p in reversed(self.patches):
            p.stop()
        self.tmp.cleanup()

    def _dirs(self):
        dirs = directory_setup.setup_directories()
        models = directory_setup.find_models(dirs)
        self.assertEqual(1, len(models))
        return dirs, models

    def test_missing_xml_v1_is_skipped_and_recorded(self):
        dirs, models = self._dirs()
        rows = run_batch(models, dirs, release=True, max_workers=1)
        self.assertEqual([], rows)
        self.assertTrue(any("XML V1" in r for r in concurrency.get_skipped_models()))

    def test_missing_xml_v3_is_a_hard_stop(self):
        dirs, models = self._dirs()
        StagePaths(dirs).xml_v1("synthetic").write_text(ERWIN_XML_RAW, encoding="utf-8")
        rows = run_batch(models, dirs, release=True, max_workers=1)
        self.assertEqual([], rows)
        self.assertTrue(any("XML V3" in r for r in concurrency.get_skipped_models()))
        # Step 1 still ran: XML V2 exists with the comments injected.
        xml_v2 = StagePaths(dirs).xml_v2("synthetic")
        self.assertTrue(xml_v2.is_file())
        self.assertIn("Note_List", xml_v2.read_text(encoding="utf-8"))

    def test_full_pass_run_writes_final_artefacts_summary_and_ledger(self):
        dirs, models = self._dirs()
        stages = StagePaths(dirs)
        stages.xml_v1("synthetic").write_text(ERWIN_XML_RAW, encoding="utf-8")
        stages.xml_v3("synthetic").write_text(ERWIN_XML, encoding="utf-8")   # "erwin" export
        stages.erwin_v2("synthetic").write_bytes(b"erwin-binary-stand-in")     # "erwin" conversion

        rows = run_batch(models, dirs, release=True, max_workers=1)
        self.assertEqual(1, len(rows))
        generate_summary_report(rows, dirs["summary"])

        self.assertTrue(stages.erwin_v3("synthetic").is_file(), ".ERWIN V3 promoted on PASS")
        self.assertTrue((stages.folder("erwin_v3") / "synthetic.xml").is_file())
        self.assertTrue((dirs["summary"] / "summary_report" / "Pass_Fail_Summary.xlsx").is_file())

        ledger = dirs["summary"] / "audit" / "pipeline_ledger.jsonl"
        entry = json.loads(ledger.read_text(encoding="utf-8").splitlines()[-1])
        self.assertEqual("PASS", entry["status"])
        self.assertEqual("3_final", entry["destination"])
        self.assertEqual("existing", entry["artefact_origin"]["xml_v3"])
        self.assertTrue(entry["reports"]["v1"] and entry["reports"]["v3"])
        self.assertEqual(100.0, entry["stages"]["V2"]["documentation"])

    def test_threaded_batch_matches_sequential(self):
        dirs, models = self._dirs()
        stages = StagePaths(dirs)
        stages.xml_v1("synthetic").write_text(ERWIN_XML_RAW, encoding="utf-8")
        stages.xml_v3("synthetic").write_text(ERWIN_XML, encoding="utf-8")
        (self.root / "sappdmodels" / "cdm" / "synthetic_cdm.cdm").write_text(PD_LDM, encoding="utf-8")
        stages.xml_v1("synthetic_cdm").write_text(ERWIN_XML_RAW, encoding="utf-8")
        stages.xml_v3("synthetic_cdm").write_text(ERWIN_XML, encoding="utf-8")
        models = directory_setup.find_models(dirs)
        self.assertEqual(2, len(models))
        rows = run_batch(models, dirs, release=False, max_workers=2)
        self.assertEqual(2, len(rows))

    def test_four_workers_give_the_same_rows_as_sequential(self):
        dirs, _ = self._dirs()
        stages = StagePaths(dirs)
        names = ["synthetic", "alpha", "bravo", "charlie", "delta"]
        for name in names[1:]:
            (self.root / "sappdmodels" / "ldm" / f"{name}.ldm").write_text(PD_LDM, encoding="utf-8")
        for name in names:
            stages.xml_v1(name).write_text(ERWIN_XML_RAW, encoding="utf-8")
            stages.xml_v3(name).write_text(ERWIN_XML, encoding="utf-8")
        models = directory_setup.find_models(dirs)
        self.assertEqual(5, len(models))

        sequential = run_batch(models, dirs, release=True, max_workers=1)
        threaded = run_batch(models, dirs, release=True, max_workers=4)
        # Columns: model, type, status, V1, V2, V3, destination — the values a
        # parallel run must not perturb. Notes/paths are model-specific anyway.
        strip = lambda rows: [tuple(r[:7]) for r in rows]   # noqa: E731
        self.assertEqual(strip(sequential), strip(threaded))
        self.assertEqual(5, len(threaded))
        # Every model got its own ledger line in both runs, none shared or lost.
        ledger = (dirs["summary"] / "audit" / "pipeline_ledger.jsonl").read_text(encoding="utf-8")
        for name in names:
            self.assertGreaterEqual(ledger.count(f'"model": "{name}"'), 2)


if __name__ == "__main__":
    unittest.main()
