"""
UDP Flow (Phase D)
==================
Runs the standalone UDP engine as one phase of the main pipeline, once per
model, for CDM, LDM and PDM alike.  ``app/main.py`` calls ``run_udp_flow`` after
reconciliation and before the promotion gate.

The four phases are the same ones ``app/udp_tool/batch_run.py`` drives, in the
same order, with the same modules -- only the orchestration moves:

    1a  classify   SAP model  -> per-model baseline + SOW classification
    1b  mapping    baseline   -> udp_schema.json + property_manifest.json
    2   inject     manifest   -> erwin .erwin binary       (COM, Windows only)
    3   report     manifest + injection results -> UDP Migration workbook
    4   compare    saved .erwin read back       -> UDP Comparison workbook

Design rules, kept deliberately identical to the rest of the framework:

* NEVER RAISES.  Every failure lands on ``UdpStageOutcome.error`` / ``.messages``
  and the pipeline carries on.  A UDP problem must not turn a good structural
  validation into a failed run.
* ADDITIVE.  Nothing here is imported by a parser, a comparator, a finding
  emitter or the preprocessing code.  ``UDP_TOOL_ENABLED = False`` skips the
  whole phase and the framework behaves exactly as it did before.
* PHASE 4 STILL RUNS WHEN PHASE 2 FAILS.  Phase 3 reports what the injector
  believed happened; Phase 4 reports what is in the file.  When those disagree,
  the file wins -- so the comparison is attempted regardless.
* SEPARATE FROM ``udp_fidelity.py``.  That module scores the erwin **XML**
  export and feeds the fidelity score.  This flow works on the erwin **.erwin**
  binary and produces the migration evidence.  Both numbers appear side by side
  on the V3 report; neither replaces the other.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, List, Optional, Sequence

from app.common.config_helpers import get_setting
from app.validation import udp_bridge

logger = logging.getLogger(__name__)

# ─── stages ───────────────────────────────────────────────────────────────────
STAGE_SKIPPED = "SKIPPED"
STAGE_EXTRACTED = "EXTRACTED"
STAGE_INJECTED = "INJECTED"
STAGE_COMPARED = "COMPARED"
STAGE_FAILED = "FAILED"

# ─── defaults, overridable through the tier config ────────────────────────────
DEFAULT_ENABLED = True
DEFAULT_INJECT_ENABLED = True
DEFAULT_READBACK_METHOD = "auto"
DEFAULT_NAME_STYLE = "bare"
DEFAULT_WORKDIR = "data/udp"
DEFAULT_EXTRACTION_ID = str(get_setting("UDP_EXTRACTION_ID", "46603045"))
DEFAULT_TIMEOUT_SECONDS = 1800
DEFAULT_REQUIRE_ERWIN_BINARY = False
# The .erwin the UDP tool works on is a MANUAL hand-off: the operator saves the
# (commented) model from erwin and copies it to app/udp_tool/input_erwin_models.
# A .erwin left next to the XML V1 export is accepted as a fallback.
_ERWIN_DIR = str(get_setting("ERWIN_MODELS_DIRNAME", "erwinmodels"))
_STAGE_INITIAL = str(get_setting("STAGE_INITIAL_DIRNAME", "1_initial"))
_STAGE_PREPROCESSED = str(get_setting("STAGE_PREPROCESSED_DIRNAME", "2_preprocessed"))

DEFAULT_ERWIN_INPUT_DIRS = (
    "app/udp_tool/input_erwin_models",
    f"{_ERWIN_DIR}/{_STAGE_INITIAL}",
)
DEFAULT_ERWIN_READBACK_DIRS = (
    f"{_ERWIN_DIR}/{_STAGE_PREPROCESSED}",
    "app/udp_tool/output_erwin_models",
    f"{_ERWIN_DIR}/{_STAGE_INITIAL}",
    "app/udp_tool/input_erwin_models",
)

_ERWIN_SUFFIX = ".erwin"


@dataclass
class UdpFlowRequest:
    """One model's inputs for Phase D."""

    pd_path: str
    model_name: str
    model_type: str                 # CDM | LDM | PDM
    reports_dir: str
    erwin_in: str = ""              # the handed-off .erwin (explicit wins over the search folders)
    erwin_out: str = ""             # where the UDP-enriched binary is written (never the input itself)
    workdir: str = ""               # defaults to <UDP_TOOL_WORKDIR>/<short model name>


@dataclass
class UdpStageOutcome:
    """Everything the pipeline and the V3 report need about one model's UDPs."""

    model_name: str = ""
    model_type: str = ""
    stage: str = STAGE_SKIPPED
    schema_path: str = ""
    manifest_path: str = ""
    classification_path: str = ""
    injection_results_path: str = ""
    migration_report_path: str = ""
    comparison_report_path: str = ""
    erwin_in: str = ""
    erwin_read: str = ""
    injected: bool = False
    comparison_result: Any = None
    messages: List[str] = field(default_factory=list)
    error: str = ""

    @property
    def udp_values(self) -> int:
        """Manifest rows with a value SAP actually held (the comparison base)."""
        result = self.comparison_result
        return int(getattr(result, "comparable", 0) or 0) if result is not None else 0

    @property
    def pass_rate(self) -> Optional[float]:
        """
        Share of SAP UDP values erwin holds, or None when nothing was measured.

        None — not zero — is returned whenever the comparison cannot support a
        verdict: no comparison ran, erwin could not be read at all, or the
        binary decoder scored its own read below the reliability floor. Those
        cases used to fall through ``or 0.0`` and be scored as a measured 100%
        UDP loss, which on the CDM turned 1177 unverifiable values into a
        24-point drop in the V3 score. A genuine 0% (erwin read cleanly and
        holds none of the values) is still returned as 0.0.
        """
        result = self.comparison_result
        if result is None or not self.udp_values:
            return None
        if not getattr(result, "readable", True):
            return None
        readback = getattr(result, "readback", None)
        if readback is not None and not getattr(readback, "reliable", True):
            return None
        return float(getattr(result, "pass_rate", 0.0) or 0.0)

    @property
    def verdict(self) -> str:
        result = self.comparison_result
        if result is None:
            return "NOT COMPARED"
        return str(getattr(result, "status", "UNKNOWN"))

    @property
    def readback_method(self) -> str:
        readback = getattr(self.comparison_result, "readback", None)
        return str(getattr(readback, "method", "")) if readback is not None else ""

    @property
    def readback_reliable(self) -> Optional[bool]:
        readback = getattr(self.comparison_result, "readback", None)
        return bool(getattr(readback, "reliable", False)) if readback is not None else None

    def summary_line(self) -> str:
        if self.error:
            return f"UDP stage {self.stage}: {self.error}"
        result = self.comparison_result
        if result is None:
            return f"UDP stage {self.stage}; no comparison performed."
        return str(result.summary_line())


# ═════════════════════════════════════════════════════════════════════════════
#  Configuration helpers
# ═════════════════════════════════════════════════════════════════════════════

def _tier_config(model_type: str):
    try:
        from app.config.validation_config import tier
        return tier(model_type)
    except (ImportError, ValueError) as exc:                   # noqa: BLE001
        logger.debug("No tier config for %s: %s", model_type, exc)
        return None


def _cfg(config, name: str, default):
    return getattr(config, name, default) if config is not None else default


def _display_name(model_name: str) -> str:
    """``real_estate`` for ``<hash>_<extraction id>_real_estate`` (see report_layout)."""
    try:
        from app.reporting.report_layout import short_model_name
        return short_model_name(model_name) or model_name
    except Exception:                                          # noqa: BLE001
        return model_name


def _project_path(path) -> Path:
    """Relative folders in the config are anchored to the project root, not the cwd."""
    candidate = Path(str(path))
    if candidate.is_absolute():
        return candidate
    try:
        from app.config import settings
        return Path(settings.BASE_DIR) / candidate
    except Exception:                                          # noqa: BLE001
        return candidate


def _find_existing(directories: Sequence[str], model_name: str,
                   model_type: str = "") -> str:
    """
    First ``.erwin`` for this model in the search folders, or ''.

    Each folder is tried three ways, because the file at the other end of a
    manual hand-off is named and filed by a person, not by the pipeline:

        <dir>/<model_name>.erwin          the canonical spelling
        <dir>/<tier>/<model_name>.erwin   the mirrored tier folder the SAP
                                          sources sit in (cdm|ldm|pdm)
        ...and both again under the SHORT model name (``real_estate`` rather
        than ``<hash>_<extraction id>_real_estate``), which is the name every
        report shows and therefore the name an operator saves the file under.

    Searching only the first of those was why a correctly handed-off .erwin
    could sit on disk while Step 2 reported WAITING_FOR_MANUAL_INPUT.
    """
    tier = str(model_type or "").strip().lower()
    short = _display_name(model_name)
    names = [model_name] + ([short] if short and short != model_name else [])
    for directory in directories or ():
        base = _project_path(directory)
        folders = [base] + ([base / tier] if tier in ("cdm", "ldm", "pdm") else [])
        for folder in folders:
            for name in names:
                candidate = folder / f"{name}{_ERWIN_SUFFIX}"
                if candidate.is_file():
                    if name != model_name:
                        logger.warning(
                            "UDP phase resolved the .erwin for %s by its short name at %s; "
                            "rename it to %s%s if that is not the right file.",
                            model_name, candidate, model_name, _ERWIN_SUFFIX)
                    return str(candidate)
    return ""


def _stale_readback(erwin_path: str, pd_path: str) -> str:
    """
    A warning when the .erwin about to be read back predates the SAP PD source
    it is supposed to carry, or '' when it does not.

    Returns text rather than raising, because the caller decides what to do
    with it; the point is that this can no longer happen invisibly.
    """
    if not erwin_path or not pd_path:
        return ""
    try:
        erwin_mtime = Path(erwin_path).stat().st_mtime
        pd_mtime = Path(pd_path).stat().st_mtime
    except OSError:
        return ""
    if erwin_mtime >= pd_mtime:
        return ""
    return (f"STALE READ-BACK: {Path(erwin_path).name} is OLDER than the SAP PD "
            f"source {Path(pd_path).name} it is being compared against, so its "
            f"UDP values may belong to an earlier version of this model. "
            f"Re-do the erwin hand-off for this model, or confirm the .erwin is "
            f"still the right one.")


# ═════════════════════════════════════════════════════════════════════════════
#  Phase steps
# ═════════════════════════════════════════════════════════════════════════════

def _run_mapping(request: UdpFlowRequest, outcome: UdpStageOutcome,
                 workdir: str, extraction_id: str, config=None) -> bool:
    """Phases 1a + 1b.  Returns True when the mapping artefacts exist."""
    classification, classification_path = udp_bridge.classify(request.pd_path, workdir)
    outcome.classification_path = classification_path

    # PD_SourceExtraction exists to prove which repository extract a UDP came
    # from, so the model's own header ExtractionId (recorded by sow_classify)
    # must win over the configured constant, which is only a fallback.
    real_extraction_id = str((classification or {}).get("extraction_id") or "").strip()
    if real_extraction_id:
        extraction_id = real_extraction_id

    schema, manifest = udp_bridge.build_mapping(
        workdir, request.model_name, extraction_id,
        pd_path=request.pd_path, config=config)
    outcome.schema_path = str(Path(workdir) / udp_bridge.SCHEMA_FILENAME)
    outcome.manifest_path = str(Path(workdir) / udp_bridge.MANIFEST_FILENAME)
    outcome.stage = STAGE_EXTRACTED
    outcome.messages.append(
        f"Mapped {len(schema)} UDP definition(s) and {len(manifest)} property value(s).")
    return bool(schema or manifest)


def _run_injection(request: UdpFlowRequest, outcome: UdpStageOutcome,
                   workdir: str, config) -> None:
    """Phase 2.  Records why it was skipped rather than failing silently."""
    if not _cfg(config, "UDP_TOOL_INJECT_ENABLED", DEFAULT_INJECT_ENABLED):
        outcome.messages.append("Injection disabled by configuration.")
        return

    erwin_in = request.erwin_in if request.erwin_in and Path(request.erwin_in).is_file() else _find_existing(
        _cfg(config, "UDP_TOOL_ERWIN_INPUT_DIRS", DEFAULT_ERWIN_INPUT_DIRS),
        request.model_name, request.model_type)
    if not erwin_in:
        outcome.messages.append(
            "WAITING_FOR_MANUAL_INPUT: no .erwin handed off for this model; injection skipped. "
            "Save the model from erwin as <name>.erwin and copy it to app/udp_tool/input_erwin_models/.")
        return
    outcome.erwin_in = erwin_in

    if not udp_bridge.com_available():
        outcome.messages.append(
            "pywin32 / erwin COM not available on this host; injection skipped. "
            "The comparison phase still reads the model back off disk.")
        return

    erwin_out = request.erwin_out or str(
        _project_path("erwinmodels/2_preprocessed") / f"{request.model_name}{_ERWIN_SUFFIX}")
    if os.path.abspath(erwin_out) == os.path.abspath(erwin_in):
        outcome.messages.append("Injection refused: output path equals the handed-off input; inputs are never overwritten.")
        return
    Path(erwin_out).parent.mkdir(parents=True, exist_ok=True)
    results_path = str(Path(workdir) / udp_bridge.RESULTS_FILENAME)

    injected = udp_bridge.inject(udp_bridge.InjectionRequest(
        erwin_in=erwin_in,
        erwin_out=erwin_out,
        schema_path=outcome.schema_path,
        manifest_path=outcome.manifest_path,
        results_path=results_path,
        name_style=str(_cfg(config, "UDP_TOOL_NAME_STYLE", DEFAULT_NAME_STYLE)),
        timeout_seconds=int(_cfg(config, "UDP_TOOL_TIMEOUT_SECONDS", DEFAULT_TIMEOUT_SECONDS)),
    ))

    outcome.injected = injected
    if injected:
        outcome.injection_results_path = results_path
        outcome.stage = STAGE_INJECTED
        outcome.messages.append(f"UDPs injected into {erwin_out}.")
    else:
        outcome.messages.append(
            "Injection did not complete; no fresh results file was written. "
            "Continuing to the comparison phase, which reads erwin off disk.")


def _run_reporting(request: UdpFlowRequest, outcome: UdpStageOutcome,
                   workdir: str, config) -> None:
    """Phases 3 + 4."""
    # Read back the enriched binary first (explicit output, then the search
    # folders), else the handed-off input so the comparison still reports.
    erwin_read = ""
    if request.erwin_out and Path(request.erwin_out).is_file():
        erwin_read = str(request.erwin_out)
    if not erwin_read:
        erwin_read = _find_existing(
            _cfg(config, "UDP_TOOL_ERWIN_READBACK_DIRS", DEFAULT_ERWIN_READBACK_DIRS),
            request.model_name, request.model_type)
    if not erwin_read and outcome.erwin_in and Path(outcome.erwin_in).is_file():
        erwin_read = outcome.erwin_in
    if not erwin_read and request.erwin_in and Path(request.erwin_in).is_file():
        erwin_read = request.erwin_in

    # STALENESS. The .erwin that gets read back may be one a PREVIOUS run left
    # in 2_preprocessed or output_erwin_models — the search above matches on
    # name, not on content or age. Its UDP pass rate then becomes this run's
    # evidence for a SAP source that may have changed since. Nothing checked
    # this, at all.
    #
    # It is reported rather than refused: on a legitimate re-run the operator's
    # handed-off .erwin is genuinely older than a freshly re-saved SAP source
    # and refusing would block a correct run. But it can no longer be silent,
    # and the message names both files so the reviewer can decide.
    stale = _stale_readback(erwin_read, request.pd_path)
    if stale:
        outcome.messages.append(stale)
        logger.warning("%s", stale)

    display = _display_name(request.model_name)
    outcome.migration_report_path = udp_bridge.migration_report(
        request.model_name, workdir, request.pd_path, erwin_read,
        request.reports_dir, display_name=display) or ""

    if not erwin_read:
        outcome.messages.append(
            "No .erwin binary available to read back; comparison skipped.")
        return

    outcome.erwin_read = erwin_read
    result, report_path = udp_bridge.compare(
        request.model_name, workdir, erwin_read, request.pd_path,
        request.model_type, request.reports_dir,
        method=str(_cfg(config, "UDP_TOOL_READBACK_METHOD", DEFAULT_READBACK_METHOD)),
        display_name=display)

    outcome.comparison_result = result
    outcome.comparison_report_path = report_path or ""
    outcome.stage = STAGE_COMPARED
    outcome.messages.append(result.summary_line())
    outcome.messages.extend(result.warnings)


# ═════════════════════════════════════════════════════════════════════════════
#  Public entry point
# ═════════════════════════════════════════════════════════════════════════════

def run_udp_flow(request: UdpFlowRequest, config=None) -> UdpStageOutcome:
    """
    Run the UDP engine for one model.  Never raises: every failure is recorded
    on the returned outcome so the pipeline can report it and carry on.
    """
    outcome = UdpStageOutcome(model_name=request.model_name,
                              model_type=(request.model_type or "").upper())
    try:
        config = config if config is not None else _tier_config(request.model_type)

        # A missing source model is a real failure and is reported first: a
        # bad path must not be masked as "phase disabled" when the phase is
        # switched off, or a typo in a 100-model batch reads as a clean skip.
        if not os.path.isfile(request.pd_path):
            outcome.stage = STAGE_FAILED
            outcome.error = f"SAP PD model not found: {request.pd_path}"
            return outcome

        if not _cfg(config, "UDP_TOOL_ENABLED", DEFAULT_ENABLED):
            outcome.messages.append("UDP phase disabled by configuration.")
            return outcome

        if not udp_bridge.available():
            outcome.messages.append(
                f"UDP tool not importable from {udp_bridge.TOOL_DIR}; phase skipped.")
            return outcome

        # Per-model workdir is named after the SHORT model name: it is a
        # scratch folder regenerated every run, and the full
        # <hash>_<extraction id>_<name> form was the last MAX_PATH exposure.
        workdir = request.workdir or str(
            _project_path(_cfg(config, "UDP_TOOL_WORKDIR", DEFAULT_WORKDIR))
            / _display_name(request.model_name))
        Path(request.reports_dir).mkdir(parents=True, exist_ok=True)

        extraction_id = str(_cfg(config, "UDP_TOOL_EXTRACTION_ID", DEFAULT_EXTRACTION_ID))
        if not _run_mapping(request, outcome, workdir, extraction_id, config):
            outcome.messages.append("No UDP values found in the SAP model.")
            return outcome

        _run_injection(request, outcome, workdir, config)
        _run_reporting(request, outcome, workdir, config)

        if _cfg(config, "UDP_TOOL_REQUIRE_ERWIN_BINARY", DEFAULT_REQUIRE_ERWIN_BINARY) \
                and not outcome.erwin_read:
            outcome.stage = STAGE_FAILED
            outcome.error = "UDP_TOOL_REQUIRE_ERWIN_BINARY is set but no .erwin was found."
        return outcome
    except Exception as exc:                                   # noqa: BLE001
        logger.warning("UDP phase failed for %s: %s", request.model_name, exc)
        outcome.stage = STAGE_FAILED
        outcome.error = f"{type(exc).__name__}: {exc}"
        return outcome


__all__ = [
    "UdpFlowRequest", "UdpStageOutcome", "run_udp_flow",
    "STAGE_SKIPPED", "STAGE_EXTRACTED", "STAGE_INJECTED",
    "STAGE_COMPARED", "STAGE_FAILED",
]


