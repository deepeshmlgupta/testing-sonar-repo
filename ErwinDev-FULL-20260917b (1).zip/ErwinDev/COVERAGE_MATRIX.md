# SAP PowerDesigner → erwin Data Modeler — object × property coverage matrix

**Framework:** ErwinDev-feature_new · **Date:** 2026-09-15 · **Evidence:** 180 mutation probes (`python -m tests.coverage_probe`), 161 detected; `tests/test_property_coverage.py` locks every row in; `tests/test_datatype_fidelity.py` (46 cases) covers the datatype rows; `tests/test_coverage_matrix.py` keeps §2 (below) in step with the code.

This is the single coverage matrix of the framework. §2 is the canonical table in the programme's column layout (generated from `tests/coverage_matrix_rows.py`); §3–§5 keep the narrative per object type; §6 lists exclusions with alternatives.

**Flow context.** The framework measures a migration that erwin's PowerDesigner import performs as a **manual** step (there is no automated bridge). "Automatically migrated" therefore means *by the framework*: Step 1 (`run_v1`, PD Comments → erwin Notes) and Step 2 (`run_udp`, SAP extended attributes → erwin UDPs). Everything else reaches erwin through the manual import and is **automatically validated** — property by property, PD value against erwin value, in the V1 / V2 / V3 reports.

## 2. Canonical coverage matrix

Status vocabulary: `AUTOMATICALLY_MIGRATED` (framework carries it, Step 1 / Step 2) · `AUTOMATICALLY_VALIDATED` (erwin import carries it — manual — and the framework proves it arrived) · `MANUALLY_MIGRATED` / `MANUALLY_VALIDATED` (a person carries / checks it; no such rows today) · `PARTIALLY_SUPPORTED` (validated with a documented limit) · `NOT_SUPPORTED_BY_ERWIN` · `NOT_SUPPORTED_BY_FRAMEWORK` · `INTENTIONALLY_OUT_OF_SCOPE` · `FUTURE_ENHANCEMENT` · `NOT_APPLICABLE` · `NOT_YET_TESTED` (check exists, erwin tag name not yet confirmed on a real export). Severities: C critical, W warning, I info (0.05 weight), V verified census row. Evidence: P = probe row in `property_probe_matrix.md`, T = test, S = report sheet.

<!-- COVERAGE_MATRIX_ROWS:BEGIN -->
_149 rows — AUTOMATICALLY_VALIDATED 96, AUTOMATICALLY_MIGRATED 27, PARTIALLY_SUPPORTED 10, INTENTIONALLY_OUT_OF_SCOPE 5, NOT_YET_TESTED 5, NOT_SUPPORTED_BY_ERWIN 4, FUTURE_ENHANCEMENT 2._

| Model Type | Object Type | Property | PD Available | Extracted | Transformed | Target Supported | Automatically Migrated | Manual Migration Required | Validated | Validation Method | Status | Alternative / Remediation | Evidence | Notes |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| CDM | Model | Name / Code / Type | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | MODEL_METADATA (W) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| CDM | Model | Comment / Definition | ✅ | ✅ | Step 1: PD Comment -> erwin Note | ✅ | ✅ | ❌ | ✅ | MODEL_DEFINITION (I) | AUTOMATICALLY_MIGRATED |  | T | run_v1 writes 2_preprocessed/<m>.xml; documentation component (25 %) |
| CDM | Entity | Presence (name/code) | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | ENTITY_MISSING (C) / ENTITY_EXTRA (W) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| CDM | Entity | Comment / Definition | ✅ | ✅ | Step 1: PD Comment -> erwin Note | ✅ | ✅ | ❌ | ✅ | DEFINITION_MISMATCH (W), DEFINITION_LOSS/PARTIAL (I); documentation component | AUTOMATICALLY_MIGRATED |  | T | run_v1 writes 2_preprocessed/<m>.xml; documentation component (25 %) |
| CDM | Entity | Extended attributes (UDPs) | ✅ | ✅ | Step 2: SAP extended attribute -> erwin UDP | ✅ | ✅ | ❌ | ✅ | UDP component (25 %), UDP_RECONCILIATION sheet, UDP tool comparison workbook | AUTOMATICALLY_MIGRATED |  | T/S | run_udp (Windows + erwin COM) injects into the handed-off .erwin; read-back pass rate is the evidence |
| CDM | Attribute | Name | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | BUSINESS_NAME (W) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| CDM | Attribute | Code / physical name | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | CODE_NOT_CARRIED (SOURCE_PRE_EXISTING, weight 0); FALLBACK_MATCH (I) for a real rename | AUTOMATICALLY_VALIDATED |  | P | erwin export has no Physical_Name; SAP PD Code preserved as the PD_Code UDP (Step 2) — an EXPECTED_TRANSFORMATION, not a loss |
| CDM | Attribute | Comment / Definition | ✅ | ✅ | Step 1: PD Comment -> erwin Note | ✅ | ✅ | ❌ | ✅ | DEFINITION_MISMATCH (W), DEFINITION_LOSS/PARTIAL (I) | AUTOMATICALLY_MIGRATED |  | T | run_v1 writes 2_preprocessed/<m>.xml; documentation component (25 %) |
| CDM | Attribute | Data type (family) | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | DATA_TYPE (C) | AUTOMATICALLY_VALIDATED |  | P/T | VARCHAR->CHAR, DATE->TIMESTAMP, INTEGER->VARCHAR are CRITICAL; tests/test_datatype_fidelity.py |
| CDM | Attribute | Length / precision / scale | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | LENGTH_PRECISION (W) | AUTOMATICALLY_VALIDATED |  | P/T | VARCHAR(500)->VARCHAR(255), DECIMAL(18,2)->DECIMAL(38,10) are WARNING; never silent |
| CDM | Attribute | Mandatory / optional | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | MANDATORY (W) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| CDM | Attribute | Domain assignment | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | ATTRIBUTE_DOMAIN (I), DOMAIN_MISMATCH (W) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| CDM | Attribute | Default value | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | ATTRIBUTE_DEFAULT (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| CDM | Attribute | Multiplicity | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | MULTIPLICITY_* (W/I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| CDM | Attribute | Extended attributes (UDPs) | ✅ | ✅ | Step 2: SAP extended attribute -> erwin UDP | ✅ | ✅ | ❌ | ✅ | UDP component (25 %), UDP_RECONCILIATION sheet, UDP tool comparison workbook | AUTOMATICALLY_MIGRATED |  | T/S | run_udp (Windows + erwin COM) injects into the handed-off .erwin; read-back pass rate is the evidence |
| CDM | Attribute | Order / sequence | ✅ | ✅ | — | ✅ | ❌ | ✅ | ❌ | — | INTENTIONALLY_OUT_OF_SCOPE | set CHECK_ATTRIBUTE_ORDER=True | P | erwin re-orders key attributes first; ungoverned |
| CDM | Identifier | Primary identifier membership | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | PRIMARY_IDENTIFIER (C) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| CDM | Identifier | Alternate identifier membership | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | ALTERNATE_IDENTIFIER (W) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| CDM | Identifier | Name / code | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | IDENTIFIER_NAME (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| CDM | Identifier | Member order | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | IDENTIFIER_MEMBER_ORDER (I) | AUTOMATICALLY_VALIDATED |  | P | only when the export writes Key_Group_Member_Order |
| CDM | Relationship | Parent / child entity | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | RELATIONSHIP_MISSING/EXTRA (W) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| CDM | Relationship | Verb phrases / role names | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | ROLE_NAME (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| CDM | Relationship | Comment / Definition | ✅ | ✅ | Step 1: PD Comment -> erwin Note | ✅ | ✅ | ❌ | ✅ | DEFINITION_MISMATCH (W) | AUTOMATICALLY_MIGRATED |  | T | run_v1 writes 2_preprocessed/<m>.xml; documentation component (25 %) |
| CDM | Relationship | Cardinality | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | CARDINALITY (W) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| CDM | Relationship | Optionality (mandatory parent) | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | OPTIONALITY (W), RELATIONSHIP_SEMANTIC_MISMATCH | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| CDM | Relationship | Identifying / dependent | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | RELATIONSHIP_SEMANTIC_MISMATCH (W) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| CDM | Relationship | RI update / delete rule | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | RELATIONSHIP_RI_RULE (I), *_UNMAPPED | PARTIALLY_SUPPORTED | confirm ERWIN_RI_RULE_CODES against one hand-set rule in erwin | P | erwin code map provisional; compared only when PD states a rule |
| CDM | Relationship | Dominance | ✅ | ✅ | — | ❌ | ❌ | ✅ | ❌ | — | NOT_SUPPORTED_BY_ERWIN | carry as a relationship UDP (Step 2) if it must reach downstream tools | P |  |
| CDM | Inheritance | Parent / children | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | INHERITANCE_STRUCTURE/EXTRA (W) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| CDM | Inheritance | Complete / exclusive | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | INHERITANCE_CONSTRAINT (W) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| CDM | Inheritance | Name | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | INHERITANCE_NAME (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| CDM | Domain | Data type | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | DOMAIN_MISMATCH (W) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| CDM | Domain | Length / precision | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | DOMAIN_LENGTH (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| CDM | Domain | Default value | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | DOMAIN_DEFAULT (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| CDM | Domain | Check parameters (low/high/list/format) | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | DOMAIN_CHECK_PARAMS (I) | PARTIALLY_SUPPORTED | list-of-values and format compared as present/absent only | P | erwin stores them in a Validation Rule / min-max |
| CDM | Domain | Name | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | DOMAIN_NAME (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| CDM | Domain | Comment / Definition | ✅ | ✅ | Step 1: PD Comment -> erwin Note | ✅ | ✅ | ❌ | ✅ | DEFINITION_MISMATCH (W) | AUTOMATICALLY_MIGRATED |  | T | run_v1 writes 2_preprocessed/<m>.xml; documentation component (25 %) |
| CDM | Business Rule | Name / expression | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | BUSINESS_NAME (W), BUSINESS_RULE_EXPRESSION (W) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| CDM | Business Rule | Type | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | BUSINESS_RULE_TYPE (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| CDM | Business Rule | Comment / Definition | ✅ | ✅ | Step 1: PD Comment -> erwin Note | ✅ | ✅ | ❌ | ✅ | DEFINITION_* (W/I) | AUTOMATICALLY_MIGRATED |  | T | run_v1 writes 2_preprocessed/<m>.xml; documentation component (25 %) |
| CDM | Package | Name / hierarchy | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | SUBJECT_AREA (I), PACKAGE_HIERARCHY (I) | AUTOMATICALLY_VALIDATED |  | P | hierarchy loss detectable only when the export writes Parent_Subject_Area somewhere |
| CDM | Package | Contents (entities) | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | PACKAGE_CONTENTS (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| CDM | Package | Comment / Definition | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | PACKAGE_DEFINITION (I) | PARTIALLY_SUPPORTED | validated, not injected: Step 1 does not write Subject_Area notes | P | FUTURE: extend pd_comment_to_erwin_note to Subject_Area |
| CDM | Diagram | Name / displayed symbols | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | DIAGRAM_MISSING, DIAGRAM_SYMBOLS (I) | NOT_YET_TESTED | confirm with one erwin export that carries Stored_Display | P | vessel export had 0 Stored_Display for 2 PD diagrams; check is silent until then |
| CDM | Diagram | Layout (positions, colours, fonts) | ✅ | ✅ | — | ✅ | ❌ | ✅ | ❌ | — | INTENTIONALLY_OUT_OF_SCOPE | presentation, not model content | P |  |
| LDM | Model | Name / Code / Type | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | MODEL_METADATA (W) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| LDM | Model | Comment / Definition | ✅ | ✅ | Step 1: PD Comment -> erwin Note | ✅ | ✅ | ❌ | ✅ | MODEL_DEFINITION (I) | AUTOMATICALLY_MIGRATED |  | T | run_v1 writes 2_preprocessed/<m>.xml; documentation component (25 %) |
| LDM | Entity | Presence (name/code) | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | ENTITY_MISSING (C) / ENTITY_EXTRA (W) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| LDM | Entity | Comment / Definition | ✅ | ✅ | Step 1: PD Comment -> erwin Note | ✅ | ✅ | ❌ | ✅ | DEFINITION_MISMATCH (W), DEFINITION_LOSS/PARTIAL (I); documentation component | AUTOMATICALLY_MIGRATED |  | T | run_v1 writes 2_preprocessed/<m>.xml; documentation component (25 %) |
| LDM | Entity | Extended attributes (UDPs) | ✅ | ✅ | Step 2: SAP extended attribute -> erwin UDP | ✅ | ✅ | ❌ | ✅ | UDP component (25 %), UDP_RECONCILIATION sheet, UDP tool comparison workbook | AUTOMATICALLY_MIGRATED |  | T/S | run_udp (Windows + erwin COM) injects into the handed-off .erwin; read-back pass rate is the evidence |
| LDM | Attribute | Name | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | BUSINESS_NAME (W) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| LDM | Attribute | Code / physical name | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | CODE_NOT_CARRIED (SOURCE_PRE_EXISTING, weight 0); FALLBACK_MATCH (I) for a real rename | AUTOMATICALLY_VALIDATED |  | P | erwin export has no Physical_Name; SAP PD Code preserved as the PD_Code UDP (Step 2) — an EXPECTED_TRANSFORMATION, not a loss |
| LDM | Attribute | Comment / Definition | ✅ | ✅ | Step 1: PD Comment -> erwin Note | ✅ | ✅ | ❌ | ✅ | DEFINITION_MISMATCH (W), DEFINITION_LOSS/PARTIAL (I) | AUTOMATICALLY_MIGRATED |  | T | run_v1 writes 2_preprocessed/<m>.xml; documentation component (25 %) |
| LDM | Attribute | Data type (family) | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | DATA_TYPE (C) | AUTOMATICALLY_VALIDATED |  | P/T | VARCHAR->CHAR, DATE->TIMESTAMP, INTEGER->VARCHAR are CRITICAL; tests/test_datatype_fidelity.py |
| LDM | Attribute | Length / precision / scale | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | LENGTH_PRECISION (W) | AUTOMATICALLY_VALIDATED |  | P/T | VARCHAR(500)->VARCHAR(255), DECIMAL(18,2)->DECIMAL(38,10) are WARNING; never silent |
| LDM | Attribute | Mandatory / optional | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | MANDATORY (W) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| LDM | Attribute | Domain assignment | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | ATTRIBUTE_DOMAIN (I), DOMAIN_MISMATCH (W) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| LDM | Attribute | Default value | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | ATTRIBUTE_DEFAULT (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| LDM | Attribute | Multiplicity | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | MULTIPLICITY_* (W/I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| LDM | Attribute | Extended attributes (UDPs) | ✅ | ✅ | Step 2: SAP extended attribute -> erwin UDP | ✅ | ✅ | ❌ | ✅ | UDP component (25 %), UDP_RECONCILIATION sheet, UDP tool comparison workbook | AUTOMATICALLY_MIGRATED |  | T/S | run_udp (Windows + erwin COM) injects into the handed-off .erwin; read-back pass rate is the evidence |
| LDM | Attribute | Order / sequence | ✅ | ✅ | — | ✅ | ❌ | ✅ | ❌ | — | INTENTIONALLY_OUT_OF_SCOPE | set CHECK_ATTRIBUTE_ORDER=True | P | erwin re-orders key attributes first; ungoverned |
| LDM | Identifier | Primary identifier membership | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | PRIMARY_IDENTIFIER (C) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| LDM | Identifier | Alternate identifier membership | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | ALTERNATE_IDENTIFIER (W) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| LDM | Identifier | Name / code | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | IDENTIFIER_NAME (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| LDM | Identifier | Member order | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | IDENTIFIER_MEMBER_ORDER (I) | AUTOMATICALLY_VALIDATED |  | P | only when the export writes Key_Group_Member_Order |
| LDM | Relationship | Parent / child entity | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | RELATIONSHIP_MISSING/EXTRA (W) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| LDM | Relationship | Verb phrases / role names | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | ROLE_NAME (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| LDM | Relationship | Comment / Definition | ✅ | ✅ | Step 1: PD Comment -> erwin Note | ✅ | ✅ | ❌ | ✅ | DEFINITION_MISMATCH (W) | AUTOMATICALLY_MIGRATED |  | T | run_v1 writes 2_preprocessed/<m>.xml; documentation component (25 %) |
| LDM | Relationship | Cardinality | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | CARDINALITY (W) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| LDM | Relationship | Optionality (mandatory parent) | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | OPTIONALITY (W), RELATIONSHIP_SEMANTIC_MISMATCH | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| LDM | Relationship | Identifying / dependent | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | RELATIONSHIP_SEMANTIC_MISMATCH (W) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| LDM | Relationship | RI update / delete rule | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | RELATIONSHIP_RI_RULE (I), *_UNMAPPED | PARTIALLY_SUPPORTED | confirm ERWIN_RI_RULE_CODES against one hand-set rule in erwin | P | erwin code map provisional; compared only when PD states a rule |
| LDM | Relationship | Dominance | ✅ | ✅ | — | ❌ | ❌ | ✅ | ❌ | — | NOT_SUPPORTED_BY_ERWIN | carry as a relationship UDP (Step 2) if it must reach downstream tools | P |  |
| LDM | Inheritance | Parent / children | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | INHERITANCE_STRUCTURE/EXTRA (W) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| LDM | Inheritance | Complete / exclusive | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | INHERITANCE_CONSTRAINT (W) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| LDM | Inheritance | Name | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | INHERITANCE_NAME (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| LDM | Domain | Data type | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | DOMAIN_MISMATCH (W) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| LDM | Domain | Length / precision | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | DOMAIN_LENGTH (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| LDM | Domain | Default value | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | DOMAIN_DEFAULT (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| LDM | Domain | Check parameters (low/high/list/format) | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | DOMAIN_CHECK_PARAMS (I) | PARTIALLY_SUPPORTED | list-of-values and format compared as present/absent only | P | erwin stores them in a Validation Rule / min-max |
| LDM | Domain | Name | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | DOMAIN_NAME (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| LDM | Domain | Comment / Definition | ✅ | ✅ | Step 1: PD Comment -> erwin Note | ✅ | ✅ | ❌ | ✅ | DEFINITION_MISMATCH (W) | AUTOMATICALLY_MIGRATED |  | T | run_v1 writes 2_preprocessed/<m>.xml; documentation component (25 %) |
| LDM | Business Rule | Name / expression | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | BUSINESS_NAME (W), BUSINESS_RULE_EXPRESSION (W) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| LDM | Business Rule | Type | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | BUSINESS_RULE_TYPE (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| LDM | Business Rule | Comment / Definition | ✅ | ✅ | Step 1: PD Comment -> erwin Note | ✅ | ✅ | ❌ | ✅ | DEFINITION_* (W/I) | AUTOMATICALLY_MIGRATED |  | T | run_v1 writes 2_preprocessed/<m>.xml; documentation component (25 %) |
| LDM | Package | Name / hierarchy | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | SUBJECT_AREA (I), PACKAGE_HIERARCHY (I) | AUTOMATICALLY_VALIDATED |  | P | hierarchy loss detectable only when the export writes Parent_Subject_Area somewhere |
| LDM | Package | Contents (entities) | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | PACKAGE_CONTENTS (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| LDM | Package | Comment / Definition | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | PACKAGE_DEFINITION (I) | PARTIALLY_SUPPORTED | validated, not injected: Step 1 does not write Subject_Area notes | P | FUTURE: extend pd_comment_to_erwin_note to Subject_Area |
| LDM | Diagram | Name / displayed symbols | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | DIAGRAM_MISSING, DIAGRAM_SYMBOLS (I) | NOT_YET_TESTED | confirm with one erwin export that carries Stored_Display | P | vessel export had 0 Stored_Display for 2 PD diagrams; check is silent until then |
| LDM | Diagram | Layout (positions, colours, fonts) | ✅ | ✅ | — | ✅ | ❌ | ✅ | ❌ | — | INTENTIONALLY_OUT_OF_SCOPE | presentation, not model content | P |  |
| LDM | Shortcut | Presence / target | ✅ | ✅ | Step 2: PD Shortcut -> erwin UDP (PD_Shortcut_*) | ✅ | ✅ | ❌ | ✅ | UDP component (25 %), UDP tool comparison workbook; SHORTCUT_* (I) census | AUTOMATICALLY_MIGRATED |  | T | erwin has no shortcut object; carried as UDPs by shortcut_udp.py and verified by the UDP read-back |
| LDM | Shortcut | Glossary term bindings (name / code) | ✅ | ✅ | Step 2: c:RelatedNameTerms / c:RelatedCodeTerms -> PD_NameTerms / PD_CodeTerms UDPs | ✅ | ✅ | ❌ | ✅ | UDP component (25 %), UDP tool comparison workbook | AUTOMATICALLY_MIGRATED |  | T | 102 of 105 entities in real_estate (797 term refs); bindings on relationships and attributes are counted into PD_Shortcut_Count, which erwin can only hold at model root |
| CDM | Data Item | Presence / type | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | folded into Attribute checks | AUTOMATICALLY_VALIDATED |  | P | CDM data items compared as attributes |
| CDM | Association | Associative entity (M:N) | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | CHECK_ASSOCIATIONS (W) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| PDM | Table | Presence (code) | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | TABLE_MISSING (C) / TABLE_EXTRA (W) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| PDM | Table | Logical name | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | TABLE_LOGICAL_NAME (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| PDM | Table | Owner / schema | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | TABLE_OWNER (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| PDM | Table | Tablespace assignment | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | TABLE_TABLESPACE (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| PDM | Table | Comment / Definition | ✅ | ✅ | Step 1: PD Comment -> erwin Note | ✅ | ✅ | ❌ | ✅ | DOCUMENTATION sheet + documentation component (Note, then Comment, then Definition) | AUTOMATICALLY_MIGRATED |  | T | run_v1 writes 2_preprocessed/<m>.xml; documentation component (25 %) |
| PDM | Table | Extended attributes (UDPs) | ✅ | ✅ | Step 2: SAP extended attribute -> erwin UDP | ✅ | ✅ | ❌ | ✅ | UDP component (25 %), UDP_RECONCILIATION sheet, UDP tool comparison workbook | AUTOMATICALLY_MIGRATED |  | T/S | run_udp (Windows + erwin COM) injects into the handed-off .erwin; read-back pass rate is the evidence |
| PDM | Column | Presence (code) | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | COLUMN_MISSING (C) / COLUMN_EXTRA (W) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| PDM | Column | Logical name | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | COLUMN_LOGICAL_NAME (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| PDM | Column | Data type incl. length / precision | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | DATA_TYPE (C), DATA_TYPE_LENGTH (W), TYPE_* (V) | AUTOMATICALLY_VALIDATED |  | P/T | any change incl. VARCHAR(500)->VARCHAR(255) or DECIMAL(18,2)->DECIMAL(38,10) is a finding |
| PDM | Column | Nullable | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | NULLABILITY (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| PDM | Column | Default value | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | DEFAULT (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| PDM | Column | Domain binding | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | COLUMN_DOMAIN (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| PDM | Column | Check constraint | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | COLUMN_CHECK_CONSTRAINT (I) | AUTOMATICALLY_VALIDATED |  | P | presence on the erwin column |
| PDM | Column | Identity / auto-increment | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | COLUMN_IDENTITY (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| PDM | Column | Comment / Definition | ✅ | ✅ | Step 1: PD Comment -> erwin Note | ✅ | ✅ | ❌ | ✅ | DOCUMENTATION sheet + documentation component | AUTOMATICALLY_MIGRATED |  | T | run_v1 writes 2_preprocessed/<m>.xml; documentation component (25 %) |
| PDM | Column | Extended attributes (UDPs) | ✅ | ✅ | Step 2: SAP extended attribute -> erwin UDP | ✅ | ✅ | ❌ | ✅ | UDP component (25 %), UDP_RECONCILIATION sheet, UDP tool comparison workbook | AUTOMATICALLY_MIGRATED |  | T/S | run_udp (Windows + erwin COM) injects into the handed-off .erwin; read-back pass rate is the evidence |
| PDM | Column | Order | ✅ | ✅ | — | ✅ | ❌ | ✅ | ❌ | — | INTENTIONALLY_OUT_OF_SCOPE | set CHECK_COLUMN_ORDER=True | P |  |
| PDM | Primary Key | Membership | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | PRIMARY_KEY (C) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| PDM | Primary Key | Name | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | KEY_NAME (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| PDM | Alternate Key | Membership / uniqueness | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | INDEX_* signature (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| PDM | Alternate Key | Name | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | KEY_NAME (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| PDM | Reference (FK) | Parent / child / join columns | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | FOREIGN_KEY_MISSING/EXTRA (W/I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| PDM | Reference (FK) | Name | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | REFERENCE_NAME (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| PDM | Reference (FK) | RI update / delete rule | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | REFERENCE_RI_RULE (I) | PARTIALLY_SUPPORTED | confirm ERWIN_RI_RULE_CODES | P | provisional erwin code map |
| PDM | Reference (FK) | Cardinality / parent optionality | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | REFERENCE_CARDINALITY (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| PDM | Index | Member columns / unique | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | INDEX_MISSING/EXTRA (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| PDM | Index | Name | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | INDEX_NAME (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| PDM | Index | Column sort order | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | INDEX_SORT_ORDER (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| PDM | Index | Clustered / fill factor / DBMS options | ✅ | ✅ | — | ✅ | ❌ | ✅ | ❌ | — | FUTURE_ENHANCEMENT | needs one real PDM export to fix erwin tag names | P |  |
| PDM | View | Presence (code) | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | VIEW_MISSING (W) / VIEW_EXTRA (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| PDM | View | SQL definition | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | VIEW_SQL_MISMATCH (W) | PARTIALLY_SUPPORTED | lower SQL_SIMILARITY_THRESHOLD for literal fidelity | P | tolerant compare (>= 90 % similar after normalisation) |
| PDM | View | Columns | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | VIEW_COLUMNS (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| PDM | View | Comment / Definition | ✅ | ✅ | Step 1: PD Comment -> erwin Note | ✅ | ✅ | ❌ | ✅ | DOCUMENTATION sheet; VIEW_DEFINITION (I) when still missing | AUTOMATICALLY_MIGRATED |  | T | run_v1 writes 2_preprocessed/<m>.xml; documentation component (25 %) |
| PDM | Procedure / Function | Presence (code) | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | PROCEDURE_MISSING/EXTRA (W/I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| PDM | Procedure / Function | Body | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | PROCEDURE_BODY_MISMATCH (W) | PARTIALLY_SUPPORTED | lower SQL_SIMILARITY_THRESHOLD | P | tolerant compare |
| PDM | Procedure / Function | Parameters (as objects) | ✅ | ✅ | — | ❌ | ❌ | ✅ | ✅ | via body comparison | NOT_SUPPORTED_BY_ERWIN | parameters live in the SQL body, which is compared | P |  |
| PDM | Procedure / Function | Comment / Definition | ✅ | ✅ | Step 1: PD Comment -> erwin Note | ✅ | ✅ | ❌ | ✅ | DOCUMENTATION sheet; PROCEDURE_DEFINITION (I) | AUTOMATICALLY_MIGRATED |  | T | run_v1 writes 2_preprocessed/<m>.xml; documentation component (25 %) |
| PDM | Trigger | Presence (code) / owning table | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | TRIGGER_MISSING/EXTRA (W/I), TRIGGER_TABLE (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| PDM | Trigger | Body | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | TRIGGER_BODY_MISMATCH (W) | PARTIALLY_SUPPORTED | lower SQL_SIMILARITY_THRESHOLD | P | single literal change inside a >= 90 % similar body passes |
| PDM | Trigger | Event / timing | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | TRIGGER_EVENT (I) | NOT_YET_TESTED | confirm Trigger_Fire_On_* tag names on a real export | P |  |
| PDM | Trigger | Comment / Definition | ✅ | ✅ | Step 1: PD Comment -> erwin Note | ✅ | ✅ | ❌ | ✅ | DOCUMENTATION sheet; TRIGGER_DEFINITION (I) | AUTOMATICALLY_MIGRATED |  | T | run_v1 writes 2_preprocessed/<m>.xml; documentation component (25 %) |
| PDM | Sequence | Presence (code) | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | SEQUENCE_MISSING/EXTRA (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| PDM | Sequence | Start / increment / min / max | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | SEQUENCE_PARAMS (I) | NOT_YET_TESTED | confirm min/max erwin tag names on a real export | P |  |
| PDM | Sequence | Comment / Definition | ✅ | ✅ | Step 1: PD Comment -> erwin Note | ✅ | ✅ | ❌ | ✅ | DOCUMENTATION sheet; SEQUENCE_DEFINITION (I) | AUTOMATICALLY_MIGRATED |  | T | run_v1 writes 2_preprocessed/<m>.xml; documentation component (25 %) |
| PDM | Tablespace | Presence (code) | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | TABLESPACE_MISSING/EXTRA (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| PDM | Tablespace | Comment / Definition | ✅ | ✅ | Step 1: PD Comment -> erwin Note | ✅ | ✅ | ❌ | ✅ | DOCUMENTATION sheet; TABLESPACE_DEFINITION (I) | AUTOMATICALLY_MIGRATED |  | T | run_v1 writes 2_preprocessed/<m>.xml; documentation component (25 %) |
| PDM | Tablespace | Physical options (files, size) | ✅ | ✅ | — | ✅ | ❌ | ✅ | ❌ | — | FUTURE_ENHANCEMENT | needs one real PDM export | P |  |
| PDM | Domain (physical) | Existence / data type / default | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | DOMAIN_OBJECT (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| PDM | Business Rule | Existence / expression | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | BUSINESS_RULE_OBJECT (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| PDM | Default | Existence / value | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | DEFAULT_OBJECT (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| PDM | Data Format | Existence / expression | ✅ | ✅ | — | ❌ | ❌ | ✅ | ✅ | DATA_FORMAT_NOT_REPRESENTABLE (V census row) | NOT_SUPPORTED_BY_ERWIN | carry as a column UDP (Step 2) or in the column definition | P | erwin has no Data Format object; never silently dropped — listed per column in every report |
| PDM | Database target | DBMS name / version | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | DATABASE_TARGET (I) | AUTOMATICALLY_VALIDATED |  | P | version compared loosely |
| PDM | Diagram | Name / displayed tables | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | DIAGRAM_MISSING, DIAGRAM_SYMBOLS (I) | NOT_YET_TESTED | confirm with one export carrying Stored_Display | P |  |
| PDM | Package | Presence / contents | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | PACKAGE_MISSING/EXTRA (I), PACKAGE_CONTENTS (I) | AUTOMATICALLY_VALIDATED |  | P | erwin import carries it (manual step); loss/change is a finding |
| PDM | User / Owner | Owner on table | ✅ | ✅ | — | ✅ | ❌ | ✅ | ✅ | TABLE_OWNER (I) | AUTOMATICALLY_VALIDATED |  | P | erwin has no separate User object |
<!-- COVERAGE_MATRIX_ROWS:END -->

---

## 1. How to read this document (narrative sections §3–§6)

Three different things are being asked about for every property, and they are kept apart throughout:

| Column | Meaning | Who does it |
|---|---|---|
| **Migrated** | The value reaches the erwin model. | erwin's PowerDesigner import (MANUAL step in erwin) for almost everything; **Step 1** of the framework injects PD *Comments* as erwin *Definitions/Notes*; **Step 2** injects PD *Extended Attributes* as erwin *UDPs*. |
| **Validated** | If the value is lost or changed between PD and the erwin XML export, a finding appears in the report (and moves the fidelity score). | The CDM / LDM / PDM engines, plus the new `app/validation/extended_properties.py` module (all its findings are **INFO**). |
| **Excluded** | Deliberately not compared, with the reason. | — |
| **Planned / not yet** | Known gap with no check today. | — |

"Validated" was established **empirically**, not by reading code: each erwin fixture property is mutated on its own and the engine is run; the row is ✅ only when a CRITICAL / WARNING / INFO finding appears. The full row-by-row output is in `property_probe_matrix.md` (also `.json`); the test suite fails if any ✅ row stops being detected or any ❌ row unexpectedly starts being detected (so the document cannot silently drift from the code).

Severity legend for the "Validated by" column: **C** = CRITICAL (fails the model), **W** = WARNING, **I** = INFO (reported and scored at 0.05 weight, never fails a model on its own), **V** = VERIFIED census row (reported, never scored).

### What the real sample export told us

The only real pair available (`…_vessel.ldm` / `…_vessel.xml`, an LDM, XML V1) is thin: 22 entities, 24 relationships, 22 key groups, verb phrases, logical data types — and **no** domains, subject areas, stored displays (diagrams), definitions, defaults, RI rules on relationships (only model-level defaults), `Physical_Name`, or UDPs. PD side: no domains, identifiers, inheritances or packages either; it does carry 2 LogicalDiagrams and 23 Comments / ExtendedAttributesText.

Two consequences:

1. **Every extended check is guarded**: it only fires when the erwin export carries the vocabulary at all (an export that never writes `<Owner>` cannot "lose" an owner). When PD has the objects and erwin has none of the corresponding element, ONE model-level `…_NOT_CARRIED` INFO row is written instead of one per object. On the real vessel pair the new module produces **zero** findings — proven by `test_thin_export_like_the_real_sample_is_never_flooded` and a direct run.
2. The erwin tag names used for properties that the sample did not contain (listed in `extended_properties.UNVERIFIED_ERWIN_TAGS`: `Default_Value`, `Domain_Name`, `Owner`, `Tablespace_Ref`, `Identity`, `Key_Group_Member_Order`, `Key_Group_Sort_Order`, `Min_Value/Max_Value`, `Start_Value/Increment_Value`, `Trigger_Fire_On_*`, `View_Attribute`, `Stored_Display`, `Subject_Area`, `Entity_Ref`, `Validation_Rule`, `Default`, `Target_Server` …) follow erwin's XML property naming but **must be confirmed against one real full export** (a PDM with the objects below). If a name differs, the check simply stays silent — it cannot produce a false defect. **Action for the client:** export one PDM containing a view, procedure, trigger, sequence, tablespace, domain, default, index, identity column and a package to XML, and run `python -m tests.coverage_probe` after swapping the fixture — or send us the export.

---

## 3. Object-type inventory

### 2.1 CDM / LDM

| PD object | erwin equivalent | Supported | Migrated | Validated (engine) | Notes |
|---|---|---|---|---|---|
| Model | Model (ModelProps) | ✅ | name/type by import; comment by Step 1 | Name/Code/Type `MODEL_METADATA` (W); Definition `MODEL_DEFINITION` (I, new) | |
| Entity | Entity | ✅ | import (Step 1 for comment, Step 2 for UDPs) | presence `ENTITY_MISSING/EXTRA` (C/W); definition `DEFINITION_*`; UDPs scored by UDP component | |
| Entity Attribute | Attribute | ✅ | import (+Step 1/2) | see §3.1 | |
| Entity Identifier | Key_Group PK / AK | ✅ | import | membership `PRIMARY_IDENTIFIER` (C) / `ALTERNATE_IDENTIFIER` (W); name `IDENTIFIER_NAME` (I, new); member order `IDENTIFIER_MEMBER_ORDER` (I, new) | erwin also creates IE/IF groups for FKs; those are skipped by config `ERWIN_SKIP_KEY_GROUP_TYPES` |
| Business Rule | Validation_Rule | ✅ | import | name `BUSINESS_NAME`; expression `BUSINESS_RULE_EXPRESSION` (W); definition; type `BUSINESS_RULE_TYPE` (I, new) | |
| Domain | Domain | ✅ | import | data type `DOMAIN_MISMATCH` (W); definition; name `DOMAIN_NAME`, length `DOMAIN_LENGTH`, default `DOMAIN_DEFAULT`, check params `DOMAIN_CHECK_PARAMS` (all I, new) | erwin models check params as a Validation Rule / min-max on the domain |
| Relationship | Relationship | ✅ | import | see §3.3 | |
| Inheritance | Subtype_Relationship | ✅ | import | parent/children `INHERITANCE_STRUCTURE/EXTRA` (W); complete / exclusive `INHERITANCE_CONSTRAINT` (W); name `INHERITANCE_NAME` (I, new) | |
| Package | Subject_Area | ✅ (partial) | import | name / parent `SUBJECT_AREA` (I); definition `PACKAGE_DEFINITION`, contents `PACKAGE_CONTENTS`, parent lost `PACKAGE_HIERARCHY` (I, new) | **sample export carried no Subject_Area** — see §4 |
| Diagram | Stored_Display | ✅ (partial) | import? | name `DIAGRAM_MISSING`, displayed objects `DIAGRAM_SYMBOLS` (I, new) | **PD sample had 2 diagrams, erwin export had 0 Stored_Display** → either the import dropped them or Save-As-XML omitted them. Verify in erwin; the check is silent until an export carries them. |
| Extended Attributes (UDP definitions + values) | UDP | ✅ | **Step 2** (`run_udp`, erwin COM on Windows, into the handed-off .erwin) | UDP component of the fidelity score (V2/V3), `UDP_RECONCILIATION` sheet | not a finding category by design |
| Shortcut (LDM) | UDP (`PD_Shortcut_*`, `PD_NameTerms`, `PD_CodeTerms`) | ✅ | **Step 2** (`run_udp`, via `app/validation/shortcut_udp.py`) | UDP component of the fidelity score (V2/V3), UDP tool comparison workbook; `SHORTCUT_*` (I) census | erwin has no shortcut object, so the content is carried as UDPs instead of being dropped. The migratable fact is the per-object glossary binding (`c:RelatedNameTerms` / `c:RelatedCodeTerms`): 102 of 105 entities in real_estate. Bindings owned by relationships, attributes, inheritances and diagrams are counted into `PD_Shortcut_Count` at the model root, because `erwin_load` can only apply a value to an Entity or the model root. |
| Data Item (CDM) | Attribute | ✅ | import | folded into attribute comparison | |
| Association / associative entity (CDM) | Relationship type 4 (M:N) | ✅ | import | `CHECK_ASSOCIATIONS` | |

### 2.2 PDM

| PD object | erwin equivalent | Supported | Migrated | Validated (engine) | Notes |
|---|---|---|---|---|---|
| Table | Entity (physical) | ✅ | import (+Step 1/2) | presence `TABLE_MISSING/EXTRA` (C/W); logical name `TABLE_LOGICAL_NAME`, owner `TABLE_OWNER`, tablespace `TABLE_TABLESPACE` (I, new); comment → DOCUMENTATION sheet | |
| Column | Attribute | ✅ | import | see §3.5 | |
| Key (PK, AK) | Key_Group PK / AK | ✅ | import | PK membership `PRIMARY_KEY` (C); AK membership + uniqueness via `INDEX` signature (I); name `KEY_NAME` (I, new) | |
| Reference (FK) | Relationship | ✅ | import | parent/child + join columns `FOREIGN_KEY_*` (W); name `REFERENCE_NAME`, RI `REFERENCE_RI_RULE`, cardinality/optionality `REFERENCE_CARDINALITY` (I, new) | |
| Index | Key_Group IE / AK | ✅ | import | members + unique flag `INDEX_*` (I); name `INDEX_NAME`, sort order `INDEX_SORT_ORDER` (I, new) | |
| View | View | ✅ | import | code `VIEW_MISSING` (W); SQL `VIEW_SQL_MISMATCH` (W); columns `VIEW_COLUMNS`, comment `VIEW_DEFINITION` (I, new) | |
| Procedure / Function | Stored_Procedure / Function | ✅ | import | code `PROCEDURE_MISSING` (W); body `PROCEDURE_BODY_MISMATCH` (W); comment `PROCEDURE_DEFINITION` (I, new) | parameters: see §3 |
| Trigger | Trigger (under Entity) | ✅ | import | code `TRIGGER_MISSING` (W); body `TRIGGER_BODY_MISMATCH` (W); event `TRIGGER_EVENT`, owning table `TRIGGER_TABLE`, comment `TRIGGER_DEFINITION` (I, new) | |
| Business Rule | Validation_Rule | ✅ | import | existence + expression `BUSINESS_RULE_OBJECT` (I, new) | previously not parsed by the PDM engine |
| Domain (physical) | Domain | ✅ | import | existence, data type, default `DOMAIN_OBJECT` (I, new) | previously not parsed by the PDM engine |
| Default | Default | ✅ | import | existence + value `DEFAULT_OBJECT` (I, new) | |
| Tablespace | Tablespace | ✅ | import | code `TABLESPACE_MISSING/EXTRA` (I); comment `TABLESPACE_DEFINITION` (I, new) | |
| Sequence | Sequence | ✅ | import | code `SEQUENCE_MISSING` (I); start / increment / min / max `SEQUENCE_PARAMS` (I, new) | |
| Data Format | **none** | ⚠️ no erwin equivalent | **not migrated** | `DATA_FORMAT_NOT_REPRESENTABLE` (V census row, lists the columns using it) | erwin has no display-format object. Alternative: carry the format expression as a column UDP (Step 2) or in the column definition. |
| Database Target (DBMS) | ModelEnvProps/Target_Server | ✅ | import (target chosen at import time) | `DATABASE_TARGET` (I, new) — differs, or empty in erwin | the vessel LDM export had an empty `<Target_Server>`; for a PDM this must be set |
| Diagram | Stored_Display | ✅ (partial) | import? | `DIAGRAM_MISSING`, `DIAGRAM_SYMBOLS` (I, new) | same caveat as CDM/LDM |
| Package | Subject_Area | ✅ | import | code `PACKAGE_MISSING/EXTRA` (I); contents `PACKAGE_CONTENTS` (I, new) | |
| User / Owner | Owner property on Entity | ✅ | import | via `TABLE_OWNER` | erwin has no separate User object |

---

## 4. Property-level detail (narrative)

Columns: **Migrated** (by whom) · **Validated** (finding category, severity) · **Excluded / Planned** (reason). Empty "Excluded" means the property is fully covered.

### 3.1 Entity Attribute (CDM / LDM)

| Property | Migrated | Validated | Excluded / planned |
|---|---|---|---|
| Name | import | `BUSINESS_NAME` (W) | |
| Code / physical name | import (`Physical_Name`) | `FALLBACK_MATCH` (I) when the attribute can only be matched on code | suppressed when erwin code == name (no Code field in CDM) |
| Definition / Comment | **Step 1** | `DEFINITION_MISMATCH` (W), `DEFINITION_LOSS`, `DEFINITION_PARTIAL` (I) | |
| Data type | import | `DATA_TYPE` (C) | |
| Length | import | `LENGTH_PRECISION` (W) | |
| Precision / scale | import | `LENGTH_PRECISION` (W) | |
| Mandatory / optional | import (`Null_Option_Type` 1/0) | `MANDATORY` (W) — **CDM parser fixed this round** (numeric code path ported from LDM) | |
| Domain assignment | import (`Domain_Name`) | `ATTRIBUTE_DOMAIN` (I, new) — changed or lost | before: only the domain's *type* was compared, so a lost binding with identical type passed silently |
| Default value | import (`Default_Value`) | `ATTRIBUTE_DEFAULT` (I, new) | |
| Extended attributes (UDPs) | **Step 2** | UDP fidelity component + `UDP_RECONCILIATION` sheet | not a finding by design (scored) |
| Order / sequence | import | — | **excluded**: `CHECK_ATTRIBUTE_ORDER = False` (order is not governed; erwin re-orders keys first). Switch on in config if required. |
| Multiplicity (min/max occurrences) | import | `MULTIPLICITY_*` | |

### 3.2 Entity Identifier (CDM / LDM)

| Property | Migrated | Validated | Excluded / planned |
|---|---|---|---|
| Primary identifier membership | import | `PRIMARY_IDENTIFIER` (C) | |
| Alternate identifier membership | import | `ALTERNATE_IDENTIFIER` (W) | |
| Primary flag lost (PK → AK) | import | `PRIMARY_IDENTIFIER` + `ALTERNATE_IDENTIFIER` | |
| Name / Code | import | `IDENTIFIER_NAME` (I, new) | |
| Member order | import (`Key_Group_Member_Order`) | `IDENTIFIER_MEMBER_ORDER` (I, new) | only when the export writes member order |

### 3.3 Relationship (CDM / LDM)

| Property | Migrated | Validated | Excluded / planned |
|---|---|---|---|
| Parent / child entity | import | `RELATIONSHIP_MISSING/EXTRA` (W) | |
| Name / verb phrase (both directions) | import | `ROLE_NAME` (I) | |
| Definition | Step 1 | `DEFINITION_MISMATCH` | |
| Cardinality (many end) | import (`Cardinality` -3/-2/-1) | `CARDINALITY` (W) | `-2` → `1,n` mapping fixed in round 1 |
| Mandatory parent / optionality | import (`Null_Option_Type` 101/100) | `OPTIONALITY` (W) + `RELATIONSHIP_SEMANTIC_MISMATCH` | derived from PD cardinality lower bound (round 1 fix) |
| Identifying / dependent flag | import (`Type` 2/7) | `RELATIONSHIP_SEMANTIC_MISMATCH` | PD `DependentRole` read (round 1 fix) |
| Referential integrity — update rule | import (`Parent_Update_Rule`, or model default per relationship kind) | `RELATIONSHIP_RI_RULE` (I, new); unmapped codes → `RELATIONSHIP_RI_RULE_UNMAPPED` | **erwin code map is provisional** (`ERWIN_RI_RULE_CODES`); real sample carries rules only as model defaults. Compared only when PD states a rule. |
| Referential integrity — delete rule | as above (`Parent_Delete_Rule`) | as above | as above |
| Dominance | — | — | **excluded**: erwin has no dominance property; PD `DominantRole` cannot be represented. Alternative: none needed for erwin; record as UDP if it must survive to Collibra. |
| Role names (PD `Entity1ToEntity2Role`) | import (verb phrases) | `ROLE_NAME` | |

### 3.4 Inheritance · Domain · Business Rule · Package · Diagram · Model (CDM / LDM)

| Object · property | Migrated | Validated | Excluded / planned |
|---|---|---|---|
| Inheritance · parent entity | import | `FALLBACK_MATCH` / `INHERITANCE_STRUCTURE` | |
| Inheritance · child entities | import | `INHERITANCE_EXTRA`, `INHERITANCE_STRUCTURE`, `MODEL_QUALITY` | |
| Inheritance · complete / incomplete | import (`Completeness`) | `INHERITANCE_CONSTRAINT` (W) | |
| Inheritance · mutually exclusive | import (`Exclusivity`) | `INHERITANCE_CONSTRAINT` (W) | |
| Inheritance · name | import | `INHERITANCE_NAME` (I, new) | |
| Domain · data type | import | `DOMAIN_MISMATCH` (W) | |
| Domain · length / precision | import | `DOMAIN_LENGTH` (I, new); precision folded into type | |
| Domain · definition | Step 1 | `DEFINITION_MISMATCH` | |
| Domain · default value | import | `DOMAIN_DEFAULT` (I, new) | |
| Domain · check parameters (low / high / list of values / format) | import → erwin Validation Rule / Min-Max | `DOMAIN_CHECK_PARAMS` (I, new): lost, or min/max value changed | list-of-values and format compared as *present/absent* only (erwin stores them in a Validation Rule) |
| Domain · name | import | `DOMAIN_NAME` (I, new) when code carried but name differs | |
| Business rule · name / expression / definition | import (+Step 1) | `BUSINESS_NAME`, `BUSINESS_RULE_EXPRESSION` (W), `DEFINITION_*` | |
| Business rule · type | import (`Rule_Type`) | `BUSINESS_RULE_TYPE` (I, new) | |
| Package · name | import | `SUBJECT_AREA` (I) | |
| Package · hierarchy (parent changed) | import | `SUBJECT_AREA` (I) | |
| Package · hierarchy (parent lost → root) | import | `PACKAGE_HIERARCHY` (I, new) | fires only when the export still writes `Parent_Subject_Area` somewhere; with a single nested package the loss cannot be told from "export never writes parents" |
| Package · contents (entities) | import (`Entity_Ref`) | `PACKAGE_CONTENTS` (I, new) | same guard: when the *only* subject area loses all refs, indistinguishable from an export without contents |
| Package · definition | Step 1 | `PACKAGE_DEFINITION` (I, new) | |
| Diagram · name | import? | `DIAGRAM_MISSING` (I, new) | only when the export carries `Stored_Display` (the sample did not) |
| Diagram · symbols displayed | import? | `DIAGRAM_SYMBOLS` (I, new) — entities shown | erwin drawing-object tag names unverified; layout/positions **excluded** (not a fidelity concern) |
| Model · name / code / type | import | `MODEL_METADATA` (W) | |
| Model · definition | Step 1 | `MODEL_DEFINITION` (I, new) | |
| Model · extended attributes | Step 2 | UDP component | |

### 3.5 Table and Column (PDM)

| Object · property | Migrated | Validated | Excluded / planned |
|---|---|---|---|
| Table · code / physical name | import | `TABLE_MISSING/EXTRA` (C/W) | |
| Table · logical name | import | `TABLE_LOGICAL_NAME` (I, new) | one model-level row when the export never writes a Name distinct from Physical_Name |
| Table · owner / schema | import (`Owner`) | `TABLE_OWNER` (I, new) | |
| Table · tablespace assignment | import (`Tablespace_Ref`) | `TABLE_TABLESPACE` (I, new) | |
| Table · definition / comment | **Step 1** (PDM now runs the comment→Note injector, same as CDM/LDM) | DOCUMENTATION sheet + documentation component of the score (25 %) | erwin Note is the carrier; Comment / Definition credited as fallbacks |
| Table · extended attributes | Step 2 | UDP component | |
| Column · code | import | `COLUMN_MISSING/EXTRA` (C/W) | |
| Column · logical name | import | `COLUMN_LOGICAL_NAME` (I, new) | |
| Column · data type / length / precision | import | `DATA_TYPE*` (C/W), `TYPE_*` classification | |
| Column · nullable | import | `NULLABILITY` (I) | |
| Column · default value | import | `DEFAULT` (I) | |
| Column · domain binding | import (`Domain_Name`) | `COLUMN_DOMAIN` (I, new) | |
| Column · check constraint / validation parameters | import (Validation Rule ref / min-max) | `COLUMN_CHECK_CONSTRAINT` (I, new) — presence on the erwin column | expression text compared via `BUSINESS_RULE_OBJECT` when it is a named rule |
| Column · identity / auto-increment | import (`Identity`) | `COLUMN_IDENTITY` (I, new) | |
| Column · definition / comment | **Step 1** | DOCUMENTATION sheet + documentation component | |
| Column · order | import | — | **excluded**: `CHECK_COLUMN_ORDER = False` |

### 3.6 Key · Reference · Index (PDM)

| Object · property | Migrated | Validated | Excluded / planned |
|---|---|---|---|
| PK · membership | import | `PRIMARY_KEY` (C) | |
| PK · name | import | `KEY_NAME` (I, new) | |
| AK · membership / uniqueness | import (Key_Group AK, `Is_Unique`) | `INDEX_*` signature (I) | |
| AK · name | import | `KEY_NAME` (I, new) | |
| Reference · parent / child table | import | `FOREIGN_KEY_MISSING/EXTRA` (W/I) | |
| Reference · join columns | import (`Parent_Attribute_Ref`) | `FOREIGN_KEY_*` | |
| Reference · name / constraint name | import | `REFERENCE_NAME` (I, new) | |
| Reference · RI update / delete rule | import | `REFERENCE_RI_RULE` (I, new) | provisional erwin code map (see §3.3) |
| Reference · cardinality / parent optionality | import | `REFERENCE_CARDINALITY` (I, new) | compared only when PD states `Cardinality` / `ParentMandatory` |
| Index · member columns / unique flag | import (Key_Group IE) | `INDEX_MISSING/EXTRA` (I) | |
| Index · name | import | `INDEX_NAME` (I, new) | |
| Index · column sort order | import (`Key_Group_Sort_Order`) | `INDEX_SORT_ORDER` (I, new) | |
| Index · clustered / fill factor / other DBMS options | import | — | **planned**: DBMS-specific physical options not compared |

### 3.7 View · Procedure · Trigger · Sequence · Tablespace (PDM)

| Object · property | Migrated | Validated | Excluded / planned |
|---|---|---|---|
| View · code | import | `VIEW_MISSING/EXTRA` (W/I) | |
| View · SQL definition | import (`User_Defined_SQL`) | `VIEW_SQL_MISMATCH` (W) | tolerant compare (≥ 90 % similarity after normalisation) |
| View · columns | import (`View_Attribute`) | `VIEW_COLUMNS` (I, new) | |
| View · comment | **Step 1** (`pd_comment_to_erwin_note.py` now covers View / Procedure / Function / Trigger / Sequence / Tablespace) | DOCUMENTATION sheet + documentation component; `VIEW_DEFINITION` (I) when still missing | |
| Procedure / Function · code | import | `PROCEDURE_MISSING/EXTRA` | functions pooled with procedures |
| Procedure / Function · body | import | `PROCEDURE_BODY_MISMATCH` (W) | tolerant compare |
| Procedure · parameters | import (inside the body) | via body comparison | **excluded as a separate property**: erwin has no parameter object; parameters live in the SQL body, which *is* compared |
| Procedure · comment | Step 1 | DOCUMENTATION sheet; `PROCEDURE_DEFINITION` (I) | |
| Trigger · code | import | `TRIGGER_MISSING/EXTRA` | |
| Trigger · body | import | `TRIGGER_BODY_MISMATCH` (W) | **tolerance caveat**: a single literal change inside an otherwise identical body (≥ 90 % similar) passes; a rewrite is caught. Lower `SQL_SIMILARITY_THRESHOLD` if literal fidelity matters. |
| Trigger · event / timing | import (`Trigger_Fire_On_Insert/Update/Delete`) | `TRIGGER_EVENT` (I, new) | erwin flag names unverified |
| Trigger · owning table | import | `TRIGGER_TABLE` (I, new) | |
| Trigger · comment | Step 1 | DOCUMENTATION sheet; `TRIGGER_DEFINITION` (I) | |
| Sequence · code | import | `SEQUENCE_MISSING/EXTRA` (I) | |
| Sequence · start / increment / min / max | import | `SEQUENCE_PARAMS` (I, new) | min/max erwin tag names unverified |
| Tablespace · code | import | `TABLESPACE_MISSING/EXTRA` (I) | |
| Tablespace · comment | Step 1 | DOCUMENTATION sheet; `TABLESPACE_DEFINITION` (I) | |
| Tablespace · physical options (files, size) | import | — | **planned** |

### 3.8 Domain · Business Rule · Default · Data Format · DBMS · Diagram · Package (PDM)

| Object · property | Migrated | Validated | Excluded / planned |
|---|---|---|---|
| Domain · existence, data type, default | import | `DOMAIN_OBJECT` (I, new) | |
| Business rule · existence, expression | import | `BUSINESS_RULE_OBJECT` (I, new) | |
| Default · existence, value | import | `DEFAULT_OBJECT` (I, new) | |
| Data Format · existence, expression | **not migratable** | `DATA_FORMAT_NOT_REPRESENTABLE` (V) | erwin has no Data Format object — reported as a census row naming the columns that use it |
| Database target · DBMS name / version | import | `DATABASE_TARGET` (I, new) — differs, or not set | version compared loosely (token match) |
| Diagram · name / displayed tables | import? | `DIAGRAM_MISSING`, `DIAGRAM_SYMBOLS` (I, new) | only when the export carries `Stored_Display` |
| Package · code | import | `PACKAGE_MISSING/EXTRA` (I) | |
| Package · contents (tables) | import (`Entity_Ref`) | `PACKAGE_CONTENTS` (I, new) | |

---

## 5. Intentionally excluded (summary) and alternatives

| Item | Why | Alternative |
|---|---|---|
| Relationship dominance | Not representable in erwin. | Carry as a relationship UDP (Step 2) if it must reach Collibra / BizzDesign. |
| Data Format | No erwin object. | Column UDP or definition text; census row keeps it visible in every report. |
| Attribute / column order | Ungoverned; erwin re-orders keys. `CHECK_ATTRIBUTE_ORDER` / `CHECK_COLUMN_ORDER` = False. | Flip the toggle. |
| Diagram layout (positions, colours, fonts) | Presentation, not model content. | Diagrams are checked for *existence* and *displayed objects* only. |
| UDP values as findings | Scored by the UDP component (25 % weight) with a dedicated sheet. | — |
| Procedure parameters as separate objects | erwin keeps them in the body; body is compared. | — |
| Physical DBMS options (index clustering, fill factor, tablespace files) | Not compared. | **Planned** — needs one real PDM export to fix tag names. |
| Step 1 comment injection for packages / subject areas | Injector covers entities, attributes, tables, columns, views, procedures, functions, triggers, sequences, tablespaces. | Package comments are validated (`PACKAGE_DEFINITION` INFO); injection into Subject_Area not implemented. |

---

## 6. Test models — how the PD samples were extended

The client asked for the PowerDesigner models to be extended with representative Views, Triggers, Procedures etc. Two things were done:

1. **Synthetic full-coverage fixtures** (`tests/fixtures_extended.py`): `PD_LDM_FULL` (Fleet: 2 domains with default / low-high / list-of-values / format, business rule, package hierarchy with a contained entity, 3 entities incl. defaults + domain bindings, PK + 2-column AK, relationship with roles + RI, inheritance incomplete/exclusive, diagram with symbols, UDPs) and `PD_PDM_FULL` (FleetDB: DBMS, tablespace, physical domain, default, data format, business rule, package with table, 3 tables with owner / tablespace / identity / check / domain / FK, PK/AK/index with sort order, trigger with event, view with columns + SQL, procedure with parameters, function, sequence with start/incr/min/max, diagram). Each has a faithful erwin export (`ERWIN_*_FULL`) so the baseline is clean (LDM 99.46 %, CDM 99.74 %, PDM 100 %) and any single mutation isolates one property. They drive `coverage_probe.py`, `test_property_coverage.py` and the new report test `ExtendedFixtureReportTests`.
2. **What still needs the real tool**: the fixtures are hand-written XML in PD's and erwin's vocabularies. To close the "unverified tag names" caveat the client should build the same FleetDB model in PowerDesigner, import it into erwin, Save-As-XML, and drop the pair into `sappdmodels/pdm/` + `erwinmodels/1_initial/`; `run_v1.py` will then produce the FINDINGS sheet with every category in this document. The `_NOT_CARRIED` rows that appear tell you exactly which properties erwin's import dropped.

---

## 7. Change history

| File | Change |
|---|---|
| `app/validation/extended_properties.py` | **new** — generic PD/erwin XML indexers + 24 property checks, INFO severity, per-check toggles, "not carried" guard, never raises. 92 % covered by tests. |
| `app/config/validation_config.py` | `CHECK_EXTENDED_PROPERTIES`, `EXTENDED_PROPERTY_CHECKS`, `PD_RI_RULE_CODES`, `ERWIN_RI_RULE_CODES` (provisional); `ERWIN_ATTRIBUTE_NULL_OPTION_CODES` moved from LDM to `_Semantic` so CDM shares it. |
| `app/validation/ldm_reconcile/comparator.py`, `cdm_reconcile/comparator.py` | one call `extended_properties.apply(result, tier, config)` before `result.finalise()`. |
| `app/validation/pdm_reconcile/pdm_erwin_validator/comparator.py` | same call before `compute_status()/compute_score()`, guarded for standalone use. |
| `app/validation/cdm_reconcile/erwin_cdm_parser.py` | **bug fix**: attribute mandatory flag now reads erwin's numeric `Null_Option_Type` (was phrase-only → every CDM attribute read as optional → `MANDATORY` never fired). |
| `app/validation/cdm_reconcile/pd_cdm_parser.py` | accepts `LogicalAttribute.Mandatory` as well as `Mandatory`. |
| `tests/fixtures_extended.py` | full-coverage PD/erwin fixtures (see §5). |
| `tests/coverage_probe.py` | 180 probes, runnable as `python -m tests.coverage_probe [--json]`. |
| `tests/test_property_coverage.py` | **new** — probe contract + behaviour tests (guards, toggles, RI fallback, trigger move, report integration). |
| `tests/test_end_to_end_reports.py` | `ExtendedFixtureReportTests`: new categories reach the V3 workbook. |
| `tests/__init__.py` | new (package). |

Results: **290 tests pass**, ruff 0 findings, coverage **78.8 %** (was 71.2 %). Probes: **161 / 180** detected; the 19 undetected rows are all in §4 (excluded by design) or the two "indistinguishable from a thin export" guard cases.

---

## 8. Second verification pass — 2026-09-15

This section exists because the first remediation pass was **not** taken as
sufficient. An independent audit re-derived the framework's behaviour from the
code and the two real LDM exports rather than from the previous pass's own
report. It found defects the first pass had not, and this section records what
it found, what was changed, and — more importantly — what is still not true.

### 8.1 Defects found and fixed

| # | Defect | Evidence it was real | Fix |
|---|---|---|---|
| 1 | **Three different RTF normalisers.** The LDM tier used a proper tokenizer; CDM used a regex chain; PDM used a 3-line regex. The two sides of a single comparison were normalised by different code, because the Comment→Note injector writes the erwin side with the LDM tokenizer. | `Caf\'e9 \'93quoted\'94` → LDM/injector `Café “quoted”`, CDM `Café \x93quoted\x94`. Identical text, reported MISMATCH. CDM also **deleted content**: `C:\\Users\\x` → `Path C:\ and`. PDM left the font table and `\*\generator` in the compared string, so *every* RTF-wrapped PDM comment mismatched however well it migrated. | `app/common/rtf_text.py` — ONE implementation; CDM, PDM and the injector delegate to it. `tests/test_post_fix_verification.py` asserts all four agree on 8 cases. |
| 2 | **The CDM docstring claimed the stripper was report-only** and changed no validation result. `_description()` called it directly, so the defects above were scoring DEFINITION findings. | `pd_cdm_parser.py:154`. | Docstring corrected; the delegation makes the claim moot. |
| 3 | **A UDP stage that had not run was scored as a measured 0 %.** Structural 100.00 + documentation 100.00 + udp 0.00 = 75.00, while `stage_state` recorded `UDP = WAITING_FOR_MANUAL_INPUT` in the same run. The score said "measured, everything lost"; the state file said "has not run". | Both sample LDMs at V2, before the fix. | `fidelity_stages.UDP_NOT_MEASURED` sentinel. Reached **only** on the recorded fact that the stage has not executed — once it has run, whatever it measured stands, including 0 %, so a genuine injection failure is still scored as the loss it is. V2 now reads `udp=n/a`, 99.48 % / 100.00 %. |
| 4 | **The attribute-level `CODE_NOT_CARRIED` guard existed on LDM but not on CDM.** The entity level had it on both. The same source model therefore scored differently at the two tiers. | `cdm_reconcile/comparator.py:547` had no guard. | `_erwin_has_own_code` added to the CDM comparator; a test asserts both tiers' predicates agree. |
| 5 | **erwin CDM ignored `Key_Group_Member_Order`.** It read only `Sequence`/`Position`/`Order`, while the LDM and PDM parsers read erwin's actual spelling first. On an export that writes it, every CDM identifier's members fell back to sequence 0 and document order. | `erwin_cdm_parser.py:471` vs `erwin_ldm_parser.py`, `erwin_parser.py:270`. | Lookup order aligned across all three tiers. Not observable on the supplied exports (they carry no member-order tags at all), so this is a defensive fix. |
| 6 | **`_parse_entity_key_groups` was defined twice** in the PDM erwin parser. The dead first copy unpacked a 2-tuple from a function returning a dict and would have raised the moment the two were reordered. | `erwin_parser.py:338` and `:402`. | Dead copy removed; a test asserts no shadowed top-level definitions. |
| 7 | **The RTF keyword pattern was not reproducible between runs.** Built from a set sorted by length only, so equal-length keywords landed in hash-randomised order. Output was stable; the pattern was not auditable. | Pattern MD5 differed across `PYTHONHASHSEED` 0 / 1 / 12345. | Sort key pinned to `(-len, keyword)`. |
| 8 | **The fidelity score was not reconstructible from the report.** | — | New `SCORE_RECONCILIATION` sheet (`app/reporting/score_audit.py`) rebuilds the number from the workbook's own FINDINGS rows, lists every severity including the non-scoring ones with the reason each is excluded, and prints an explicit **AGREES / DISAGREES** verdict. |

### 8.2 Verified correct — no change needed

* **No ML, regression, historical or predicted scoring exists anywhere.** Full-repo sweep for `sklearn`, `LinearRegression`, `RandomForest`, `statsmodels`, `torch`, `polyfit`, "prediction", "historical score": 11 hits, all doc prose or pytest "regression test". `requirements.txt` is `defusedxml, lxml, openpyxl, pytest, pywin32`. Every input to the score is a count from parsing *this* source against *this* target. Locked by `test_no_statistical_or_ml_machinery_participates_in_scoring`.
* **The PK/primary-identifier four-case matrix is correct on all three tiers.** A: PD has / erwin lost → `PRIMARY_IDENTIFIER` or `PRIMARY_KEY`, CRITICAL. B: PD lacks / erwin has → `UNEXPECTED_TRANSFORMATION` (LDM/CDM) or `PRIMARY_KEY_PD_ONLY` (PDM) — a *different* key from A, so a report grouped by category can tell a fabrication from a loss. C: neither → `MODEL_QUALITY` / `PRIMARY_KEY_ABSENT_BOTH` at `SOURCE_PRE_EXISTING`: **visible, weight 0**. D: both → `IDENTIFIER_VERIFIED` / `KEY_VERIFIED`.
* **Manual handoffs never produce a silent zero or a silent pass.** A missing XML V1, a missing `.erwin` and a missing XML V3 each record `WAITING_FOR_MANUAL_INPUT` with an operator instruction and a fingerprint of what was looked for. A missing XML V3 is a hard stop — the model is not scored and the promotion gate is not evaluated. An artefact that exists but is invalid is `FAILED`, deliberately distinct from "not done yet".
* **Model identity is enforced.** A SAP PD model reconciled against another model's erwin export is refused by `_same_model` before it is scored; stored UDP evidence is refused on model mismatch, on source-file change (SHA-256) and on schema drift. Negative test: `test_swapping_two_models_erwin_exports_is_rejected_not_scored`, with the correctly paired control so the guard is discriminating rather than always-refusing.

### 8.3 Scores, reconstructed from the finding rows

Both reconstruct exactly; the arithmetic is now in the workbook.

| Model | comparable | penalty | structural | Scoring findings | Visible, non-scoring |
|---|---|---|---|---|---|
| `modeling_and_simulation` | E18+A82+R22+I19+H0 = 141 | 1×1.0 + 2×0.05 = 1.10 | **99.22** | 1 CRITICAL `DATA_TYPE`, 1 INFO `DEFINITION_PARTIAL`, 1 INFO `MODEL_DEFINITION` | 41 `SOURCE_PRE_EXISTING` + 218 `VERIFIED` |
| `real_estate` | E105+A42+R130+I0+H2 = 279 | 0 | **100.00** | none | 147 `SOURCE_PRE_EXISTING` (42 `CODE_NOT_CARRIED` + 105 `MODEL_QUALITY`) + 362 `VERIFIED` |

The 147 `real_estate` rows are **still in the report** — reclassified, not deleted. That is the whole basis on which the score improved, and `test_non_scoring_findings_stay_visible_in_the_report` fails if they ever stop being emitted. The `modeling_and_simulation` true positives are locked in by `test_genuine_defects_on_modeling_and_simulation_are_still_reported`.

### 8.4 Known gaps — NOT fixed, and why

These are real and remain open. They are listed so nobody reads §2 as a claim of completeness.

| Gap | Status | Why it is still open |
|---|---|---|
| **Description → erwin `<Definition>` injection** | `NOT_YET_TESTED` / `MANUAL_REQUIRED` | The injector is a byte-splice whose Note format was derived empirically by diffing an erwin-authored export. `modeling_and_simulation`'s export contains 2 erwin-authored `<Definition>` elements (model-level and one entity), `real_estate`'s contains 0 — not enough to derive the format for attributes, relationships or domains. Writing it blind would be inventing erwin's format, which is exactly what "never invent erwin support" forbids. Needs one erwin export with hand-populated Definitions on each object type. |
| **Attribute-level `PD_Code` preservation** | open | `app/udp_tool/erwin_load.py:359` resolves injection targets by **entity name only** and cannot address an attribute. Options are a machine-readable code-preservation ledger (safe) or modifying `erwin_load.py` (breaks the "nothing in `app/udp_tool` is modified" invariant, on a Windows-only COM path that cannot be tested here). Entity-level `PD_Code` works today; attribute-level codes are reported as `CODE_NOT_CARRIED` and are genuinely not yet in erwin. |
| **CDM has no `definition_field` provenance** | open | The LDM tier records which SAP PD field was compared against which erwin field and prints it in the finding message; CDM does not. A CDM definition finding therefore cannot say whether it compared two Definitions or a Comment against a Note. No CDM sample model exists in this checkout to verify a change against. |
| **PDM structural comparator reads no definitions** | open | `pd_parser.py` and `erwin_parser.py` give tables and columns no definition at all; `_definition()` on the erwin side is wired only to views/procedures/functions/triggers/packages. PDM table and column documentation is covered **only** by the separate `pdm_documentation` sheet, so the structural comparator cannot emit `DEFINITION_LOSS` for them. PDM comments parsed at `pd_parser.py:117` have no consumer at all. |
| **PDM business rules are structurally unvalidated** | open | Neither PDM parser reads `o:BusinessRule` / `Validation_Rule`; `extended_properties.py` covers them at INFO only. |
| **erwin PDM references carry no cardinality or identifying flag** | open | The LDM/CDM tiers resolve both from the same element vocabulary. No PDM erwin sample exists in this checkout to confirm the properties are present to read. |
| **`UNVERIFIED_ERWIN_TAGS`** | 28 tag names | `extended_properties.py:51` lists erwin tag names never observed on a real export. The `_carries` guard means a spelling mismatch makes a check **silently not fire** rather than report. Confirming them needs an export that contains the constructs. |
| **LDM does not use the `Is_Unique=false` inversion-entry rule** that CDM does | open by choice | Adding it would suppress findings, and neither supplied export carries `Is_Unique` at all, so the change could not be verified against real data. Documented rather than applied. |
| **`sappdmodels/cdm/` and `sappdmodels/pdm/` are empty** | — | Every CDM and PDM row in §2 is backed by synthetic fixtures and probes, not by a real model pair. The Simple/Medium/Complex × CDM/LDM/PDM grid is therefore complete only for LDM. |

### 8.5 Flow — what the code actually does

The documented flow is accurate with these corrections; they are documentation errors, not code defects.

* `erwinmodels/1_initial/*.xml` is an **input** to `run_v1`, not its output. It is the operator's manual erwin export. `run_v1` reads and validates it and never modifies it.
* `run_v1` has a second output the diagram omits: **Step 1 writes `erwinmodels/2_preprocessed/<model>.xml`** (comments injected). That file — not `1_initial` — is what the operator opens in erwin to produce the `.erwin`.
* There is a **V2 stage**, measured by `run_v3` against `2_preprocessed/<model>.xml`. The framework is V1 → V2 → V3.
* The `.erwin` handoff is not purely manual: `erwin_handoff.ensure` tries erwin COM first, then an interactive prompt, then an unattended poll. Manual is the fallback.
* There is **no single "combined V1 + UDP/V3" number.** The only combination is *within* each stage — the weighted mean of structural / documentation / udp. Progression across stages is shown as one row per stage plus the delta, on `FIDELITY_PROGRESSION`, and the arithmetic behind the reported stage is now on `SCORE_RECONCILIATION`.
* On gate PASS the model is promoted to `erwinmodels/3_final/`; on FAIL it stays in `2_preprocessed` and its reports route to `manual_review_reports/`.

### 8.6 Late finding — V3 was silently the V2 artefact

Found while re-running the two real models for §8.3, not by reading the code.

`FINAL_XML_FALLBACK_TO_PREPROCESSED` is declared `"true"` in
`app/config/settings.py:62`, while **every** call site reads it as
`get_setting(..., False)` and every docstring describes it as off by default.
The call-site default is dead — `get_setting` finds the settings value — so in
a stock checkout the fallback is **ON**.

The effect: with no manually validated XML V3 present, `run_v3` measured V3
against the *same* preprocessed XML as V2, and `FIDELITY_PROGRESSION` printed a
V3 row identical to V2 captioned **"SAP PD vs the FINAL manually validated erwin
XML"**. `stage_state` said `V3_XML_EXPORT = WAITING_FOR_MANUAL_INPUT` in the same
run. Nothing in the deliverable said the two disagreed.

The value was **not** changed — flipping it would hard-stop a pipeline that is
currently producing reports, and that is the operator's call, not a fix. What
changed is that it can no longer be missed:

* `run_v3` prints an explicit `FALLBACK:` line and logs a warning naming the model.
* The V3 row's "What was compared" column now reads *"FALLBACK — no manually
  validated erwin XML V3 exists for this model … the V3 number is NOT evidence
  about the final erwin model."*
* A stage-to-stage delta measured on a **different component set** is now
  labelled *"not directly comparable — different components measured"*, because
  part of such a change comes from weight renormalisation rather than from the
  migration. On `modeling_and_simulation` the V1 → V2 jump is +58.53 and is
  flagged: V1 scores a UDP component, V2 drops it.

To get a real V3, export the enriched `.erwin` from erwin as XML into
`final_xml_models/<tier>/<model>.xml`. To make a missing one a hard stop
instead, set `FINAL_XML_FALLBACK_TO_PREPROCESSED=false`.

---

## 9. Production-readiness pass — 2026-09-15

This section supersedes §8.4 where they disagree: several gaps listed open there are now
closed, and this pass found further ones that were not known when §8 was written.

### 9.1 Closed

| Gap (was open in §8.4) | How it is closed now |
|---|---|
| **Attribute-level `PD_Code` preservation** | `app/validation/code_ledger.py` — a deterministic source→target ledger keyed by `(pd_entity_oid, pd_attr_oid)`, **never by name alone**. Each entry carries the attribute's declaration order and a datatype fingerprint, so a reader has three independent identity signals; an attribute whose only unique signal is its name is recorded `AMBIGUOUS` and its code is **not** encoded. Transport is the entity-level `PD_Attribute_Codes` UDP, which travels through the existing manifest → `erwin_load` → read-back path, so `app/udp_tool` is still unmodified. On `real_estate`: 41 of 42 codes encoded across 13 entity UDPs, 0 ambiguous, payload round-trips byte-stable. **Delivery is still `EXTERNAL_VERIFICATION_REQUIRED`** — encoded for transport is not the same fact as present in erwin. |
| **`UNVERIFIED_ERWIN_TAGS` could silently skip a check** | `ErDoc.carries()` now records every tag it was asked for and did not find; `unverified_tag_findings()` reports each affected check group at `EXTERNAL_VERIFICATION_REQUIRED` (visible, never scored). A clean sheet can no longer be produced by a spelling mistake. |
| **V3 unsafe by default** | `FINAL_XML_FALLBACK_TO_PREPROCESSED` now defaults to **false**, so a missing final XML is a hard stop. With it on, the run prints `FALLBACK:`, the progression sheet says the V3 number is not evidence about the final erwin model, and the model is **never promoted** (it would otherwise be rediscovered as an XML V3 on the next run — a self-confirming score). |
| **CDM had no `definition_field` provenance** | Added to all six CDM dataclasses and populated in both CDM parsers, including the Data Item indirection (a definition borrowed from a Data Item is labelled as such). All five CDM definition call sites pass it, and every definition message now names the two properties compared. |
| **PDM erwin parser had a shadowed duplicate function** | Removed (`_parse_entity_key_groups`); a test asserts no shadowed top-level definitions. |
| **`NOT_MEASURED` could become 0%** | Two places. (a) The UDP stage not having run is a recorded fact, and yields the `UDP_NOT_MEASURED` sentinel. (b) At **V2/V3 only**, an erwin XML carrying no UDP evidence cannot answer the question and the component is dropped. **V1 is deliberately excluded** — its low UDP number is the honest size of the initial gap and suppressing it would raise V1 for nothing. |
| **`input_erwin_models/<tier>/` and `input_sap_models/` were never created** | Both are created by `setup_directories`. The operator was previously told to put files into folders that did not exist. |

### 9.2 Found and fixed in this pass (were not known in §8)

| Hazard | Fix |
|---|---|
| **A missing `.erwin` handoff did not block promotion.** A dropped component renormalises the weights, so structural 100 + documentation 100 = **100.00 overall**, the gate checked only the number, and the model was copied into `3_final` — while its own stage state said `UDP: WAITING_FOR_MANUAL_INPUT`. Byte-identical output to a model that genuinely migrated everything. | `StageScore.unverified` now names components dropped for want of evidence (distinct from *not applicable* — a model with no UDPs at all is not blocked). `promotion_gate.unverified_failures()` refuses promotion, `PROMOTION_BLOCK_ON_UNVERIFIED=True` by default, and the PDM gate applies the same rule. |
| **A failed comment injection fabricated XML V2.** `orchestrator.py` copied XML V1 over XML V2 and the caller recorded `READY`, so an uninjected export was scored as "comments migrated" — and `copy2` preserves mtime, so the freshness guard kept the fabricated file on every later run. | The fallback is gone. Step 1 raises `PreprocessingFailed`, removes any partial file, and the stage is recorded `FAILED` with a next action. |
| **PDM took its UDP pass rate with every guard bypassed.** `pdm_workflow` passed neither `result`, `dirs` nor `pd_path`, so `workbook_belongs_to_model` never armed and the SHA-256-verified evidence path was skipped entirely — the exact Vessel/Sanctions failure mode, unarmed on the PDM route. | All three are passed. |
| **XML V2 freshness was judged against XML V1, not the SAP source.** Editing the `.ldm` did not invalidate a cached XML V2. | Freshness is now judged against the newer of XML V1 and the SAP PD source. |
| **The `.erwin` read-back had no freshness check at all.** A previous run's `.erwin` could be read back and its pass rate reported as this run's evidence. | `_stale_readback()` reports `STALE READ-BACK` naming both files. Reported rather than refused, because a legitimate re-run can have an older handoff. |
| **Evidence with no digest was trusted.** `sha256_of` returns `""` on `OSError`, and `_check_source` treated an empty digest as "no rejection" — a disk error silently switched staleness checking off. | Both an absent stored digest and a failure to hash the source now return `REJECT_UNVERIFIABLE`. |
| **`_model_udp_candidates` swallowed with no trace.** A bare `except` returning `[]`, indistinguishable from "erwin has no model UDP", affecting finding counts. | Logs a warning naming the file and the consequence. |

### 9.3 Still open — EXTERNAL_VERIFICATION_REQUIRED / TEST_DATA_GAP

| Item | Class | Why it stays open |
|---|---|---|
| Attribute codes reaching erwin | `EXTERNAL_VERIFICATION_REQUIRED` | Needs one Windows + erwin run to read the `PD_Attribute_Codes` UDP back. The ledger records what was encoded; only erwin can confirm delivery. |
| 28 `UNVERIFIED_ERWIN_TAGS` spellings | `EXTERNAL_VERIFICATION_REQUIRED` | Needs one erwin export that definitely contains each construct. Now reported rather than silent. |
| Description → erwin `<Definition>` injection | `EXTERNAL_VERIFICATION_REQUIRED` | `modeling_and_simulation` carries 2 erwin-authored `<Definition>` elements, `real_estate` 0 — not enough to derive the format for attributes, relationships or domains. Writing it blind would be inventing erwin's format. |
| Real CDM and real PDM model pairs | `TEST_DATA_GAP` | `sappdmodels/cdm/` and `sappdmodels/pdm/` are empty. Every CDM/PDM row in §2 rests on synthetic fixtures: **code path verified, erwin vocabulary not**. The CDM/LDM/PDM × Simple/Medium/Complex grid is complete only for LDM. |
| PDM structural comparator reads no table/column definitions | **By design, not a gap** | PDM documentation is measured and scored through the documentation component (25%) via `pdm_documentation.build_rows`. Adding structural `DEFINITION` findings would double-count the same loss. Re-examined in this pass and deliberately left alone. |
| PDM business rules | `TEST_DATA_GAP` | Neither PDM parser reads `o:BusinessRule` / `Validation_Rule`; `extended_properties` covers them at INFO. Closing it needs a real PDM pair to verify the erwin vocabulary against. |
| erwin PDM references carry no cardinality | `TEST_DATA_GAP` | No PDM erwin sample exists here to confirm the properties are present to read. |
| Artefacts resolved by filename across runs | Documented | `final_xml_models/` and the UDP workbooks are still name-resolved between separate runs. Content guards (`_same_model`, "no entity in common", `workbook_belongs_to_model`) catch a *wrong-model* file; they do not catch a *stale same-model* file. See PRODUCTION_RUNBOOK.md §6. |
| `stage_state` records a SHA-256 per artefact that nothing reads back | Improvement, not a hazard | The digest is written but never re-verified. Every path that matters (`udp_evidence`, `code_ledger`) does its own verification. |
