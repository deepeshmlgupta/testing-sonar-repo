# Quick Setup Checklist for Colleagues

**Time Required:** ~5 minutes  
**Difficulty:** Easy  
**Platforms:** Windows, Linux, Mac  

---

## 📋 Pre-Setup Checklist

- [ ] Have Python 3.8+ installed
  - Check: `python --version`
- [ ] Have internet connection (for pip install)
- [ ] Have write permissions in current directory

---

## 🚀 Quick Setup (Choose One)

### Option 1: Automated Setup (Recommended)

#### Windows
```bash
setup.bat
```
Click and wait ~2 minutes.

#### Linux/Mac
```bash
python setup.py
```

---

### Option 2: Manual Setup (Step-by-Step)

```bash
# 1. Create virtual environment (recommended)
python -m venv venv
source venv/bin/activate              # Linux/Mac
# OR
venv\Scripts\activate                 # Windows

# 2. Install dependencies
pip install -r requirements.txt

# 3. Create directories
mkdir -p sappdmodels/{ldm,cdm,pdm}    # Linux/Mac
mkdir -p final_xml_models/{ldm,cdm,pdm}
mkdir -p batch_summary/audit
# OR (Windows)
mkdir sappdmodels\ldm sappdmodels\cdm sappdmodels\pdm
mkdir final_xml_models\ldm final_xml_models\cdm final_xml_models\pdm
mkdir batch_summary\audit

# 4. Verify installation
python -m pytest tests/test_multiuser_functionality.py

# 5. Ready to use!
python -m app.main          # from the checkout root
```

---

## 🔁 The flow at a glance (two manual erwin steps — there is no automated bridge)

```
sappdmodels/<tier>/<model>.(cdm|ldm|pdm)          your SAP PD model
   │  MANUAL  erwin: import, Save As XML
   ▼
erwinmodels/1_initial/<model>.xml                  never modified by the code
   │  python -m app.run_v1        Fidelity V1 report + Step 1 (PD comments -> erwin notes)
   ▼
erwinmodels/2_preprocessed/<model>.xml             generated
   │  AUTO    run_udp converts it via erwin SCAPI when erwin COM is on the host
   │  MANUAL  otherwise erwin: open it, save as <model>.erwin, into app/udp_tool/input_erwin_models/
   │          (run_udp prints the exact paths, writes a .HOWTO.txt and waits at a prompt)
   │  python -m app.run_udp       UDPs injected (Windows + erwin COM) -> 2_preprocessed/<model>.erwin
   │  MANUAL  erwin: open 2_preprocessed/<model>.erwin (the .erwin, NOT the .xml beside it),
   │          Save As XML -> final_xml_models/<tier>/<model>.xml
   ▼
   python -m app.run_v3           Fidelity V2 + V3 (V1 / UDP / V3 / combined in one report)
   ├─ ≥ 90 %  -> erwinmodels/3_final/<model>.xml + <model>.erwin
   └─ < 90 %  -> stays in erwinmodels/2_preprocessed; findings in app/reporting/<tier>_reports/<model>/manual_review_report/
```

Each script ends by printing what a person must do next; `batch_summary/stage_state/<model>.json`
holds the status of every stage (`WAITING_FOR_MANUAL_INPUT`, `VALIDATED`, `FAILED`, `READY_FOR_NEXT_STAGE` …)
with the SHA-256 of every artefact. `python -m app.main` runs everything in one process once all
manual files are in place.

## 📁 What You Need to Provide

### Input Files (Required)
```
sappdmodels/
├── ldm/          ← Place your .ldm files here
├── cdm/          ← Place your .cdm files here
└── pdm/          ← Place your .pdm files here
```

### What 2_preprocessed/ holds

The folder is named for the PHASE, so it holds two artefacts; the extension
tells them apart:

    erwinmodels/2_preprocessed/<model>.xml     XML V2     run_v1 output  -> Step 2 input
    erwinmodels/2_preprocessed/<model>.erwin   .ERWIN V2  run_udp output

.ERWIN V1 (Step 2's input) is NOT here — it lives in
app/udp_tool/input_erwin_models/, so an input cannot be confused with an output.

### erwin exports (MANUAL unless erwin COM is on this host)
```
erwinmodels/1_initial/<model>.xml           ← erwin's XML export of the imported model (before run_v1)
app/udp_tool/input_erwin_models/<model>.erwin ← .ERWIN V1, from erwinmodels/2_preprocessed/<model>.xml
                                                 (run_udp makes it itself when erwin COM is available)
final_xml_models/<ldm|cdm|pdm>/<model>.xml  ← XML V3, erwin's export of 2_preprocessed/<model>.erwin (before run_v3)
```
Without the last file `run_v3` stops the model (`WAITING_FOR_MANUAL_INPUT`) — V3 is never measured against a substitute.


---

## ⚙️ Configuration (Optional)

### Use Different Paths
```bash
# Linux/Mac
export SAP_PD_MODELS_DIR="/your/model/path"
export ERWIN_MODELS_DIR="/your/output/path"

# Windows
set SAP_PD_MODELS_DIR=C:\your\model\path
set ERWIN_MODELS_DIR=C:\your\output\path
```

### Disable Multi-User Mode (Not Recommended)
```bash
export ENABLE_SESSION_ISOLATION=false  # Linux/Mac
set ENABLE_SESSION_ISOLATION=false     # Windows
```

---

## ▶️ Running the Application

```bash
python -m app.run_v1        # stage 1  (then: save .erwin from 2_preprocessed/<model>.xml into app/udp_tool/input_erwin_models/)
python -m app.run_udp       # stage 2  (then: export 2_preprocessed/<model>.erwin as XML into final_xml_models/<tier>/)
python -m app.run_v3        # stage 3  gate -> 3_final
python -m app.main          # or all three in one process, when every manual file already exists
```

**Expected Output:**
```
Starting SAP PowerDesigner to erwin Migration Pipeline...
Session: alice_20250912_143022_a1b2c3d4
Found N model(s) to process.
...
Pipeline execution completed.
```

---

## 📊 Where's the Output?

| Output | Location |
|--------|----------|
| Step 1 output (comments as notes) | `erwinmodels/2_preprocessed/<model>.xml` |
| UDP-enriched model | `erwinmodels/2_preprocessed/<model>.erwin` |
| Gate PASS (≥ 90 %) | `erwinmodels/3_final/<model>.xml` + `.erwin` |
| V1 / V2 / V3 workbooks + model log | `app/reporting/<tier>_reports/<model>/` |
| Batch summary | `batch_summary/summary_report/Pass_Fail_Summary.xlsx` |
| Pipeline ledger (lineage, hashes) | `batch_summary/audit/pipeline_ledger.jsonl` |
| Hand-off status per model | `batch_summary/stage_state/<model>.json` |
| (with `--isolate`) everything above | `sessions/<user>_<id>/…` |

---

## 🆘 Troubleshooting

| Problem | Solution |
|---------|----------|
| `Python not found` | Install Python 3.8+ |
| `No module named 'defusedxml'` | Run: `pip install -r requirements.txt` |
| `No models found` | Place `.ldm`, `.cdm`, or `.pdm` files in `sappdmodels/` |
| `Permission denied` | Run with admin privileges or check file permissions |
| `ModuleNotFoundError: No module named 'app'` | Run from the root directory: `python -m app.main` |

---

## 📚 Documentation

- **SETUP.md** - Complete setup guide with detailed explanations
- **tests/** - the pytest suite (`python -m pytest`)

---

## ✅ How to Verify Setup is Working

```bash
# Test 1: Run test suite
python -m pytest tests/test_multiuser_functionality.py
# Expected: "ALL TESTS PASSED"

# Test 2: Check configuration
python -c "from app.config import settings; print(f'Base dir: {settings.BASE_DIR}')"
# Expected: Shows your installation path

# Test 3: Try a dry run
python -m app.main          # from the checkout root
# Expected: "No models found" (this is OK, you haven't added models yet)
```

---

## 🎯 Next Steps

1. ✅ Run setup script (setup.py or setup.bat)
2. ✅ Place SAP models in `sappdmodels/`
3. ✅ Run: `python -m app.run_v1` → `run_udp` → `run_v3` (from the checkout root), doing the erwin step between each
4. ✅ Check `batch_summary/` for outputs
5. ✅ Read SETUP.md for more options

---

## 💡 Pro Tips

- Use virtual environment (`venv`) to avoid Python conflicts
- Place models in `sappdmodels/` before running
- Enable debug logging if something goes wrong: `set LOG_LEVEL=DEBUG`
- Each user gets isolated output directory (multi-user safe by default)
- All settings can be overridden via environment variables

---

## 📞 Questions?

Refer to:
1. **This checklist** - Quick answers
2. **SETUP.md** - Detailed guide
4. **Code docstrings** - Technical details

---

**That's it! You're ready to go! 🚀**
