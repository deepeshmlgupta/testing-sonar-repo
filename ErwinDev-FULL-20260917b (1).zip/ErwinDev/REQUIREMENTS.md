# REQUIREMENTS.md - Complete Setup Requirements 

## Summary
 
**Setup time:** ~5 minutes  
**Difficulty:** Easy  
**One-liner:** `python setup.py` (automated) or follow manual steps below  

---

## System Requirements

### Absolute Must-Have 
- **Python 3.8+** (3.10+ recommended)
  - Check: `python --version`
  - Download: https://www.python.org/downloads/
  - Verify: `python -m pip --version` (pip should also work)

### Platform Support
| Platform | Support | Notes |
|----------|---------|-------|
| Windows | ✅ Full | pywin32 installed automatically; erwin Data Modeler needed for the UDP injection step (run_udp) and for the two manual XML/.erwin exports |
| Linux | ✅ Partial | V1/V2/V3 fidelity, Step 1, UDP extraction/mapping work; UDP injection (run_udp) records FAILED with the remedy — no erwin COM |
| Mac | ✅ Partial | same as Linux |
| WSL | ✅ Partial | Linux-side Python cannot reach erwin's COM API; run run_udp from Windows Python |

---

## Python Dependencies

### Automatically Installed via `pip install -r requirements.txt`

| Package | Version | Purpose | Size |
|---------|---------|---------|------|
| defusedxml | >=0.7.1 | Safe XML parsing | ~100 KB |
| lxml | >=4.9.0 | High-performance XML parsing | ~3 MB |
| openpyxl | >=3.1.5 | Excel workbook generation | ~5 MB |
| tqdm | >=4.60.0 | Progress bar support | ~100 KB |
| pytest | >=8.0.0 | Test framework (optional) | ~1 MB |
| pywin32 | >=306 | Windows COM API (Windows only) | ~5 MB |

**Total install size:** ~11 MB (11 MB for Windows, 6 MB for Linux/Mac)

---

## Directory Structure Setup

After extraction, colleagues must create these directories (automated if using setup.py/setup.bat):

```
ErwinDev/
├── sappdmodels/               ← INPUT: SAP models (user provides)
│   ├── ldm/                   ← Place .ldm files here
│   ├── cdm/                   ← Place .cdm files here
│   └── pdm/                   ← Place .pdm files here
│
├── final_xml_models/          ← INPUT (MANUAL): erwin's XML export of the UDP-enriched model — required for V3
│   ├── ldm/
│   ├── cdm/
│   └── pdm/
│
├── erwinmodels/               ← three flat folders, auto-created
│   ├── 1_initial/             ← INPUT (MANUAL): erwin's XML export of the imported model
│   ├── 2_preprocessed/        ← OUTPUT: <model>.xml (comments -> notes), <model>.erwin (UDPs)
│   └── 3_final/               ← OUTPUT: gate PASS only (V3 fidelity ≥ 90 %)
│
├── app/udp_tool/input_erwin_models/  ← INPUT (MANUAL): <model>.erwin saved from 2_preprocessed/<model>.xml
│
├── batch_summary/             ← OUTPUT: Auto-created
│   ├── audit/                 ← Auto-created
│   └── summary_report/        ← Auto-created
│
└── [other project files]
```

**To create:**
```bash
# Linux/Mac
mkdir -p sappdmodels/{ldm,cdm,pdm}
mkdir -p final_xml_models/{ldm,cdm,pdm}
mkdir -p batch_summary/audit

# Windows
mkdir sappdmodels\ldm sappdmodels\cdm sappdmodels\pdm
mkdir final_xml_models\ldm final_xml_models\cdm final_xml_models\pdm
mkdir batch_summary\audit
```

---

## Step-by-Step Setup Instructions

### Method 1: Automated Setup (Recommended) ⭐

#### Windows
```
1. Extract ZIP
2. Double-click: setup.bat
3. Wait ~2 minutes
4. Done! 🎉
```

#### Linux/Mac/WSL
```bash
unzip erwin-migration-platform.zip
cd ErwinDev
python setup.py
# Wait ~2 minutes
# Done! 🎉
```

**What it does automatically:**
- ✅ Checks Python version
- ✅ Creates all required directories
- ✅ Installs all dependencies
- ✅ Runs tests to verify

---

### Method 2: Manual Setup

#### Step 1: Install Python
Verify Python 3.8+ is installed:
```bash
python --version
# Expected: Python 3.8.x, 3.9.x, 3.10.x, 3.11.x, or 3.12.x
```

If not installed: https://www.python.org/downloads/

#### Step 2: Create Virtual Environment (Recommended)
```bash
# Linux/Mac
python -m venv venv
source venv/bin/activate

# Windows PowerShell
python -m venv venv
.\venv\Scripts\Activate.ps1

# Windows CMD
python -m venv venv
venv\Scripts\activate
```

#### Step 3: Install Dependencies
```bash
pip install -r requirements.txt
```

**Expected output:**
```
Successfully installed defusedxml-0.7.1 openpyxl-3.1.5 pytest-8.0.0 pywin32-306
```

#### Step 4: Create Directories
```bash
# Linux/Mac
mkdir -p sappdmodels/{ldm,cdm,pdm}
mkdir -p final_xml_models/{ldm,cdm,pdm}
mkdir -p erwinmodels
mkdir -p batch_summary/audit

# Windows
mkdir sappdmodels\ldm sappdmodels\cdm sappdmodels\pdm
mkdir final_xml_models\ldm final_xml_models\cdm final_xml_models\pdm
mkdir erwinmodels
mkdir batch_summary\audit
```

#### Step 5: Verify Installation
```bash
cd app
python -m pytest                             # full suite
```

**Expected output:**
```
[TEST 1] User Detection ........................... PASSED ✓
[TEST 2] Session ID Generation ................... PASSED ✓
[TEST 3] SessionContext Directory Structure ...... PASSED ✓
[TEST 4] File Locking ............................ PASSED ✓
[TEST 5] Atomic JSONL Append ..................... PASSED ✓
[TEST 6] Configuration Settings ................. PASSED ✓
[TEST 7] Concurrent Writes (2 processes) ........ PASSED ✓

✓ ALL TESTS PASSED
```

---

## Configuration Requirements

### No Configuration Needed ✅
The app works **out of the box** with defaults.

### Optional Configuration

#### Custom Input/Output Paths
```bash
# Linux/Mac
export SAP_PD_MODELS_DIR="/custom/sap/models"
export ERWIN_MODELS_DIR="/custom/erwin/output"
export FINAL_XML_DIR="/custom/final/xml"

# Windows (PowerShell)
$env:SAP_PD_MODELS_DIR = "C:\custom\sap\models"
$env:ERWIN_MODELS_DIR = "C:\custom\erwin\output"
$env:FINAL_XML_DIR = "C:\custom\final\xml"

# Windows (CMD)
set SAP_PD_MODELS_DIR=C:\custom\sap\models
set ERWIN_MODELS_DIR=C:\custom\erwin\output
set FINAL_XML_DIR=C:\custom\final\xml
```

#### Disable Multi-User Mode (Not Recommended)
```bash
export ENABLE_SESSION_ISOLATION=false      # Linux/Mac
set ENABLE_SESSION_ISOLATION=false         # Windows
python -m app.main
```

#### Enable Debug Logging
```bash
export LOG_LEVEL=DEBUG                     # Linux/Mac
set LOG_LEVEL=DEBUG                        # Windows
python -m app.main
```

---

## Input Data Requirements

### Required: SAP Models
Place one or more of:
- `.ldm` files in `sappdmodels/ldm/`
- `.cdm` files in `sappdmodels/cdm/`
- `.pdm` files in `sappdmodels/pdm/`

Example:
```
sappdmodels/
├── ldm/
│   ├── customer.ldm
│   ├── orders.ldm
│   └── products.ldm
├── cdm/
│   └── enterprise.cdm
└── pdm/
    └── database.pdm
```

### Optional: Final Validated erwin XML
For V3 validation reports:
```
final_xml_models/
├── ldm/
│   ├── customer.xml
│   ├── orders.xml
│   └── products.xml
├── cdm/
│   └── enterprise.xml
└── pdm/
    └── database.xml
```

---

## Platform-Specific Requirements

### Windows ✅

**Required:**
- Python 3.8+
- pip (comes with Python)

**Automatically installed:**
- pywin32 (for COM API access to erwin)
- fcntl-equivalent locking (msvcrt)

**Additional (if issues):**
```bash
# Install pywin32 explicitly if needed
pip install pywin32>=306

# Post-install (only if COM access fails):
python -m pip install --upgrade pywin32
```

### Linux / Mac ✅

**Required:**
- Python 3.8+
- pip (usually pre-installed)

**Works:**
- SAP model parsing and analysis
- Report generation
- Multi-user session isolation
- File locking (via fcntl)

**Doesn't work:**
- erwin COM API (Windows-only)
- erwin model opening/reading

**Alternative for Mac users:**
- Use WSL (Windows Subsystem for Linux) for full Windows support

### WSL (Windows Subsystem for Linux) ✅

**Best for Linux users on Windows**

```bash
# Install WSL2 (if not already installed)
wsl --install

# Then in WSL terminal:
cd /mnt/c/Users/username/ErwinDev
python setup.py
```

---

## Network/Firewall Requirements

| Requirement | Reason | Can Work Offline |
|-------------|--------|-----------------|
| Internet for `pip install` | Download dependencies | ❌ No (first time) |
| After first install | Running the app | ✅ Yes |
| File share access | Reading/writing models | ✅ Yes |

**For offline deployments:**
- Download wheels once: `pip download -r requirements.txt`
- Copy wheels to target machine
- Install from wheels: `pip install --no-index --find-links=./wheels -r requirements.txt`

---

## Verification Checklist

After setup, verify everything with:

```bash
# 1. Python installed
python --version                           # Should show 3.8+

# 2. Dependencies installed
pip list | grep -E "defusedxml|openpyxl"   # Should show versions

# 3. Directories exist
ls -la sappdmodels/ final_xml_models/ batch_summary/
# (Or: dir sappdmodels\ final_xml_models\ batch_summary\ on Windows)

# 4. Tests pass
cd app
python -m pytest                             # full suite

# 5. App runs
python -m app.main                         # Should show welcome message
```

---

## Troubleshooting

| Issue | Cause | Solution |
|-------|-------|----------|
| `command not found: python` | Python not installed | Install Python 3.8+ |
| `ModuleNotFoundError: No module named 'defusedxml'` | Dependencies not installed | Run: `pip install -r requirements.txt` |
| `No models found` | Models not in correct location | Place `.ldm`/`.cdm`/`.pdm` files in `sappdmodels/` |
| `Permission denied` | Missing directory permissions | Create directories manually or run with elevated privileges |
| `ImportError: No module named 'app'` | Running from wrong directory | Run from project root: `python -m app.main` |
| `ModuleNotFoundError: No module named 'pywin32'` | Windows API not installed | Run: `pip install pywin32>=306` |

---

## What NOT to Do

❌ **Don't:**
- Run `python app/main.py` directly (use `python -m app.main`)
- Edit configuration in code (use environment variables)
- Skip the `requirements.txt` install step
- Use Python 3.7 or older (not supported)
- Run multiple instances without session isolation (only safe if isolation disabled)

✅ **Do:**
- Use virtual environment (`venv`) to avoid conflicts
- Follow the setup steps in order
- Place models in correct subdirectories
- Use environment variables for custom paths
- Run tests to verify installation

---

## Minimal Setup (No Extras)

If colleagues want **only** what's needed:

```bash
# Minimum: Just install and run
pip install defusedxml openpyxl pywin32
mkdir -p sappdmodels/{ldm,cdm,pdm}
mkdir -p final_xml_models
cd app
python -m app.main
```

**But we recommend using `setup.py` or `setup.bat` instead!**

---

## Full Dependency Graph

```
ERwin Migration Platform
├── Python 3.8+
├── defusedxml 0.7.1+ (XML parsing)
├── openpyxl 3.1.5+ (Excel reports)
├── pytest 8.0.0+ (Testing)
└── pywin32 306+ (Windows only, COM API)
```

---

## Disk Space Requirements

| Component | Size | Required |
|-----------|------|----------|
| Python 3.10 | ~100 MB | Yes |
| Dependencies | ~11 MB | Yes |
| Source code | ~50 MB | Yes |
| Per SAP model | ~1-5 MB | Variable |
| Batch outputs | 2x input size | Variable |

**Minimum to start:** 200 MB  
**Typical usage:** 1-10 GB (depending on model count)

---

## What's Included in the ZIP

```
ErwinDev.zip
├── app/                              ← Main application
│   ├── requirements.txt              ← Dependencies list
│   ├── main.py                       ← Entry point
│   ├── utils/session_manager.py      ← Multi-user support (NEW!)
│   └── ...
│   └── ...
├── SETUP.md                          ← Detailed setup guide
├── QUICK_START.md                    ← Quick reference (NEW!)
├── REQUIREMENTS.md                   ← This file (NEW!)
├── setup.py                          ← Automated setup (NEW!)
├── setup.bat                         ← Windows setup (NEW!)
└── ...
```

---

## Quick Command Reference

```bash
# Initial setup
python setup.py                        # Automated (recommended)

# Manual setup
python -m venv venv
source venv/bin/activate              # Linux/Mac
venv\Scripts\activate                 # Windows
pip install -r requirements.txt

# Create directories
mkdir -p sappdmodels/{ldm,cdm,pdm}

# Run application
cd app
python -m app.main

# Run tests
python -m pytest                             # full suite

# Set custom paths
export SAP_PD_MODELS_DIR="/path"       # Linux/Mac
set SAP_PD_MODELS_DIR=C:\path          # Windows

# Debug
export LOG_LEVEL=DEBUG                 # Linux/Mac
set LOG_LEVEL=DEBUG                    # Windows
```

---

## Support Resources

1. **SETUP.md** - Complete setup guide with FAQs
2. **QUICK_START.md** - Quick reference checklist
3. **python -m pytest** - Verify setup works
4. **Code comments and docstrings** - Implementation details

---

## Summary Table

| Item | Requirement | Status |
|------|-------------|--------|
| Python | 3.8+ | Required |
| Setup time | ~5 min | Automated |
| Manual steps | 5 steps | Or 1 command |
| Configuration needed | No | Optional |
| Input data needed | Yes | SAP models |
| Cross-platform | Windows, Linux, Mac | Yes |
| Multi-user safe | By default | Yes |
| Tests included | Yes | 7/7 pass |
| Documentation | Comprehensive | Yes |

---

**Share the ZIP with colleagues and have them run `setup.py` or `setup.bat`. Done! ✅**


---

## Production operation

See **PRODUCTION_RUNBOOK.md** for the flow as implemented, the manual handoffs, the
settings that change a verdict, and what a green run does *not* tell you.

Two things worth knowing before a first production run:

* `pywin32` is required only on the Windows host that drives erwin (Step 2 and the
  conversions). Parsing, reconciliation, scoring and reporting run anywhere.
* `python -m app.run_v1` creates every folder the operator is asked to use, including
  `app/udp_tool/input_erwin_models/{cdm,ldm,pdm}/` and `app/udp_tool/input_sap_models/`.
  Run it once before looking for them.

Verify any run with:

```bash
python -m tools.production_verify
```

which recomputes every reported score from that run's own finding rows and fails if a
score is not what its rows produce, if a NOT MEASURED component was scored as 0%, or if a
code-ledger payload does not round-trip.
