import os
import sys
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.validation.external_model_resolver import (
    resolve_external_erwin_xml,
    resolve_external_model,
)
from app.validation.shortcut_validator import STATUS_RESOLVED, STATUS_UNRESOLVED, validate_shortcut


class ExternalModelResolverTests(unittest.TestCase):
    def test_resolves_model_by_tolerant_name_match(self):
        with TemporaryDirectory() as tmp:
            (Path(tmp) / "Shared Glossary.ldm").write_text("<x/>", encoding="utf-8")
            found = resolve_external_model("shared_glossary", [tmp])
            self.assertIsNotNone(found)
            self.assertTrue(found.endswith("Shared Glossary.ldm"))

    def test_returns_none_when_not_found(self):
        with TemporaryDirectory() as tmp:
            self.assertIsNone(resolve_external_model("Nonexistent", [tmp]))

    def test_empty_target_returns_none(self):
        self.assertIsNone(resolve_external_model("", ["."]))

    def test_resolves_erwin_xml_by_tolerant_name_match(self):
        with TemporaryDirectory() as tmp:
            (Path(tmp) / "SharedGlossary.xml").write_text("<x/>", encoding="utf-8")
            found = resolve_external_erwin_xml("Shared Glossary", [tmp])
            self.assertIsNotNone(found)


class ShortcutValidatorTests(unittest.TestCase):
    def test_unresolved_when_target_model_not_found(self):
        shortcut = {"name": "Category", "target_model": "Nonexistent"}
        result = validate_shortcut(shortcut, ["."], lambda p: None, lambda p: None)
        self.assertEqual(STATUS_UNRESOLVED, result.status)
        self.assertFalse(result.external_model_found)

    def test_resolved_when_both_files_found_and_parse_succeeds(self):
        class _FakeModel:
            def __init__(self, entities):
                self.entities = entities

        with TemporaryDirectory() as tmp:
            (Path(tmp) / "Shared.ldm").write_text("<x/>", encoding="utf-8")
            (Path(tmp) / "Shared.xml").write_text("<x/>", encoding="utf-8")
            shortcut = {"name": "Category", "target_model": "Shared"}
            result = validate_shortcut(
                shortcut, [tmp],
                parse_pd_fn=lambda p: _FakeModel({"A": 1, "B": 2}),
                parse_erwin_fn=lambda p: _FakeModel({"A": 1}),
            )
            self.assertEqual(STATUS_RESOLVED, result.status)
            self.assertTrue(result.external_model_found)
            self.assertEqual(50.0, result.external_object_match_pct)

    def test_parse_failure_reports_error_not_crash(self):
        def _boom(path):
            raise ValueError("bad xml")

        with TemporaryDirectory() as tmp:
            (Path(tmp) / "Shared.ldm").write_text("<x/>", encoding="utf-8")
            (Path(tmp) / "Shared.xml").write_text("<x/>", encoding="utf-8")
            shortcut = {"name": "Category", "target_model": "Shared"}
            result = validate_shortcut(shortcut, [tmp], _boom, _boom)
            self.assertEqual("ERROR", result.status)


if __name__ == "__main__":
    unittest.main()
