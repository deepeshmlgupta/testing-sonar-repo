"""
Regression test for the PDM flow ordering fix: V3 (the final validated erwin
XML) must be measured LAST, after any remediation/V2 pass, never as a
short-circuit that skips migration entirely. This mirrors the V1 -> UDP -> V2
-> V3 ordering used by the CDM/LDM workflow.
"""

from types import SimpleNamespace
from unittest.mock import patch

from app.validation.pdm_reconcile import pdm_flow


def _result(status="PASS", fidelity=100.0, critical=0, warning=0, info=0):
    return SimpleNamespace(
        status=status, fidelity_score=fidelity, fidelity_score_raw=fidelity,
        critical_count=critical, warning_count=warning, info_count=info,
        reconciliation_errors=None, udp_fidelity=None,
    )


def test_v3_runs_after_preprocessing_not_as_a_shortcut(tmp_path):
    pdm_path = tmp_path / "model.pdm"
    pdm_path.write_text("<Model/>")
    initial_xml = tmp_path / "initial.xml"
    initial_xml.write_text("<model/>")
    final_validated_xml = tmp_path / "final_validated.xml"
    final_validated_xml.write_text("<model/>")

    initial_result = _result(fidelity=40.0, critical=1)   # V1: needs remediation
    preprocessed_result = _result(fidelity=100.0)          # V2: fixed by remediation
    final_result = _result(fidelity=100.0)                 # V3: the authority

    call_order = []

    def fake_validate_pair(pdm_path, xml_path):
        if xml_path == str(initial_xml):
            call_order.append("V1")
            return initial_result
        if xml_path == str(final_validated_xml):
            call_order.append("V3")
            return final_result
        call_order.append("V2")
        return preprocessed_result

    def fake_preprocess_model(**kwargs):
        call_order.append("PREPROCESS")
        return SimpleNamespace(summary=lambda: "1 column restored",
                               erwin_binary_stale=False)

    with patch.object(pdm_flow.bridge, "parse_pdm", return_value=object()), \
         patch.object(pdm_flow.bridge, "validate_pair", side_effect=fake_validate_pair), \
         patch.object(pdm_flow.bridge, "parse_erwin", return_value=None), \
         patch.object(pdm_flow.pdm_preprocessor, "preprocess_model", side_effect=fake_preprocess_model), \
         patch.object(pdm_flow.fidelity_stages, "apply",
                     side_effect=lambda result, *a, **k: SimpleNamespace(summary_line=lambda: "")), \
         patch.object(pdm_flow.fidelity_stages, "carry_history"):
        outcome = pdm_flow.run_pdm_flow(
            pdm_path=str(pdm_path),
            initial_erwin=str(tmp_path / "initial.erwin"),
            initial_xml=str(initial_xml),
            preprocessed_erwin=str(tmp_path / "preprocessed.erwin"),
            preprocessed_xml=str(tmp_path / "preprocessed.xml"),
            final_erwin=str(tmp_path / "final.erwin"),
            final_xml=str(tmp_path / "final.xml"),
            target_fidelity=90.0,
            final_validated_xml=str(final_validated_xml),
        )

    # V1 must run first, remediation must happen, V2 must be measured, and V3
    # must be measured LAST — never short-circuiting ahead of migration.
    assert call_order == ["V1", "PREPROCESS", "V2", "V3"]
    assert outcome.final_result is final_result
    assert outcome.promoted
