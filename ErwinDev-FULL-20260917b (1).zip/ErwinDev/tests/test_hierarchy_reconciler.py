import os
import sys
import unittest
from dataclasses import dataclass

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.validation.hierarchy_reconciler import reconcile


@dataclass
class _Pkg:
    name: str
    code: str = ""
    parent: str = ""


class HierarchyReconcilerTests(unittest.TestCase):
    def test_empty_both_sides_is_fully_matched(self):
        outcome = reconcile([], [])
        self.assertEqual(100.0, outcome.fidelity_pct)
        self.assertEqual(0, outcome.total_nodes)

    def test_identical_hierarchy_matches_fully(self):
        pd = [_Pkg("Business"), _Pkg("Customer", parent="Business"),
              _Pkg("Retail", parent="Customer")]
        erwin = [_Pkg("Business"), _Pkg("Customer", parent="Business"),
                 _Pkg("Retail", parent="Customer")]
        outcome = reconcile(pd, erwin)
        self.assertEqual(100.0, outcome.fidelity_pct)
        self.assertTrue(all(f.status == "MATCHED" for f in outcome.findings))

    def test_missing_ancestor_detected(self):
        pd = [_Pkg("Business"), _Pkg("Customer", parent="Business"),
              _Pkg("Retail", parent="Customer")]
        # erwin re-parents Retail directly under nothing (Business dropped)
        erwin = [_Pkg("Customer"), _Pkg("Retail", parent="Customer")]
        outcome = reconcile(pd, erwin)
        retail = next(f for f in outcome.findings if f.name == "Retail")
        self.assertEqual("PATH_MISMATCH", retail.status)
        self.assertEqual("Business", retail.missing_ancestor)
        self.assertGreater(retail.depth_difference, 0)

    def test_node_missing_entirely_in_target(self):
        pd = [_Pkg("Business"), _Pkg("Product", parent="Business")]
        erwin = [_Pkg("Business")]
        outcome = reconcile(pd, erwin)
        product = next(f for f in outcome.findings if f.name == "Product")
        self.assertEqual("MISSING_IN_TARGET", product.status)
        self.assertLess(outcome.fidelity_pct, 100.0)

    def test_extra_node_in_target_only(self):
        pd = [_Pkg("Business")]
        erwin = [_Pkg("Business"), _Pkg("Extra", parent="Business")]
        outcome = reconcile(pd, erwin)
        extra = next(f for f in outcome.findings if f.name == "Extra")
        self.assertEqual("EXTRA_IN_TARGET", extra.status)
        # Extra-only nodes don't penalise fidelity (PD is the source of truth)
        self.assertEqual(100.0, outcome.fidelity_pct)

    def test_cyclic_parent_chain_does_not_hang(self):
        pd = [_Pkg("A", parent="B"), _Pkg("B", parent="A")]
        erwin = [_Pkg("A", parent="B"), _Pkg("B", parent="A")]
        outcome = reconcile(pd, erwin)  # must return, not recurse forever
        self.assertEqual(2, outcome.total_nodes)


if __name__ == "__main__":
    unittest.main()
