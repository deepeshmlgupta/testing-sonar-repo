"""
Classifying a reconciliation finding correctly.

Every finding has to land in the right one of these, because they need
different remedies and carry different fidelity weight:

    genuine migration loss          erwin lost something SAP PD had
    unexpected transformation       erwin holds something SAP PD never had
    source pre-existing             identical in both — migration did neither
    target representation           erwin has no field for it; preserved elsewhere
    traceability only               visible, but identity is otherwise secure

Three misclassifications were found and fixed, all of them charging fidelity
for something the migration did not do wrong:

  1. "no primary identifier in EITHER model" was INFO — 0.05 penalty each. On
     real_estate that is 105 entities, ~1.3 points of structural fidelity, for
     a SAP PD modelling gap the migration reproduced faithfully.
  2. "erwin has a primary identifier SAP PD does not" reused PRIMARY_IDENTIFIER
     — the same CRITICAL category as "erwin LOST the identifier", so a report
     grouped by category could not tell a loss from a fabrication.
  3. 41 attributes reported as FALLBACK_MATCH "possible rename" were nothing of
     the sort: erwin's logical export has no Physical_Name, so the parser
     fabricates code from name for the whole model.
"""

import os
import sys
import unittest
from types import SimpleNamespace

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.validation.ldm_reconcile import comparator as ldm
from app.validation.ldm_reconcile.comparator import ValidationResult
from app.validation.udp_bridge import UDP_PD_CODE, _append_code_rows

SPE = ldm.SEVERITY_SOURCE_PRE_EXISTING


def _result():
    return ValidationResult(pd_model="m", erwin_model="m", pd_file="m.ldm", erwin_file="m.xml")


def _findings(result, category=None):
    return [f for f in result.findings if category is None or f.category == category]


def _attr(name, code, is_migrated=False, oid="", order=0, data_type=""):
    return SimpleNamespace(name=name, code=code, is_migrated=is_migrated,
                           oid=oid, order=order, data_type=data_type, length="")


class SeverityWeightingTests(unittest.TestCase):
    """SOURCE_PRE_EXISTING must be visible AND weigh nothing."""

    def test_it_is_recorded_but_never_counted(self):
        result = _result()
        result.emit("MODEL_QUALITY", object_type="IDENTIFIER", object_name="ADDRESS",
                    severity=SPE, message="pre-existing")
        self.assertEqual(1, len(result.findings), "it must appear in the report")
        self.assertEqual(0, result.critical_count)
        self.assertEqual(0, result.warning_count)
        self.assertEqual(0, result.info_count, "it must not be weighted")

    def test_it_is_distinct_from_verified(self):
        # VERIFIED asserts something migrated intact; this asserts the
        # migration was not involved. Collapsing them would be a lie.
        self.assertNotEqual("VERIFIED", SPE)


class PrimaryIdentifierClassificationTests(unittest.TestCase):

    def test_absent_in_both_is_source_pre_existing_with_no_fidelity_impact(self):
        result = _result()
        ldm._emit_primary_absent_both(result, "ADDRESS")
        finding = _findings(result, "MODEL_QUALITY")[0]
        self.assertEqual(SPE, finding.severity)
        self.assertIn("pre-existing", finding.message.lower())
        self.assertEqual(0, result.info_count + result.warning_count + result.critical_count)

    def test_lost_in_erwin_remains_a_critical_migration_finding(self):
        result = _result()
        ldm._emit_primary_missing_in_erwin(result, "ADDRESS", "PK_ADDRESS")
        finding = _findings(result, "PRIMARY_IDENTIFIER")[0]
        self.assertEqual("CRITICAL", finding.severity)
        self.assertEqual(1, result.critical_count, "a genuine loss must still be scored")

    def test_invented_by_erwin_is_an_unexpected_transformation_not_a_loss(self):
        result = _result()
        pd_entity = SimpleNamespace(is_associative=False, attributes=[])
        erwin_entity = SimpleNamespace(is_associative=False,
                                       attributes=[_attr("ID", "ID", is_migrated=False)])
        erwin_primary = SimpleNamespace(attributes=["ID"])
        ldm._emit_primary_missing_in_pd(result, "ADDRESS", pd_entity, erwin_entity,
                                        set(), erwin_primary, "PK_ADDRESS")
        categories = {f.category for f in result.findings}
        self.assertIn("UNEXPECTED_TRANSFORMATION", categories)
        self.assertNotIn("PRIMARY_IDENTIFIER", categories,
                         "a fabrication must not share the category used for a loss")

    def test_the_three_cases_are_separable_by_category_alone(self):
        """A dashboard grouping by category must not conflate them."""
        loss = _result()
        ldm._emit_primary_missing_in_erwin(loss, "A", "PK_A")
        both = _result()
        ldm._emit_primary_absent_both(both, "B")
        invented = _result()
        ldm._emit_primary_missing_in_pd(
            invented, "C", SimpleNamespace(is_associative=False, attributes=[]),
            SimpleNamespace(is_associative=False, attributes=[_attr("ID", "ID")]),
            set(), SimpleNamespace(attributes=["ID"]), "PK_C")
        self.assertEqual(3, len({loss.findings[0].category,
                                 both.findings[0].category,
                                 invented.findings[0].category}))

    def test_inherited_identity_is_still_recognised(self):
        """A subtype whose identity comes from its supertype is equivalent."""
        result = _result()
        pd_entity = SimpleNamespace(is_associative=True, attributes=[])
        erwin_entity = SimpleNamespace(is_associative=True,
                                       attributes=[_attr("ID", "ID", is_migrated=True)])
        ldm._emit_primary_missing_in_pd(result, "LINK", pd_entity, erwin_entity,
                                        set(), SimpleNamespace(attributes=["ID"]), "PK")
        self.assertEqual("INHERITED_IDENTITY", result.findings[0].category)


class CodePreservationTests(unittest.TestCase):
    """Name and Code are separate metadata; neither may silently become the other."""

    def test_erwin_without_a_code_field_is_detected(self):
        self.assertFalse(ldm._erwin_has_own_code(
            _attr("Cost_Distribution_Type", "Cost_Distribution_Type")))
        self.assertTrue(ldm._erwin_has_own_code(
            _attr("Cost_Distribution_Type", "CST_DSTRBTN_TYP")))

    def test_no_code_field_is_reported_as_a_representation_difference(self):
        """The real_estate case: 41 attributes, none of them renamed."""
        result = _result()
        pd_attr = _attr("Cost_Distribution_Type", "CST_DSTRBTN_TYP",
                        oid="o543", order=1, data_type="BL")
        pd_entity = SimpleNamespace(oid="o512", name="COST_DISTRIBUTION_METHOD",
                                    code="CST_DSTRBTN_MTHD", attributes=[pd_attr])
        ldm._check_attribute_fallback_match(
            result, "COST_DISTRIBUTION_METHOD", "Cost_Distribution_Type", pd_attr,
            _attr("Cost_Distribution_Type", "Cost_Distribution_Type"), "name",
            pd_entity)
        finding = result.findings[0]
        self.assertEqual("CODE_NOT_CARRIED", finding.category)
        self.assertEqual(SPE, finding.severity)
        self.assertEqual(0, result.info_count, "no fidelity penalty for an erwin limitation")
        # The report names the mechanism that actually carries the code — and
        # says it is still unconfirmed, because encoded for transport is not
        # the same fact as delivered to erwin.
        text = finding.remediation + finding.message
        self.assertIn("PD_Attribute_Codes", text)
        self.assertIn("EXTERNAL_VERIFICATION_REQUIRED", text)
        self.assertIn("CST_DSTRBTN_TYP", finding.pd_value,
                      "the source code must stay visible as evidence")

    def test_an_attribute_that_cannot_be_identified_is_not_claimed_as_preserved(self):
        """
        Two attributes of one entity sharing a name, a type and an order cannot
        be told apart, so neither code is encoded. Claiming preservation here
        would attach one attribute's code to the other.
        """
        result = _result()
        twin_a = _attr("ID", "CUST_ID", oid="o1", order=1, data_type="VA10")
        twin_b = _attr("ID", "ORDER_ID", oid="o2", order=1, data_type="VA10")
        pd_entity = SimpleNamespace(oid="o99", name="E", code="E",
                                    attributes=[twin_a, twin_b])
        ldm._check_attribute_fallback_match(
            result, "E", "ID", twin_a, _attr("ID", "ID"), "name", pd_entity)
        finding = result.findings[0]
        self.assertEqual("CODE_NOT_CARRIED", finding.category)
        self.assertEqual(SPE, finding.severity)
        text = finding.remediation + finding.message
        self.assertIn("NOT carried", text)
        self.assertNotIn("carried into erwin as", text)

    def test_an_entity_without_an_object_id_is_never_claimed_as_preserved(self):
        """
        build() refuses to record an entity it cannot anchor; the comparator
        must refuse to claim one, or the report would assert a preservation
        that was never written and erwin never received.
        """
        result = _result()
        pd_attr = _attr("Amount", "AMT", oid="o7", order=1, data_type="DC")
        pd_entity = SimpleNamespace(oid="", name="E", code="E", attributes=[pd_attr])
        ldm._check_attribute_fallback_match(
            result, "E", "Amount", pd_attr, _attr("Amount", "Amount"), "name", pd_entity)
        text = result.findings[0].remediation + result.findings[0].message
        self.assertIn("NOT carried", text)

    def test_a_genuine_rename_is_still_reported_as_a_fallback_match(self):
        """erwin HAS its own code and it differs: that is a real rename."""
        result = _result()
        ldm._check_attribute_fallback_match(
            result, "E", "Amount",
            _attr("Amount", "AMT"), _attr("Amount", "AMOUNT_V2"), "name")
        finding = result.findings[0]
        self.assertEqual("FALLBACK_MATCH", finding.category)
        self.assertEqual("INFO", finding.severity)
        self.assertEqual(1, result.info_count, "a real rename is still scored")

    def test_an_exact_code_match_emits_nothing(self):
        result = _result()
        ldm._check_attribute_fallback_match(
            result, "E", "Amount", _attr("Amount", "AMT"), _attr("Amount", "AMT"), "code")
        self.assertEqual([], result.findings)

    def test_equal_name_and_code_in_the_source_emits_nothing(self):
        """Nothing to preserve when PD's own name and code are the same."""
        result = _result()
        ldm._check_attribute_fallback_match(
            result, "E", "Amount", _attr("Amount", "Amount"),
            _attr("Amount", "Amount"), "name")
        self.assertEqual([], result.findings)


class CodeUdpPreservationTests(unittest.TestCase):
    """The code must actually reach erwin, not merely be reported as absent."""

    def test_a_differing_code_is_preserved_as_a_udp(self):
        manifest = [{"entity_name": "Cost Distribution Method",
                     "entity_code": "CST_DSTRBTN_MTHD",
                     "udp": "DataConfidentiality", "value": "C", "source_path": ""}]
        schema, rows = _append_code_rows([], manifest)
        self.assertEqual([UDP_PD_CODE], [r["udp"] for r in schema])
        preserved = [r for r in rows if r["udp"] == UDP_PD_CODE]
        self.assertEqual(1, len(preserved))
        self.assertEqual("CST_DSTRBTN_MTHD", preserved[0]["value"])
        self.assertEqual("Cost Distribution Method", preserved[0]["entity_name"],
                         "erwin_load resolves its target by entity NAME")

    def test_an_identical_code_is_not_preserved_as_noise(self):
        manifest = [{"entity_name": "ADDRESS", "entity_code": "ADDRESS",
                     "udp": "X", "value": "1", "source_path": ""}]
        schema, rows = _append_code_rows([], manifest)
        self.assertEqual(([], manifest), (schema, rows))

    def test_the_rows_match_the_injector_row_shape(self):
        manifest = [{"entity_name": "E", "entity_code": "E_CD",
                     "udp": "X", "value": "1", "source_path": ""}]
        _, rows = _append_code_rows([], manifest)
        required = {"pd_object_id", "entity_name", "entity_code", "udp", "value", "source_path"}
        for row in [r for r in rows if r["udp"] == UDP_PD_CODE]:
            self.assertEqual(required, set(row),
                             "erwin_load reads these keys; a missing one is skipped silently")

    def test_the_udp_is_defined_only_once(self):
        manifest = [{"entity_name": "A", "entity_code": "A_CD", "udp": "X",
                     "value": "1", "source_path": ""},
                    {"entity_name": "B", "entity_code": "B_CD", "udp": "X",
                     "value": "2", "source_path": ""}]
        schema, rows = _append_code_rows([], manifest)
        self.assertEqual(1, [r["udp"] for r in schema].count(UDP_PD_CODE))
        self.assertEqual(2, sum(1 for r in rows if r["udp"] == UDP_PD_CODE))

    def test_nothing_is_preserved_twice_on_a_rerun(self):
        manifest = [{"entity_name": "A", "entity_code": "A_CD", "udp": "X",
                     "value": "1", "source_path": ""}]
        schema, rows = _append_code_rows([], manifest)
        schema2, rows2 = _append_code_rows(schema, rows)
        self.assertEqual(1, [r["udp"] for r in schema2].count(UDP_PD_CODE))


if __name__ == "__main__":       # pragma: no cover
    unittest.main()


class ModelIdentityTests(unittest.TestCase):
    """
    A model-code difference is traceability-only ONLY when the pair is provably
    the same model. Two unrelated models must never become indistinguishable
    because only their names were compared.
    """

    def test_identity_is_secure_when_the_entities_overlap(self):
        self.assertTrue(ldm._model_identity_is_secure(
            SimpleNamespace(entities_pd=105, entities_matched=103)))

    def test_identity_is_not_secure_when_they_do_not(self):
        self.assertFalse(ldm._model_identity_is_secure(
            SimpleNamespace(entities_pd=105, entities_matched=2)))

    def test_identity_is_not_secure_with_nothing_to_compare(self):
        self.assertFalse(ldm._model_identity_is_secure(
            SimpleNamespace(entities_pd=0, entities_matched=0)))

    def test_erwin_without_a_model_code_field_is_detected(self):
        # erwin reports the model NAME as the code when it has no Code field.
        self.assertFalse(ldm._erwin_has_own_model_code("Real Estate", "Real Estate"))
        self.assertTrue(ldm._erwin_has_own_model_code("RL_ESTT_V2", "Real Estate"))

    def test_the_real_estate_case_is_traceability_only(self):
        result = _result()
        result.entities_pd, result.entities_matched = 105, 103
        ldm._check_model_metadata_value(result, "Code", "RL_ESTT", "Real Estate",
                                        erwin_model_name="Real Estate")
        finding = result.findings[0]
        self.assertEqual("CODE_NOT_CARRIED", finding.category)
        self.assertEqual(SPE, finding.severity)
        self.assertEqual(0, result.info_count, "traceability-only, no structural penalty")
        self.assertIn("RL_ESTT", finding.pd_value)

    def test_a_code_difference_with_no_entity_overlap_stays_a_real_finding(self):
        """The wrong export paired with this source must not be excused."""
        result = _result()
        result.entities_pd, result.entities_matched = 105, 1
        ldm._check_model_metadata_value(result, "Code", "RL_ESTT", "Fleet",
                                        erwin_model_name="Fleet")
        finding = result.findings[0]
        self.assertEqual("MODEL_METADATA", finding.category)
        self.assertEqual("INFO", finding.severity)
        self.assertIn("may not be the same model", finding.message)

    def test_a_genuinely_different_model_code_is_still_reported(self):
        """erwin HAS its own code and it differs: a real metadata difference."""
        result = _result()
        result.entities_pd, result.entities_matched = 105, 103
        ldm._check_model_metadata_value(result, "Code", "RL_ESTT", "RL_ESTT_V2",
                                        erwin_model_name="Real Estate")
        self.assertEqual("MODEL_METADATA", result.findings[0].category)

    def test_an_exact_model_code_match_is_verified(self):
        result = _result()
        ldm._check_model_metadata_value(result, "Code", "RL_ESTT", "RL_ESTT",
                                        erwin_model_name="Real Estate")
        self.assertEqual("VERIFIED", result.findings[0].severity)
