"""
PowerDesigner Shortcuts carried into erwin as UDPs
(app/validation/shortcut_udp.py + the udp_bridge hook).

Before this, shortcuts were counted and then dropped: erwin has no shortcut
object, the component was weighted 0.0, and sow_classify recorded them as
``facts_lost``. The migratable fact is not the shortcut itself but the
per-object glossary BINDING — "this entity's name is built from these terms" —
and that is what these tests pin down.

The fixtures mirror the structure measured in the two real LDMs: the
modeller's ``c:ExternalObjects`` collection is absent, and all the content is
in ``c:TermObjects`` / ``c:SessionShortcuts`` with ``c:RelatedNameTerms`` /
``c:RelatedCodeTerms`` pointing into it by Ref.
"""

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.validation import shortcut_udp, udp_bridge

# Glossary-only model, exactly the shape of the real files.
PD_GLOSSARY = """<?xml version="1.0" encoding="UTF-8"?>
<Model xmlns:a="attribute" xmlns:c="collection" xmlns:o="object">
<o:RootObject Id="root"><c:Children><o:Model Id="m1">
  <a:Name>Real Estate</a:Name>
  <a:Code>REAL_ESTATE</a:Code>
  <c:TermObjects>
    <o:Shortcut Id="t1">
      <a:ObjectID>GUID-SITE</a:ObjectID><a:Name>Site</a:Name><a:Code>ST</a:Code>
      <a:TargetStereotype>IsEntity</a:TargetStereotype>
      <a:TargetClassID>EBE946CF-7218-4FAC-B85E-4AB922930494</a:TargetClassID>
      <a:TargetPackagePath>&lt;Model&gt;</a:TargetPackagePath>
    </o:Shortcut>
    <o:Shortcut Id="t2">
      <a:ObjectID>GUID-PROP</a:ObjectID><a:Name>Property</a:Name><a:Code>PRPRTY</a:Code>
      <a:TargetClassID>EBE946CF-7218-4FAC-B85E-4AB922930494</a:TargetClassID>
    </o:Shortcut>
  </c:TermObjects>
  <c:Entities>
    <o:Entity Id="e1">
      <a:Name>Property Site</a:Name><a:Code>PROPERTY_SITE</a:Code>
      <a:ObjectID>GUID-E1</a:ObjectID>
      <c:RelatedNameTerms><o:Shortcut Ref="t2"/><o:Shortcut Ref="t1"/></c:RelatedNameTerms>
      <c:RelatedCodeTerms><o:Shortcut Ref="t2"/><o:Shortcut Ref="t1"/></c:RelatedCodeTerms>
    </o:Entity>
    <o:Entity Id="e2">
      <a:Name>Unbound Entity</a:Name><a:Code>UNBOUND</a:Code>
    </o:Entity>
  </c:Entities>
  <c:Relationships>
    <o:Relationship Id="r1">
      <a:Name>Site Of Property</a:Name>
      <c:RelatedNameTerms><o:Shortcut Ref="t1"/></c:RelatedNameTerms>
    </o:Relationship>
  </c:Relationships>
</o:Model></c:Children></o:RootObject></Model>
"""

# A model that also has the modeller's real "List of Shortcuts".
PD_EXTERNAL = """<?xml version="1.0" encoding="UTF-8"?>
<Model xmlns:a="attribute" xmlns:c="collection" xmlns:o="object">
<o:RootObject Id="root"><c:Children><o:Model Id="m1">
  <a:Name>Fleet</a:Name>
  <c:ExternalObjects>
    <o:Shortcut Id="x1">
      <a:ObjectID>GUID-X1</a:ObjectID><a:Name>Vessel</a:Name><a:Code>VSL</a:Code>
      <a:TargetClassID>CD2F5C71-2CA9-4B74-9BBA-50786D1D88EF</a:TargetClassID>
      <a:TargetModelURL>Core Marine Model</a:TargetModelURL>
      <a:TargetPackagePath>Marine/Assets</a:TargetPackagePath>
      <a:TargetStereotype>IsEntity</a:TargetStereotype>
    </o:Shortcut>
  </c:ExternalObjects>
</o:Model></c:Children></o:RootObject></Model>
"""


def _write(tmp: Path, text: str, name: str = "m.ldm") -> Path:
    path = tmp / name
    path.write_text(text, encoding="utf-8")
    return path


class ExtractionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def test_glossary_collections_are_censused(self):
        census = shortcut_udp.extract(_write(self.root, PD_GLOSSARY))
        self.assertEqual(2, len(census.shortcuts))
        self.assertEqual({"Site", "Property"}, {s.name for s in census.shortcuts})
        self.assertEqual(2, len(census.glossary_terms))
        self.assertEqual([], census.external_references)

    def test_ref_pointers_are_not_counted_as_definitions(self):
        # Every binding repeats the shortcut as <o:Shortcut Ref="..."/>; counting
        # those would multiply the census by the number of objects using a term.
        census = shortcut_udp.extract(_write(self.root, PD_GLOSSARY))
        self.assertEqual(2, len(census.shortcuts), "definitions only, not Ref pointers")

    def test_bindings_resolve_refs_to_term_names_and_codes(self):
        census = shortcut_udp.extract(_write(self.root, PD_GLOSSARY))
        entity = next(b for b in census.bindings if b.owner_name == "Property Site")
        self.assertEqual(["Property", "Site"], entity.name_terms)
        self.assertEqual(["PRPRTY", "ST"], entity.code_terms)
        self.assertEqual("GUID-E1", entity.owner_oid)

    def test_an_object_without_bindings_produces_none(self):
        census = shortcut_udp.extract(_write(self.root, PD_GLOSSARY))
        self.assertNotIn("Unbound Entity", {b.owner_name for b in census.bindings})

    def test_bindings_on_objects_erwin_cannot_hold_are_kept_separate(self):
        # erwin_load applies values to Entities and the model root only. A
        # relationship binding is real but unreachable; it must be reported as
        # such rather than emitted as a row that silently goes nowhere.
        census = shortcut_udp.extract(_write(self.root, PD_GLOSSARY))
        self.assertEqual(["Property Site"], [b.owner_name for b in census.injectable_bindings])
        unreachable = {b.owner_type for b in census.unreachable_bindings}
        self.assertIn("Relationship", unreachable)
        self.assertIn("erwin cannot hold a UDP for", census.summary_line())

    def test_external_shortcuts_keep_their_target(self):
        census = shortcut_udp.extract(_write(self.root, PD_EXTERNAL))
        shortcut = census.external_references[0]
        self.assertEqual("Vessel", shortcut.name)
        self.assertEqual("Category", shortcut.target_type)
        self.assertEqual("Core Marine Model", shortcut.target_model)
        self.assertEqual("Marine/Assets", shortcut.target_package)
        self.assertTrue(shortcut.is_external_reference)

    def test_collections_are_configurable(self):
        class Config:
            SHORTCUT_COLLECTIONS = ("ExternalObjects",)      # the old, narrower rule
            SHORTCUT_BINDING_COLLECTIONS = ("RelatedNameTerms", "RelatedCodeTerms")

        census = shortcut_udp.extract(_write(self.root, PD_GLOSSARY), config=Config())
        self.assertEqual([], census.shortcuts,
                         "this is exactly why shortcuts_pd read 0 on the real models")

    def test_an_unreadable_model_is_an_empty_census_not_a_crash(self):
        broken = _write(self.root, "<Model><o:Entity", "broken.ldm")
        census = shortcut_udp.extract(broken)
        self.assertTrue(census.error)
        self.assertEqual([], census.shortcuts)
        self.assertIn("failed", census.summary_line())

    def test_a_missing_file_is_an_empty_census_not_a_crash(self):
        self.assertTrue(shortcut_udp.extract(self.root / "absent.ldm").error)


class SchemaAndManifestTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.schema, self.manifest, self.census = shortcut_udp.build(
            _write(self.root, PD_GLOSSARY), "real_estate")

    def tearDown(self):
        self.tmp.cleanup()

    def test_schema_rows_match_the_udp_tool_row_shape(self):
        # erwin_prepare.build_udp_schema rows are consumed by erwin_load's
        # dictionary setup; a row missing a key would fail at injection time.
        required = {"udp", "type", "length", "value_list", "source_path",
                    "coverage", "distinct_observed", "list_source", "purpose"}
        for row in self.schema:
            self.assertEqual(required, set(row), row.get("udp"))
            self.assertIn(row["type"], ("Text", "List"))
            self.assertTrue(row["purpose"], row["udp"])

    def test_manifest_rows_match_the_injector_row_shape(self):
        required = {"pd_object_id", "entity_name", "entity_code", "udp", "value", "source_path"}
        for row in self.manifest:
            self.assertEqual(required, set(row), row.get("udp"))

    def test_the_entity_binding_becomes_two_udp_values(self):
        rows = {r["udp"]: r for r in self.manifest if r["entity_name"] == "Property Site"}
        self.assertEqual("Property, Site", rows[shortcut_udp.UDP_NAME_TERMS]["value"])
        self.assertEqual("PRPRTY, ST", rows[shortcut_udp.UDP_CODE_TERMS]["value"])

    def test_entity_name_is_what_the_injector_matches_on(self):
        # erwin_load builds entities_by_name from ent.Name.lower(); a row keyed
        # on the CODE would never find its entity.
        row = next(r for r in self.manifest if r["udp"] == shortcut_udp.UDP_NAME_TERMS)
        self.assertEqual("Property Site", row["entity_name"])
        self.assertEqual("PROPERTY_SITE", row["entity_code"])

    def test_model_root_rows_record_what_existed(self):
        root_rows = {r["udp"]: r["value"] for r in self.manifest if not r["entity_name"]}
        self.assertEqual("2", root_rows[shortcut_udp.UDP_SHORTCUT_COUNT])
        self.assertIn("Site(ST)", root_rows[shortcut_udp.UDP_SHORTCUT_TERMS])

    def test_the_census_row_lands_even_when_nothing_is_injectable(self):
        # A model whose bindings are all on relationships still records them.
        text = PD_GLOSSARY.replace('<o:Entity Id="e1">', '<o:Ignored Id="e1">').replace(
            "</o:Entity>\n    <o:Entity", "</o:Ignored>\n    <o:Entity")
        _, manifest, census = shortcut_udp.build(_write(self.root, text, "b.ldm"))
        self.assertEqual([], census.injectable_bindings)
        self.assertIn(shortcut_udp.UDP_SHORTCUT_COUNT, {r["udp"] for r in manifest})

    def test_external_shortcut_values(self):
        _, manifest, _ = shortcut_udp.build(_write(self.root, PD_EXTERNAL, "x.ldm"))
        rows = {r["udp"]: r["value"] for r in manifest if r["entity_name"] == "Vessel"}
        self.assertEqual("Core Marine Model", rows[shortcut_udp.UDP_SHORTCUT_TARGET])
        self.assertEqual("Category", rows[shortcut_udp.UDP_SHORTCUT_TYPE])
        self.assertEqual("Marine/Assets", rows[shortcut_udp.UDP_SHORTCUT_PACKAGE])
        self.assertEqual("IsEntity", rows[shortcut_udp.UDP_SHORTCUT_STEREOTYPE])

    def test_long_values_are_truncated_visibly_not_silently(self):
        class Config:
            SHORTCUT_UDP_MAX_LENGTH = 20

        _, manifest, _ = shortcut_udp.build(
            _write(self.root, PD_GLOSSARY, "t.ldm"), config=Config())
        terms = next(r["value"] for r in manifest
                     if r["udp"] == shortcut_udp.UDP_SHORTCUT_TERMS)
        self.assertLessEqual(len(terms), 20)
        self.assertIn("truncated", terms)

    def test_a_model_with_no_shortcuts_produces_no_rows(self):
        bare = _write(self.root, "<?xml version='1.0'?><Model><o:X/></Model>", "bare.ldm")
        schema, manifest, census = shortcut_udp.build(bare)
        self.assertEqual(([], []), (schema, manifest))
        self.assertEqual([], census.shortcuts)


class BridgeIntegrationTests(unittest.TestCase):
    """The rows have to reach the two files the erwin injector actually reads."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.workdir = self.root / "work"
        (self.workdir / "baseline").mkdir(parents=True)
        (self.workdir / "baseline" / "extended_attributes.json").write_text("{}", encoding="utf-8")
        (self.workdir / "baseline" / "entities.json").write_text("[]", encoding="utf-8")
        self.model = _write(self.root, PD_GLOSSARY)

    def tearDown(self):
        self.tmp.cleanup()

    def _build(self, config=None):
        return udp_bridge.build_mapping(str(self.workdir), "real_estate", "46007266",
                                        pd_path=str(self.model), config=config)

    def test_shortcut_rows_are_written_into_the_manifest_the_injector_reads(self):
        _, manifest = self._build()
        written = json.loads((self.workdir / "property_manifest.json").read_text(encoding="utf-8"))
        self.assertEqual(manifest, written)
        self.assertIn(shortcut_udp.UDP_NAME_TERMS, {r["udp"] for r in written})

    def test_shortcut_definitions_are_written_into_the_schema(self):
        schema, _ = self._build()
        written = json.loads((self.workdir / "udp_schema.json").read_text(encoding="utf-8"))
        self.assertEqual(schema, written)
        self.assertIn(shortcut_udp.UDP_CODE_TERMS, {r["udp"] for r in written})

    def test_the_tools_own_structural_udps_are_untouched(self):
        schema, _ = self._build()
        names = [r["udp"] for r in schema]
        self.assertEqual(["PD_ObjectID", "PD_SourceExtraction", "PD_SourceModel"], names[:3],
                         "shortcut rows are APPENDED; the tool's own output must not move")

    def test_the_feature_can_be_switched_off(self):
        class Config:
            UDP_TOOL_INCLUDE_SHORTCUTS = False

        schema, manifest = self._build(Config())
        self.assertEqual([], [r for r in manifest if str(r["udp"]).startswith("PD_Shortcut")])
        self.assertEqual([], [r for r in schema if str(r["udp"]).startswith("PD_Shortcut")])

    def test_no_pd_path_means_no_shortcut_rows(self):
        _, manifest = udp_bridge.build_mapping(str(self.workdir), "real_estate", "46007266")
        self.assertEqual([], [r for r in manifest if str(r["udp"]).startswith("PD_")
                              and "Shortcut" in str(r["udp"])])

    def test_a_shortcut_failure_never_costs_the_model_its_other_udps(self):
        with patch.object(shortcut_udp, "build", side_effect=RuntimeError("boom")):
            schema, manifest = self._build()
        self.assertTrue(schema, "the extended-attribute UDPs still come through")

    def test_a_duplicate_udp_definition_is_not_added_twice(self):
        # If a model's extended attributes ever produce a PD_NameTerms UDP, the
        # shortcut row must not redefine it — erwin would see two definitions.
        original = udp_bridge.load()["erwin_prepare"].build_udp_schema

        def with_clash(profile):
            return original(profile) + [{"udp": shortcut_udp.UDP_NAME_TERMS, "type": "Text",
                                         "length": 60, "value_list": None, "source_path": "x",
                                         "coverage": "", "distinct_observed": "",
                                         "list_source": "", "purpose": "pre-existing"}]

        with patch.dict(udp_bridge.load(), {}, clear=False):
            with patch.object(udp_bridge.load()["erwin_prepare"], "build_udp_schema", with_clash):
                schema, _ = self._build()
        names = [r["udp"] for r in schema]
        self.assertEqual(1, names.count(shortcut_udp.UDP_NAME_TERMS))


if __name__ == "__main__":       # pragma: no cover
    unittest.main()
