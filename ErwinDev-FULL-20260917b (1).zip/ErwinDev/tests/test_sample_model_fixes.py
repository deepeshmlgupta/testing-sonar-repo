"""
Regressions surfaced by the 02_logistics_segment.cdm / 05_Carbon_Calculator.pdm
sample models (2026-09-14).

1. CDM parser: relationship-end `mandatory` must follow the cardinality lower
   bound and `dependent` must honour <a:DependentRole>, as the LDM parser
   already does — otherwise every mandatory / identifying relationship is
   reported as a RELATIONSHIP_SEMANTIC_MISMATCH against erwin.
2. Report generators: the MAX_DIFF_ROWS_PER_MODEL cap must be applied AFTER
   severity ordering so a truncated FINDINGS sheet never drops warnings while
   keeping VERIFIED / INFO rows.
3. report_layout: a COUNTIF criterion given as a cell reference ($A2) must be
   resolved to that cell's value when the udp_tool sheets are cached into the
   V3 workbook, otherwise the per-UDP rollup reads 0 everywhere.
4. pdm_preprocessor._ErwinDoc helpers are instance methods (a stray
   @staticmethod made preprocess_model raise TypeError on every PDM that
   needed a column restored).
"""
import textwrap

from openpyxl import Workbook

from app.preprocessing import pdm_preprocessor
from app.reporting import report_layout
from app.validation.cdm_reconcile import report_generator as cdm_report
from app.validation.cdm_reconcile.comparator import Finding
from app.validation.cdm_reconcile.pd_cdm_parser import parse_cdm
from app.validation.ldm_reconcile import report_generator as ldm_report

_CDM = textwrap.dedent("""\
    <?xml version="1.0" encoding="UTF-8"?>
    <Model xmlns:a="attribute" xmlns:c="collection" xmlns:o="object">
    <o:RootObject Id="o1"><c:Children>
    <o:Model Id="o2"><a:Name>M</a:Name><a:Code>M</a:Code>
    <c:Entities>
      <o:Entity Id="o10"><a:Name>Role</a:Name><a:Code>ROLE</a:Code></o:Entity>
      <o:Entity Id="o11"><a:Name>Party</a:Name><a:Code>PARTY</a:Code></o:Entity>
    </c:Entities>
    <c:Relationships>
      <o:Relationship Id="o20"><a:Name>plays</a:Name><a:Code>PLAYS</a:Code>
        <a:DependentRole>B</a:DependentRole>
        <a:Entity1ToEntity2RoleCardinality>0..n</a:Entity1ToEntity2RoleCardinality>
        <a:Entity2ToEntity1RoleCardinality>1..1</a:Entity2ToEntity1RoleCardinality>
        <c:Object1><o:Entity Ref="o10"/></c:Object1>
        <c:Object2><o:Entity Ref="o11"/></c:Object2>
      </o:Relationship>
      <o:Relationship Id="o21"><a:Name>owns</a:Name><a:Code>OWNS</a:Code>
        <a:Entity1ToEntity2RoleCardinality>1..n</a:Entity1ToEntity2RoleCardinality>
        <a:Entity2ToEntity1RoleCardinality>0..1</a:Entity2ToEntity1RoleCardinality>
        <c:Object1><o:Entity Ref="o11"/></c:Object1>
        <c:Object2><o:Entity Ref="o10"/></c:Object2>
      </o:Relationship>
    </c:Relationships>
    </o:Model></c:Children></o:RootObject></Model>
""")


def _rels(model):
    rels = model.relationships
    return {r.name: r for r in (rels.values() if isinstance(rels, dict) else rels)}


def test_cdm_relationship_mandatory_follows_cardinality_lower_bound(tmp_path):
    path = tmp_path / "m.cdm"
    path.write_text(_CDM, encoding="utf-8")
    rels = _rels(parse_cdm(str(path)))

    plays = rels["plays"]
    assert plays.end1.cardinality == "0,n" and plays.end1.mandatory is False
    assert plays.end2.cardinality == "1,1" and plays.end2.mandatory is True

    owns = rels["owns"]
    assert owns.end1.mandatory is True      # 1..n
    assert owns.end2.mandatory is False     # 0..1


def test_cdm_relationship_dependent_end_honours_dependentrole(tmp_path):
    path = tmp_path / "m.cdm"
    path.write_text(_CDM, encoding="utf-8")
    rels = _rels(parse_cdm(str(path)))
    assert rels["plays"].end1.dependent is True      # "B" -> end 1 (Entity1)
    assert rels["plays"].end2.dependent is False
    assert not rels["owns"].end1.dependent and not rels["owns"].end2.dependent


def _finding(severity, n):
    return Finding(category="X", severity=severity, object_type="E",
                   object_name=f"obj{n:04d}", member="", message="m",
                   pd_value="", erwin_value="", remediation="")


def test_findings_cap_is_applied_after_severity_ordering(monkeypatch):
    for module in (cdm_report, ldm_report):
        monkeypatch.setattr(module.config, "MAX_DIFF_ROWS_PER_MODEL", 5, raising=False)
        # emission order: verified first, warnings last (the real-world order)
        findings = [_finding("VERIFIED", i) for i in range(10)]
        findings += [_finding("WARNING", i) for i in range(4)]
        findings += [_finding("CRITICAL", 0)]
        kept = module._limited(findings)
        assert len(kept) == 5
        assert [f.severity for f in kept] == ["CRITICAL"] + ["WARNING"] * 4


def test_countif_criterion_cell_reference_is_resolved():
    wb = Workbook()
    detail = wb.active
    detail.title = "UDP Comparison"
    detail.append(["Entity", "Applied", "UDP Name", "SAP", "erwin", "Status"])
    for udp, status in (("Owner", "MISSING"), ("Owner", "PASS"), ("Category", "MISSING")):
        detail.append(["E", "Entity", udp, "v", "", status])
    rollup = wb.create_sheet("By UDP")
    rollup.append(["UDP Name", "Rows", "MISSING"])
    rollup.append(["Owner",
                   "=COUNTIF('UDP Comparison'!$C$2:$C$4,$A2)",
                   "=COUNTIFS('UDP Comparison'!$C$2:$C$4,$A2,'UDP Comparison'!$F$2:$F$4,\"MISSING\")"])
    rollup.append(["Category",
                   "=COUNTIF('UDP Comparison'!$C$2:$C$4,$A3)",
                   "=COUNTIFS('UDP Comparison'!$C$2:$C$4,$A3,'UDP Comparison'!$F$2:$F$4,\"MISSING\")"])

    ev = lambda cell: report_layout._evaluate_aggregate(cell.value, wb, "By UDP")  # noqa: E731
    assert ev(rollup["B2"]) == 2 and ev(rollup["C2"]) == 1
    assert ev(rollup["B3"]) == 1 and ev(rollup["C3"]) == 1
    # literal criteria still work unchanged
    assert report_layout._evaluate_aggregate(
        "=COUNTIF('UDP Comparison'!$F$2:$F$4,\"PASS\")", wb, "By UDP") == 1


def test_erwin_doc_helpers_are_bound_methods():
    import inspect
    for name in ("entity_phys", "attributes", "attr_by_code", "key_groups"):
        assert not isinstance(inspect.getattr_static(pdm_preprocessor._ErwinDoc, name),
                              staticmethod), name


# ── Short model names everywhere a human reads them ──────────────────────────

_FULL = "4d95b17a5883fbeb69fb9088bf1767c1_46007266_real_estate"


def test_short_model_name_strips_repository_prefix():
    assert report_layout.short_model_name(_FULL) == "real_estate"
    assert report_layout.short_model_name("02_logistics_segment") == "02_logistics_segment"
    assert report_layout.report_name(_FULL, report_layout.V1_SUFFIX) == "real_estate_v1_fidelity_report.xlsx"
    assert report_layout.report_name(_FULL, report_layout.V3_SUFFIX) == "real_estate_v3_fidelity_report.xlsx"


def test_udp_workbooks_named_after_short_name_still_resolve(tmp_path):
    tier = tmp_path / "ldm"
    tier.mkdir()
    (tier / "real_estate_udp_migration_report.xlsx").write_bytes(b"")
    (tier / "real_estate_udp_comparison.xlsx").write_bytes(b"")
    hit = report_layout.resolve_workbook(_FULL, [tier], ("_udp_migration_report", "_UDP_Migration_Report"))
    assert hit.endswith("real_estate_udp_migration_report.xlsx")
    hit = report_layout.resolve_workbook(_FULL, [tier], ("_udp_comparison", "_UDP_Comparison"))
    assert hit.endswith("real_estate_udp_comparison.xlsx")


def test_legacy_full_name_udp_workbooks_still_resolve(tmp_path):
    tier = tmp_path / "ldm"
    tier.mkdir()
    (tier / f"{_FULL}_UDP_Migration_Report.xlsx").write_bytes(b"")
    hit = report_layout.resolve_workbook(_FULL, [tier], ("_udp_migration_report", "_UDP_Migration_Report"))
    assert hit.endswith(f"{_FULL}_UDP_Migration_Report.xlsx")


def test_udp_flow_display_name_and_workdir_use_short_name(tmp_path):
    from app.validation import udp_flow
    assert udp_flow._display_name(_FULL) == "real_estate"


# ── Flat erwinmodels stage layout: 1_initial / 2_preprocessed / 3_final ──────

def test_stage_folders_are_flat(tmp_path, monkeypatch):
    from app.config import settings
    from app.orchestration import directory_setup
    monkeypatch.setattr(settings, "SAMPLES_DIR", str(tmp_path / "sappdmodels"), raising=False)
    monkeypatch.setattr(settings, "OUTPUT_DIR", str(tmp_path / "erwinmodels"), raising=False)
    monkeypatch.setattr(settings, "SUMMARY_DIR", str(tmp_path / "batch_summary"), raising=False)
    monkeypatch.setattr(settings, "FINAL_XML_DIR", str(tmp_path / "final_xml_models"), raising=False)
    dirs = directory_setup.setup_directories()
    for stage in ("initial", "preprocessed", "final"):
        assert dirs[stage].is_dir()
        assert not (dirs[stage] / "xml").exists()
        assert not (dirs[stage] / "erwin").exists()
    assert directory_setup.stage_file(dirs, "initial", "real_estate", ".xml") \
        == tmp_path / "erwinmodels" / "1_initial" / "real_estate.xml"
    assert directory_setup.stage_file(dirs, "final", "real_estate", "erwin").name == "real_estate.erwin"


def _record(base, score):
    from types import SimpleNamespace
    result = SimpleNamespace(status="PASS", fidelity_score=score, critical_count=0,
                             warning_count=0, info_count=0, promotion_note="")
    return SimpleNamespace(base_name=base, result=result, final_xml="", destination="")


def test_passing_model_lands_flat_in_3_final_with_binary(tmp_path, monkeypatch):
    from app.orchestration.model_record import DEST_FINAL
    from app.workflows import promotion_routing
    dirs = {k: tmp_path / v for k, v in
            (("initial", "1_initial"), ("preprocessed", "2_preprocessed"), ("final", "3_final"))}
    for d in dirs.values():
        d.mkdir()
    (dirs["preprocessed"] / "m.xml").write_text("<erwin/>")
    (dirs["initial"] / "m.erwin").write_bytes(b"bin")
    monkeypatch.setattr(promotion_routing.promotion_gate, "apply", lambda result: True)
    record = _record("m", 95.0)
    promotion_routing.route_model(record, dirs["preprocessed"] / "m.xml", dirs)
    assert record.destination == DEST_FINAL
    assert (dirs["final"] / "m.xml").is_file()
    assert (dirs["final"] / "m.erwin").read_bytes() == b"bin"
    assert not (dirs["final"] / "xml").exists()


def test_failing_model_stays_in_2_preprocessed(tmp_path, monkeypatch):
    from app.workflows import promotion_routing
    dirs = {k: tmp_path / v for k, v in
            (("initial", "1_initial"), ("preprocessed", "2_preprocessed"), ("final", "3_final"))}
    for d in dirs.values():
        d.mkdir()
    (dirs["preprocessed"] / "m.xml").write_text("<erwin/>")
    monkeypatch.setattr(promotion_routing.promotion_gate, "apply", lambda result: False)
    monkeypatch.setattr(promotion_routing.promotion_gate, "band",
                        lambda result, *_: promotion_routing.promotion_gate.BAND_FAIL)
    record = _record("m", 74.3)
    promotion_routing.route_model(record, dirs["preprocessed"] / "m.xml", dirs)
    assert (dirs["preprocessed"] / "m.xml").is_file()      # untouched
    assert not any(dirs["final"].iterdir())                 # nothing promoted
    assert record.destination != "3_final"
