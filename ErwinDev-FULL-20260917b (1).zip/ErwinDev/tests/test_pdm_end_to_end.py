"""
PDM engine end to end on a two-table synthetic model: PD parser, erwin parser,
comparator, pdm_flow (V1 -> remediation -> V3 -> gate) and the PDM report
generator. The PDM path had ~25 % coverage and no test drove its flow.
"""

import os
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from openpyxl import load_workbook

from app.validation.pdm_reconcile import pdm_flow, pdm_report_generator, pdm_validator_bridge

PD_PDM = textwrap.dedent("""\
    <?xml version="1.0" encoding="UTF-8"?>
    <?PowerDesigner AppLocale="UTF16" ExtractionId="1" Name="Orders"?>
    <Model xmlns:a="attribute" xmlns:c="collection" xmlns:o="object">
    <o:RootObject Id="o1"><c:Children>
    <o:Model Id="o2"><a:Name>Orders</a:Name><a:Code>ORDERS</a:Code>
    <c:Tables>
      <o:Table Id="t1"><a:ObjectID>T1</a:ObjectID><a:Name>Customer</a:Name><a:Code>CUSTOMER</a:Code>
        <a:Comment>A customer.</a:Comment>
        <c:Columns>
          <o:Column Id="c1"><a:ObjectID>C1</a:ObjectID><a:Name>Customer Id</a:Name><a:Code>CUSTOMER_ID</a:Code>
            <a:DataType>integer</a:DataType><a:Column.Mandatory>1</a:Column.Mandatory></o:Column>
          <o:Column Id="c2"><a:ObjectID>C2</a:ObjectID><a:Name>Customer Name</a:Name><a:Code>CUSTOMER_NAME</a:Code>
            <a:DataType>varchar(100)</a:DataType><a:Length>100</a:Length></o:Column>
        </c:Columns>
        <c:Keys><o:Key Id="k1"><a:ObjectID>K1</a:ObjectID><a:Name>PK_CUSTOMER</a:Name><a:Code>PK_CUSTOMER</a:Code>
          <c:Key.Columns><o:Column Ref="c1"/></c:Key.Columns></o:Key></c:Keys>
        <c:PrimaryKey><o:Key Ref="k1"/></c:PrimaryKey>
      </o:Table>
      <o:Table Id="t2"><a:ObjectID>T2</a:ObjectID><a:Name>Order</a:Name><a:Code>ORDER_T</a:Code>
        <a:Comment>An order.</a:Comment>
        <c:Columns>
          <o:Column Id="c3"><a:ObjectID>C3</a:ObjectID><a:Name>Order Id</a:Name><a:Code>ORDER_ID</a:Code>
            <a:DataType>integer</a:DataType><a:Column.Mandatory>1</a:Column.Mandatory></o:Column>
          <o:Column Id="c4"><a:ObjectID>C4</a:ObjectID><a:Name>Customer Id</a:Name><a:Code>CUSTOMER_ID</a:Code>
            <a:DataType>integer</a:DataType><a:Column.Mandatory>1</a:Column.Mandatory></o:Column>
        </c:Columns>
        <c:Keys><o:Key Id="k2"><a:ObjectID>K2</a:ObjectID><a:Name>PK_ORDER</a:Name><a:Code>PK_ORDER</a:Code>
          <c:Key.Columns><o:Column Ref="c3"/></c:Key.Columns></o:Key></c:Keys>
        <c:PrimaryKey><o:Key Ref="k2"/></c:PrimaryKey>
      </o:Table>
    </c:Tables>
    <c:References>
      <o:Reference Id="r1"><a:ObjectID>R1</a:ObjectID><a:Name>places</a:Name><a:Code>FK_ORDER_CUSTOMER</a:Code>
        <c:ParentTable><o:Table Ref="t1"/></c:ParentTable>
        <c:ChildTable><o:Table Ref="t2"/></c:ChildTable>
        <c:Joins><o:ReferenceJoin Id="j1">
          <c:Object1><o:Column Ref="c1"/></c:Object1>
          <c:Object2><o:Column Ref="c4"/></c:Object2></o:ReferenceJoin></c:Joins>
      </o:Reference>
    </c:References>
    </o:Model></c:Children></o:RootObject></Model>
""")

ERWIN_PDM_XML = textwrap.dedent("""\
    <?xml version="1.0" encoding="UTF-8"?>
    <erwin xmlns="http://www.erwin.com/dm" xmlns:EMX="http://www.erwin.com/dm/data">
    <EMX:Model id="{M}+00000001" name="Orders" xmlns="http://www.erwin.com/dm/data">
    <ModelProps><Name>Orders</Name><Type>2</Type></ModelProps>
    <Entity id="{E1}+00000000" name="Customer"><EntityProps><Name>Customer</Name><Physical_Name>CUSTOMER</Physical_Name>
      <Definition>A customer.</Definition></EntityProps>
      <Attribute id="{A1}+00000000" name="Customer Id"><AttributeProps><Name>Customer Id</Name><Physical_Name>CUSTOMER_ID</Physical_Name>
        <Physical_Data_Type>INTEGER</Physical_Data_Type><Null_Option_Type>1</Null_Option_Type></AttributeProps></Attribute>
      <Attribute id="{A2}+00000000" name="Customer Name"><AttributeProps><Name>Customer Name</Name><Physical_Name>CUSTOMER_NAME</Physical_Name>
        <Physical_Data_Type>VARCHAR(100)</Physical_Data_Type><Null_Option_Type>0</Null_Option_Type></AttributeProps></Attribute>
      <Key_Group id="{K1}+00000000" name="PK_CUSTOMER"><Key_GroupProps><Name>PK_CUSTOMER</Name><Key_Group_Type>PK</Key_Group_Type></Key_GroupProps>
        <Key_Group_Member id="{KM1}+00000000"><Key_Group_MemberProps><Attribute_Ref>{A1}+00000000</Attribute_Ref></Key_Group_MemberProps></Key_Group_Member>
      </Key_Group>
    </Entity>
    <Entity id="{E2}+00000000" name="Order"><EntityProps><Name>Order</Name><Physical_Name>ORDER_T</Physical_Name>
      <Definition>An order.</Definition></EntityProps>
      <Attribute id="{A3}+00000000" name="Order Id"><AttributeProps><Name>Order Id</Name><Physical_Name>ORDER_ID</Physical_Name>
        <Physical_Data_Type>INTEGER</Physical_Data_Type><Null_Option_Type>1</Null_Option_Type></AttributeProps></Attribute>
      <Attribute id="{A4}+00000000" name="Customer Id"><AttributeProps><Name>Customer Id</Name><Physical_Name>CUSTOMER_ID</Physical_Name>
        <Physical_Data_Type>INTEGER</Physical_Data_Type><Null_Option_Type>1</Null_Option_Type>
        <Parent_Attribute_Ref>{A1}+00000000</Parent_Attribute_Ref></AttributeProps></Attribute>
      <Key_Group id="{K2}+00000000" name="PK_ORDER"><Key_GroupProps><Name>PK_ORDER</Name><Key_Group_Type>PK</Key_Group_Type></Key_GroupProps>
        <Key_Group_Member id="{KM2}+00000000"><Key_Group_MemberProps><Attribute_Ref>{A3}+00000000</Attribute_Ref></Key_Group_MemberProps></Key_Group_Member>
      </Key_Group>
    </Entity>
    <Relationship id="{R1}+00000000" name="places"><RelationshipProps><Name>places</Name><Physical_Name>FK_ORDER_CUSTOMER</Physical_Name>
      <Type>7</Type><Null_Option_Type>101</Null_Option_Type><Cardinality>-3</Cardinality>
      <Parent_Entity_Ref>{E1}+00000000</Parent_Entity_Ref><Child_Entity_Ref>{E2}+00000000</Child_Entity_Ref>
    </RelationshipProps></Relationship>
    </EMX:Model></erwin>
""")


class PdmEndToEndTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        self.pdm = root / "orders.pdm"
        self.pdm.write_text(PD_PDM, encoding="utf-8")
        self.xml = root / "1_initial" / "xml" / "orders.xml"
        self.xml.parent.mkdir(parents=True)
        self.xml.write_text(ERWIN_PDM_XML, encoding="utf-8")
        self.root = root

    def tearDown(self):
        self.tmp.cleanup()

    def test_parsers_and_comparator_see_the_model(self):
        pd_model = pdm_validator_bridge.parse_pdm(str(self.pdm))
        erwin_model = pdm_validator_bridge.parse_erwin(str(self.xml))
        result = pdm_validator_bridge.compare(pd_model, erwin_model)
        self.assertEqual(2, result.tables_pd)
        self.assertEqual(2, result.tables_matched)
        self.assertEqual([], result.reconciliation_errors())

    def test_flow_validates_and_reports(self):
        r = self.root
        outcome = pdm_flow.run_pdm_flow(
            pdm_path=str(self.pdm),
            initial_erwin=str(r / "1_initial" / "erwin" / "orders.erwin"),
            initial_xml=str(self.xml),
            preprocessed_erwin=str(r / "2_preprocessed" / "erwin" / "orders.erwin"),
            preprocessed_xml=str(r / "2_preprocessed" / "xml" / "orders.xml"),
            final_erwin=str(r / "3_final" / "erwin" / "orders.erwin"),
            final_xml=str(r / "3_final" / "xml" / "orders.xml"),
            target_fidelity=90.0,
            preprocess_enabled=True,
            manual_review_dir=str(r / "manual_review"),
        )
        self.assertIsNotNone(outcome.final_result)
        self.assertIsNotNone(outcome.initial_result)
        self.assertIn("V1", outcome.final_result.stage_scores)
        self.assertGreater(outcome.final_result.fidelity_score, 0.0)

        report = pdm_report_generator.generate_report([outcome.final_result], str(r / "reports"))
        self.assertTrue(Path(report).is_file())
        wb = load_workbook(report, read_only=True)
        for sheet in ("SUMMARY", "FINDINGS", "TABLE_MATRIX", "RELATIONSHIPS", "CONFIG"):
            self.assertIn(sheet, wb.sheetnames)
        wb.close()

    def test_initial_only_path(self):
        outcome = pdm_flow.validate_initial_only(
            pdm_path=str(self.pdm), initial_xml=str(self.xml),
            initial_erwin=str(self.root / "1_initial" / "erwin" / "orders.erwin"))
        self.assertIsNotNone(outcome.initial_result)
        self.assertIn("V1", outcome.initial_result.stage_scores)


if __name__ == "__main__":
    unittest.main()
