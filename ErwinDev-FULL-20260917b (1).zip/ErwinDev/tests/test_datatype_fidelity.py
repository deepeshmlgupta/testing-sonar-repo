"""
Datatype fidelity — the migration must never silently change a type.

Both engines (LDM/CDM ``normalizers.classify_type_match`` and the PDM
``data_type_mapper.classify_type_match``) are driven through the same table
of cases: identical declarations match, a changed base type (VARCHAR(500) ->
CHAR(500)) or a changed size (DECIMAL(18,2) -> DECIMAL(38,10)) is a mismatch,
and DATE is never confused with TIMESTAMP. The comparator-level test then
proves the mismatch reaches a finding with the PD and erwin values on it.
"""

import pytest

from app.validation.ldm_reconcile import normalizers as ldm_norm
from app.validation.pdm_reconcile.pdm_erwin_validator import data_type_mapper as pdm_types

DATATYPES = ["VARCHAR(500)", "VARCHAR(255)", "DECIMAL(18,2)", "DECIMAL(38,10)",
             "DATE", "TIMESTAMP", "CHAR(10)", "INTEGER", "BIGINT"]

SAME, TYPE_CHANGED, SIZE_CHANGED = "same", "type", "size"

# (PD declaration, erwin declaration, what happened)
CASES = [
    ("VARCHAR(500)", "VARCHAR(500)", SAME),
    ("VARCHAR(255)", "VARCHAR(255)", SAME),
    ("DECIMAL(18,2)", "DECIMAL(18,2)", SAME),
    ("DECIMAL(38,10)", "DECIMAL(38,10)", SAME),
    ("DATE", "DATE", SAME),
    ("TIMESTAMP", "TIMESTAMP", SAME),
    ("CHAR(10)", "CHAR(10)", SAME),
    ("INTEGER", "INTEGER", SAME),
    ("BIGINT", "BIGINT", SAME),
    # silent changes that MUST be reported
    ("VARCHAR(500)", "CHAR(500)", TYPE_CHANGED),
    ("VARCHAR(500)", "VARCHAR(255)", SIZE_CHANGED),
    ("VARCHAR(255)", "VARCHAR(500)", SIZE_CHANGED),
    ("DECIMAL(18,2)", "DECIMAL(38,10)", SIZE_CHANGED),
    ("DECIMAL(38,10)", "DECIMAL(18,2)", SIZE_CHANGED),
    ("DATE", "TIMESTAMP", TYPE_CHANGED),
    ("TIMESTAMP", "DATE", TYPE_CHANGED),
    ("CHAR(10)", "VARCHAR(10)", TYPE_CHANGED),
    ("INTEGER", "VARCHAR(10)", TYPE_CHANGED),
    ("INTEGER", "DATE", TYPE_CHANGED),
    ("BIGINT", "CHAR(20)", TYPE_CHANGED),
]


@pytest.mark.parametrize("pd_type,erwin_type,expected", CASES)
def test_ldm_engine_type_verdict(pd_type, erwin_type, expected):
    """
    The LDM/CDM engine splits the verdict in two: the type FAMILY (DATA_TYPE,
    critical) and the declared SIZE (LENGTH_PRECISION, warning). A size change
    therefore passes the family check and fails dimensions_match — both are
    findings in the report; neither is silent.
    """
    category, is_match = ldm_norm.classify_type_match(pd_type, erwin_type)
    dims_ok = ldm_norm.dimensions_match(pd_type, "", "", erwin_type, "", "")
    if expected == SAME:
        assert is_match and dims_ok, f"LDM: {pd_type} vs {erwin_type} -> {category}"
    elif expected == TYPE_CHANGED:
        assert not is_match and category == "TYPE_MISMATCH", f"LDM: {pd_type} vs {erwin_type} -> {category}"
    else:
        assert is_match and not dims_ok, f"LDM: {pd_type} vs {erwin_type} -> {category}, dims={dims_ok}"


@pytest.mark.parametrize("pd_type,erwin_type,expected", CASES)
def test_pdm_engine_type_verdict(pd_type, erwin_type, expected):
    """The PDM engine folds size into the verdict: any change is a non-match."""
    category, is_match = pdm_types.classify_type_match(pd_type, erwin_type)
    assert is_match is (expected == SAME), f"PDM: {pd_type} vs {erwin_type} -> {category}"


def test_ldm_size_kept_in_separate_fields_is_still_compared():
    """PowerDesigner often stores the size apart from the type string."""
    assert ldm_norm.dimensions_match("VARCHAR", "500", "", "VARCHAR", "255", "") is False
    assert ldm_norm.dimensions_match("DECIMAL", "18", "2", "DECIMAL", "38", "10") is False
    assert ldm_norm.dimensions_match("VARCHAR", "500", "", "VARCHAR(500)", "", "") is True
    _, ok = ldm_norm.classify_type_match("VARCHAR", "VARCHAR(500)", pd_len="500")
    assert ok is True


def test_pd_short_codes_resolve_to_the_same_family():
    """PD's VA500 / A10 / DC18,2 spellings must be read as VARCHAR / CHAR / DECIMAL, not as unknown types."""
    assert ldm_norm.canonical_type("VA500") == "VARCHAR"
    assert ldm_norm.canonical_type("A10") == "CHAR"
    assert ldm_norm.classify_type_match("VA500", "VARCHAR(500)")[1] is True
    assert ldm_norm.classify_type_match("VA500", "CHAR(500)")[1] is False
    assert ldm_norm.classify_type_match("A10", "CHAR(10)")[1] is True


def _ldm_pair(pd_type, erwin_type):
    from app.validation.ldm_reconcile.comparator import compare
    from app.validation.ldm_reconcile.ldm_model import Attribute, Entity, LDMModel

    def model(dtype):
        entity = Entity(name="Customer", code="CUSTOMER")
        entity.attributes.append(Attribute(name="Name", code="NAME", data_type=dtype))
        m = LDMModel(model_name="m")
        m.entities["CUSTOMER"] = entity
        return m

    return compare(model(pd_type), model(erwin_type))


@pytest.mark.parametrize("pd_type,erwin_type", [("VARCHAR(500)", "CHAR(500)"),
                                                ("DECIMAL(18,2)", "DECIMAL(38,10)"),
                                                ("DATE", "TIMESTAMP")])
def test_ldm_comparator_reports_the_change_with_both_values(pd_type, erwin_type):
    result = _ldm_pair(pd_type, erwin_type)
    findings = [f for f in result.findings if f.category in ("DATA_TYPE", "LENGTH_PRECISION")
                and f.severity in ("CRITICAL", "WARNING")]
    assert findings, f"{pd_type} -> {erwin_type} produced no failing datatype finding"
    finding = findings[0]
    assert finding.object_type == "ATTRIBUTE" and finding.member
    if finding.category == "DATA_TYPE":
        assert pd_type.split("(")[0] in str(finding.pd_value).upper()
        assert erwin_type.split("(")[0] in str(finding.erwin_value).upper()
    else:  # LENGTH_PRECISION carries the effective sizes
        assert "18" in str(finding.pd_value) and "38" in str(finding.erwin_value)
    baseline = _ldm_pair(pd_type, pd_type)
    assert result.fidelity_score < baseline.fidelity_score


def test_ldm_comparator_identical_types_are_verified_not_penalised():
    result = _ldm_pair("VARCHAR(500)", "VARCHAR(500)")
    assert not [f for f in result.findings if f.category in ("DATA_TYPE", "LENGTH_PRECISION")
                and f.severity != "VERIFIED"]
    assert [f for f in result.findings if f.category.startswith("TYPE_") and f.severity == "VERIFIED"]
