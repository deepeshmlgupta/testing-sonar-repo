"""
Windows file preparation for the erwin conversion path
(app/erwin/windows_files.py).

The reported failure: converting XML V2 to .ERWIN V1 on a Windows workstation
failed with a read-only error, and kept failing after the file was made
writable by hand. Four separate defects produced that:

  1. ``os.access(path, os.W_OK)`` decided whether to clear the attribute, and
     on Windows it does not consult NTFS ACLs, so the clear was often skipped.
  2. Only the SOURCE was prepared — never the TARGET, so a second conversion
     over an existing read-only .erwin failed at the delete.
  3. The output FOLDER was never checked.
  4. The failure was reported as "currently open or locked", which sent the
     operator looking for a process to close instead of an attribute to clear.

The attribute bits are Windows-only, so the behavioural tests run on POSIX
permissions and the Windows-specific paths are exercised with faked
``st_file_attributes``.
"""

import os
import stat
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.erwin import windows_files as wf


class _Stat:
    """Just enough of an os.stat_result to carry Windows attribute bits."""

    def __init__(self, attrs):
        self.st_file_attributes = attrs


class ReadOnlyDetectionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.file = self.root / "m.erwin"
        self.file.write_bytes(b"model")

    def tearDown(self):
        try:
            os.chmod(self.file, stat.S_IWRITE | stat.S_IREAD)
        except OSError:
            pass
        self.tmp.cleanup()

    def test_the_windows_attribute_bit_is_what_is_tested(self):
        # The defect: os.access says writable, the attribute says otherwise,
        # and erwin obeys the attribute.
        with patch.object(wf, "IS_WINDOWS", True), \
             patch.object(os, "stat", return_value=_Stat(wf.FILE_ATTRIBUTE_READONLY)):
            self.assertTrue(wf.is_read_only(self.file))
        with patch.object(wf, "IS_WINDOWS", True), \
             patch.object(os, "stat", return_value=_Stat(0)):
            self.assertFalse(wf.is_read_only(self.file))

    def test_a_missing_file_is_not_read_only(self):
        self.assertFalse(wf.is_read_only(self.root / "absent.erwin"))

    def test_clearing_makes_a_read_only_file_writable(self):
        os.chmod(self.file, stat.S_IREAD)
        if os.access(self.file, os.W_OK):
            self.skipTest("this filesystem ignores the read-only mode bit")
        self.assertTrue(wf.is_read_only(self.file))
        self.assertTrue(wf.clear_read_only(self.file))
        self.assertFalse(wf.is_read_only(self.file))

    def test_clearing_an_already_writable_file_is_a_no_op_that_succeeds(self):
        self.assertTrue(wf.clear_read_only(self.file))

    def test_clearing_never_raises_when_it_cannot(self):
        with patch.object(wf, "is_read_only", return_value=True), \
             patch.object(os, "chmod", side_effect=PermissionError("denied")):
            self.assertFalse(wf.clear_read_only(self.file))


class CloudAndMarkOfTheWebTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.file = self.root / "m.xml"
        self.file.write_text("<erwin/>")

    def tearDown(self):
        self.tmp.cleanup()

    def test_a_onedrive_placeholder_is_detected(self):
        for bit in (wf.FILE_ATTRIBUTE_OFFLINE,
                    wf.FILE_ATTRIBUTE_RECALL_ON_OPEN,
                    wf.FILE_ATTRIBUTE_RECALL_ON_DATA_ACCESS):
            with patch.object(wf, "IS_WINDOWS", True), \
                 patch.object(os, "stat", return_value=_Stat(bit)):
                self.assertTrue(wf.is_cloud_only(self.file), hex(bit))

    def test_a_local_file_is_not_a_placeholder(self):
        self.assertFalse(wf.is_cloud_only(self.file))

    def test_hydrating_reads_the_file_so_the_download_happens_here(self):
        # erwin times out on a placeholder without saying why; forcing the
        # download up front turns that into a reportable step.
        self.assertTrue(wf.hydrate(self.file))

    def test_hydrating_a_missing_file_is_false_not_an_exception(self):
        self.assertFalse(wf.hydrate(self.root / "absent.xml"))

    def test_mark_of_the_web_is_a_no_op_off_windows(self):
        with patch.object(wf, "IS_WINDOWS", False):
            self.assertFalse(wf.strip_mark_of_the_web(self.file))


class PrepareTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self):
        for p in self.root.rglob("*"):
            try:
                os.chmod(p, stat.S_IWRITE | stat.S_IREAD)
            except OSError:
                pass
        self.tmp.cleanup()

    def test_a_ready_source_reports_no_block(self):
        src = self.root / "m.xml"
        src.write_text("<erwin/>")
        state = wf.prepare(src)
        self.assertTrue(state.exists)
        self.assertFalse(state.blocked)

    def test_a_missing_source_is_reported_not_raised(self):
        state = wf.prepare(self.root / "absent.xml")
        self.assertFalse(state.exists)
        self.assertIn("does not exist", state.summary())

    def test_a_read_only_source_is_cleared(self):
        src = self.root / "m.xml"
        src.write_text("<erwin/>")
        os.chmod(src, stat.S_IREAD)
        if os.access(src, os.W_OK):
            self.skipTest("this filesystem ignores the read-only mode bit")
        state = wf.prepare(src)
        self.assertTrue(state.read_only)
        self.assertTrue(state.cleared)
        self.assertFalse(state.blocked)
        self.assertIn("read-only attribute cleared", state.summary())

    def test_a_read_only_TARGET_is_cleared_so_it_can_be_replaced(self):
        # THE reported bug: only the source was ever prepared, so converting a
        # second time over an existing read-only .erwin failed at the delete.
        dst = self.root / "out" / "m.erwin"
        dst.parent.mkdir()
        dst.write_bytes(b"old")
        os.chmod(dst, stat.S_IREAD)
        if os.access(dst, os.W_OK):
            self.skipTest("this filesystem ignores the read-only mode bit")
        state = wf.prepare_target(dst)
        self.assertTrue(state.cleared)
        self.assertFalse(state.blocked)
        dst.unlink()            # the delete the converter does must now succeed

    def test_a_read_only_TARGET_is_cleared_on_windows_attributes(self):
        """
        The same case as above, driven through the Windows attribute bit so it
        runs everywhere — including as root, where POSIX mode bits are ignored
        and the permission-based test skips. This is the exact reported
        failure, so it must not be a test that silently does not run.
        """
        dst = self.root / "out" / "m.erwin"
        dst.parent.mkdir()
        dst.write_bytes(b"old")
        attrs = {"value": wf.FILE_ATTRIBUTE_READONLY}
        real_stat = os.stat

        def fake_stat(path, *a, **k):
            if Path(path) == dst:
                return _Stat(attrs["value"])
            return real_stat(path, *a, **k)

        def fake_chmod(path, mode, *a, **k):
            if Path(path) == dst and mode & stat.S_IWRITE:
                attrs["value"] &= ~wf.FILE_ATTRIBUTE_READONLY
                return None
            return os.chmod(path, mode, *a, **k)

        with patch.object(wf, "IS_WINDOWS", True), \
             patch.object(os, "stat", side_effect=fake_stat), \
             patch.object(os, "chmod", side_effect=fake_chmod):
            state = wf.prepare_target(dst)

        self.assertTrue(state.read_only, "the attribute must be seen")
        self.assertTrue(state.cleared, "and cleared, or the delete fails")
        self.assertFalse(state.blocked)
        self.assertEqual(0, attrs["value"] & wf.FILE_ATTRIBUTE_READONLY)

    def test_a_target_whose_attribute_cannot_be_cleared_blocks_with_the_right_reason(self):
        dst = self.root / "out" / "m.erwin"
        dst.parent.mkdir()
        dst.write_bytes(b"old")
        with patch.object(wf, "is_read_only", return_value=True), \
             patch.object(os, "chmod", side_effect=PermissionError("denied")):
            state = wf.prepare_target(dst)
        self.assertTrue(state.blocked)
        self.assertIn("read-only", state.summary())
        self.assertNotIn("locked by another process", state.summary(),
                         "a read-only attribute must not be reported as a file lock")

    def test_the_target_folder_is_created_when_absent(self):
        dst = self.root / "brand" / "new" / "m.erwin"
        state = wf.prepare_target(dst)
        self.assertTrue(dst.parent.is_dir())
        self.assertFalse(state.blocked)

    def test_an_unwritable_target_folder_is_reported_before_erwin_starts(self):
        dst = self.root / "locked" / "m.erwin"
        dst.parent.mkdir()
        os.chmod(dst.parent, stat.S_IREAD | stat.S_IEXEC)
        try:
            if os.access(dst.parent, os.W_OK):
                self.skipTest("this filesystem ignores directory permissions")
            state = wf.prepare_target(dst)
            self.assertTrue(state.blocked)
            self.assertIn("not writable", " ".join(state.messages))
        finally:
            os.chmod(dst.parent, stat.S_IRWXU)

    def test_the_probe_file_never_survives(self):
        dst = self.root / "out" / "m.erwin"
        wf.prepare_target(dst)
        self.assertEqual([], [p.name for p in dst.parent.iterdir()
                              if p.name.startswith(".erwin_write_test")])

    def test_locked_is_distinguished_from_read_only(self):
        # These need opposite actions, so they must not share one message.
        target = self.root / "m.erwin"
        target.write_bytes(b"x")
        with patch("builtins.open", side_effect=PermissionError("in use")):
            self.assertTrue(wf.is_locked(target))
        self.assertFalse(wf.is_locked(target))

    def test_blocking_reason_names_the_first_real_problem(self):
        src = self.root / "absent.xml"
        dst = self.root / "out" / "m.erwin"
        reason = wf.blocking_reason(wf.prepare_conversion(src, dst))
        self.assertIsNotNone(reason)
        self.assertIn("does not exist", reason)

    def test_a_clean_conversion_has_no_blocking_reason(self):
        src = self.root / "m.xml"
        src.write_text("<erwin/>")
        dst = self.root / "out" / "m.erwin"
        self.assertIsNone(wf.blocking_reason(wf.prepare_conversion(src, dst)))


class ConverterIntegrationTests(unittest.TestCase):
    """The converter must not launch erwin when a file already blocks it."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def test_a_blocked_conversion_returns_the_blocked_code_without_running_erwin(self):
        from app.erwin import erwin_converter

        with patch.object(erwin_converter.subprocess, "run") as run:
            code = erwin_converter.run_convert(
                self.root / "absent.xml", self.root / "out" / "m.erwin", 60)
        run.assert_not_called()
        self.assertEqual(erwin_converter._EXIT_BLOCKED, code)

    def test_a_clean_conversion_does_launch_erwin(self):
        from app.erwin import erwin_converter

        src = self.root / "m.xml"

        src.write_text("<erwin/>")

        class Done:
            returncode, stdout, stderr = 0, "", ""

        with patch.object(erwin_converter.subprocess, "run", return_value=Done()) as run:
            code = erwin_converter.run_convert(src, self.root / "out" / "m.erwin", 60)
        run.assert_called_once()
        self.assertEqual(0, code)


if __name__ == "__main__":       # pragma: no cover
    unittest.main()
