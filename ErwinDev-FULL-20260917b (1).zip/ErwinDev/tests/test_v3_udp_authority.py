"""
Which artefact is allowed to decide the V3 UDP score.

Reported symptom (real_estate, Windows run with erwin COM):

    FIDELITY_PROGRESSION
        V2   98.66%   structural 97.37   documentation 100   udp  99.88
        V3   73.69%   structural 97.37   documentation 100   udp   0.00   (-24.97)

Nothing about the migration changed between V2 and V3, so a 25-point drop was
wrong. The cause: the validated erwin XML carried 105 UDP values, 0 of them
matching a SAP PD UDP and 0 UDP definitions — every one classified "extra in
erwin" — and a bare non-zero value count was accepted as proof that the XML
could speak about UDP migration. That discarded the engine's verified
read-back of the .erwin model.

These tests pin the corrected rule in the two places it still has to hold:
the predicate and the score. (A third place, the UDP_RECONCILIATION workbook
sheet that used to narrate this same verdict, no longer exists — removed
from both V2 and V3 reports.)
"""

import os
import sys
from types import SimpleNamespace

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.orchestration.udp_helpers import erwin_xml_carries_udps, udp_stage_override
from app.validation import fidelity_stages

# The measured real_estate numbers.
PD_VALUES = 1156
XML_EXTRA_VALUES = 105
ENGINE_RATE = 99.88


def _real_estate_result():
    """A V3 result shaped exactly like the reported one."""
    fidelity = SimpleNamespace(
        udp_values_erwin=XML_EXTRA_VALUES,     # present, but all "extra in erwin"
        udp_definitions_erwin=0,               # no UDP dictionary in the export
        udp_matched=0,                         # none correspond to a SAP PD UDP
        udp_values_pd=PD_VALUES,
    )
    return SimpleNamespace(
        udp_fidelity=fidelity,
        udp_total=PD_VALUES, udp_matched=0, udp_missing=PD_VALUES, udp_mismatch=0,
        structural_fidelity_score=97.37, documentation_fidelity_score=100.0,
        pd_model="real_estate",
    )


# ── 1. the predicate ─────────────────────────────────────────────────────────

def test_unrelated_export_values_are_not_evidence_about_migration():
    assert not erwin_xml_carries_udps(_real_estate_result()), (
        "105 values that match no SAP PD UDP must not overrule a verified read-back")


def test_a_single_matched_value_does_make_the_export_authoritative():
    result = _real_estate_result()
    result.udp_fidelity.udp_matched = 1
    assert erwin_xml_carries_udps(result)


def test_a_udp_dictionary_makes_the_export_authoritative():
    result = _real_estate_result()
    result.udp_fidelity.udp_definitions_erwin = 11
    assert erwin_xml_carries_udps(result)


# ── 2. the score ─────────────────────────────────────────────────────────────

def test_v3_takes_the_engine_read_back_for_the_udp_component():
    outcome = SimpleNamespace(pass_rate=ENGINE_RATE)
    assert udp_stage_override(_real_estate_result(), outcome,
                              "real_estate", "LDM") == ENGINE_RATE


def test_v2_and_v3_cannot_disagree_for_the_same_migration():
    outcome = SimpleNamespace(pass_rate=ENGINE_RATE)
    v2 = SimpleNamespace(udp_fidelity=SimpleNamespace(
        udp_values_erwin=0, udp_definitions_erwin=0, udp_matched=0))
    v3 = _real_estate_result()
    assert (udp_stage_override(v2, outcome, "real_estate", "LDM")
            == udp_stage_override(v3, outcome, "real_estate", "LDM")
            == ENGINE_RATE)


def test_the_stage_score_records_where_the_udp_number_came_from():
    score = fidelity_stages.apply(_real_estate_result(), fidelity_stages.STAGE_V3,
                                  udp_override=ENGINE_RATE, model_type="LDM")
    assert score.components.get(fidelity_stages.COMPONENT_UDP) == ENGINE_RATE
    assert any("read-back" in note for note in score.notes), (
        "the V3 row must say the UDP number came from the engine, not be blank")


def test_the_v3_overall_no_longer_collapses_below_v2():
    """0.50*97.37 + 0.25*100 + 0.25*99.88 ≈ 98.66, not 73.69."""
    score = fidelity_stages.apply(_real_estate_result(), fidelity_stages.STAGE_V3,
                                  udp_override=ENGINE_RATE, model_type="LDM")
    assert score.overall > 95.0, f"V3 overall came out at {score.overall}"
