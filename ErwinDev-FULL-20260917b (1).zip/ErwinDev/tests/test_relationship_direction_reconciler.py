import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.validation.ldm_reconcile.ldm_model import Relationship, RelationshipEnd
from app.validation.relationship_direction_reconciler import reconcile_unmatched
from app.validation.relationship_orientation_analyzer import (
    cardinality_equivalent_when_reversed,
    entity_pair,
    is_reversed,
)


def _rel(name, e1, e2, c1="0,n", c2="1,1"):
    return Relationship(
        name=name,
        end1=RelationshipEnd(entity=e1, cardinality=c1),
        end2=RelationshipEnd(entity=e2, cardinality=c2),
    )


class OrientationAnalyzerTests(unittest.TestCase):
    def test_entity_pair_is_order_independent(self):
        a = _rel("R1", "CUSTOMER", "ORDER")
        b = _rel("R1", "ORDER", "CUSTOMER")
        self.assertEqual(entity_pair(a), entity_pair(b))

    def test_reversed_relationship_detected(self):
        a = _rel("Places", "CUSTOMER", "ORDER")
        b = _rel("Places", "ORDER", "CUSTOMER")
        self.assertTrue(is_reversed(a, b))

    def test_identical_order_is_not_reversed(self):
        a = _rel("Places", "CUSTOMER", "ORDER")
        b = _rel("Places", "CUSTOMER", "ORDER")
        self.assertFalse(is_reversed(a, b))

    def test_cardinality_equivalent_when_ends_crossed(self):
        a = _rel("Places", "CUSTOMER", "ORDER", c1="0,n", c2="1,1")
        b = _rel("Places", "ORDER", "CUSTOMER", c1="1,1", c2="0,n")
        self.assertTrue(cardinality_equivalent_when_reversed(a, b))

    def test_cardinality_not_equivalent_when_changed(self):
        a = _rel("Places", "CUSTOMER", "ORDER", c1="0,n", c2="1,1")
        b = _rel("Places", "ORDER", "CUSTOMER", c1="0,n", c2="1,1")
        self.assertFalse(cardinality_equivalent_when_reversed(a, b))


class DirectionReconcilerTests(unittest.TestCase):
    def test_reversed_pair_is_reconciled_not_missing_or_extra(self):
        pd_only = [_rel("Places", "CUSTOMER", "ORDER", "0,n", "1,1")]
        erwin_only = [_rel("Places", "ORDER", "CUSTOMER", "1,1", "0,n")]
        outcome = reconcile_unmatched(pd_only, erwin_only)
        self.assertEqual(1, len(outcome.reconciled))
        self.assertEqual([], outcome.still_missing)
        self.assertEqual([], outcome.still_extra)
        self.assertTrue(outcome.reconciled[0].semantic_direction_match)

    def test_genuinely_unrelated_relationships_stay_unmatched(self):
        pd_only = [_rel("Places", "CUSTOMER", "ORDER")]
        erwin_only = [_rel("Ships", "WAREHOUSE", "PRODUCT")]
        outcome = reconcile_unmatched(pd_only, erwin_only)
        self.assertEqual(0, len(outcome.reconciled))
        self.assertEqual(1, len(outcome.still_missing))
        self.assertEqual(1, len(outcome.still_extra))

    def test_each_erwin_relationship_consumed_at_most_once(self):
        pd_only = [_rel("Places", "CUSTOMER", "ORDER"),
                   _rel("Places2", "CUSTOMER", "ORDER")]
        erwin_only = [_rel("Places", "ORDER", "CUSTOMER")]
        outcome = reconcile_unmatched(pd_only, erwin_only)
        self.assertEqual(1, len(outcome.reconciled))
        self.assertEqual(1, len(outcome.still_missing))


if __name__ == "__main__":
    unittest.main()
