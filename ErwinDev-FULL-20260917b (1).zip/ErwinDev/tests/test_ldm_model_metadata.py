import os
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.validation.ldm_reconcile.comparator import (
    ValidationResult,
    _compare_model_metadata,
    compare,
)
from app.validation.ldm_reconcile.ldm_model import Entity, LDMModel


class ModelMetadataTests(unittest.TestCase):
    def _models(self):
        return (
            LDMModel(model_name="Sales Model", model_code="SALES", model_type="Logical"),
            LDMModel(model_name="Sales_Model", model_code="sales", model_type="LOGICAL"),
        )

    def test_matching_metadata_emits_score_neutral_verified_evidence(self):
        pd_model, erwin_model = self._models()
        result = ValidationResult(pd_file="source.ldm", erwin_file="target.xml")

        _compare_model_metadata(result, pd_model, erwin_model)

        findings = [finding for finding in result.findings
                    if finding.category == "MODEL_METADATA"]
        self.assertEqual(3, len(findings))
        self.assertEqual({"Name", "Code", "Type"},
                         {finding.member for finding in findings})
        self.assertTrue(all(finding.severity == "VERIFIED" for finding in findings))
        self.assertEqual(0, result.info_count)
        self.assertEqual(0, result.warning_count)
        self.assertEqual(0, result.critical_count)

    def test_different_model_code_emits_metadata_finding(self):
        pd_model, erwin_model = self._models()
        erwin_model.model_code = "ORDERS"
        result = ValidationResult(pd_file="source.ldm", erwin_file="target.xml")

        _compare_model_metadata(result, pd_model, erwin_model)

        findings = [finding for finding in result.findings
                    if finding.category == "MODEL_METADATA"
                    and finding.member == "Code"]
        self.assertEqual(1, len(findings))
        self.assertEqual("INFO", findings[0].severity)
        self.assertEqual("SALES", findings[0].pd_value)
        self.assertEqual("ORDERS", findings[0].erwin_value)

    def test_model_code_does_not_use_plural_name_normalization(self):
        pd_model, erwin_model = self._models()
        pd_model.model_code = "SALES"
        erwin_model.model_code = "SALE"
        result = ValidationResult(pd_file="source.ldm", erwin_file="target.xml")

        _compare_model_metadata(result, pd_model, erwin_model)

        findings = [finding for finding in result.findings
                    if finding.category == "MODEL_METADATA"
                    and finding.member == "Code"]
        self.assertEqual(1, len(findings))
        self.assertEqual("INFO", findings[0].severity)

    def test_unavailable_metadata_is_not_invented(self):
        pd_model, erwin_model = self._models()
        erwin_model.model_code = ""
        result = ValidationResult(pd_file="source.ldm", erwin_file="target.xml")

        _compare_model_metadata(result, pd_model, erwin_model)

        self.assertFalse(any(finding.member == "Code" for finding in result.findings))

    def test_parse_warnings_remain_separate_from_metadata(self):
        result = ValidationResult(pd_file="source.ldm", erwin_file="target.xml")
        result.emit("PARSE_WARNING", object_type="MODEL", message="Fallback used")

        self.assertEqual(1, len(result.findings))
        self.assertEqual("PARSE_WARNING", result.findings[0].category)
        self.assertEqual("WARNING", result.findings[0].severity)

    @patch("app.validation.ldm_reconcile.comparator.udp_fidelity.apply")
    @patch(
        "app.validation.ldm_reconcile.comparator.config.CHECK_MODEL_METADATA",
        False,
    )
    def test_disabled_metadata_check_suppresses_metadata_findings(
        self, _apply_udp
    ):
        pd_model, erwin_model = self._models()
        pd_model.add_entity(Entity(oid="pd-1", name="Customer", code="CUSTOMER"))
        erwin_model.add_entity(Entity(oid="erwin-1", name="Customer", code="CUSTOMER"))

        result = compare(pd_model, erwin_model)

        self.assertFalse(
            any(finding.category == "MODEL_METADATA"
                for finding in result.findings)
        )


if __name__ == "__main__":
    unittest.main()
