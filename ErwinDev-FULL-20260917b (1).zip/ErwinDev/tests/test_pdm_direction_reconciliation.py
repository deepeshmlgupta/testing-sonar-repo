import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.validation.pdm_reconcile.pdm_erwin_validator.comparator import (
    ValidationResult,
    _compare_foreign_keys,
    _reconcile_reversed_foreign_keys,
)


def _fk(name, parent, child, parent_col="ID", child_col="PARENT_ID"):
    return {
        "name": name, "code": name,
        "parent_table": parent, "child_table": child,
        "join_columns": [{"parent_col": parent_col, "child_col": child_col}],
    }


class PdmDirectionReconciliationTests(unittest.TestCase):
    def test_reversed_fk_is_reconciled(self):
        result = ValidationResult(pd_file="a.pdm", erwin_file="a.xml")
        pd_refs = [_fk("FK1", "PARENT", "CHILD", "ID", "PARENT_ID")]
        erwin_refs = [_fk("FK1", "CHILD", "PARENT", "PARENT_ID", "ID")]
        remaining_pd, remaining_erwin, count = _reconcile_reversed_foreign_keys(
            result, pd_refs, erwin_refs)
        self.assertEqual(1, count)
        self.assertEqual([], remaining_pd)
        self.assertEqual([], remaining_erwin)
        self.assertTrue(any(f.severity == "INFO" and "reversed" in f.message
                            for f in result.findings))

    def test_unrelated_fks_are_not_reconciled(self):
        result = ValidationResult(pd_file="a.pdm", erwin_file="a.xml")
        pd_refs = [_fk("FK1", "PARENT", "CHILD")]
        erwin_refs = [_fk("FK2", "OTHER_PARENT", "OTHER_CHILD")]
        remaining_pd, remaining_erwin, count = _reconcile_reversed_foreign_keys(
            result, pd_refs, erwin_refs)
        self.assertEqual(0, count)
        self.assertEqual(1, len(remaining_pd))
        self.assertEqual(1, len(remaining_erwin))

    def test_compare_foreign_keys_counts_reconciled_as_matched(self):
        result = ValidationResult(pd_file="a.pdm", erwin_file="a.xml")
        pd_refs = [_fk("FK1", "PARENT", "CHILD", "ID", "PARENT_ID")]
        erwin_refs = [_fk("FK1", "CHILD", "PARENT", "PARENT_ID", "ID")]
        import app.validation.pdm_reconcile.pdm_erwin_validator.comparator as comparator_module
        original = getattr(comparator_module.config, "ENABLE_DIRECTION_RECONCILIATION", False)
        comparator_module.config.ENABLE_DIRECTION_RECONCILIATION = True
        try:
            _compare_foreign_keys(result, pd_refs, erwin_refs)
        finally:
            comparator_module.config.ENABLE_DIRECTION_RECONCILIATION = original
        self.assertEqual(1, result.fk_pd)
        self.assertEqual(1, result.fk_erwin)
        self.assertEqual(1, result.fk_matched)
        self.assertEqual(0, result.fk_missing_in_erwin)
        self.assertEqual(0, result.fk_extra_in_erwin)


if __name__ == "__main__":
    unittest.main()
