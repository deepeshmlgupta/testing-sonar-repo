"""
Production readiness
====================

Locks the behaviours a production sign-off depends on. Each test names the
failure mode it prevents, because the value of these is entirely in what they
stop from coming back.

The governing rule, from which all of them follow:

    A missing or unverified artefact must produce WAITING, FAILED or
    EXTERNAL_VERIFICATION_REQUIRED — never a fabricated score and never a
    successful validation.
"""

from pathlib import Path
from types import SimpleNamespace

import pytest

from app.validation import code_evidence, code_ledger, extended_properties, fidelity_stages

REPO = Path(__file__).resolve().parents[1]

REAL_LDM = REPO / "sappdmodels/ldm/4d95b17a5883fbeb69fb9088bf1767c1_46007266_real_estate.ldm"
REAL_XML = REPO / "erwinmodels/2_preprocessed/4d95b17a5883fbeb69fb9088bf1767c1_46007266_real_estate.xml"
requires_real = pytest.mark.skipif(
    not (REAL_LDM.is_file() and REAL_XML.is_file()),
    reason="the real LDM sample pair is not present in this checkout")


def _attr(name, code, oid="", order=0, data_type="", length="", is_migrated=False):
    return SimpleNamespace(name=name, code=code, oid=oid, order=order,
                           data_type=data_type, length=length, is_migrated=is_migrated)


def _entity(name, oid, attributes, code=""):
    return SimpleNamespace(name=name, oid=oid, code=code or name, attributes=attributes)


def _model(entities):
    return SimpleNamespace(model_name="M", entities=entities)


# ═════════════════════════════════════════════════════════════════════════════
#  1. Attribute code preservation — deterministic, never by name alone
# ═════════════════════════════════════════════════════════════════════════════

def test_attributes_are_identified_by_object_id_not_by_name():
    """
    Two entities can each have an attribute called ID. Keying on the name
    alone is how one entity's code gets recorded against another's.
    """
    a = _attr("ID", "CUST_ID", oid="o1", order=1, data_type="VA10")
    b = _attr("ID", "ORDER_ID", oid="o2", order=1, data_type="VA10")
    ledger = code_ledger.build(_model([_entity("CUSTOMER", "e1", [a]),
                                       _entity("ORDER", "e2", [b])]))

    assert ledger.lookup("e1", "o1").pd_attr_code == "CUST_ID"
    assert ledger.lookup("e2", "o2").pd_attr_code == "ORDER_ID"
    assert ledger.lookup("e1", "o2") is None, "an attribute resolved into the wrong entity"
    assert not hasattr(ledger, "lookup_by_name"), "there must be no name-only lookup"


def test_an_attribute_that_cannot_be_told_apart_is_never_preserved():
    """
    Same name, same type, same position inside ONE entity: nothing
    distinguishes them, so neither code is encoded. A wrong code attached to a
    real attribute is worse than a missing one.
    """
    twins = [_attr("ID", "A_ID", oid="o1", order=1, data_type="VA10"),
             _attr("ID", "B_ID", oid="o2", order=1, data_type="VA10")]
    ledger = code_ledger.build(_model([_entity("E", "e1", twins)]))

    assert all(r.status == code_ledger.STATUS_AMBIGUOUS for r in ledger.records)
    assert ledger.preserved() == []
    schema, manifest = code_ledger.udp_rows(ledger)
    assert manifest == [], "an unidentifiable attribute must not reach the UDP payload"


def test_order_alone_is_enough_but_name_alone_is_not():
    same_name = [_attr("ID", "A_ID", oid="o1", order=1, data_type="VA10"),
                 _attr("ID", "B_ID", oid="o2", order=2, data_type="VA10")]
    ledger = code_ledger.build(_model([_entity("E", "e1", same_name)]))
    assert {r.status for r in ledger.records} == {code_ledger.STATUS_PRESERVED}
    assert all("order" in r.identity_basis for r in ledger.records)

    # Unique names but COLLIDING declaration order and no type to separate
    # them: the only distinguishing signal left is the name, and a name-only
    # match is refused by policy, so neither code is encoded.
    name_only = [_attr("Alpha", "A", oid="o1", order=1),
                 _attr("Beta", "B", oid="o2", order=1)]
    ledger = code_ledger.build(_model([_entity("E", "e1", name_only)]))
    for record in ledger.records:
        assert record.identity_basis == "name"
        assert record.status == code_ledger.STATUS_AMBIGUOUS
        assert "name-only match is not accepted" in record.note


def test_an_entity_without_an_object_id_is_skipped_not_guessed():
    ledger = code_ledger.build(_model([
        _entity("E", "", [_attr("Amount", "AMT", oid="o1", order=1)])]))
    assert ledger.entities == 0
    assert ledger.records == []


def test_the_encoded_payload_round_trips_and_is_byte_stable():
    attributes = [_attr("Organisation_Code", "ORGNSTN_CD", oid="o1", order=2, data_type="VA12"),
                  _attr("Organisation_Name", "ORGNSTN_NM", oid="o2", order=1, data_type="VA64")]
    ledger = code_ledger.build(_model([_entity("Organisation", "e1", attributes)]))
    payload = code_ledger.encode(ledger.preserved())

    decoded = code_ledger.decode(payload)
    assert [item["name"] for item in decoded] == ["Organisation_Name", "Organisation_Code"], \
        "entries must be ordered by declaration order, so the payload is stable"
    assert decoded[0]["code"] == "ORGNSTN_NM" and decoded[0]["order"] == 1
    assert code_ledger.encode(ledger.preserved()) == payload


def test_a_malformed_payload_entry_is_skipped_not_guessed():
    decoded = code_ledger.decode("Good=GD~1~VA10|garbage-with-no-separator|Also=AL~2~X")
    assert [item["name"] for item in decoded] == ["Good", "Also"]


def test_a_value_that_cannot_be_encoded_is_reported_not_mangled():
    """A name containing a separator would corrupt every entry after it."""
    ledger = code_ledger.build(_model([
        _entity("E", "e1", [_attr("Has|Pipe", "CODE", oid="o1", order=1)])]))
    assert ledger.records[0].status == code_ledger.STATUS_AMBIGUOUS
    assert "encode" in ledger.records[0].note


def test_the_ledger_refuses_another_models_record(tmp_path):
    ledger = code_ledger.CodeLedger(model_name="model_a", pd_sha256="abc")
    assert code_ledger.verify(ledger, "model_b")[1] == code_ledger.REJECT_MODEL
    assert code_ledger.verify(None, "model_a")[1] == code_ledger.REJECT_ABSENT

    stale = code_ledger.CodeLedger(model_name="m", schema_version=99)
    assert code_ledger.verify(stale, "m")[1] == code_ledger.REJECT_SCHEMA

    source = tmp_path / "m.ldm"
    source.write_text("<Model/>", encoding="utf-8")
    recorded = code_ledger.CodeLedger(model_name="m", pd_sha256=code_ledger.sha256_of(source))
    assert code_ledger.verify(recorded, "m", str(source))[1] == ""
    source.write_text("<Model changed='yes'/>", encoding="utf-8")
    assert code_ledger.verify(recorded, "m", str(source))[1] == code_ledger.REJECT_SOURCE_CHANGED


def test_reading_a_ledger_does_not_create_directories(tmp_path):
    assert code_ledger.load({"summary": str(tmp_path)}, "nobody") is None
    assert not any(tmp_path.iterdir())


def test_the_comparator_and_the_ledger_agree_on_every_status():
    """
    The report must not claim a preservation the transport did not make, so
    the message the comparator writes comes from the ledger's own rules.
    """
    cases = [
        (_attr("Amount", "AMT", oid="o1", order=1), "e1", "carried into erwin as"),
        (_attr("Amount", "Amount", oid="o1", order=1), "e1", "nothing to carry"),
        (_attr("Amount", "AMT", oid="o1", order=1), "", "NOT carried"),
        (_attr("Amount", "AMT", oid="", order=1), "e1", "NOT carried"),
    ]
    for attribute, entity_oid, expected in cases:
        entity = _entity("E", entity_oid, [attribute])
        message, remediation = code_evidence.code_not_carried(entity, attribute)
        assert expected in (message + remediation), (attribute, entity_oid, message)


def test_preserved_is_still_external_verification_required():
    """Encoded for transport is not the same fact as delivered to erwin."""
    attribute = _attr("Amount", "AMT", oid="o1", order=1)
    message, remediation = code_evidence.code_not_carried(_entity("E", "e1", [attribute]),
                                                          attribute)
    assert code_ledger.UDP_ATTRIBUTE_CODES in message
    assert code_ledger.STATUS_EXTERNAL in remediation
    assert "not proven to have arrived" in remediation


@requires_real
def test_the_ledger_covers_the_real_model_deterministically():
    from app.validation.ldm_reconcile.pd_ldm_parser import parse_ldm

    ledger = code_ledger.build(parse_ldm(str(REAL_LDM)), model_name="real_estate",
                               model_type="LDM", pd_path=str(REAL_LDM))
    assert ledger.entities == 105
    assert ledger.attributes == 42
    assert len(ledger.preserved()) == 41
    assert ledger.by_status(code_ledger.STATUS_AMBIGUOUS) == []

    schema, manifest = code_ledger.udp_rows(ledger)
    assert len(schema) == 1 and schema[0]["udp"] == code_ledger.UDP_ATTRIBUTE_CODES
    assert manifest, "the attribute codes never reached the injection manifest"
    for entry in manifest:
        assert entry["entity_name"] and entry["value"]
        assert code_ledger.decode(entry["value"])


# ═════════════════════════════════════════════════════════════════════════════
#  2. A check that did not run is never reported as a check that passed
# ═════════════════════════════════════════════════════════════════════════════

def test_carries_records_what_it_was_asked_for():
    class _Doc:
        tags = {"Entity", "Attribute"}
        asked = set()
        missing = set()
        carries = extended_properties.ErDoc.carries

    doc = _Doc()
    assert doc.carries("Entity") is True
    assert doc.carries("Owner") is False
    assert "Owner" in doc.missing and "Entity" not in doc.missing


def test_an_unverified_tag_that_is_absent_is_reported_not_skipped():
    class _Doc:
        missing = {"Owner", "Tablespace_Ref", "Stored_Display"}

    findings = extended_properties.unverified_tag_findings(_Doc())
    assert findings, "a silently non-firing check produced no report at all"
    assert all(f.severity == extended_properties.SEVERITY_EXTERNAL_VERIFICATION
               for f in findings)
    assert all(f.category == "ERWIN_TAG_UNVERIFIED" for f in findings)
    text = " ".join(f.message + f.remediation for f in findings)
    assert "indistinguishable" in text
    assert "not performed rather than as passed" in text


def test_a_tag_that_is_present_is_not_reported():
    class _Doc:
        missing = set()

    assert extended_properties.unverified_tag_findings(_Doc()) == []


def test_a_missing_tag_that_is_already_verified_is_not_reported():
    """Only UNVERIFIED spellings are ambiguous; a confirmed one that is absent
    genuinely means the export has no such property."""
    class _Doc:
        missing = {"Entity", "Attribute"}          # neither is in UNVERIFIED_ERWIN_TAGS

    assert extended_properties.unverified_tag_findings(_Doc()) == []


def test_external_verification_required_never_scores():
    """It records that the framework did not look — not that something is wrong."""
    from app.reporting import score_audit

    assert (extended_properties.SEVERITY_EXTERNAL_VERIFICATION
            not in score_audit.SCORING_SEVERITIES)


@requires_real
def test_the_real_model_reports_its_unlooked_at_checks():
    from app.orchestration.udp_helpers import reconcile

    result = reconcile(str(REAL_LDM), str(REAL_XML), "LDM")
    unverified = [f for f in result.findings if f.category == "ERWIN_TAG_UNVERIFIED"]
    assert unverified, "the report claims a clean sheet for checks that never ran"
    assert result.critical_count == 0 and result.warning_count == 0 and result.info_count == 0, \
        "an EXTERNAL_VERIFICATION_REQUIRED row must not move the score"


# ═════════════════════════════════════════════════════════════════════════════
#  3. V3 is safe by default
# ═════════════════════════════════════════════════════════════════════════════

def test_the_final_xml_fallback_is_off_by_default():
    """
    It used to default to "true" while every call site read it as False. A V3
    number that was never measured against the final erwin model, presented as
    final validation, is the worst output this framework can produce.
    """
    import app.config.settings as settings

    assert settings.FINAL_XML_FALLBACK_TO_PREPROCESSED is False


def test_a_fallback_v3_is_never_promoted():
    """
    Promoting a fallback would also make the NEXT run discover the promoted
    copy as an XML V3 and measure V3 against the framework's own output.
    """
    source = (REPO / "app/run_v3.py").read_text(encoding="utf-8")
    body = source.split('if get_setting("FINAL_XML_FALLBACK_TO_PREPROCESSED", False):', 1)[1]
    fallback = body.split("return record", 1)[0]
    assert "route_model(" not in fallback, "the fallback branch promotes the model"
    assert "DEST_MANUAL_REVIEW" in fallback


def test_a_fallback_v3_is_labelled_in_the_report():
    from app.reporting import v3_report

    request = v3_report.V3ReportRequest(
        result=None, tier_report_path="", outdir="",
        artefacts={"xml_v3_how": "fallback (commented XML)"})
    caption = v3_report._v3_source_caption(request)
    assert caption.startswith("FALLBACK")
    assert "NOT evidence about the final erwin model" in caption


# ═════════════════════════════════════════════════════════════════════════════
#  4. NOT MEASURED is never 0%
# ═════════════════════════════════════════════════════════════════════════════

class _Result:
    def __init__(self, udp_total=219, udp_fidelity_score=0.0, matched=0, definitions=0):
        self.udp_total = udp_total
        self.udp_fidelity_score = udp_fidelity_score
        self.udp_fidelity = SimpleNamespace(udp_matched=matched,
                                            udp_definitions_erwin=definitions,
                                            udp_values_erwin=0)
        self.structural_fidelity_score = 100.0
        self.documentation_rows = []
        self.findings = []
        self.pd_file = self.erwin_file = ""


def test_a_post_injection_stage_measuring_a_udp_less_xml_reports_not_measured():
    for stage in (fidelity_stages.STAGE_V2, fidelity_stages.STAGE_V3):
        assert fidelity_stages.udp_fidelity_component(_Result(), None, stage) is None


def test_v1_keeps_its_baseline_measurement():
    """
    V1 measures the raw export BEFORE injection. Its low UDP number is the
    point of the stage — the honest size of the initial gap — so it must not
    be suppressed, which would raise V1 for no reason.
    """
    assert fidelity_stages.udp_fidelity_component(
        _Result(), None, fidelity_stages.STAGE_V1) == 0.0


def test_an_xml_that_does_carry_udps_is_still_measured():
    """The rule must never hide a genuine loss measured against real evidence."""
    result = _Result(udp_fidelity_score=12.5, matched=3)
    assert fidelity_stages.udp_fidelity_component(
        result, None, fidelity_stages.STAGE_V3) == 12.5


def test_an_override_always_wins():
    for stage in fidelity_stages.STAGES:
        assert fidelity_stages.udp_fidelity_component(_Result(), 97.5, stage) == 97.5


def test_a_dropped_component_renormalises_rather_than_scoring_zero():
    from app.common.config_helpers import tier_config

    result = _Result()
    result.documentation_rows = []
    stage = fidelity_stages.score(result, fidelity_stages.STAGE_V2, None, "LDM",
                                  tier_config("LDM"))
    assert stage.components["udp"] is None
    assert stage.overall == 100.0, "structural 100 with udp dropped must renormalise to 100"
    assert any("renormalised" in note for note in stage.notes)


def test_the_two_udp_predicates_are_one_implementation():
    """Two copies would be free to disagree about the same file."""
    from app.orchestration import udp_helpers

    for matched, definitions, expected in ((0, 0, False), (1, 0, True), (0, 1, True)):
        result = _Result(matched=matched, definitions=definitions)
        assert fidelity_stages.erwin_side_carries_udps(result) is expected
        assert udp_helpers.erwin_xml_carries_udps(result) is expected


# ═════════════════════════════════════════════════════════════════════════════
#  5. An unverified model is never promoted
# ═════════════════════════════════════════════════════════════════════════════

def test_a_dropped_component_blocks_promotion():
    """
    THE production hazard. A dropped component renormalises the weights, so a
    model whose .erwin was never handed off scored structural 100 +
    documentation 100 = 100.00, passed the gate on the number alone, and was
    copied into erwinmodels/3_final — output identical to a model that
    genuinely migrated everything, while its own stage state said
    UDP = WAITING_FOR_MANUAL_INPUT.
    """
    from app.common.config_helpers import tier_config
    from app.validation import promotion_gate

    result = _Result()
    stage = fidelity_stages.apply(result, fidelity_stages.STAGE_V3, None, "LDM",
                                  tier_config("LDM"))
    assert stage.unverified == ["udp"]
    assert stage.overall == 100.0, "the renormalised score is still 100 — that is the trap"

    failures = promotion_gate.gate_failures(result, fidelity_threshold=90.0)
    assert failures, "a 100.00 score with an unmeasured component still passed the gate"
    assert any("EXTERNAL_VERIFICATION_REQUIRED" in f for f in failures)


def test_a_model_with_no_udps_at_all_is_not_blocked():
    """Not applicable is not the same as unverified; a model without extended
    attributes must not be held back for metadata it never had."""
    from app.common.config_helpers import tier_config
    from app.validation import promotion_gate

    result = _Result(udp_total=0)
    stage = fidelity_stages.apply(result, fidelity_stages.STAGE_V3, None, "LDM",
                                  tier_config("LDM"))
    assert stage.unverified == []
    assert promotion_gate.gate_failures(result, fidelity_threshold=90.0) == []


def test_a_measured_model_is_not_blocked():
    from app.common.config_helpers import tier_config
    from app.validation import promotion_gate

    result = _Result(matched=5, udp_fidelity_score=99.0)
    fidelity_stages.apply(result, fidelity_stages.STAGE_V3, None, "LDM", tier_config("LDM"))
    assert promotion_gate.gate_failures(result, fidelity_threshold=90.0) == []


def test_the_pdm_gate_applies_the_same_rule():
    from app.validation.pdm_reconcile import pdm_flow

    source = (REPO / "app/validation/pdm_reconcile/pdm_flow.py").read_text(encoding="utf-8")
    body = source.split("def _gate_failures", 1)[1].split("\ndef ", 1)[0]
    assert "unverified_failures" in body, "PDM promotes on the number alone"
    assert hasattr(pdm_flow, "_gate_failures")


# ═════════════════════════════════════════════════════════════════════════════
#  6. Step 1 never fabricates XML V2
# ═════════════════════════════════════════════════════════════════════════════

def test_a_failed_comment_injection_does_not_copy_xml_v1_over_xml_v2():
    """
    The old fallback copied XML V1 to XML V2 and the caller recorded READY, so
    an uninjected export was scored as "comments migrated" — and copy2 preserves
    mtime, so the freshness guard kept the fabricated file forever.
    """
    source = (REPO / "app/preprocessing/orchestrator.py").read_text(encoding="utf-8")
    body = source.split("Phase B: Injecting Comments", 1)[1].split("\ndef ", 1)[0]
    assert "shutil.copy2(initial_xml_file, preprocessed_xml_file)" not in body
    assert "PreprocessingFailed" in body

    from app.preprocessing.orchestrator import PreprocessingFailed
    assert issubclass(PreprocessingFailed, RuntimeError)


def test_xml_v2_freshness_is_judged_against_the_sap_source_too():
    """Editing the .ldm must invalidate a cached XML V2; judging it against
    XML V1 alone meant it did not."""
    source = (REPO / "app/workflows/conceptual_workflow.py").read_text(encoding="utf-8")
    body = source.split("def inject_comments", 1)[1].split("\ndef ", 1)[0]
    assert "_mtime(model_path)" in body


# ═════════════════════════════════════════════════════════════════════════════
#  7. Evidence that cannot be verified is refused, not trusted
# ═════════════════════════════════════════════════════════════════════════════

def test_evidence_without_a_digest_is_refused(tmp_path):
    from app.orchestration import udp_evidence

    source = tmp_path / "m.ldm"
    source.write_text("<Model/>", encoding="utf-8")
    record = udp_evidence.UdpEvidence(model_name="m", pass_rate=99.0, comparable=10,
                                      passed=10, pd_sha256="", pd_bytes=0)
    assert udp_evidence._check_source(record, str(source)) == udp_evidence.REJECT_UNVERIFIABLE


def test_a_stale_readback_is_reported(tmp_path):
    import os
    import time

    from app.validation import udp_flow

    erwin = tmp_path / "m.erwin"
    source = tmp_path / "m.ldm"
    erwin.write_bytes(b"x")
    time.sleep(0.01)
    source.write_text("<Model/>", encoding="utf-8")
    os.utime(erwin, (time.time() - 3600, time.time() - 3600))

    message = udp_flow._stale_readback(str(erwin), str(source))
    assert "STALE READ-BACK" in message
    assert erwin.name in message and source.name in message

    os.utime(erwin, None)          # now newer than the source
    assert udp_flow._stale_readback(str(erwin), str(source)) == ""


# ═════════════════════════════════════════════════════════════════════════════
#  8. The folders an operator is told to use actually exist
# ═════════════════════════════════════════════════════════════════════════════

def test_the_udp_tool_input_folders_are_created():
    """
    The operator is told to drop the handed-off .erwin into
    app/udp_tool/input_erwin_models/<tier>/ and to paste the SAP model into
    input_sap_models. Neither the tier sub-folders nor input_sap_models were
    created by anything, so both instructions pointed at folders that did not
    exist.
    """
    from app.orchestration import directory_setup

    root = REPO / "app/udp_tool"
    assert (root / "input_erwin_models").is_dir()
    assert (root / "input_sap_models").is_dir(), "input_sap_models is never created"
    for tier in ("cdm", "ldm", "pdm"):
        assert (root / "input_erwin_models" / tier).is_dir(), f"{tier} sub-folder missing"
    assert directory_setup.UDP_INPUT_SAP_DIR.name == "input_sap_models"
