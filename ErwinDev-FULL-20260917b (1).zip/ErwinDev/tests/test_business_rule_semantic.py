import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.validation.business_rule_comparator import compare_rule_expressions
from app.validation.business_rule_normalizer import normalize_expression
from app.validation.business_rule_parser import parse_expression


class BusinessRuleParserTests(unittest.TestCase):
    def test_parses_simple_comparison(self):
        self.assertIsNotNone(parse_expression("Amount > 0"))

    def test_rewrites_bare_equals(self):
        self.assertIsNotNone(parse_expression("Revenue = Sales - Returns"))

    def test_rewrites_logical_words(self):
        self.assertIsNotNone(parse_expression("Amount > 0 AND Status = 'OPEN'"))

    def test_unparsable_prose_returns_none(self):
        self.assertIsNone(parse_expression("This must always be true, no exceptions."))

    def test_never_executes_disallowed_constructs(self):
        # Attribute access / subscripting are rejected, not silently accepted.
        self.assertIsNone(parse_expression("os.system('rm -rf /')"))
        self.assertIsNone(parse_expression("__import__('os')"))


class BusinessRuleNormalizerTests(unittest.TestCase):
    def test_mirrored_comparison_normalizes_equal(self):
        self.assertEqual(normalize_expression("Amount > 0"),
                         normalize_expression("0 < Amount"))

    def test_mirrored_equation_normalizes_equal(self):
        self.assertEqual(normalize_expression("Revenue = Sales - Returns"),
                         normalize_expression("Sales - Returns = Revenue"))

    def test_commutative_addition_normalizes_equal(self):
        self.assertEqual(normalize_expression("Qty + Price"),
                         normalize_expression("Price + Qty"))

    def test_non_commutative_subtraction_is_order_sensitive(self):
        # "A - B" is NOT the same rule as "B - A"; only the equation mirror
        # (Workstream 2's own example) is normalized, not the subtraction itself.
        self.assertNotEqual(normalize_expression("Result = A - B"),
                            normalize_expression("Result = B - A"))

    def test_case_insensitive_names(self):
        self.assertEqual(normalize_expression("amount > 0"),
                         normalize_expression("AMOUNT > 0"))


class BusinessRuleComparatorTests(unittest.TestCase):
    def test_semantic_match_for_mirrored_comparison(self):
        result = compare_rule_expressions("Amount > 0", "0 < Amount")
        self.assertTrue(result.semantic_match)

    def test_semantic_match_for_mirrored_equation(self):
        result = compare_rule_expressions("Revenue = Sales - Returns",
                                          "Sales - Returns = Revenue")
        self.assertTrue(result.semantic_match)

    def test_genuinely_different_rules_do_not_match(self):
        result = compare_rule_expressions("Amount > 0", "Amount > 100")
        self.assertFalse(result.semantic_match)

    def test_unparsable_expression_falls_back_safely(self):
        result = compare_rule_expressions("must be positive", "Amount > 0")
        self.assertFalse(result.semantic_match)
        self.assertIn("could not be parsed", result.reason)

    def test_identical_text_is_syntactic_match(self):
        result = compare_rule_expressions("Amount > 0", "Amount > 0")
        self.assertTrue(result.syntactic_match)
        self.assertTrue(result.semantic_match)


if __name__ == "__main__":
    unittest.main()
