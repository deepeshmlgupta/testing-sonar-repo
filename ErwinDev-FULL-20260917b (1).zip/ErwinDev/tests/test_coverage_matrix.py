"""
COVERAGE_MATRIX.md cannot drift from the code:

* every row's Status is in the agreed vocabulary and every column is filled;
* the document carries exactly the rendered table (regenerate with
  ``python -m tests.coverage_matrix_rows`` after editing the rows);
* every finding category the matrix names as a validation method exists in
  the engines / extended checks (no phantom validation);
* the mutation probes agree: a property the probes detect is not listed as
  unvalidated, and the datatype rows are backed by tests/test_datatype_fidelity.py.
"""

import re
from pathlib import Path

from tests import coverage_matrix_rows as cm

ROOT = Path(__file__).resolve().parents[1]
DOC = ROOT / "COVERAGE_MATRIX.md"


def test_rows_are_complete_and_use_the_vocabulary():
    seen = set()
    for row in cm.ROWS:
        assert row.status in cm.STATUSES, row
        assert row.model in ("CDM", "LDM", "PDM") and row.obj and row.prop, row
        assert row.method, f"{row.model}/{row.obj}/{row.prop} has no validation method"
        if row.status in (cm.INTENTIONALLY_OUT_OF_SCOPE, cm.NOT_SUPPORTED_BY_ERWIN, cm.FUTURE_ENHANCEMENT,
                          cm.NOT_SUPPORTED_BY_FRAMEWORK, cm.PARTIALLY_SUPPORTED, cm.NOT_YET_TESTED):
            assert row.remediation, f"{row.model}/{row.obj}/{row.prop}: excluded/partial rows need an alternative"
        if row.status == cm.AUTOMATICALLY_MIGRATED:
            assert row.auto == cm.Y and row.transformed.startswith("Step"), row
        if row.status == cm.AUTOMATICALLY_VALIDATED:
            assert row.validated == cm.Y and row.manual == cm.Y, row
        key = (row.model, row.obj, row.prop)
        assert key not in seen, f"duplicate row {key}"
        seen.add(key)
    assert len(cm.ROWS) >= 140


def test_document_carries_the_rendered_table():
    text = DOC.read_text(encoding="utf-8")
    assert cm.BEGIN in text and cm.END in text
    block = text.split(cm.BEGIN, 1)[1].split(cm.END, 1)[0].strip()
    assert block == cm.render().strip(), "COVERAGE_MATRIX.md is stale — run python -m tests.coverage_matrix_rows"
    assert text.count("## 2. Canonical coverage matrix") == 1, "exactly one canonical matrix"


def _known_categories():
    """Every finding category string the engines and the extended checks can emit."""
    sources = [ROOT / "app" / "validation"]
    pattern = re.compile(r'"([A-Z][A-Z0-9_]{3,})"')
    cats = set()
    for base in sources:
        for path in base.rglob("*.py"):
            cats.update(pattern.findall(path.read_text(encoding="utf-8", errors="ignore")))
    return cats


def test_named_validation_methods_exist_in_the_engines():
    """Every category-looking token in a Validation Method must be emitted somewhere under app/validation."""
    known = _known_categories()
    missing = []
    for row in cm.ROWS:
        method = row.method
        # expand "A_MISSING/EXTRA" and "A_LOSS/PARTIAL" shorthands into full category names
        for prefix, alts in re.findall(r"\b([A-Z][A-Z0-9_]*)_([A-Z]+(?:/[A-Z]+)+)\b", method):
            for alt in alts.split("/"):
                method += f" {prefix}_{alt}"
        for token in re.findall(r"\b[A-Z][A-Z0-9]+(?:_[A-Z0-9]+)+\b", method):
            if token.endswith("_"):
                continue
            if token in known or token + "_MISSING" in known or any(k.startswith(token + "_") for k in known):
                continue
            if token in ("UDP_RECONCILIATION", "CHECK_ASSOCIATIONS", "SQL_SIMILARITY_THRESHOLD"):
                continue
            missing.append((row.model, row.obj, row.prop, token))
    assert not missing, f"validation methods not found in app/validation: {missing}"


def test_probe_results_agree_with_the_matrix():
    from tests import coverage_probe
    detected = {(r.engine.upper(), r.obj.lower(), r.prop.lower()) for eng in coverage_probe.ENGINES
                for r in coverage_probe.run_probes(eng) if r.detected}
    # A property the matrix marks as not validated must not be one the probes detect.
    for row in cm.ROWS:
        if row.validated == cm.N:
            hits = [d for d in detected if d[0] == row.model and d[1] == row.obj.lower()
                    and d[2] == row.prop.lower()]
            assert not hits, f"{row} is listed unvalidated but the probes detect it"


def test_datatype_rows_are_backed_by_the_datatype_tests():
    text = (ROOT / "tests" / "test_datatype_fidelity.py").read_text(encoding="utf-8")
    for literal in ("VARCHAR(500)", "VARCHAR(255)", "DECIMAL(18,2)", "DECIMAL(38,10)", "DATE", "TIMESTAMP",
                    "CHAR(10)", "INTEGER", "BIGINT"):
        assert literal in text
    rows = [r for r in cm.ROWS if r.obj in ("Attribute", "Column")
            and (r.prop.startswith("Data type") or r.prop.startswith("Length"))]
    assert rows and all("T" in r.evidence for r in rows)
