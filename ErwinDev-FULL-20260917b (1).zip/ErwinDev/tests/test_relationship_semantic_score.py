import os
import sys
import unittest
from dataclasses import dataclass, field

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.validation.relationship_semantic_score import classify_pair, score_relationships


@dataclass
class _End:
    entity: str = ""
    mandatory: bool = False
    dependent: bool = False


@dataclass
class _Rel:
    name: str = ""
    identifying: bool = False
    end1: _End = field(default_factory=_End)
    end2: _End = field(default_factory=_End)


class RelationshipSemanticScoreTests(unittest.TestCase):
    def test_fully_agreeing_pair_scores_100(self):
        pd_rel = _Rel(name="Places", identifying=True,
                     end1=_End("CUSTOMER", mandatory=True), end2=_End("ORDER", dependent=True))
        erwin_rel = _Rel(name="Places", identifying=True,
                         end1=_End("CUSTOMER", mandatory=True), end2=_End("ORDER", dependent=True))
        finding = classify_pair(pd_rel, erwin_rel)
        self.assertEqual(100.0, finding.semantic_score_pct)
        self.assertTrue(finding.identifying_match)
        self.assertTrue(finding.weak_entity_match)
        self.assertTrue(finding.participation_match)

    def test_identifying_mismatch_lowers_score(self):
        pd_rel = _Rel(name="Places", identifying=True)
        erwin_rel = _Rel(name="Places", identifying=False)
        finding = classify_pair(pd_rel, erwin_rel)
        self.assertFalse(finding.identifying_match)
        self.assertLess(finding.semantic_score_pct, 100.0)

    def test_all_three_axes_disagree_scores_zero(self):
        pd_rel = _Rel(name="Places", identifying=True,
                     end1=_End("CUSTOMER", mandatory=True), end2=_End("ORDER", dependent=True))
        erwin_rel = _Rel(name="Places", identifying=False,
                         end1=_End("CUSTOMER", mandatory=False), end2=_End("ORDER", dependent=False))
        finding = classify_pair(pd_rel, erwin_rel)
        self.assertEqual(0.0, finding.semantic_score_pct)

    def test_score_relationships_blends_across_pairs(self):
        agree = _Rel(name="A"), _Rel(name="A")
        disagree = _Rel(name="B", identifying=True), _Rel(name="B", identifying=False)
        outcome = score_relationships([agree, disagree])
        self.assertEqual(2, len(outcome.findings))
        self.assertAlmostEqual((100.0 + 66.67) / 2, outcome.fidelity_pct, places=1)

    def test_empty_pairs_returns_none_fidelity(self):
        outcome = score_relationships([])
        self.assertIsNone(outcome.fidelity_pct)
        self.assertEqual([], outcome.findings)


if __name__ == "__main__":
    unittest.main()
