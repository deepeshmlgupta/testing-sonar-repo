from pathlib import Path

from app.xem_tool.run_xem import main
from app.xem_tool.xem_mapper import build_mapping_template, rows_to_udp_schema
from app.xem_tool.xem_parser import XEMParser

FIXTURE = Path(__file__).parent / "xem_samples" / "sample.xem"


def test_xem_parser_inventory():
    inventory = XEMParser().parse(FIXTURE)
    assert inventory.root_element == "Profile"
    assert len(inventory.definitions) == 1
    definition = inventory.definitions[0]
    assert definition.name == "Data Classification"
    assert definition.code == "DataClassification"
    assert "Entity" in definition.applies_to
    assert "Confidential" in definition.allowed_values


def test_mapping_requires_review_by_default():
    inventory = XEMParser().parse(FIXTURE)
    rows = build_mapping_template(inventory)
    assert rows[0]["status"] == "REVIEW"
    assert rows[0]["erwin_udp"] == "Data_Classification"


def test_approved_mapping_emits_schema():
    inventory = XEMParser().parse(FIXTURE)
    rows = build_mapping_template(inventory)
    rows[0]["status"] = "MANUAL_UDP"
    rows[0]["erwin_target_object"] = "Entity"
    rows[0]["value_list"] = "Public | Internal | Confidential"
    schema = rows_to_udp_schema(rows)
    assert schema[0]["udp"] == "Data_Classification"
    assert schema[0]["type"] == "List"
    assert schema[0]["value_list"] == ["Public", "Internal", "Confidential"]


def test_cli_creates_review_artifacts(tmp_path):
    rc = main(["--xem", str(FIXTURE), "--outdir", str(tmp_path)])
    assert rc == 0
    assert (tmp_path / "xem_inventory.json").is_file()
    assert (tmp_path / "xem_inventory.csv").is_file()
    assert (tmp_path / "xem_to_erwin_mapping.csv").is_file()
    assert (tmp_path / "xem_run_summary.json").is_file()
