"""
Property-coverage contract.

Every probe in tests/coverage_probe.py marked expect=True MUST be detected by
its engine, and every probe marked expect=False MUST NOT be (those are the
documented gaps — when one starts being detected, the matrix document has to
be updated, so the test fails on purpose). Probes marked None are recorded
only.

Also covers the behaviours of app/validation/extended_properties.py that a
single-line mutation cannot express: the "not carried" guard, the master
switch, a trigger moved under another table, and a thin export in the shape of
the real vessel sample (no Subject_Area / Stored_Display / Default_Value ...)
which must produce no extended findings at all.
"""

import os
import re
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.config.validation_config import LDM_CONFIG, PDM_CONFIG
from app.validation import extended_properties as ext
from tests import coverage_probe as cp
from tests.fixtures_extended import ERWIN_LDM_FULL, ERWIN_PDM_FULL, PD_LDM_FULL, PD_PDM_FULL, mutate


def _write(directory: str, name: str, text: str) -> str:
    path = os.path.join(directory, name)
    Path(path).write_text(text, encoding="utf-8")
    return path


class ProbeContractTests(unittest.TestCase):
    """Runs the whole probe catalogue once per engine and checks the expectations."""

    @classmethod
    def setUpClass(cls):
        cls.results = {engine: cp.run_probes(engine) for engine in cp.ENGINES}

    def _check(self, engine: str) -> None:
        wrong = []
        for r in self.results[engine]:
            if r.expect is True and not r.detected:
                wrong.append(f"EXPECTED DETECTED but was not: {engine} / {r.obj} / {r.prop}")
            if r.expect is False and r.detected:
                wrong.append(f"documented gap is now detected (update the matrix): {engine} / {r.obj} / {r.prop} -> {r.categories}")
        self.assertEqual([], wrong, "\n".join(wrong))

    def test_ldm_probes(self):
        self._check("LDM")

    def test_cdm_probes(self):
        self._check("CDM")

    def test_pdm_probes(self):
        self._check("PDM")

    def test_coverage_floor(self):
        detected = sum(r.detected for rs in self.results.values() for r in rs)
        total = sum(len(rs) for rs in self.results.values())
        self.assertGreaterEqual(detected / total, 0.85, f"{detected}/{total} probes detected")


class ExtendedPropertiesBehaviourTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = self.tmp.name

    def tearDown(self):
        self.tmp.cleanup()

    def _run(self, pd_xml: str, er_xml: str, model_type: str, config=None):
        pd_path = _write(self.dir, "m." + model_type, pd_xml)
        er_path = _write(self.dir, "m.xml", er_xml)
        return ext.run(pd_path, er_path, model_type, config or (PDM_CONFIG if model_type == "pdm" else LDM_CONFIG))

    def test_clean_baselines_produce_no_extended_findings(self):
        for pd_xml, er_xml, kind in ((PD_LDM_FULL, ERWIN_LDM_FULL, "ldm"), (PD_LDM_FULL, ERWIN_LDM_FULL, "cdm"),
                                     (PD_PDM_FULL, ERWIN_PDM_FULL, "pdm")):
            findings = [f for f in self._run(pd_xml, er_xml, kind) if f.severity != "VERIFIED"]
            # EXTERNAL_VERIFICATION_REQUIRED rows are not defect findings: they
            # record that a check could not run because the erwin element name
            # it needs was absent and has never been confirmed against a real
            # export. A clean baseline must produce no DEFECTS; it may still
            # legitimately report what was not looked at.
            defects = [f for f in findings
                       if f.severity != ext.SEVERITY_EXTERNAL_VERIFICATION]
            self.assertEqual([], [(f.category, f.object_name, f.pd_value, f.erwin_value) for f in defects], kind)

    def test_data_format_is_a_verified_census_row_only(self):
        rows = [f for f in self._run(PD_PDM_FULL, ERWIN_PDM_FULL, "pdm") if f.category == "DATA_FORMAT_NOT_REPRESENTABLE"]
        self.assertEqual(1, len(rows))
        self.assertEqual("VERIFIED", rows[0].severity)
        self.assertIn("Voyage.Departure Date", rows[0].member)

    def test_not_carried_guard_emits_one_model_level_finding(self):
        # Strip every <Owner> from the export: the two PD owners cannot be
        # compared object by object, so ONE model-level row is expected.
        er = re.sub(r"<Owner>[^<]*</Owner>", "", ERWIN_PDM_FULL)
        found = [f for f in self._run(PD_PDM_FULL, er, "pdm") if f.category.startswith("TABLE_OWNER")]
        self.assertEqual(["TABLE_OWNER_NOT_CARRIED"], [f.category for f in found])
        self.assertEqual("2", found[0].pd_value)

    def test_thin_export_like_the_real_sample_is_never_flooded(self):
        # The real vessel export carries none of: Subject_Area, Stored_Display,
        # Default_Value, Domain_Name, Owner, Key_Group_Member_Order, per-
        # relationship RI rules. Drop all of them and the module must stay quiet
        # except for the explicit "not carried" summaries.
        er = ERWIN_LDM_FULL
        er = re.sub(r"<Subject_Area_Groups>.*?</Subject_Area_Groups>", "", er, flags=re.S)
        er = re.sub(r"<Domain_Groups>.*?</Domain_Groups>", "", er, flags=re.S)
        for tag in ("Default_Value", "Domain_Name", "Key_Group_Member_Order", "Parent_Update_Rule", "Parent_Delete_Rule"):
            er = re.sub(rf"<{tag}>[^<]*</{tag}>", "", er)
        findings = [f for f in self._run(PD_LDM_FULL, er, "ldm")
                    if f.severity not in ("VERIFIED", ext.SEVERITY_EXTERNAL_VERIFICATION)]
        self.assertTrue(all(f.category.endswith("_NOT_CARRIED") for f in findings),
                        [(f.category, f.object_name) for f in findings])

        # ...and the stripped vocabularies ARE reported as not-looked-at, so a
        # thin export cannot pass for a checked one just because it is quiet.
        unverified = [f for f in self._run(PD_LDM_FULL, er, "ldm")
                      if f.severity == ext.SEVERITY_EXTERNAL_VERIFICATION]
        self.assertTrue(unverified, "removing the erwin vocabulary silenced the checks "
                                    "without recording that they did not run")
        self.assertTrue(all(f.category == "ERWIN_TAG_UNVERIFIED" for f in unverified))
        self.assertEqual({"(model)"}, {f.object_name for f in findings})

    def test_master_switch_disables_everything(self):
        class Off:
            CHECK_EXTENDED_PROPERTIES = False
        class Result:
            pd_file = _write(self.dir, "a.pdm", PD_PDM_FULL)
            erwin_file = _write(self.dir, "a.xml", mutate(ERWIN_PDM_FULL, "<Owner>dbo</Owner>", "<Owner>x</Owner>"))
            findings = []
            def emit(self, *a, **k):
                self.findings.append(a)
        r = Result()
        self.assertEqual(0, ext.apply(r, "pdm", Off()))
        self.assertEqual([], r.findings)

    def test_single_check_toggle(self):
        class Cfg:
            CHECK_EXTENDED_PROPERTIES = True
            EXTENDED_PROPERTY_CHECKS = {"TABLE_OWNER": False}
        er = mutate(ERWIN_PDM_FULL, "<Owner>dbo</Owner>", "<Owner>sales</Owner>")
        cats = {f.category for f in self._run(PD_PDM_FULL, er, "pdm", Cfg())}
        self.assertNotIn("TABLE_OWNER", cats)
        cats = {f.category for f in self._run(PD_PDM_FULL, er, "pdm")}
        self.assertIn("TABLE_OWNER", cats)

    def test_trigger_moved_to_another_table(self):
        trigger = re.search(r"\s*<Trigger id=.*?</Trigger>", ERWIN_PDM_FULL, re.S).group(0)
        er = ERWIN_PDM_FULL.replace(trigger, "", 1)
        anchor = '<Physical_Name>VOYAGE</Physical_Name><Owner>dbo</Owner><Definition>A journey made by a vessel.</Definition></EntityProps>'
        er = mutate(er, anchor, anchor + trigger)
        found = [f for f in self._run(PD_PDM_FULL, er, "pdm") if f.category == "TRIGGER_TABLE"]
        self.assertEqual(1, len(found))
        self.assertEqual(("VESSEL", "VOYAGE"), (found[0].pd_value, found[0].erwin_value))

    def test_ri_rule_falls_back_to_model_defaults(self):
        # No per-relationship rule, but the export carries model-level defaults
        # for a non-identifying not-null relationship: 10002 = SET NULL (provisional
        # map) vs PD 2 = CASCADE -> mismatch attributed to the model default.
        er = ERWIN_LDM_FULL
        er = re.sub(r"<Parent_Update_Rule>[^<]*</Parent_Update_Rule><Parent_Delete_Rule>[^<]*</Parent_Delete_Rule>", "", er)
        er = mutate(er, "<ModelProps><Name>Fleet</Name>",
                    "<ModelProps><Name>Fleet</Name><Parent_Update_Rule_Nonidentifying_Not_Null>10002</Parent_Update_Rule_Nonidentifying_Not_Null>"
                    "<Parent_Delete_Rule_Nonidentifying_Not_Null>10005</Parent_Delete_Rule_Nonidentifying_Not_Null>")
        found = {f.member: f for f in self._run(PD_LDM_FULL, er, "ldm") if f.category == "RELATIONSHIP_RI_RULE"}
        self.assertEqual({"update"}, set(found))
        self.assertIn("model default", found["update"].erwin_value)

    def test_unmapped_ri_code_is_reported_as_unmapped_not_mismatch(self):
        er = mutate(ERWIN_LDM_FULL, "<Parent_Update_Rule>10000</Parent_Update_Rule>", "<Parent_Update_Rule>10099</Parent_Update_Rule>")
        cats = [f.category for f in self._run(PD_LDM_FULL, er, "ldm") if "RI_RULE" in f.category]
        self.assertEqual(["RELATIONSHIP_RI_RULE_UNMAPPED"], cats)

    def test_findings_land_in_the_engine_results_as_info(self):
        pd_path = _write(self.dir, "f.ldm", PD_LDM_FULL)
        er_path = _write(self.dir, "f.xml", mutate(ERWIN_LDM_FULL, "<Default_Value>'ACTIVE'</Default_Value>", ""))
        from app.validation.ldm_reconcile.comparator import compare
        from app.validation.ldm_reconcile.erwin_ldm_parser import parse_erwin_ldm
        from app.validation.ldm_reconcile.pd_ldm_parser import parse_ldm
        result = compare(parse_ldm(pd_path), parse_erwin_ldm(er_path))
        hits = [f for f in result.findings if f.category == "ATTRIBUTE_DEFAULT"]
        self.assertEqual(1, len(hits))
        self.assertEqual("INFO", hits[0].severity)
        self.assertEqual("PASS", result.status)          # INFO never fails a model

        pd_path = _write(self.dir, "g.pdm", PD_PDM_FULL)
        er_path = _write(self.dir, "g.xml", mutate(ERWIN_PDM_FULL, "<Owner>dbo</Owner>", "<Owner>sales</Owner>"))
        from app.validation.pdm_reconcile import pdm_validator_bridge as bridge
        result = bridge.compare(bridge.parse_pdm(pd_path), bridge.parse_erwin(er_path))
        hits = [f for f in result.findings if f.category == "TABLE_OWNER"]
        self.assertEqual(1, len(hits))
        self.assertEqual(("INFO", "TABLE", "Vessel"), (hits[0].severity, hits[0].object_type, hits[0].table))
        self.assertEqual("PASS", result.status)
        self.assertEqual([], result.reconciliation_errors())


if __name__ == "__main__":
    unittest.main()
