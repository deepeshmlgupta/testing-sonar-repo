"""
Post-fix verification pass
==========================

Regression tests for the defects found by the SECOND, independent audit of the
remediation — the one that did not assume the first pass was sufficient. Each
test names the defect it guards, because a test whose purpose is not written
down gets deleted by the next person who finds it inconvenient.

Covered here:

1. RTF normalisation is ONE implementation, shared by every tier. Three
   independent strippers produced different plain text for the same bytes, and
   the two sides of a single comparison were normalised by different ones.
2. The UDP component is NOT scored 0% for a stage that has not run.
3. The fidelity score is reconstructible from the finding rows.
4. Model identity: artefacts belonging to two different models cannot be
   combined into one score.
5. The genuine defects on the real sample models are still reported.
"""

import os
from pathlib import Path

import pytest

from app.common import rtf_text
from app.reporting import score_audit

REPO = Path(__file__).resolve().parents[1]

PD_MODELS = {
    "modeling_and_simulation":
        REPO / "sappdmodels/ldm/3eafce5dd91787f5f61afafbe5ffcf7d_46584675_modeling_and_simulation.ldm",
    "real_estate":
        REPO / "sappdmodels/ldm/4d95b17a5883fbeb69fb9088bf1767c1_46007266_real_estate.ldm",
}
ERWIN_XML = {
    "modeling_and_simulation":
        REPO / "erwinmodels/2_preprocessed/3eafce5dd91787f5f61afafbe5ffcf7d_46584675_modeling_and_simulation.xml",
    "real_estate":
        REPO / "erwinmodels/2_preprocessed/4d95b17a5883fbeb69fb9088bf1767c1_46007266_real_estate.xml",
}

_HAVE_SAMPLES = all(path.is_file() for path in list(PD_MODELS.values()) + list(ERWIN_XML.values()))
requires_samples = pytest.mark.skipif(
    not _HAVE_SAMPLES, reason="the two real LDM sample models are not present in this checkout")


# ═════════════════════════════════════════════════════════════════════════════
#  1. ONE RTF normaliser
# ═════════════════════════════════════════════════════════════════════════════

RTF_CASES = [
    # (input, expected plain text, what it guards)
    (r"{\rtf1\ansi\ansicpg1252\deflang1033{\fonttbl{\f0\fnil Times New Roman;}}"
     r"{\*\generator Riched20 10.0.22000;}\pard\b Owner: \b0\par Author: Vincent\par}",
     "Owner: \nAuthor: Vincent",
     "font table and \\*\\generator must not leak into the compared text"),

    (r"{\rtf1\ansi\ansicpg1252 Caf\'e9 \'93quoted\'94}",
     "Caf\u00e9 \u201cquoted\u201d",
     "\\'xx is a cp1252 BYTE, not a Unicode code point: the regex chain gave "
     "U+0093/U+0094 control characters and reported a MISMATCH against the "
     "erwin Note that held the real smart quotes"),

    (r"{\rtf1\ansi Path C:\\Users\\x and \{brace\}}",
     "Path C:\\Users\\x and {brace}",
     "escaped backslashes must survive: the regex chain let the following "
     "backslash start a control-word match and DELETED the next word"),

    (r"{\rtf1\ansi price \u8364 ?100}",
     "price \u20ac100",
     "\\uNNNN decodes, and its single ANSI fallback character is discarded"),

    (r"{\rtf1\ansi see {\field{\*\fldinst HYPERLINK \"http://x/y\"}{\fldrslt the doc}} now}",
     "see the doc now",
     "a hyperlink's field CODE is not body text; its RESULT is"),

    (r"{\rtf1\ansi before {\pict\wmetafile8 0100090000ffff} after}",
     "before after",
     "embedded picture hex is not body text"),

    ("plain text, no rtf at all", "plain text, no rtf at all",
     "a non-RTF value passes through untouched"),

    ("", "", "empty stays empty"),
]


def _all_tier_strippers():
    """The normaliser each tier actually uses, by name."""
    from app.preprocessing.scripts import pd_comment_to_erwin_note as injector
    from app.validation.cdm_reconcile import pd_cdm_parser
    from app.validation.ldm_reconcile import pd_ldm_parser
    from app.validation.pdm_reconcile import pdm_documentation

    return {
        "shared": rtf_text.strip_rtf,
        "LDM": pd_ldm_parser._strip_rtf,
        "CDM": pd_cdm_parser._strip_rtf_for_report,
        "PDM": pdm_documentation._strip_rtf,
        "Comment->Note injector": injector._strip_rtf,
    }


@pytest.mark.parametrize("raw,expected,guards", RTF_CASES,
                         ids=[case[0][:28] or "empty" for case in RTF_CASES])
def test_every_tier_normalises_rtf_identically(raw, expected, guards):
    results = {}
    for tier, strip in _all_tier_strippers().items():
        # The injector deliberately returns the RAW text when stripping would
        # empty a non-empty comment, so it is only comparable on cases that
        # produce text. Every other tier must agree exactly.
        if tier == "Comment->Note injector" and not expected:
            continue
        results[tier] = strip(raw)
    assert len(set(results.values())) == 1, (
        f"tiers disagree ({guards}): {results}")
    assert next(iter(results.values())) == expected, f"{guards}: got {results}"


def test_the_tiers_share_one_implementation_not_three_copies():
    """
    Equal OUTPUT today is not enough — three copies drift. The LDM alias and
    the shared entry point must be the same function object, and the CDM and
    PDM wrappers must call into this module rather than carry their own regex
    chains.
    """
    from app.validation.cdm_reconcile import pd_cdm_parser
    from app.validation.ldm_reconcile import pd_ldm_parser

    assert pd_ldm_parser._strip_rtf is rtf_text.strip_rtf

    for module in (pd_cdm_parser, __import__(
            "app.validation.pdm_reconcile.pdm_documentation",
            fromlist=["pdm_documentation"])):
        source = Path(module.__file__).read_text(encoding="utf-8")
        assert "rtf_text.strip_rtf" in source, (
            f"{module.__name__} no longer delegates to the shared normaliser")
        assert "\\\\'([0-9a-fA-F]{2})" not in source, (
            f"{module.__name__} has grown its own hex-escape regex again")


def test_the_keyword_pattern_is_reproducible_across_runs():
    """
    The known-keyword alternation is built from a SET. Sorting it by length
    alone left equal-length keywords in hash-randomised order, so the compiled
    pattern differed between interpreter runs. Output was stable, but a
    pattern an auditor cannot reproduce is not auditable.
    """
    keywords = rtf_text._RTF_KNOWN_KEYWORDS
    assert keywords == sorted(set(keywords), key=lambda word: (-len(word), word))


# ═════════════════════════════════════════════════════════════════════════════
#  2. A stage that has not run is NOT a measured zero
# ═════════════════════════════════════════════════════════════════════════════

class _Result:
    """Minimal stand-in exposing only what the scorer reads."""

    def __init__(self, udp_total=219, udp_fidelity_score=0.0):
        self.udp_total = udp_total
        self.udp_fidelity_score = udp_fidelity_score
        self.structural_fidelity_score = 100.0
        self.documentation_rows = []
        self.findings = []
        self.pd_file = ""
        self.erwin_file = ""


def test_not_measured_sentinel_drops_the_component_instead_of_scoring_zero():
    from app.validation import fidelity_stages

    result = _Result()
    assert fidelity_stages.udp_fidelity_component(
        result, fidelity_stages.UDP_NOT_MEASURED) is None
    # Without the sentinel, V1 still reports its MEASURED 0% — that baseline is
    # the point of V1 and must not be suppressed.
    assert fidelity_stages.udp_fidelity_component(
        result, None, fidelity_stages.STAGE_V1) == 0.0
    # At V2/V3 an XML carrying no UDP evidence cannot answer the question, so
    # the component is dropped rather than reported as a measured total loss.
    for stage in (fidelity_stages.STAGE_V2, fidelity_stages.STAGE_V3):
        assert fidelity_stages.udp_fidelity_component(result, None, stage) is None


def test_the_sentinel_is_distinguishable_from_a_real_zero():
    """
    0.0 is falsy and None is falsy; the sentinel must be neither of them by
    identity, or the three states collapse again.
    """
    from app.validation import fidelity_stages

    sentinel = fidelity_stages.UDP_NOT_MEASURED
    assert sentinel is not None
    assert sentinel != 0.0
    assert fidelity_stages.udp_fidelity_component(_Result(), 0.0) == 0.0


def test_a_ran_udp_stage_still_scores_its_measured_loss():
    """
    The guard must never hide a genuine injection failure. Only a RECORDED
    'stage has not run' reaches the sentinel; any executed status keeps the
    measurement, including a bad one.
    """
    from app.orchestration import stage_state, udp_helpers

    class _Dirs(dict):
        pass

    statuses = {}

    def fake_status(dirs, name, stage):
        return statuses[name]

    original = stage_state.stage_status
    stage_state.stage_status = fake_status
    try:
        statuses["waiting"] = stage_state.STATUS_WAITING
        statuses["ran"] = stage_state.STATUS_VALIDATED
        statuses["failed"] = stage_state.STATUS_FAILED
        assert udp_helpers._udp_stage_not_executed(_Dirs(), "waiting") is True
        assert udp_helpers._udp_stage_not_executed(_Dirs(), "ran") is False
        assert udp_helpers._udp_stage_not_executed(_Dirs(), "failed") is False
    finally:
        stage_state.stage_status = original


def test_no_dirs_means_no_sentinel():
    """Unit paths that pass no dirs keep the previous behaviour exactly."""
    from app.orchestration import udp_helpers

    assert udp_helpers._udp_stage_not_executed(None, "anything") is False
    assert udp_helpers._udp_stage_not_executed({}, "") is False


# ═════════════════════════════════════════════════════════════════════════════
#  3. The score is reconstructible from the rows
# ═════════════════════════════════════════════════════════════════════════════

@requires_samples
@pytest.mark.parametrize("model", sorted(PD_MODELS))
def test_structural_score_reconstructs_from_the_finding_rows(model):
    from app.config.validation_config import LDM_CONFIG
    from app.orchestration.udp_helpers import reconcile

    result = reconcile(str(PD_MODELS[model]), str(ERWIN_XML[model]), "LDM")
    audit = score_audit.reconstruct(result, LDM_CONFIG)

    assert audit["reported"] is not None
    assert audit["agrees"] is True, (
        f"{model}: the reported score {audit['reported']} is not what its own "
        f"rows produce ({audit['recomputed']}); {audit['formula']}")


@requires_samples
def test_non_scoring_findings_stay_visible_in_the_report():
    """
    Reclassifying a finding to SOURCE_PRE_EXISTING must make it stop COUNTING,
    never make it disappear. That is the difference between reclassification
    and suppression, and it is the whole basis on which the score improved.
    """
    from app.config.validation_config import LDM_CONFIG
    from app.orchestration.udp_helpers import reconcile

    result = reconcile(str(PD_MODELS["real_estate"]), str(ERWIN_XML["real_estate"]), "LDM")
    audit = score_audit.reconstruct(result, LDM_CONFIG)

    pre_existing = audit["severities"].get("SOURCE_PRE_EXISTING", 0)
    assert pre_existing >= 140, (
        "the pre-existing source-quality rows have gone missing from the "
        f"report, not merely stopped scoring (found {pre_existing})")
    assert audit["findings_total"] > pre_existing, "no other rows survive at all"
    # And they genuinely cost nothing.
    assert audit["penalty"] == 0.0


def test_score_audit_reports_disagreement_rather_than_hiding_it():
    class _Drifted:
        findings = []
        entities_pd = 10
        attributes_pd = 0
        relationships_pd = 0
        identifiers_pd = 0
        inheritances_pd = 0
        structural_fidelity_score = 42.0        # not what zero findings produce

    audit = score_audit.reconstruct(_Drifted(), None)
    assert audit["recomputed"] == 100.0
    assert audit["agrees"] is False


# ═════════════════════════════════════════════════════════════════════════════
#  4. Model identity — artefacts from two models must not combine
# ═════════════════════════════════════════════════════════════════════════════

@requires_samples
def test_swapping_two_models_erwin_exports_is_rejected_not_scored():
    """
    NEGATIVE test: reconcile each SAP PD model against the OTHER model's erwin
    export. The framework must refuse the pair rather than produce a score
    combining Model A's source with Model B's target.
    """
    from app.orchestration.udp_helpers import reconcile
    from app.workflows.conceptual_workflow import _same_model

    for source, target in (("modeling_and_simulation", "real_estate"),
                           ("real_estate", "modeling_and_simulation")):
        crossed = reconcile(str(PD_MODELS[source]), str(ERWIN_XML[target]), "LDM")
        assert _same_model(crossed) is False, (
            f"SAP PD {source} was accepted against the erwin export of "
            f"{target}: a score built from two different models")

    # The control: the correctly paired artefacts ARE accepted, so the guard
    # is discriminating rather than simply always refusing.
    for model in PD_MODELS:
        matched = reconcile(str(PD_MODELS[model]), str(ERWIN_XML[model]), "LDM")
        assert _same_model(matched) is True, f"{model} rejected against its own export"


@requires_samples
def test_udp_evidence_refuses_another_models_record(tmp_path):
    """
    The persisted UDP read-back is the one number V3 carries across processes,
    so a record written for another model must be refused by identity, not
    silently used because the filename matched.
    """
    from app.orchestration import udp_evidence

    assert udp_evidence.REJECT_MODEL
    assert udp_evidence.REJECT_SOURCE_CHANGED
    # Reading evidence for a model that has none must say ABSENT, never 0%.
    rate, reason = udp_evidence.pass_rate_for(
        {"summary": str(tmp_path)}, "a_model_that_does_not_exist", "LDM", None)
    assert rate is None
    assert reason == udp_evidence.REJECT_ABSENT

    # And asking must not have CREATED anything: a read that writes leaves
    # stray folders wherever the process happens to be running.
    assert not any(tmp_path.iterdir())


# ═════════════════════════════════════════════════════════════════════════════
#  5. True positives survive the new classification and normalisation
# ═════════════════════════════════════════════════════════════════════════════

@requires_samples
def test_genuine_defects_on_modeling_and_simulation_are_still_reported():
    """
    The remediation is only valid if it removed false positives WITHOUT hiding
    true ones. These are the known genuine findings on this model.
    """
    from app.orchestration.udp_helpers import reconcile

    result = reconcile(str(PD_MODELS["modeling_and_simulation"]),
                       str(ERWIN_XML["modeling_and_simulation"]), "LDM")
    scoring = [f for f in result.findings
               if f.severity in score_audit.SCORING_SEVERITIES]

    critical = [f for f in scoring if f.severity == "CRITICAL"]
    assert any(f.category == "DATA_TYPE" for f in critical), (
        "the CRITICAL DATA_TYPE finding has been suppressed")

    info_definitions = [f for f in scoring
                        if f.severity == "INFO" and "DEFINITION" in f.category]
    assert len(info_definitions) >= 2, (
        "the INFO definition findings have been suppressed by the new "
        f"normalisation: {[f.category for f in scoring]}")

    assert result.critical_count >= 1
    assert result.info_count >= 2


@requires_samples
def test_definition_findings_carry_their_field_provenance():
    """
    A definition finding must say WHICH SAP PD field was compared against
    which erwin field. Comparing a PD Comment against an erwin Note is a
    different fact from comparing two Definitions, and a report that hides the
    difference cannot be checked.
    """
    from app.orchestration.udp_helpers import reconcile

    result = reconcile(str(PD_MODELS["real_estate"]), str(ERWIN_XML["real_estate"]), "LDM")
    definition_rows = [f for f in result.findings if "DEFINITION" in f.category]
    assert definition_rows, "no definition findings at all on this model"
    assert any("compared SAP PD" in (f.message or "") for f in definition_rows), (
        "definition findings no longer record which fields were compared")


# ═════════════════════════════════════════════════════════════════════════════
#  6. erwin's derived code is not presented as erwin's own
# ═════════════════════════════════════════════════════════════════════════════

@requires_samples
def test_the_erwin_exports_really_have_no_physical_name():
    """
    The premise of the whole CODE_NOT_CARRIED classification. If a future
    export DOES carry Physical_Name, the derivation contract in the parsers'
    _code() docstrings no longer describes reality and must be revisited.
    """
    for path in ERWIN_XML.values():
        text = path.read_text(encoding="utf-8", errors="replace")
        assert "<Physical_Name>" not in text, (
            f"{path.name} carries Physical_Name — erwin now has a native field "
            "for the SAP PD Code, so CODE_NOT_CARRIED is no longer correct")


def test_both_tiers_agree_on_whether_erwin_has_its_own_code():
    """
    The predicate existed only on the LDM tier, so the same source model
    scored differently at CDM. Both must now answer identically.
    """
    from app.validation.cdm_reconcile.comparator import _erwin_has_own_code as cdm_predicate
    from app.validation.ldm_reconcile.comparator import _erwin_has_own_code as ldm_predicate

    class _Obj:
        def __init__(self, name, code):
            self.name, self.code = name, code

    for name, code, expected in (("Address", "Address", False),
                                 ("Address", "ADDRSS", True),
                                 ("Address", "address", False),
                                 ("Address", "", True)):
        assert cdm_predicate(_Obj(name, code)) is ldm_predicate(_Obj(name, code))
        assert ldm_predicate(_Obj(name, code)) is expected


def test_code_not_carried_is_visible_but_never_scored():
    """It is an EXPECTED_TRANSFORMATION, not a loss and not a suppression."""
    from app.validation.cdm_reconcile import comparator as cdm
    from app.validation.ldm_reconcile import comparator as ldm

    for module in (ldm, cdm):
        severity = module.SEVERITY_DEFAULTS["CODE_NOT_CARRIED"]
        assert severity == module.SEVERITY_SOURCE_PRE_EXISTING
        assert severity not in score_audit.SCORING_SEVERITIES


# ═════════════════════════════════════════════════════════════════════════════
#  7. PDM parity
# ═════════════════════════════════════════════════════════════════════════════

def test_pdm_records_an_explicit_result_when_neither_side_has_a_primary_key():
    """
    'No PK anywhere' must be distinguishable from 'PK validation did not run'.
    It used to emit nothing at all, so the two were indistinguishable in the
    report.
    """
    from app.validation.pdm_reconcile.pdm_erwin_validator import comparator as pdm

    assert pdm._DEFAULT_SEVERITY["PRIMARY_KEY_ABSENT_BOTH"] == pdm.SEVERITY_SOURCE_PRE_EXISTING
    # The four PK cases are four DIFFERENT keys, so a report grouped by
    # category can tell a loss from a fabrication from a source gap.
    keys = {"PRIMARY_KEY", "PRIMARY_KEY_PD_ONLY", "PRIMARY_KEY_ABSENT_BOTH", "KEY_VERIFIED"}
    assert keys <= set(pdm._DEFAULT_SEVERITY)
    assert len({pdm._DEFAULT_SEVERITY[key] for key in keys}) >= 3


def test_pdm_erwin_parser_has_no_shadowed_duplicate_definitions():
    """
    _parse_entity_key_groups was defined twice; the dead first copy unpacked a
    two-tuple from a function returning a dict and would have raised the moment
    the two were reordered.
    """
    import ast

    source_path = (REPO / "app/validation/pdm_reconcile/pdm_erwin_validator/erwin_parser.py")
    tree = ast.parse(source_path.read_text(encoding="utf-8"))
    names = [node.name for node in tree.body
             if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))]
    duplicates = {name for name in names if names.count(name) > 1}
    assert not duplicates, f"shadowed top-level definitions: {sorted(duplicates)}"


# ═════════════════════════════════════════════════════════════════════════════
#  8. The score is not estimated, predicted or carried from history
# ═════════════════════════════════════════════════════════════════════════════

def test_no_statistical_or_ml_machinery_participates_in_scoring():
    """
    The fidelity number must come from comparing this source against this
    target, not from a model fitted to previous runs.
    """
    banned = ("sklearn", "LinearRegression", "RandomForest", "statsmodels",
              "numpy.polyfit", "torch", "tensorflow")
    scoring_modules = [
        "app/validation/fidelity_stages.py",
        "app/validation/udp_fidelity.py",
        "app/validation/ldm_reconcile/comparator.py",
        "app/validation/cdm_reconcile/comparator.py",
        "app/validation/pdm_reconcile/pdm_erwin_validator/comparator.py",
        "app/reporting/score_audit.py",
    ]
    for relative in scoring_modules:
        path = REPO / relative
        if not path.is_file():
            continue
        source = path.read_text(encoding="utf-8")
        for token in banned:
            assert token not in source, f"{relative} references {token}"


def test_requirements_pull_in_no_ml_dependency():
    requirements = (REPO / "requirements.txt")
    if not requirements.is_file():
        pytest.skip("no requirements.txt in this checkout")
    text = requirements.read_text(encoding="utf-8").lower()
    for package in ("scikit-learn", "sklearn", "tensorflow", "torch", "statsmodels"):
        assert package not in text


# ═════════════════════════════════════════════════════════════════════════════
#  9. The score reconciliation sheet reaches the deliverable
# ═════════════════════════════════════════════════════════════════════════════

@requires_samples
def test_score_reconciliation_sheet_is_written_into_a_workbook(tmp_path):
    openpyxl = pytest.importorskip("openpyxl")
    from app.config.validation_config import LDM_CONFIG
    from app.orchestration.udp_helpers import reconcile
    from app.validation import fidelity_stages

    result = reconcile(str(PD_MODELS["real_estate"]), str(ERWIN_XML["real_estate"]), "LDM")
    stage = fidelity_stages.score(result, fidelity_stages.STAGE_V2, None, "LDM", LDM_CONFIG)

    workbook = openpyxl.Workbook()
    score_audit.write_sheet(workbook, result, stage, LDM_CONFIG, index=0)
    assert score_audit.SHEET_SCORE_AUDIT in workbook.sheetnames

    sheet = workbook[score_audit.SHEET_SCORE_AUDIT]
    text = "\n".join(str(cell.value) for row in sheet.iter_rows() for cell in row
                     if cell.value is not None)
    assert "AGREES" in text
    assert "SOURCE_PRE_EXISTING" in text          # the excluded rows are named
    assert "100 x (1 -" in text                   # the arithmetic is shown
    workbook.close()


def test_score_audit_never_raises_on_a_broken_result():
    """A reporting problem must not fail a pipeline run."""
    openpyxl = pytest.importorskip("openpyxl")

    class _Broken:
        @property
        def findings(self):
            raise RuntimeError("boom")

    workbook = openpyxl.Workbook()
    score_audit.write_sheet(workbook, _Broken(), None, None, index=0)
    workbook.close()


def test_environment_sanity():
    """Guard against a checkout whose sample models silently disappeared."""
    if not _HAVE_SAMPLES:
        pytest.skip("samples absent by design in this checkout")
    for path in list(PD_MODELS.values()) + list(ERWIN_XML.values()):
        assert os.path.getsize(path) > 1024


# ═════════════════════════════════════════════════════════════════════════════
# 10. A fallback V3 must never be captioned as a manually validated export
# ═════════════════════════════════════════════════════════════════════════════

def test_fallback_v3_is_labelled_as_a_fallback_not_as_the_final_export():
    """
    FINAL_XML_FALLBACK_TO_PREPROCESSED defaults to TRUE in
    app/config/settings.py while every call site passes False and every
    docstring calls it off-by-default. An operator who never set it therefore
    gets a "V3" that is the V2 artefact measured a second time — and the
    progression sheet captioned it "SAP PD vs the FINAL manually validated
    erwin XML" regardless.
    """
    from app.reporting import v3_report

    fallback = v3_report.V3ReportRequest(
        result=None, tier_report_path="", outdir="",
        artefacts={"xml_v3_how": "fallback (commented XML)"})
    caption = v3_report._v3_source_caption(fallback)
    assert caption.startswith("FALLBACK")
    assert "NOT evidence" in caption
    assert "manually validated" not in caption.replace("no manually validated", "")

    real = v3_report.V3ReportRequest(
        result=None, tier_report_path="", outdir="",
        artefacts={"xml_v3_how": "existing"})
    assert v3_report._v3_source_caption(real) == v3_report._STAGE_SOURCES["V3"]


def test_a_delta_across_different_component_sets_is_flagged():
    """
    V1 scores a UDP component; V2 drops it when the UDP stage has not run. The
    weights are then renormalised, so part of the V1 -> V2 change comes from
    the basis rather than from the migration. Presenting one number for both
    is what makes a 61-point "improvement" unverifiable.
    """
    from app.reporting import v3_report
    from app.validation.fidelity_stages import StageScore

    same = StageScore(stage="V2", overall=90.0,
                      components={"structural": 90.0, "documentation": 90.0})
    other = StageScore(stage="V1", overall=70.0,
                       components={"structural": 90.0, "documentation": 90.0, "udp": 0.0})
    assert v3_report._measurable(same) != v3_report._measurable(other)

    dropped = StageScore(stage="V2", overall=90.0,
                         components={"structural": 90.0, "udp": None})
    assert "udp" not in v3_report._measurable(dropped)
