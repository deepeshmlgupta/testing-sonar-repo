"""
Direct behavioural test of run_v3.py's per-model processing: verifies the
V1->V2->V3 stage history and the UDP override are actually wired correctly
when V1 ran as a separate earlier process (persisted via stage_state), that
V3 is measured against the XML V3 export in final_xml_models/<tier>/ and
that the manual hand-off ledger is written.
"""

from types import SimpleNamespace
from unittest.mock import patch

from app import run_v3
from app.orchestration import stage_state
from app.validation import fidelity_stages

CW = "app.workflows.conceptual_workflow"


def _fake_result(pd_file="pd.ldm", erwin_file="e.xml", udp_total=373,
                 udp_matched=0, erwin_values_erwin=0):
    fidelity = SimpleNamespace(udp_values_erwin=erwin_values_erwin,
                               udp_definitions_erwin=0)
    return SimpleNamespace(
        pd_file=pd_file, erwin_file=erwin_file, status="PASS",
        fidelity_score=100.0, fidelity_score_raw=100.0,
        structural_fidelity_score=100.0,
        critical_count=0, warning_count=0, info_count=0,
        udp_total=udp_total, udp_matched=udp_matched, udp_missing=udp_total - udp_matched,
        udp_mismatch=0, udp_fidelity_score=(100.0 * udp_matched / udp_total) if udp_total else None,
        udp_fidelity=fidelity, pd_model="model", reconciliation_errors=None,
    )


def _dirs(tmp_path):
    dirs = {
        "initial": tmp_path / "erwinmodels" / "1_initial",
        "preprocessed": tmp_path / "erwinmodels" / "2_preprocessed",
        "final": tmp_path / "erwinmodels" / "3_final",
        "final_xml": tmp_path / "final_xml_models",
        "udp_input": tmp_path / "input_erwin_models",
        "summary": tmp_path / "summary",
    }
    for d in dirs.values():
        d.mkdir(parents=True, exist_ok=True)          # flat stage folders (no xml/ erwin/ sub-dirs)
    (dirs["initial"] / "model.xml").write_text("<model/>")
    return dirs


def _xml_v3(dirs):
    path = dirs["final_xml"] / "ldm" / "model.xml"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("<model/>")
    return path


def _save_v1(dirs):
    v1_score = fidelity_stages.StageScore(
        stage="V1", overall=40.0, components={"structural": 40.0, "udp": None},
        weights={"structural": 1.0}, notes=[])
    stage_state.save_v1(dirs, "model", "reports/model_V1.xlsx", v1_score)


def test_v2_and_v3_apply_the_same_udp_override_when_no_final_xml(tmp_path):
    dirs = _dirs(tmp_path)
    _save_v1(dirs)
    v2_result = _fake_result(udp_total=373, udp_matched=0, erwin_values_erwin=0)

    # A missing XML V3 is a hard stop by default (it gates the Mart publish);
    # this test is about the DRY-RUN fallback, so opt into it explicitly.
    def _settings(name, default):
        return True if name == "FINAL_XML_FALLBACK_TO_PREPROCESSED" else default

    with patch(f"{CW}.reconcile", return_value=v2_result), \
         patch(f"{CW}.validate_erwin_xml", return_value=(True, "")), \
         patch(f"{CW}.run_preprocessing", return_value=dirs["preprocessed"] / "model.xml"), \
         patch(f"{CW}.udp_stage_override", return_value=97.5) as override_v2, \
         patch("app.run_v3.udp_stage_override", return_value=97.5) as override_v3, \
         patch("app.run_v3.route_model"), \
         patch.object(run_v3, "get_setting", side_effect=_settings), \
         patch(f"{CW}.get_setting", side_effect=_settings):
        record = run_v3._process_conceptual(tmp_path / "model.ldm", "model", "LDM", dirs)

    assert record is not None
    # Both V2 and V3 must have asked for (and received) the same override.
    assert override_v2.call_count == 1 and override_v3.call_count == 1
    assert record.v2_result.stage_scores["V2"].components["udp"] == 97.5
    assert record.result.stage_scores["V3"].components["udp"] == 97.5
    assert record.artefacts["xml_v3_how"].startswith("fallback")
    assert any("No final erwin XML export" in note for note in record.notes)

    # The V1 score persisted by run_v1.py must be visible in V3's history.
    assert record.result.stage_scores["V1"].overall == 40.0
    assert "V2" in record.result.stage_scores
    assert stage_state.stage_status(dirs, "model", stage_state.STAGE_V3_XML) == stage_state.STATUS_WAITING


def test_missing_final_xml_is_a_hard_stop_when_fallback_disabled(tmp_path):
    dirs = _dirs(tmp_path)
    _save_v1(dirs)

    def _strict(name, default):
        return False if name == "FINAL_XML_FALLBACK_TO_PREPROCESSED" else default

    with patch(f"{CW}.reconcile", return_value=_fake_result()), \
         patch(f"{CW}.validate_erwin_xml", return_value=(True, "")), \
         patch(f"{CW}.run_preprocessing", return_value=dirs["preprocessed"] / "model.xml"), \
         patch.object(run_v3, "get_setting", side_effect=_strict), \
         patch(f"{CW}.get_setting", side_effect=_strict), \
         patch("app.run_v3.route_model") as route:
        record = run_v3._process_conceptual(tmp_path / "model.ldm", "model", "LDM", dirs)
    assert record is None
    route.assert_not_called()
    assert stage_state.stage_status(dirs, "model", stage_state.STAGE_V3_XML) == stage_state.STATUS_WAITING
    assert any("final_xml_models" in line for line in stage_state.pending_actions(dirs, "model"))
    assert not list(dirs["final"].iterdir())


def test_v3_carries_v1_and_v2_history_when_a_final_xml_exists(tmp_path):
    """
    V3 measures a DIFFERENT file (the XML V3 export) than V2 did, so
    record.result is a different object than record.v2_result. Its
    stage_scores must still carry V1 and V2, and its own UDP component must
    use the same override rule as V2.
    """
    dirs = _dirs(tmp_path)
    _save_v1(dirs)
    xml_v3 = _xml_v3(dirs)
    v2_result = _fake_result(erwin_file="preprocessed.xml", udp_total=373, udp_matched=0)
    v3_result = _fake_result(erwin_file="final_validated.xml", udp_total=373, udp_matched=0)
    calls = {"n": 0}

    def fake_reconcile(model_path, erwin_xml, model_type):
        calls["n"] += 1
        return v2_result if calls["n"] == 1 else v3_result

    with patch(f"{CW}.reconcile", side_effect=fake_reconcile), \
         patch(f"{CW}.validate_erwin_xml", return_value=(True, "")), \
         patch(f"{CW}.run_preprocessing", return_value=dirs["preprocessed"] / "model.xml"), \
         patch(f"{CW}.udp_stage_override", return_value=97.5) as mock_override, \
         patch("app.run_v3.route_model"):
        record = run_v3._process_conceptual(tmp_path / "model.ldm", "model", "LDM", dirs)

    assert record is not None
    assert record.result is not record.v2_result
    assert mock_override.call_count == 2
    assert record.result.stage_scores["V2"].components["udp"] == 97.5
    assert record.result.stage_scores["V3"].components["udp"] == 97.5
    assert record.result.stage_scores["V1"].overall == 40.0
    assert record.artefacts["xml_v3"] == str(xml_v3)
    # the hand-off ledger shows every stage of THIS model
    assert stage_state.stage_status(dirs, "model", stage_state.STAGE_V3_XML) == stage_state.STATUS_VALIDATED
    assert stage_state.stage_status(dirs, "model", stage_state.STAGE_V3_FIDELITY) == stage_state.STATUS_READY
    v3_event = stage_state.history(dirs, "model")[-1]
    assert v3_event["stage"] == stage_state.STAGE_V3_FIDELITY and v3_event["timestamp"]


def test_real_override_logic_end_to_end_with_a_real_final_xml(tmp_path):
    """
    Same as above, but with udp_stage_override / erwin_xml_carries_udps /
    udp_engine_pass_rate left UNMOCKED — only the on-disk engine workbook
    lookup is faked. This is the actual production code path.
    """
    dirs = _dirs(tmp_path)
    _save_v1(dirs)
    _xml_v3(dirs)
    v2_result = _fake_result(erwin_file="preprocessed.xml", udp_total=373, udp_matched=0, erwin_values_erwin=0)
    v3_result = _fake_result(erwin_file="final_validated.xml", udp_total=373, udp_matched=0, erwin_values_erwin=0)
    calls = {"n": 0}

    def fake_reconcile(model_path, erwin_xml, model_type):
        calls["n"] += 1
        return v2_result if calls["n"] == 1 else v3_result

    with patch(f"{CW}.reconcile", side_effect=fake_reconcile), \
         patch(f"{CW}.validate_erwin_xml", return_value=(True, "")), \
         patch(f"{CW}.run_preprocessing", return_value=dirs["preprocessed"] / "model.xml"), \
         patch("app.reporting.report_layout.udp_comparison_counts",
               return_value={"passed": 349, "comparable": 349, "pass_rate": 100.0,
                             "source": "model_UDP_Comparison.xlsx"}), \
         patch("app.run_v3.route_model"):
        record = run_v3._process_conceptual(tmp_path / "model.ldm", "model", "LDM", dirs)

    assert record is not None
    v2_udp = record.v2_result.stage_scores["V2"].components["udp"]
    v3_udp = record.result.stage_scores["V3"].components["udp"]
    assert v2_udp == v3_udp == 100.0


def test_final_xml_of_another_model_is_refused(tmp_path):
    dirs = _dirs(tmp_path)
    _save_v1(dirs)
    _xml_v3(dirs)
    own = _fake_result(erwin_file="preprocessed.xml")
    own.entities_pd, own.entities_matched = 5, 5
    stranger = _fake_result(erwin_file="other_model.xml")
    stranger.entities_pd, stranger.entities_matched = 5, 0
    calls = {"n": 0}

    def fake_reconcile(model_path, erwin_xml, model_type):
        calls["n"] += 1
        return own if calls["n"] == 1 else stranger

    with patch(f"{CW}.reconcile", side_effect=fake_reconcile), \
         patch(f"{CW}.validate_erwin_xml", return_value=(True, "")), \
         patch(f"{CW}.run_preprocessing", return_value=dirs["preprocessed"] / "model.xml"), \
         patch("app.run_v3.route_model") as route:
        record = run_v3._process_conceptual(tmp_path / "model.ldm", "model", "LDM", dirs)

    assert record is None
    route.assert_not_called()
    assert stage_state.stage_status(dirs, "model", stage_state.STAGE_V3_XML) == stage_state.STATUS_FAILED
    assert "different model" in stage_state.history(dirs, "model")[-1]["message"]
