import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.validation.ldm_reconcile.comparator import (
    ValidationResult as LDMValidationResult,
)
from app.validation.ldm_reconcile.comparator import (
    _compare_business_rules as ldm_compare_rules,
)
from app.validation.ldm_reconcile.comparator import (
    _compare_packages_and_subject_areas as ldm_compare_packages,
)
from app.validation.ldm_reconcile.ldm_model import BusinessRule, LDMModel, Package


class BusinessRulesAndPackagesTests(unittest.TestCase):
    def test_business_rule_matching(self):
        pd_model = LDMModel(source_file="m.ldm", model_name="M")
        erwin_model = LDMModel(source_file="m.xml", model_name="M")

        rule1 = BusinessRule(name="Valid Age", code="VAL_AGE", expression="age >= 18", definition="Age check")
        rule2 = BusinessRule(name="Valid Age", code="VAL_AGE", expression="age >= 18", definition="Age check")
        pd_model.business_rules.append(rule1)
        erwin_model.business_rules.append(rule2)

        result = LDMValidationResult(pd_file="m.ldm", erwin_file="m.xml")
        ldm_compare_rules(result, pd_model, erwin_model)

        verified = [f for f in result.findings if f.category == "BUSINESS_RULE_VERIFIED"]
        self.assertEqual(1, len(verified))
        self.assertEqual("VERIFIED", verified[0].severity)

    def test_business_rule_expression_differs(self):
        pd_model = LDMModel(source_file="m.ldm", model_name="M")
        erwin_model = LDMModel(source_file="m.xml", model_name="M")

        rule1 = BusinessRule(name="Credit Limit", code="CR_LIM", expression="limit <= 50000")
        rule2 = BusinessRule(name="Credit Limit", code="CR_LIM", expression="limit <= 100000")
        pd_model.business_rules.append(rule1)
        erwin_model.business_rules.append(rule2)

        result = LDMValidationResult(pd_file="m.ldm", erwin_file="m.xml")
        ldm_compare_rules(result, pd_model, erwin_model)

        diffs = [f for f in result.findings if f.category in ("BUSINESS_RULE_EXPRESSION", "BUSINESS_RULE")]
        self.assertEqual(1, len(diffs))
        self.assertEqual("WARNING", diffs[0].severity)

    def test_package_hierarchy_matching(self):
        pd_model = LDMModel(source_file="m.ldm", model_name="M")
        erwin_model = LDMModel(source_file="m.xml", model_name="M")

        pkg_pd = Package(name="Trading", code="TRADING", parent="Energy")
        pkg_erwin = Package(name="Trading", code="TRADING", parent="Energy")
        pd_model.packages.append(pkg_pd)
        erwin_model.packages.append(pkg_erwin)

        result = LDMValidationResult(pd_file="m.ldm", erwin_file="m.xml")
        ldm_compare_packages(result, pd_model, erwin_model)

        verified = [f for f in result.findings if f.category == "SUBJECT_AREA" and f.severity == "VERIFIED"]
        self.assertEqual(1, len(verified))


if __name__ == "__main__":
    unittest.main()
