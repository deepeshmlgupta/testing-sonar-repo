import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.validation.cdm_reconcile.cdm_model import Attribute as CDMAttribute
from app.validation.cdm_reconcile.comparator import (
    ValidationResult as CDMValidationResult,
)
from app.validation.cdm_reconcile.comparator import (
    _check_attribute_data_type as cdm_check_data_type,
)
from app.validation.ldm_reconcile.comparator import (
    ValidationResult as LDMValidationResult,
)
from app.validation.ldm_reconcile.comparator import (
    _check_attribute_data_type as ldm_check_data_type,
)
from app.validation.ldm_reconcile.ldm_model import Attribute as LDMAttribute


class DataTypeMismatchTests(unittest.TestCase):
    def test_ldm_data_type_mismatch_is_critical_and_fails(self):
        result = LDMValidationResult(pd_file="model.ldm", erwin_file="model.xml")
        pd_attr = LDMAttribute(name="Amount", code="AMOUNT", data_type="DECIMAL(10,2)")
        erwin_attr = LDMAttribute(name="Amount", code="AMOUNT", data_type="VARCHAR(50)")

        ldm_check_data_type(result, "CUSTOMER", "Amount", pd_attr, erwin_attr)
        result.finalise()

        data_type_findings = [f for f in result.findings if f.category == "DATA_TYPE"]
        self.assertEqual(1, len(data_type_findings))
        self.assertEqual("CRITICAL", data_type_findings[0].severity)
        self.assertEqual(1, result.critical_count)
        self.assertEqual("FAIL", result.status)

    def test_cdm_data_type_mismatch_is_critical_and_fails(self):
        result = CDMValidationResult(pd_file="model.cdm", erwin_file="model.xml")
        pd_attr = CDMAttribute(name="Code", code="CODE", data_type="INTEGER")
        erwin_attr = CDMAttribute(name="Code", code="CODE", data_type="CHAR(10)")

        cdm_check_data_type(result, "ORDER", "Code", pd_attr, erwin_attr)
        result.finalise()

        data_type_findings = [f for f in result.findings if f.category == "DATA_TYPE"]
        self.assertEqual(1, len(data_type_findings))
        self.assertEqual("CRITICAL", data_type_findings[0].severity)
        self.assertEqual(1, result.critical_count)
        self.assertEqual("FAIL", result.status)


if __name__ == "__main__":
    unittest.main()
