"""
Tests for the erwinDMAPI -MitiLoad probe (tools/mitiload_probe.py).

The probe itself cannot be executed here — it needs Windows and an erwin
installation — so these lock the parts that CAN go wrong on any host, and in
particular the one that would be expensive: the probe must never run the
converter against sappdmodels/, because -MitiLoad writes its output and its
logs next to the source files and those models cannot be regenerated.
"""

import platform
from pathlib import Path

from tools import mitiload_probe as probe

REPO = Path(__file__).resolve().parents[1]


def test_it_refuses_to_run_off_windows():
    if platform.system() == "Windows":
        return
    assert probe.main([]) == 3


def test_it_stages_copies_and_never_touches_the_source_folder(tmp_path):
    source = tmp_path / "sappdmodels" / "ldm"
    source.mkdir(parents=True)
    model = source / "a_model.ldm"
    model.write_text("<Model/>", encoding="utf-8")

    scratch = tmp_path / "scratch"
    original_root = probe.PD_ROOT
    probe.PD_ROOT = tmp_path / "sappdmodels"
    try:
        staged = probe._stage("ldm", [model], scratch)
    finally:
        probe.PD_ROOT = original_root

    assert staged != source
    assert (staged / "a_model.ldm").read_text(encoding="utf-8") == "<Model/>"
    # the original is untouched and alone in its folder
    assert [p.name for p in source.iterdir()] == ["a_model.ldm"]


def test_all_models_of_a_tier_are_staged_together(tmp_path):
    """
    erwin documents shortcut resolution failing when cross-referenced models
    are not migrated together, so a tier goes into ONE folder.
    """
    scratch = tmp_path / "scratch"
    models = []
    for name in ("one.ldm", "two.ldm", "three.ldm"):
        path = tmp_path / name
        path.write_text("<Model/>", encoding="utf-8")
        models.append(path)
    staged = probe._stage("ldm", models, scratch)
    assert sorted(p.name for p in staged.iterdir()) == ["one.ldm", "three.ldm", "two.ldm"]


def test_missing_executable_is_reported_not_guessed(tmp_path):
    assert probe.find_erwin_api(str(tmp_path)) is None
    fake = tmp_path / "erwinDMAPI.exe"
    fake.write_text("", encoding="utf-8")
    assert probe.find_erwin_api(str(tmp_path)) == fake
    assert probe.find_erwin_api(str(fake)) == fake


def test_error_logs_are_printed_in_full(tmp_path, capsys):
    (tmp_path / "model_ERR1.txt").write_text(
        "WARNING: attribute FOO skipped\nWARNING: type remapped", encoding="utf-8")
    (tmp_path / "other_ERR1.txt").write_text("", encoding="utf-8")
    assert probe._dump_error_logs(tmp_path) == 2
    printed = capsys.readouterr().out
    assert "attribute FOO skipped" in printed
    assert "type remapped" in printed
    assert "nothing was flagged" in printed


def test_no_logs_is_stated_rather_than_assumed_clean(tmp_path, capsys):
    assert probe._dump_error_logs(tmp_path) == 0
    assert "no _ERR1.txt" in capsys.readouterr().out


def test_only_new_erwin_files_are_reported(tmp_path):
    (tmp_path / "pre_existing.erwin").write_text("", encoding="utf-8")
    before = {"pre_existing.erwin": 0.0}
    (tmp_path / "fresh.erwin").write_text("", encoding="utf-8")
    (tmp_path / "ignored.txt").write_text("", encoding="utf-8")
    produced = probe._report_outputs(tmp_path, before)
    assert [p.name for p in produced] == ["fresh.erwin"]
