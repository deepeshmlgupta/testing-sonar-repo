import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.validation.cdm_reconcile.cdm_model import Attribute as CDMAttribute
from app.validation.cdm_reconcile.comparator import (
    ValidationResult as CDMValidationResult,
)
from app.validation.cdm_reconcile.comparator import (
    _check_attribute_domain as cdm_check_domain,
)
from app.validation.ldm_reconcile.comparator import (
    ValidationResult as LDMValidationResult,
)
from app.validation.ldm_reconcile.comparator import (
    _check_attribute_domain as ldm_check_domain,
)
from app.validation.ldm_reconcile.ldm_model import Attribute as LDMAttribute


class DomainAwareReconciliationTests(unittest.TestCase):
    def test_domain_preserved_intact(self):
        result = LDMValidationResult(pd_file="m.ldm", erwin_file="m.xml")
        pd_attr = LDMAttribute(name="Amount", code="AMOUNT", domain="Currency_Amount", data_type="DECIMAL(18,2)")
        erwin_attr = LDMAttribute(name="Amount", code="AMOUNT", domain="Currency_Amount", data_type="DECIMAL(18,2)")

        ldm_check_domain(result, "ACCOUNT", "AMOUNT", pd_attr, erwin_attr)
        findings = [f for f in result.findings if f.category in ("DOMAIN_PRESERVED", "DOMAIN_VERIFIED")]
        self.assertEqual(1, len(findings))
        self.assertEqual("VERIFIED", findings[0].severity)

    def test_domain_lost_but_datatype_semantically_preserved(self):
        result = LDMValidationResult(pd_file="m.ldm", erwin_file="m.xml")
        # In PD, domain is Identifier; in erwin, domain was not mapped but datatype is BIGINT
        pd_attr = LDMAttribute(name="Cust_ID", code="CUST_ID", domain="Identifier", data_type="NUMBER(18,0)")
        erwin_attr = LDMAttribute(name="Cust_ID", code="CUST_ID", domain="", data_type="BIGINT")

        ldm_check_domain(result, "CUSTOMER", "CUST_ID", pd_attr, erwin_attr)
        findings = [f for f in result.findings if f.category == "DOMAIN_SEMANTIC_MATCH"]
        self.assertEqual(1, len(findings))
        self.assertEqual("VERIFIED", findings[0].severity)

    def test_domain_and_datatype_both_differ_yields_mismatch(self):
        result = CDMValidationResult(pd_file="m.cdm", erwin_file="m.xml")
        pd_attr = CDMAttribute(name="Status", code="STATUS", domain="Status_Code", data_type="CHAR(1)")
        erwin_attr = CDMAttribute(name="Status", code="STATUS", domain="Other_Domain", data_type="INTEGER")

        cdm_check_domain(result, "ORDER", "STATUS", pd_attr, erwin_attr)
        findings = [f for f in result.findings if f.category in ("DOMAIN_MISMATCH", "DOMAIN")]
        self.assertEqual(1, len(findings))
        self.assertEqual("WARNING", findings[0].severity)


if __name__ == "__main__":
    unittest.main()
