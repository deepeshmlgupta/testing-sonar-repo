"""
Regression tests for preprocessing/scripts/pd_comment_to_erwin_note.py

Covers the two concrete defects that let a SAP PD Comment silently fail to
land in erwin:
  1. An existing but BLANK erwin Note_List was treated as "already has a
     note" and blocked migration under the default --on-existing skip.
  2. Entity/attribute matching was exact-string only, so a name/code that
     differed only in casing or punctuation between SAP PD and erwin never
     matched and its comment was silently dropped.
"""

import importlib.util
import sys
from pathlib import Path

_MODULE_PATH = (Path(__file__).resolve().parent.parent / "app" / "preprocessing" / "scripts"
               / "pd_comment_to_erwin_note.py")
_spec = importlib.util.spec_from_file_location("pd_comment_to_erwin_note", _MODULE_PATH)
pcen = importlib.util.module_from_spec(_spec)
sys.modules[_spec.name] = pcen
_spec.loader.exec_module(pcen)


ERWIN_HEADER = b"<Model><Entities>"
ERWIN_FOOTER = b"</Entities></Model>"


def _entity_props(name, physical_name, note_array=b""):
    return (
        b"<EntityProps><Name>%b</Name><Physical_Name>%b</Physical_Name>"
        b"<User_Formatted_Physical_Name>%b</User_Formatted_Physical_Name>"
        b"%b</EntityProps>"
        % (name, physical_name, physical_name, note_array)
    )


def test_blank_existing_note_does_not_block_migration():
    blank_note = (
        b'<Note_List_Array><Note_List HandleNonPrintableChar="Y" index="0">'
        b"1" + pcen.SEP.encode() + pcen.SEP.encode() + pcen.SEP.encode()
        + pcen.SEP.encode() + pcen.SEP.encode() + pcen.SEP.encode()
        + pcen.SEP.encode() + b"F" + pcen.SEP.encode() + pcen.SEP.encode()
        + pcen.SEP.encode() + b"{GUID}" + pcen.SEP.encode()
        + b"</Note_List></Note_List_Array>"
    )
    raw = ERWIN_HEADER + _entity_props(b"CUSTOMER", b"CUSTOMER", blank_note) + ERWIN_FOOTER

    objects = pcen.scan_erwin(raw)
    assert len(objects) == 1
    assert objects[0].existing_notes == 0, "a blank placeholder note must not count as a real note"


def test_real_existing_note_is_still_detected():
    real_note = (
        b'<Note_List_Array><Note_List HandleNonPrintableChar="Y" index="0">'
        b"1" + pcen.SEP.encode() + pcen.SEP.encode() + pcen.SEP.encode()
        + pcen.SEP.encode() + pcen.SEP.encode() + pcen.SEP.encode()
        + b"Already documented" + pcen.SEP.encode() + b"F" + pcen.SEP.encode()
        + pcen.SEP.encode() + b"{GUID}" + pcen.SEP.encode()
        + b"</Note_List></Note_List_Array>"
    )
    raw = ERWIN_HEADER + _entity_props(b"CUSTOMER", b"CUSTOMER", real_note) + ERWIN_FOOTER

    objects = pcen.scan_erwin(raw)
    assert objects[0].existing_notes == 1


def test_case_and_punctuation_drift_still_matches():
    pd = pcen.PDModel()
    pd.entities[("Business Customer", "BUSINESS_CUSTOMER")] = "A real business customer entity."

    raw = ERWIN_HEADER + _entity_props(b"BusinessCustomer", b"business-customer") + ERWIN_FOOTER
    objects = pcen.scan_erwin(raw)

    matches, unmatched = pcen.match_objects(pd, objects)
    assert not unmatched
    comment, tier = matches[id(objects[0])]
    assert comment == "A real business customer entity."
    assert tier == 4


def test_migration_writes_note_when_matched_with_no_existing_note():
    pd = pcen.PDModel()
    pd.entities[("CUSTOMER", "CUSTOMER")] = "Holds customer master data."

    raw = ERWIN_HEADER + _entity_props(b"CUSTOMER", b"CUSTOMER") + ERWIN_FOOTER
    objects = pcen.scan_erwin(raw)
    matches, unmatched = pcen.match_objects(pd, objects)
    assert not unmatched

    obj = objects[0]
    comment, _ = matches[id(obj)]
    start = obj.anchor_end if obj.anchor_end is not None else obj.props_close
    assert start is not None

    record = pcen.build_note_record(comment, "TEST", "escaped-lf")
    payload = pcen.build_note_array([record]).encode("utf-8")
    out = bytearray(raw)
    out[start:start] = payload

    assert b"<Note_List_Array>" in out
    assert b"Holds customer master data." in out
