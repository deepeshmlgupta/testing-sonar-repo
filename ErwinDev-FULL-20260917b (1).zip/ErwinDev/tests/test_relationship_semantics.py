import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.validation.ldm_reconcile.comparator import (
    ValidationResult as LDMValidationResult,
)
from app.validation.ldm_reconcile.comparator import (
    _compare_relationship_pair as ldm_compare_rel,
)
from app.validation.ldm_reconcile.ldm_model import Relationship, RelationshipEnd


class RelationshipSemanticsTests(unittest.TestCase):
    def test_relationship_verified_semantic_match(self):
        result = LDMValidationResult(pd_file="m.ldm", erwin_file="m.xml")
        pd_rel = Relationship(
            name="Places", code="PLACES",
            end1=RelationshipEnd(entity="CUSTOMER", role="places", cardinality="0,n", mandatory=False),
            end2=RelationshipEnd(entity="ORDER", role="placed by", cardinality="1,1", mandatory=True),
        )
        erwin_rel = Relationship(
            name="Places", code="PLACES",
            end1=RelationshipEnd(entity="CUSTOMER", role="places", cardinality="0,n", mandatory=False),
            end2=RelationshipEnd(entity="ORDER", role="placed by", cardinality="1,1", mandatory=True),
        )

        ldm_compare_rel(result, pd_rel, erwin_rel, "name")
        verified = [f for f in result.findings if f.category == "RELATIONSHIP_VERIFIED"]
        self.assertEqual(1, len(verified))
        self.assertEqual("VERIFIED", verified[0].severity)

    def test_relationship_cardinality_changed(self):
        result = LDMValidationResult(pd_file="m.ldm", erwin_file="m.xml")
        pd_rel = Relationship(
            name="Owns", code="OWNS",
            end1=RelationshipEnd(entity="CUSTOMER", cardinality="0,n"),
            end2=RelationshipEnd(entity="ACCOUNT", cardinality="1,1"),
        )
        erwin_rel = Relationship(
            name="Owns", code="OWNS",
            end1=RelationshipEnd(entity="CUSTOMER", cardinality="0,1"),
            end2=RelationshipEnd(entity="ACCOUNT", cardinality="1,1"),
        )

        ldm_compare_rel(result, pd_rel, erwin_rel, "name")
        mismatches = [f for f in result.findings if f.category == "CARDINALITY"]
        self.assertEqual(1, len(mismatches))
        self.assertEqual("CRITICAL", mismatches[0].severity)


if __name__ == "__main__":
    unittest.main()
