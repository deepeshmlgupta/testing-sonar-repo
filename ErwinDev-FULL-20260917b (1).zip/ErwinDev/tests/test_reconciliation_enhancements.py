"""Tests for the Task 1-6 automated reconciliation modules."""

from app.validation import (
    cardinality_normalizer,
    comment_resolution_engine,
    model_metadata_resolver,
    relationship_dependency_mapper,
)

# ─── Task 1/2: relationship_dependency_mapper ─────────────────────────────────

def test_dependent_matches_identifying_is_pass():
    result = relationship_dependency_mapper.reconcile(True, True)
    assert result.status == relationship_dependency_mapper.STATUS_PASS
    assert result.semantically_equivalent
    assert result.pd_label == "Dependent"
    assert result.erwin_label == "Identifying"


def test_independent_matches_non_identifying_is_pass():
    result = relationship_dependency_mapper.reconcile(False, False)
    assert result.status == relationship_dependency_mapper.STATUS_PASS
    assert result.erwin_label == "Non-Identifying"


def test_dependent_vs_independent_is_genuine_mismatch():
    result = relationship_dependency_mapper.reconcile(True, False)
    assert result.status == relationship_dependency_mapper.STATUS_MISMATCH
    assert not result.semantically_equivalent


def test_direction_reversal_reconciles_instead_of_mismatch():
    # PD dependent=True, straight erwin end says False, but the OTHER erwin
    # end (FK ownership read from the opposite direction) says True.
    result = relationship_dependency_mapper.reconcile(
        True, False, reversed_erwin_identifying=True)
    assert result.status == relationship_dependency_mapper.STATUS_DIRECTION_RECONCILED
    assert result.semantically_equivalent


# ─── Task 3: cardinality_normalizer ───────────────────────────────────────────

def test_numeric_and_dotted_variants_normalize_the_same():
    assert cardinality_normalizer.normalize("1") == cardinality_normalizer.ONE_TO_ONE
    assert cardinality_normalizer.normalize("1..1") == cardinality_normalizer.ONE_TO_ONE
    assert cardinality_normalizer.normalize("0,1") == cardinality_normalizer.ZERO_OR_ONE
    assert cardinality_normalizer.normalize("0..1") == cardinality_normalizer.ZERO_OR_ONE
    assert cardinality_normalizer.normalize("1,N") == cardinality_normalizer.ONE_TO_MANY
    assert cardinality_normalizer.normalize("1..*") == cardinality_normalizer.ONE_TO_MANY


def test_compare_reports_semantic_match_across_notations():
    row = cardinality_normalizer.compare("1..1", "1,1")
    assert row.normalized_source == row.normalized_target == cardinality_normalizer.ONE_TO_ONE
    assert row.semantic_match


def test_compare_reports_genuine_mismatch():
    row = cardinality_normalizer.compare("1..1", "0..1")
    assert not row.semantic_match


# ─── Task 4: model_metadata_resolver ──────────────────────────────────────────

def test_model_code_found_under_erwin_model_name():
    resolution = model_metadata_resolver.resolve_model_code(
        "TRADED_ASSET_PRODUCT", "Airport", erwin_name="TRADED_ASSET_PRODUCT")
    assert resolution.located
    assert resolution.located_in == model_metadata_resolver.LOCATED_IN_MODEL_NAME


def test_model_code_found_in_udp_candidate():
    resolution = model_metadata_resolver.resolve_model_code(
        "TRADED_ASSET_PRODUCT", "Airport", erwin_name="Airport",
        udp_candidates=["TRADED_ASSET_PRODUCT"])
    assert resolution.located
    assert resolution.located_in == model_metadata_resolver.LOCATED_IN_UDP


def test_model_code_genuinely_not_found():
    resolution = model_metadata_resolver.resolve_model_code(
        "TRADED_ASSET_PRODUCT", "Airport", erwin_name="Airport")
    assert not resolution.located
    assert resolution.located_in == model_metadata_resolver.NOT_FOUND


# ─── Task 5/6: comment_resolution_engine ──────────────────────────────────────

def test_comment_found_in_note_is_not_missing():
    resolution = comment_resolution_engine.classify(
        "Business meaning of this field.", "Business meaning of this field.")
    assert resolution.located
    assert resolution.located_in == comment_resolution_engine.LOCATED_IN_NOTE


def test_comment_found_in_definition_fallback():
    resolution = comment_resolution_engine.classify(
        "Business meaning of this field.", "",
        definition="Business meaning of this field.")
    assert resolution.located
    assert resolution.located_in == comment_resolution_engine.LOCATED_IN_DEFINITION
    assert resolution.root_cause == comment_resolution_engine.ROOT_CAUSE_DIFFERENT_PROPERTY


def test_comment_found_in_udp_fallback():
    resolution = comment_resolution_engine.classify(
        "Business meaning of this field.", "", udp_value="Business meaning of this field.")
    assert resolution.located
    assert resolution.located_in == comment_resolution_engine.LOCATED_IN_UDP
    assert resolution.root_cause == comment_resolution_engine.ROOT_CAUSE_FOUND_IN_UDP


def test_comment_truncated_is_classified_not_lost():
    long_comment = "Business meaning of this field, including edge cases."
    resolution = comment_resolution_engine.classify(long_comment, "", definition=long_comment[:30])
    assert resolution.located
    assert resolution.root_cause == comment_resolution_engine.ROOT_CAUSE_TRUNCATED


def test_comment_encoding_difference_is_classified_not_lost():
    resolution = comment_resolution_engine.classify("Café résumé", "", definition="Cafe resume")
    assert resolution.located
    assert resolution.root_cause == comment_resolution_engine.ROOT_CAUSE_ENCODING_DIFFERENCE


def test_comment_genuinely_not_migrated():
    resolution = comment_resolution_engine.classify("Business meaning of this field.", "")
    assert not resolution.located
    assert resolution.root_cause == comment_resolution_engine.ROOT_CAUSE_NOT_MIGRATED


def test_whitespace_only_comment_is_not_a_real_migration_gap():
    resolution = comment_resolution_engine.classify("   ", "")
    assert resolution.located
    assert resolution.root_cause == ""
