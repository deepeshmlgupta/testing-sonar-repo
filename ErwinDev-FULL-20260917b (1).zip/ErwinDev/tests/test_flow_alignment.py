"""
Regression tests for the flow-alignment changes:

  * flat stage layout (1_initial / 2_preprocessed / 3_final + the manual
    hand-off folders) with legacy fallback (orchestration/stage_paths.py)
  * erwin conversion wrapper (erwin/erwin_converter.py); existing / missing /
    disabled cases. It is reached only through the Step 2 hand-off gate
    (erwin/erwin_handoff.py, covered by tests/test_erwin_handoff.py), never
    from the stage scripts themselves.
  * UDP phase injects into the EXPLICIT handed-off .erwin and reads back the
    enriched output first
  * gate PASS copies the enriched .erwin + XML V3 into 3_final
  * a missing XML V3 is a hard stop unless the dry-run fallback is set
  * pipeline ledger lines (model + skip)
  * session_manager.file_lock actually locks
"""

import json
import os
import sys
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.erwin import erwin_converter
from app.orchestration import pipeline_ledger
from app.orchestration.model_record import DEST_FINAL, ModelRecord
from app.orchestration.stage_paths import STAGE_KEYS, StagePaths, stage_folders
from app.utils.session_manager import append_jsonl_line_safely, file_lock
from app.validation import fidelity_stages, udp_flow
from app.workflows import promotion_routing


def _dirs(root: Path):
    root = Path(root)
    dirs = {
        "initial": root / "1_initial", "preprocessed": root / "2_preprocessed",
        "final": root / "3_final", "final_xml": root / "final_xml_models",
        "udp_input": root / "input_erwin_models",
        "summary": root / "batch_summary",
    }
    dirs["stages"] = stage_folders(root, dirs["final_xml"], dirs["udp_input"])
    for key in ("initial", "preprocessed", "final"):
        for sub in ("xml", "erwin"):            # pre-flat legacy sub-folders, for the fallback tests
            (dirs[key] / sub).mkdir(parents=True, exist_ok=True)
    for path in dirs["stages"].values():
        path.mkdir(parents=True, exist_ok=True)
    (dirs["final_xml"] / "ldm").mkdir(parents=True, exist_ok=True)
    (dirs["summary"] / "audit").mkdir(parents=True, exist_ok=True)
    return dirs


class StagePathsTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dirs = _dirs(self.tmp.name)
        self.stages = StagePaths(self.dirs)

    def tearDown(self):
        self.tmp.cleanup()

    def test_flat_layout_and_manual_handoff_folders(self):
        self.assertEqual(set(STAGE_KEYS), set(self.stages.stages))
        self.assertTrue(str(self.stages.xml_v1("m")).endswith("1_initial/m.xml"))
        self.assertTrue(str(self.stages.xml_v2("m")).endswith("2_preprocessed/m.xml"))
        self.assertTrue(str(self.stages.erwin_v1("m")).endswith("input_erwin_models/m.erwin"), "manual hand-off")
        self.assertTrue(str(self.stages.erwin_v2("m")).endswith("2_preprocessed/m.erwin"))
        self.assertTrue(str(self.stages.xml_v3("m")).endswith("final_xml_models/m.xml"), "manual export")
        self.assertTrue(str(StagePaths(self.dirs, "LDM").xml_v3("m")).endswith("final_xml_models/ldm/m.xml"))
        self.assertTrue(str(self.stages.erwin_v3("m")).endswith("3_final/m.erwin"))

    def test_stage_folder_wins_over_legacy(self):
        (self.dirs["initial"] / "xml" / "m.xml").write_text("<legacy/>")
        self.assertEqual(self.dirs["initial"] / "xml" / "m.xml", self.stages.find_xml_v1("m"))
        self.stages.xml_v1("m").write_text("<new/>")
        self.assertEqual(self.stages.xml_v1("m"), self.stages.find_xml_v1("m"))

    def test_legacy_locations_for_erwin_v1_and_xml_v3(self):
        (self.dirs["initial"] / "erwin" / "m.erwin").write_bytes(b"x")
        self.assertEqual(self.dirs["initial"] / "erwin" / "m.erwin", self.stages.find_erwin_v1("m"))
        (self.dirs["final_xml"] / "ldm" / "m.xml").write_text("<x/>")
        self.assertEqual(self.dirs["final_xml"] / "ldm" / "m.xml", self.stages.find_xml_v3("m"))
        # the retired six-folder names are still searched as inputs
        six = Path(self.dirs["initial"]).parent / "1_xml_v1"
        six.mkdir()
        (six / "old.xml").write_text("<x/>")
        self.assertEqual(six / "old.xml", self.stages.find_xml_v1("old"))

    def test_legacy_fallback_can_be_disabled(self):
        (self.dirs["initial"] / "xml" / "m.xml").write_text("<legacy/>")
        with patch("app.orchestration.stage_paths.get_setting",
                   side_effect=lambda n, d: False if n == "LEGACY_STAGE_FALLBACK" else d):
            self.assertIsNone(StagePaths(self.dirs).find_xml_v1("m"))


class ErwinConverterTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def test_existing_valid_artifact_is_returned_untouched(self):
        dst = self.root / "m.xml"
        dst.write_text("<erwin><a/></erwin>")
        outcome = erwin_converter.ensure_artifact(dst, self.root / "src.erwin", "XML V3")
        self.assertTrue(outcome.ok)
        self.assertEqual(erwin_converter.HOW_EXISTING, outcome.how)

    def test_missing_without_com_reports_manual_requirement(self):
        src = self.root / "src.xml"
        src.write_text("<erwin/>")
        with patch.object(erwin_converter, "com_available", return_value=False), \
             patch("app.erwin.erwin_converter.get_setting", side_effect=lambda n, d: 0 if "WAIT" in n else d):
            outcome = erwin_converter.ensure_artifact(self.root / "m.erwin", src, ".ERWIN V1")
        self.assertFalse(outcome.ok)
        self.assertEqual(erwin_converter.HOW_MISSING, outcome.how)
        self.assertTrue(any("by hand" in m for m in outcome.messages))

    def test_converter_success_is_reported_as_converted(self):
        src = self.root / "src.erwin"
        src.write_bytes(b"binary")
        dst = self.root / "m.xml"

        def fake_convert(s, d, timeout):
            Path(d).write_text("<erwin><ok/></erwin>")
            return 0

        # the converter is an opt-in utility (ERWIN_CONVERT_ENABLED is False by default)
        with patch.object(erwin_converter, "com_available", return_value=True), \
             patch.object(erwin_converter, "run_convert", side_effect=fake_convert), \
             patch("app.erwin.erwin_converter.get_setting",
                   side_effect=lambda n, d: True if n == "ERWIN_CONVERT_ENABLED" else d):
            outcome = erwin_converter.ensure_artifact(dst, src, "XML V3")
        self.assertTrue(outcome.ok)
        self.assertEqual(erwin_converter.HOW_CONVERTED, outcome.how)

    def test_the_stage_scripts_never_drive_erwin_themselves(self):
        """
        The entry points stay thin: they must not reach for erwin directly.

        This used to assert the converter had NO caller anywhere, which is what
        left run_udp.py unable to produce an output .erwin on any host. erwin is
        now driven — but from one place, the hand-off gate in the shared Step 2
        helper, so run_v1 / run_udp / run_v3 and app.main cannot drift apart in
        how they obtain the two erwin artefacts.
        """
        import ast
        import inspect

        def imported_names(module):
            """Every dotted name the module imports (prose in docstrings is not a call)."""
            names = set()
            for node in ast.walk(ast.parse(inspect.getsource(module))):
                if isinstance(node, ast.Import):
                    names.update(alias.name for alias in node.names)
                elif isinstance(node, ast.ImportFrom):
                    base = node.module or ""
                    names.add(base)
                    names.update(f"{base}.{alias.name}".strip(".") for alias in node.names)
            return names

        from app import run_udp, run_v1, run_v3
        for module in (run_v1, run_udp, run_v3):
            names = imported_names(module)
            self.assertNotIn("app.erwin.erwin_converter", names, module.__name__)
            self.assertNotIn("app.erwin.erwin_handoff", names, module.__name__)
            self.assertFalse([n for n in names if n.startswith("app.erwin")], module.__name__)

    def test_step2_obtains_both_erwin_artefacts_through_the_gate(self):
        import inspect

        from app.workflows import conceptual_workflow

        v1 = inspect.getsource(conceptual_workflow._obtain_erwin_v1)
        v2 = inspect.getsource(conceptual_workflow._obtain_erwin_v2)
        self.assertIn("erwin_handoff.ensure", v1)
        self.assertIn(".ERWIN V1", v1)
        self.assertIn("erwin_handoff.ensure", v2)
        self.assertIn(".ERWIN V2", v2)
        # and run_step2 is what calls them, so no caller can skip the gate
        step2 = inspect.getsource(conceptual_workflow.run_step2)
        self.assertIn("_obtain_erwin_v1", step2)
        self.assertIn("_obtain_erwin_v2", step2)

    def test_needs_visible_ui_falls_back_to_manual_wait(self):
        src = self.root / "src.xml"
        src.write_text("<erwin/>")
        with patch.object(erwin_converter, "com_available", return_value=True), \
             patch.object(erwin_converter, "run_convert", return_value=2), \
             patch("app.erwin.erwin_converter.get_setting", side_effect=lambda n, d: 0 if "WAIT" in n else d):
            outcome = erwin_converter.ensure_artifact(self.root / "m.erwin", src, ".ERWIN V1")
        self.assertFalse(outcome.ok)
        self.assertTrue(any("open on the desktop" in m for m in outcome.messages))


class UdpFlowInputTests(unittest.TestCase):
    def test_explicit_erwin_v1_wins_over_search_folders(self):
        with tempfile.TemporaryDirectory() as tmp:
            erwin_v1 = Path(tmp) / "input_erwin_models" / "m.erwin"
            erwin_v1.parent.mkdir(parents=True)
            erwin_v1.write_bytes(b"x")
            request = udp_flow.UdpFlowRequest(pd_path="p.ldm", model_name="m", model_type="LDM",
                                              reports_dir=tmp, erwin_in=str(erwin_v1),
                                              erwin_out=str(Path(tmp) / "2_preprocessed" / "m.erwin"))
            outcome = udp_flow.UdpStageOutcome(model_name="m")
            captured = {}

            def fake_inject(req):
                captured["erwin_in"] = req.erwin_in
                captured["erwin_out"] = req.erwin_out
                return False

            with patch.object(udp_flow.udp_bridge, "com_available", return_value=True), \
                 patch.object(udp_flow.udp_bridge, "inject", side_effect=fake_inject):
                outcome.schema_path = outcome.manifest_path = "x.json"
                udp_flow._run_injection(request, outcome, tmp, config=None)
            self.assertEqual(str(erwin_v1), captured["erwin_in"])
            self.assertTrue(captured["erwin_out"].endswith("2_preprocessed/m.erwin"))

    def test_readback_prefers_injected_output(self):
        with tempfile.TemporaryDirectory() as tmp:
            v1 = Path(tmp) / "m_v1.erwin"
            v1.write_bytes(b"a")
            v2 = Path(tmp) / "m_v2.erwin"
            v2.write_bytes(b"b")
            request = udp_flow.UdpFlowRequest(pd_path="p.ldm", model_name="m", model_type="LDM",
                                              reports_dir=tmp, erwin_in=str(v1), erwin_out=str(v2))
            outcome = udp_flow.UdpStageOutcome(model_name="m")

            class _Res:
                warnings = []
                def summary_line(self): return "ok"

            seen = {}

            def fake_compare(model_name, workdir, erwin_model, *a, **k):
                seen["read"] = erwin_model
                return _Res(), ""

            with patch.object(udp_flow.udp_bridge, "migration_report", return_value=""), \
                 patch.object(udp_flow.udp_bridge, "compare", side_effect=fake_compare):
                udp_flow._run_reporting(request, outcome, tmp, config=None)
            self.assertEqual(str(v2), seen["read"])


class _Result:
    """Minimal result the gate and ledger can read."""
    def __init__(self, fidelity):
        self.status = "PASS"
        self.fidelity_score = fidelity
        self.fidelity_score_raw = fidelity
        self.structural_fidelity_score = fidelity
        self.critical_count = self.warning_count = 0
        self.info_count = 3
        self.stage_scores = {"V3": fidelity_stages.StageScore(stage="V3", overall=fidelity,
                                                              components={"structural": fidelity})}
        self.promotion_note = ""


class PromotionRoutingTests(unittest.TestCase):
    def test_pass_writes_erwin_v3_and_xml_v3_to_final_stage(self):
        with tempfile.TemporaryDirectory() as tmp:
            dirs = _dirs(tmp)
            stages = StagePaths(dirs)
            xml_v3 = stages.xml_v3("m")
            xml_v3.write_text("<erwin/>")
            erwin_v2 = stages.erwin_v2("m")
            erwin_v2.write_bytes(b"model")
            record = ModelRecord(base_name="m", model_type="LDM", result=_Result(99.0), final_xml=str(xml_v3))
            with patch.object(promotion_routing.promotion_gate, "apply", return_value=True):
                promotion_routing.route_model(record, xml_v3, dirs, stages=stages, erwin_source=erwin_v2)
            self.assertEqual(DEST_FINAL, record.destination)
            self.assertTrue(stages.erwin_v3("m").is_file())
            self.assertTrue((stages.folder("erwin_v3") / "m.xml").is_file())
            self.assertTrue(xml_v3.is_file(), "XML V3 must be copied, not moved")

    def test_pass_without_erwin_v2_notes_the_gap(self):
        with tempfile.TemporaryDirectory() as tmp:
            dirs = _dirs(tmp)
            stages = StagePaths(dirs)
            xml_v3 = stages.xml_v3("m")
            xml_v3.write_text("<erwin/>")
            record = ModelRecord(base_name="m", model_type="LDM", result=_Result(99.0), final_xml=str(xml_v3))
            with patch.object(promotion_routing.promotion_gate, "apply", return_value=True):
                promotion_routing.route_model(record, xml_v3, dirs, stages=stages, erwin_source=None)
            self.assertFalse(stages.erwin_v3("m").exists())
            self.assertTrue(any(".ERWIN V2" in n for n in record.notes))


class HardStopTests(unittest.TestCase):
    def test_missing_xml_v3_stops_the_model_by_default(self):
        from app.workflows import conceptual_workflow as cw
        with tempfile.TemporaryDirectory() as tmp:
            dirs = _dirs(tmp)
            stages = StagePaths(dirs)
            stages.xml_v1("m").write_text("<erwin/>")
            result = _Result(50.0)
            with patch.object(cw, "reconcile", return_value=result), \
                 patch.object(cw, "run_preprocessing", return_value=stages.xml_v2("m")), \
                 patch.object(cw, "run_udp_phase", return_value=None), \
                 patch.object(cw, "udp_stage_override", return_value=None), \
                 patch.object(cw, "get_setting", side_effect=lambda n, d: 0 if "WAIT" in n else d), \
                 patch.object(cw, "validate_erwin_xml", return_value=(True, "")):
                record = cw.process_conceptual_model(Path(tmp) / "m.ldm", "m", "LDM", dirs)
            self.assertIsNone(record)
            ledger = dirs["summary"] / "audit" / "pipeline_ledger.jsonl"
            self.assertTrue(ledger.is_file())
            self.assertEqual("SKIPPED", json.loads(ledger.read_text().splitlines()[-1])["status"])


class PipelineLedgerTests(unittest.TestCase):
    def test_model_entry_has_lineage_and_scores(self):
        with tempfile.TemporaryDirectory() as tmp:
            dirs = _dirs(tmp)
            record = ModelRecord(base_name="m", model_type="LDM", result=_Result(91.5),
                                 destination=DEST_FINAL, v3_report_path="r/m_V3.xlsx")
            path = pipeline_ledger.record_model(record, dirs, {"xml_v3": "a.xml", "xml_v3_how": "converted"})
            entry = json.loads(Path(path).read_text().splitlines()[-1])
            self.assertEqual("PASS", entry["status"])
            self.assertEqual(91.5, entry["stages"]["V3"]["overall"])
            self.assertEqual("a.xml", entry["artefacts"]["xml_v3"])
            self.assertEqual("converted", entry["artefact_origin"]["xml_v3"])
            self.assertEqual("r/m_V3.xlsx", entry["reports"]["v3"])


class FileLockTests(unittest.TestCase):
    def test_lock_yields_path_and_creates_lock_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "x.jsonl"
            with file_lock(target) as got:
                self.assertEqual(target, got)
                self.assertTrue(Path(str(target) + ".lock").exists())

    def test_concurrent_appends_are_all_intact(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "x.jsonl"

            def writer(i):
                for k in range(40):
                    append_jsonl_line_safely(target, {"t": i, "k": k, "pad": "x" * 200})

            threads = [threading.Thread(target=writer, args=(i,)) for i in range(6)]
            for t in threads:
                t.start()
            for t in threads:
                t.join()
            lines = target.read_text().splitlines()
            self.assertEqual(240, len(lines))
            for line in lines:
                json.loads(line)


if __name__ == "__main__":
    unittest.main()
