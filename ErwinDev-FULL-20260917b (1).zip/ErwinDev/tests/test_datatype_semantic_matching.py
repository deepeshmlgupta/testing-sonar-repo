import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.validation.cdm_reconcile import normalizers as cdm_norm
from app.validation.ldm_reconcile import normalizers as ldm_norm
from app.validation.pdm_reconcile.pdm_erwin_validator import data_type_mapper as pdm_mapper


class DatatypeSemanticMatchingTests(unittest.TestCase):
    def test_varchar_and_variable_character(self):
        cat, is_match = ldm_norm.classify_type_match("VARCHAR(50)", "Variable Character(50)")
        self.assertTrue(is_match)
        self.assertIn(cat, ("TYPE_EXACT_MATCH", "TYPE_CANONICAL_MATCH", "TYPE_SEMANTIC_MATCH"))

        cat_cdm, is_match_cdm = cdm_norm.classify_type_match("VARCHAR(50)", "Variable Character(50)")
        self.assertTrue(is_match_cdm)

        cat_pdm, is_match_pdm = pdm_mapper.classify_type_match("VARCHAR(50)", "Variable Character(50)")
        self.assertTrue(is_match_pdm)

    def test_number_18_0_and_bigint(self):
        cat, is_match = ldm_norm.classify_type_match("NUMBER(18,0)", "BIGINT")
        self.assertTrue(is_match)
        self.assertEqual("TYPE_SEMANTIC_MATCH", cat)

        cat_cdm, is_match_cdm = cdm_norm.classify_type_match("NUMBER(18,0)", "BIGINT")
        self.assertTrue(is_match_cdm)
        self.assertEqual("TYPE_SEMANTIC_MATCH", cat_cdm)

        cat_pdm, is_match_pdm = pdm_mapper.classify_type_match("NUMERIC(18,0)", "BIGINT")
        self.assertTrue(is_match_pdm)
        self.assertEqual("TYPE_SEMANTIC_MATCH", cat_pdm)

    def test_decimal_19_0_and_integer_or_bigint(self):
        cat, is_match = ldm_norm.classify_type_match("DECIMAL(19,0)", "INTEGER")
        self.assertTrue(is_match)
        self.assertEqual("TYPE_SEMANTIC_MATCH", cat)

    def test_incompatible_types_yield_mismatch(self):
        cat, is_match = ldm_norm.classify_type_match("VARCHAR(50)", "INTEGER")
        self.assertFalse(is_match)
        self.assertEqual("TYPE_MISMATCH", cat)


if __name__ == "__main__":
    unittest.main()
