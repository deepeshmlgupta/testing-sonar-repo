import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.validation.cdm_reconcile.cdm_model import Package, Relationship, RelationshipEnd
from app.validation.cdm_reconcile.comparator import (
    ValidationResult,
    _reconcile_package_hierarchy,
    _score_relationship_semantics,
)


def _pkg(name, parent=""):
    return Package(name=name, code=name, parent=parent)


def _rel(name, e1, e2, c1="0,n", c2="1,1"):
    return Relationship(
        name=name,
        end1=RelationshipEnd(entity=e1, cardinality=c1, mandatory=True),
        end2=RelationshipEnd(entity=e2, cardinality=c2),
    )


class CdmHierarchyWiringTests(unittest.TestCase):
    def test_matched_hierarchy_reports_full_fidelity(self):
        result = ValidationResult(pd_file="a.cdm", erwin_file="a.xml")
        pd_pkgs = [_pkg("Business"), _pkg("Customer", parent="Business")]
        erwin_pkgs = [_pkg("Business"), _pkg("Customer", parent="Business")]
        _reconcile_package_hierarchy(result, pd_pkgs, erwin_pkgs)
        self.assertEqual(100.0, result.hierarchy_fidelity_pct)

    def test_missing_ancestor_lowers_fidelity_and_emits_finding(self):
        result = ValidationResult(pd_file="a.cdm", erwin_file="a.xml")
        pd_pkgs = [_pkg("Business"), _pkg("Customer", parent="Business")]
        erwin_pkgs = [_pkg("Customer")]  # Business ancestor missing
        _reconcile_package_hierarchy(result, pd_pkgs, erwin_pkgs)
        self.assertLess(result.hierarchy_fidelity_pct, 100.0)
        self.assertTrue(any(f.category == "HIERARCHY_PATH_MISMATCH" for f in result.findings))


class CdmRelationshipSemanticWiringTests(unittest.TestCase):
    def test_fully_agreeing_pair_scores_100_and_emits_nothing(self):
        result = ValidationResult(pd_file="a.cdm", erwin_file="a.xml")
        pd_rel = _rel("Places", "CUSTOMER", "ORDER")
        erwin_rel = _rel("Places", "CUSTOMER", "ORDER")
        _score_relationship_semantics(result, [(pd_rel, erwin_rel, "name")])
        self.assertEqual(100.0, result.relationship_semantic_fidelity_pct)
        self.assertFalse(any(f.category == "RELATIONSHIP_SEMANTIC_MISMATCH" for f in result.findings))

    def test_participation_mismatch_lowers_score_and_emits_finding(self):
        result = ValidationResult(pd_file="a.cdm", erwin_file="a.xml")
        pd_rel = _rel("Places", "CUSTOMER", "ORDER")
        erwin_rel = Relationship(
            name="Places",
            end1=RelationshipEnd(entity="CUSTOMER", cardinality="0,n", mandatory=False),
            end2=RelationshipEnd(entity="ORDER", cardinality="1,1"),
        )
        _score_relationship_semantics(result, [(pd_rel, erwin_rel, "name")])
        self.assertLess(result.relationship_semantic_fidelity_pct, 100.0)
        self.assertTrue(any(f.category == "RELATIONSHIP_SEMANTIC_MISMATCH" for f in result.findings))


if __name__ == "__main__":
    unittest.main()
