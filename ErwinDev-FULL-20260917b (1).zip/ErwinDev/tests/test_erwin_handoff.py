"""
The erwin hand-off gate (app/erwin/erwin_handoff.py) and the tolerant lookup
that feeds it (app/orchestration/stage_paths.py).

These cover the defect that left ``run_udp.py`` producing no output .erwin:

  * a correctly handed-off .erwin in the TIER sub-folder, or saved under the
    SHORT model name, was invisible to Step 2;
  * with erwin COM on the host nothing converted XML V2 -> .ERWIN V1, because
    the converter had no caller;
  * without erwin COM the stage ended at EXTRACTED with a one-line note, so a
    run that migrated nothing looked like a run that worked.

Every erwin-COM path is faked, because erwin Data Modeler is Windows-only and
the suite must pass on the build host.
"""

import os
import sys
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.erwin import erwin_converter, erwin_handoff
from app.orchestration.stage_paths import StagePaths, stage_folders


def _tree(root: Path):
    """A minimal dirs mapping with the flat stage folders created."""
    root = Path(root)
    dirs = {
        "initial": root / "erwinmodels" / "1_initial",
        "preprocessed": root / "erwinmodels" / "2_preprocessed",
        "final": root / "erwinmodels" / "3_final",
        "final_xml": root / "final_xml_models",
        "udp_input": root / "app" / "udp_tool" / "input_erwin_models",
    }
    dirs["stages"] = stage_folders(root / "erwinmodels", dirs["final_xml"], dirs["udp_input"])
    for path in dirs["stages"].values():
        path.mkdir(parents=True, exist_ok=True)
    return dirs


class TolerantLookupTests(unittest.TestCase):
    """stage_paths finds what a PERSON saved, not only what the pipeline asks for."""

    LONG = "4d95b17a5883fbeb69fb9088bf1767c1_46007266_real_estate"

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dirs = _tree(self.tmp.name)
        self.stages = StagePaths(self.dirs, "LDM")

    def tearDown(self):
        self.tmp.cleanup()

    def test_erwin_v1_in_the_tier_subfolder_is_found(self):
        # mirror_models_to_udp_input fills input_erwin_models/ldm/ with the SAP
        # sources, so that is where an operator saves the .erwin beside them.
        target = self.dirs["udp_input"] / "ldm" / f"{self.LONG}.erwin"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(b"erwin-binary")
        self.assertEqual(target, self.stages.find_erwin_v1(self.LONG))

    def test_erwin_v1_under_the_short_model_name_is_found(self):
        target = self.dirs["udp_input"] / "real_estate.erwin"
        target.write_bytes(b"erwin-binary")
        self.assertEqual(target, self.stages.find_erwin_v1(self.LONG))

    def test_short_name_in_the_tier_subfolder_is_found(self):
        target = self.dirs["udp_input"] / "ldm" / "real_estate.erwin"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(b"erwin-binary")
        self.assertEqual(target, self.stages.find_erwin_v1(self.LONG))

    def test_the_canonical_path_always_wins(self):
        canonical = self.dirs["udp_input"] / f"{self.LONG}.erwin"
        canonical.write_bytes(b"right")
        (self.dirs["udp_input"] / "real_estate.erwin").write_bytes(b"wrong")
        self.assertEqual(canonical, self.stages.find_erwin_v1(self.LONG))

    def test_short_name_fallback_can_be_switched_off(self):
        (self.dirs["udp_input"] / "real_estate.erwin").write_bytes(b"x")
        with patch("app.orchestration.stage_paths.get_setting",
                   side_effect=lambda n, d: False if n == "SHORT_NAME_HANDOFF_FALLBACK" else d):
            self.assertIsNone(self.stages.find_erwin_v1(self.LONG))

    def test_short_name_resolution_is_warned_about(self):
        # Two extracts of one model share a short name, so resolving by it is
        # never silent — the operator has to be able to see which file was used.
        (self.dirs["udp_input"] / "real_estate.erwin").write_bytes(b"x")
        with self.assertLogs("app.orchestration.stage_paths", level="WARNING") as logged:
            self.stages.find_erwin_v1(self.LONG)
        self.assertTrue(any("short name" in line for line in logged.output))

    def test_pipeline_outputs_are_not_given_tolerant_lookup(self):
        # xml_v2 is written by run_v1 at an exact path; accepting a differently
        # named file there would score an artefact the pipeline never made.
        (self.dirs["stages"]["xml_v2"] / "real_estate.xml").write_text("<erwin/>")
        self.assertIsNone(self.stages.find_xml_v2(self.LONG))

    def test_candidates_are_deduplicated(self):
        candidates = self.stages.candidates("erwin_v1", self.LONG)
        self.assertEqual(len(candidates), len(set(candidates)))


class GateWithErwinAvailableTests(unittest.TestCase):
    """erwin COM on the host: the artefact is made, not asked for."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def test_conversion_produces_the_artifact(self):
        source = self.root / "m.xml"
        source.write_text("<erwin><ok/></erwin>")
        target = self.root / "out" / "m.erwin"

        def fake_convert(src, dst, timeout):
            Path(dst).parent.mkdir(parents=True, exist_ok=True)
            Path(dst).write_bytes(b"erwin-binary")
            return 0

        with patch.object(erwin_converter, "com_available", return_value=True), \
             patch.object(erwin_converter, "run_convert", side_effect=fake_convert):
            outcome = erwin_handoff.ensure(target, source, ".ERWIN V1", model_name="m")

        self.assertTrue(outcome.ok)
        self.assertEqual(erwin_handoff.HOW_CONVERTED, outcome.how)
        self.assertTrue(target.is_file())

    def test_conversion_is_not_attempted_when_disabled(self):
        source = self.root / "m.xml"
        source.write_text("<erwin/>")
        with patch.object(erwin_converter, "com_available", return_value=True), \
             patch.object(erwin_converter, "run_convert") as convert, \
             patch("app.erwin.erwin_handoff.get_setting",
                   side_effect=lambda n, d: False if n in ("ERWIN_CONVERT_ENABLED",
                                                           "ERWIN_MANUAL_PROMPT_ENABLED") else d):
            outcome = erwin_handoff.ensure(self.root / "m.erwin", source, ".ERWIN V1")
        convert.assert_not_called()
        self.assertFalse(outcome.ok)
        self.assertTrue(any("ERWIN_CONVERT_ENABLED is off" in m for m in outcome.messages))

    def test_needs_visible_ui_is_reported_not_swallowed(self):
        source = self.root / "m.xml"
        source.write_text("<erwin/>")
        with patch.object(erwin_converter, "com_available", return_value=True), \
             patch.object(erwin_converter, "run_convert", return_value=2), \
             patch.object(erwin_handoff, "interactive_allowed", return_value=False), \
             patch("app.erwin.erwin_handoff.get_setting",
                   side_effect=lambda n, d: 0 if "WAIT" in n else d):
            outcome = erwin_handoff.ensure(self.root / "m.erwin", source, ".ERWIN V1")
        self.assertFalse(outcome.ok)
        self.assertTrue(any("open on the desktop" in m for m in outcome.messages))

    def test_an_existing_artifact_is_never_reconverted(self):
        target = self.root / "m.erwin"
        target.write_bytes(b"already here")
        with patch.object(erwin_converter, "run_convert") as convert:
            outcome = erwin_handoff.ensure(target, self.root / "m.xml", ".ERWIN V1")
        convert.assert_not_called()
        self.assertTrue(outcome.ok)
        self.assertEqual(erwin_handoff.HOW_EXISTING, outcome.how)


class GateWithoutErwinTests(unittest.TestCase):
    """No erwin COM: say exactly what to make, and wait for it if anyone is there."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.source = self.root / "m.xml"
        self.source.write_text("<erwin/>")
        self.target = self.root / "input_erwin_models" / "m.erwin"
        self.com = patch.object(erwin_converter, "com_available", return_value=False)
        self.com.start()

    def tearDown(self):
        self.com.stop()
        self.tmp.cleanup()

    def _no_wait(self, name, default):
        return 0 if "WAIT" in name else default

    def test_unattended_run_reports_instructions_and_carries_on(self):
        with patch.object(erwin_handoff, "interactive_allowed", return_value=False), \
             patch("app.erwin.erwin_handoff.get_setting", side_effect=self._no_wait):
            outcome = erwin_handoff.ensure(self.target, self.source, ".ERWIN V1", model_name="m")
        self.assertFalse(outcome.ok)
        self.assertEqual(erwin_handoff.HOW_MISSING, outcome.how)
        self.assertIn("erwin COM automation unavailable", " ".join(outcome.messages))
        # the instructions name the real source and the real target
        self.assertIn(str(self.source), outcome.instructions)
        self.assertIn(str(self.target), outcome.instructions)

    def test_instructions_are_written_next_to_the_target(self):
        with patch.object(erwin_handoff, "interactive_allowed", return_value=False), \
             patch("app.erwin.erwin_handoff.get_setting", side_effect=self._no_wait):
            erwin_handoff.ensure(self.target, self.source, ".ERWIN V1", model_name="m")
        howto = list(self.target.parent.glob(f"*{erwin_handoff.HOWTO_SUFFIX}"))
        self.assertEqual(1, len(howto))
        self.assertIn("File > Save As", howto[0].read_text(encoding="utf-8"))

    def test_operator_produces_the_file_at_the_prompt(self):
        answers = iter(["", ""])

        def fake_input(_prompt):
            answer = next(answers)
            # the operator saves the model in erwin between the two prompts
            self.target.parent.mkdir(parents=True, exist_ok=True)
            self.target.write_bytes(b"erwin-binary")
            return answer

        with patch.object(erwin_handoff, "interactive_allowed", return_value=True), \
             patch("builtins.input", side_effect=fake_input):
            outcome = erwin_handoff.ensure(self.target, self.source, ".ERWIN V1", model_name="m")

        self.assertTrue(outcome.ok)
        self.assertEqual(erwin_handoff.HOW_MANUAL, outcome.how)
        self.assertEqual(self.target, outcome.path)

    def test_prompt_rechecks_the_tolerant_locations(self):
        # The operator saves it under the short name; the prompt must accept it,
        # because a re-check that only stats the exact path would reject a file
        # that the rest of the pipeline would happily have found.
        elsewhere = self.root / "input_erwin_models" / "short.erwin"

        def fake_input(_prompt):
            elsewhere.parent.mkdir(parents=True, exist_ok=True)
            elsewhere.write_bytes(b"erwin-binary")
            return ""

        with patch.object(erwin_handoff, "interactive_allowed", return_value=True), \
             patch("builtins.input", side_effect=fake_input):
            outcome = erwin_handoff.ensure(
                self.target, self.source, ".ERWIN V1", model_name="m",
                recheck=lambda: elsewhere if elsewhere.is_file() else None)

        self.assertTrue(outcome.ok)
        self.assertEqual(elsewhere, outcome.path)

    def test_operator_can_skip_one_model_without_ending_the_batch(self):
        with patch.object(erwin_handoff, "interactive_allowed", return_value=True), \
             patch("builtins.input", return_value="s"):
            outcome = erwin_handoff.ensure(self.target, self.source, ".ERWIN V1", model_name="m")
        self.assertFalse(outcome.ok)
        self.assertTrue(any("skipped" in m for m in outcome.messages))

    def test_closed_stdin_is_a_skip_not_a_crash(self):
        with patch.object(erwin_handoff, "interactive_allowed", return_value=True), \
             patch("builtins.input", side_effect=EOFError):
            outcome = erwin_handoff.ensure(self.target, self.source, ".ERWIN V1", model_name="m")
        self.assertFalse(outcome.ok)

    def test_prompting_gives_up_after_the_configured_attempts(self):
        calls = []

        def fake_input(_prompt):
            calls.append(1)
            return ""                       # never actually saves anything

        with patch.object(erwin_handoff, "interactive_allowed", return_value=True), \
             patch("app.erwin.erwin_handoff.get_setting",
                   side_effect=lambda n, d: 3 if n == "ERWIN_MANUAL_PROMPT_ATTEMPTS" else d), \
             patch("builtins.input", side_effect=fake_input):
            outcome = erwin_handoff.ensure(self.target, self.source, ".ERWIN V1")
        self.assertEqual(3, len(calls))
        self.assertFalse(outcome.ok)


class InteractivityGuardTests(unittest.TestCase):
    """A prompt in the wrong place hangs a batch; these are the guards."""

    def test_never_prompts_from_a_worker_thread(self):
        # MAX_WORKERS is 4 by default: four threads prompting on one terminal
        # would interleave their questions and none of them could be answered.
        result = {}

        def worker():
            result["allowed"] = erwin_handoff.interactive_allowed()

        thread = threading.Thread(target=worker)
        thread.start()
        thread.join()
        self.assertFalse(result["allowed"])

    def test_never_prompts_when_stdin_is_not_a_terminal(self):
        class NotATty:
            def isatty(self):
                return False

        with patch.object(sys, "stdin", NotATty()):
            self.assertFalse(erwin_handoff.interactive_allowed())

    def test_never_prompts_when_disabled_by_configuration(self):
        with patch("app.erwin.erwin_handoff.get_setting",
                   side_effect=lambda n, d: False if n == "ERWIN_MANUAL_PROMPT_ENABLED" else d):
            self.assertFalse(erwin_handoff.interactive_allowed())

    def test_a_closed_stdin_does_not_raise(self):
        with patch.object(sys, "stdin", None):
            self.assertFalse(erwin_handoff.interactive_allowed())


if __name__ == "__main__":       # pragma: no cover
    unittest.main()
