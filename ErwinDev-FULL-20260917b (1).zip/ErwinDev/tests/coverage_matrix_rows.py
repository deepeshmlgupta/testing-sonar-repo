"""
The canonical coverage matrix — one row per (model type, object type,
property) with the columns the programme asked for:

    Model Type | Object Type | Property | PD Available | Extracted | Transformed |
    Target Supported | Automatically Migrated | Manual Migration Required | Validated |
    Validation Method | Status | Alternative / Remediation | Evidence | Notes

``Status`` uses the coverage classification vocabulary (``STATUSES``). The rows
are rendered into COVERAGE_MATRIX.md between the markers by

    python -m tests.coverage_matrix_rows

and ``tests/test_coverage_matrix.py`` keeps the document, this table and the
mutation probes (``tests/coverage_probe.py``) consistent.

Column semantics
----------------
PD Available          the property exists in the PowerDesigner model (parsed by the framework)
Extracted             the framework's PD parser reads it
Transformed           the framework changes it on the way to erwin (Step 1 comments -> notes, Step 2 UDPs); "-" = erwin's own import carries it
Target Supported      erwin Data Modeler has a place for it
Automatically Migrated  by the framework (Step 1 / Step 2). erwin's PowerDesigner import is a MANUAL step in this flow.
Manual Migration Required  a person (erwin import / hand edit) has to carry it
Validated             a property-level finding fires when it is lost or changed between PD and the erwin XML
Validation Method     the finding category (severity C/W/I) or sheet
Evidence              probe row in property_probe_matrix.md (P), test (T), or report sheet (S)
"""

from __future__ import annotations

import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import List

AUTOMATICALLY_MIGRATED = "AUTOMATICALLY_MIGRATED"
AUTOMATICALLY_VALIDATED = "AUTOMATICALLY_VALIDATED"
MANUALLY_MIGRATED = "MANUALLY_MIGRATED"
MANUALLY_VALIDATED = "MANUALLY_VALIDATED"
PARTIALLY_SUPPORTED = "PARTIALLY_SUPPORTED"
NOT_SUPPORTED_BY_ERWIN = "NOT_SUPPORTED_BY_ERWIN"
NOT_SUPPORTED_BY_FRAMEWORK = "NOT_SUPPORTED_BY_FRAMEWORK"
INTENTIONALLY_OUT_OF_SCOPE = "INTENTIONALLY_OUT_OF_SCOPE"
FUTURE_ENHANCEMENT = "FUTURE_ENHANCEMENT"
NOT_APPLICABLE = "NOT_APPLICABLE"
NOT_YET_TESTED = "NOT_YET_TESTED"
STATUSES = (AUTOMATICALLY_MIGRATED, AUTOMATICALLY_VALIDATED, MANUALLY_MIGRATED, MANUALLY_VALIDATED,
            PARTIALLY_SUPPORTED, NOT_SUPPORTED_BY_ERWIN, NOT_SUPPORTED_BY_FRAMEWORK,
            INTENTIONALLY_OUT_OF_SCOPE, FUTURE_ENHANCEMENT, NOT_APPLICABLE, NOT_YET_TESTED)

COLUMNS = ("Model Type", "Object Type", "Property", "PD Available", "Extracted", "Transformed",
           "Target Supported", "Automatically Migrated", "Manual Migration Required", "Validated",
           "Validation Method", "Status", "Alternative / Remediation", "Evidence", "Notes")

Y, N, D = "✅", "❌", "—"


@dataclass(frozen=True)
class Row:
    model: str
    obj: str
    prop: str
    pd: str = Y
    extracted: str = Y
    transformed: str = D
    target: str = Y
    auto: str = N
    manual: str = Y
    validated: str = Y
    method: str = ""
    status: str = MANUALLY_MIGRATED
    remediation: str = ""
    evidence: str = "P"
    notes: str = ""

    def cells(self):
        return (self.model, self.obj, self.prop, self.pd, self.extracted, self.transformed, self.target,
                self.auto, self.manual, self.validated, self.method, self.status, self.remediation,
                self.evidence, self.notes)


def _imp(model, obj, prop, method, evidence="P", notes="", remediation=""):
    """Carried by erwin's PowerDesigner import (manual), validated automatically."""
    return Row(model, obj, prop, method=method, status=AUTOMATICALLY_VALIDATED, evidence=evidence,
               notes=notes or "erwin import carries it (manual step); loss/change is a finding",
               remediation=remediation)


def _step1(model, obj, method, evidence="T", notes=""):
    return Row(model, obj, "Comment / Definition", transformed="Step 1: PD Comment -> erwin Note",
               auto=Y, manual=N, method=method, status=AUTOMATICALLY_MIGRATED, evidence=evidence,
               notes=notes or "run_v1 writes 2_preprocessed/<m>.xml; documentation component (25 %)")


def _step2(model, obj):
    return Row(model, obj, "Extended attributes (UDPs)", transformed="Step 2: SAP extended attribute -> erwin UDP",
               auto=Y, manual=N, method="UDP component (25 %), UDP_RECONCILIATION sheet, UDP tool comparison workbook",
               status=AUTOMATICALLY_MIGRATED, evidence="T/S",
               notes="run_udp (Windows + erwin COM) injects into the handed-off .erwin; read-back pass rate is the evidence")


def _excluded(model, obj, prop, status, remediation, notes="", target=Y, validated=N, method="—", evidence="P"):
    return Row(model, obj, prop, target=target, validated=validated, method=method, status=status,
               remediation=remediation, evidence=evidence, notes=notes)


ROWS: List[Row] = []
for tier in ("CDM", "LDM"):
    ROWS += [
        _imp(tier, "Model", "Name / Code / Type", "MODEL_METADATA (W)"),
        _step1(tier, "Model", "MODEL_DEFINITION (I)"),
        _imp(tier, "Entity", "Presence (name/code)", "ENTITY_MISSING (C) / ENTITY_EXTRA (W)"),
        _step1(tier, "Entity", "DEFINITION_MISMATCH (W), DEFINITION_LOSS/PARTIAL (I); documentation component"),
        _step2(tier, "Entity"),
        _imp(tier, "Attribute", "Name", "BUSINESS_NAME (W)"),
        # Verified on both supplied erwin exports: ZERO <Physical_Name>
        # elements. erwin's conceptual/logical export has no native field for
        # the SAP PD Code at all, so this is not "sometimes suppressed" — the
        # code is never carried natively on this tier. CODE_NOT_CARRIED
        # (SOURCE_PRE_EXISTING, weight 0) records that as an approved mapping
        # to the PD_Code UDP; FALLBACK_MATCH (I) is still emitted for a
        # genuine rename, where the NAMES differ too.
        _imp(tier, "Attribute", "Code / physical name",
             "CODE_NOT_CARRIED (SOURCE_PRE_EXISTING, weight 0); FALLBACK_MATCH (I) for a real rename",
             notes="erwin export has no Physical_Name; SAP PD Code preserved as the PD_Code UDP "
                   "(Step 2) — an EXPECTED_TRANSFORMATION, not a loss"),
        _step1(tier, "Attribute", "DEFINITION_MISMATCH (W), DEFINITION_LOSS/PARTIAL (I)"),
        _imp(tier, "Attribute", "Data type (family)", "DATA_TYPE (C)", evidence="P/T",
             notes="VARCHAR->CHAR, DATE->TIMESTAMP, INTEGER->VARCHAR are CRITICAL; tests/test_datatype_fidelity.py"),
        _imp(tier, "Attribute", "Length / precision / scale", "LENGTH_PRECISION (W)", evidence="P/T",
             notes="VARCHAR(500)->VARCHAR(255), DECIMAL(18,2)->DECIMAL(38,10) are WARNING; never silent"),
        _imp(tier, "Attribute", "Mandatory / optional", "MANDATORY (W)"),
        _imp(tier, "Attribute", "Domain assignment", "ATTRIBUTE_DOMAIN (I), DOMAIN_MISMATCH (W)"),
        _imp(tier, "Attribute", "Default value", "ATTRIBUTE_DEFAULT (I)"),
        _imp(tier, "Attribute", "Multiplicity", "MULTIPLICITY_* (W/I)"),
        _step2(tier, "Attribute"),
        _excluded(tier, "Attribute", "Order / sequence", INTENTIONALLY_OUT_OF_SCOPE,
                  "set CHECK_ATTRIBUTE_ORDER=True", notes="erwin re-orders key attributes first; ungoverned"),
        _imp(tier, "Identifier", "Primary identifier membership", "PRIMARY_IDENTIFIER (C)"),
        _imp(tier, "Identifier", "Alternate identifier membership", "ALTERNATE_IDENTIFIER (W)"),
        _imp(tier, "Identifier", "Name / code", "IDENTIFIER_NAME (I)"),
        _imp(tier, "Identifier", "Member order", "IDENTIFIER_MEMBER_ORDER (I)",
             notes="only when the export writes Key_Group_Member_Order"),
        _imp(tier, "Relationship", "Parent / child entity", "RELATIONSHIP_MISSING/EXTRA (W)"),
        _imp(tier, "Relationship", "Verb phrases / role names", "ROLE_NAME (I)"),
        _step1(tier, "Relationship", "DEFINITION_MISMATCH (W)"),
        _imp(tier, "Relationship", "Cardinality", "CARDINALITY (W)"),
        _imp(tier, "Relationship", "Optionality (mandatory parent)", "OPTIONALITY (W), RELATIONSHIP_SEMANTIC_MISMATCH"),
        _imp(tier, "Relationship", "Identifying / dependent", "RELATIONSHIP_SEMANTIC_MISMATCH (W)"),
        Row(tier, "Relationship", "RI update / delete rule", method="RELATIONSHIP_RI_RULE (I), *_UNMAPPED",
            status=PARTIALLY_SUPPORTED, remediation="confirm ERWIN_RI_RULE_CODES against one hand-set rule in erwin",
            notes="erwin code map provisional; compared only when PD states a rule"),
        _excluded(tier, "Relationship", "Dominance", NOT_SUPPORTED_BY_ERWIN,
                  "carry as a relationship UDP (Step 2) if it must reach downstream tools", target=N),
        _imp(tier, "Inheritance", "Parent / children", "INHERITANCE_STRUCTURE/EXTRA (W)"),
        _imp(tier, "Inheritance", "Complete / exclusive", "INHERITANCE_CONSTRAINT (W)"),
        _imp(tier, "Inheritance", "Name", "INHERITANCE_NAME (I)"),
        _imp(tier, "Domain", "Data type", "DOMAIN_MISMATCH (W)"),
        _imp(tier, "Domain", "Length / precision", "DOMAIN_LENGTH (I)"),
        _imp(tier, "Domain", "Default value", "DOMAIN_DEFAULT (I)"),
        Row(tier, "Domain", "Check parameters (low/high/list/format)", method="DOMAIN_CHECK_PARAMS (I)",
            status=PARTIALLY_SUPPORTED, remediation="list-of-values and format compared as present/absent only",
            notes="erwin stores them in a Validation Rule / min-max"),
        _imp(tier, "Domain", "Name", "DOMAIN_NAME (I)"),
        _step1(tier, "Domain", "DEFINITION_MISMATCH (W)"),
        _imp(tier, "Business Rule", "Name / expression", "BUSINESS_NAME (W), BUSINESS_RULE_EXPRESSION (W)"),
        _imp(tier, "Business Rule", "Type", "BUSINESS_RULE_TYPE (I)"),
        _step1(tier, "Business Rule", "DEFINITION_* (W/I)"),
        _imp(tier, "Package", "Name / hierarchy", "SUBJECT_AREA (I), PACKAGE_HIERARCHY (I)",
             notes="hierarchy loss detectable only when the export writes Parent_Subject_Area somewhere"),
        _imp(tier, "Package", "Contents (entities)", "PACKAGE_CONTENTS (I)"),
        Row(tier, "Package", "Comment / Definition", method="PACKAGE_DEFINITION (I)", status=PARTIALLY_SUPPORTED,
            remediation="validated, not injected: Step 1 does not write Subject_Area notes",
            notes="FUTURE: extend pd_comment_to_erwin_note to Subject_Area"),
        Row(tier, "Diagram", "Name / displayed symbols", method="DIAGRAM_MISSING, DIAGRAM_SYMBOLS (I)",
            status=NOT_YET_TESTED, remediation="confirm with one erwin export that carries Stored_Display",
            notes="vessel export had 0 Stored_Display for 2 PD diagrams; check is silent until then"),
        _excluded(tier, "Diagram", "Layout (positions, colours, fonts)", INTENTIONALLY_OUT_OF_SCOPE,
                  "presentation, not model content", notes=""),
    ]
ROWS += [
    # Shortcuts have no erwin object, so erwin's import cannot carry them. Since
    # app/validation/shortcut_udp.py they are MIGRATED as UDPs instead, on the
    # same manifest / injector / read-back as every other UDP. The old row said
    # AUTOMATICALLY_VALIDATED, which was never true: nothing on the erwin side
    # was parsed, so nothing was validated.
    Row("LDM", "Shortcut", "Presence / target",
        transformed="Step 2: PD Shortcut -> erwin UDP (PD_Shortcut_*)",
        auto=Y, manual=N, method="UDP component (25 %), UDP tool comparison workbook; SHORTCUT_* (I) census",
        status=AUTOMATICALLY_MIGRATED, evidence="T",
        notes="erwin has no shortcut object; carried as UDPs by shortcut_udp.py and "
              "verified by the UDP read-back"),
    Row("LDM", "Shortcut", "Glossary term bindings (name / code)",
        transformed="Step 2: c:RelatedNameTerms / c:RelatedCodeTerms -> PD_NameTerms / PD_CodeTerms UDPs",
        auto=Y, manual=N, method="UDP component (25 %), UDP tool comparison workbook",
        status=AUTOMATICALLY_MIGRATED, evidence="T",
        notes="102 of 105 entities in real_estate (797 term refs); bindings on relationships and "
              "attributes are counted into PD_Shortcut_Count, which erwin can only hold at model root"),
    _imp("CDM", "Data Item", "Presence / type", "folded into Attribute checks", notes="CDM data items compared as attributes"),
    _imp("CDM", "Association", "Associative entity (M:N)", "CHECK_ASSOCIATIONS (W)"),
    # ── PDM ──
    _imp("PDM", "Table", "Presence (code)", "TABLE_MISSING (C) / TABLE_EXTRA (W)"),
    _imp("PDM", "Table", "Logical name", "TABLE_LOGICAL_NAME (I)"),
    _imp("PDM", "Table", "Owner / schema", "TABLE_OWNER (I)"),
    _imp("PDM", "Table", "Tablespace assignment", "TABLE_TABLESPACE (I)"),
    _step1("PDM", "Table", "DOCUMENTATION sheet + documentation component (Note, then Comment, then Definition)"),
    _step2("PDM", "Table"),
    _imp("PDM", "Column", "Presence (code)", "COLUMN_MISSING (C) / COLUMN_EXTRA (W)"),
    _imp("PDM", "Column", "Logical name", "COLUMN_LOGICAL_NAME (I)"),
    _imp("PDM", "Column", "Data type incl. length / precision", "DATA_TYPE (C), DATA_TYPE_LENGTH (W), TYPE_* (V)",
         evidence="P/T", notes="any change incl. VARCHAR(500)->VARCHAR(255) or DECIMAL(18,2)->DECIMAL(38,10) is a finding"),
    _imp("PDM", "Column", "Nullable", "NULLABILITY (I)"),
    _imp("PDM", "Column", "Default value", "DEFAULT (I)"),
    _imp("PDM", "Column", "Domain binding", "COLUMN_DOMAIN (I)"),
    _imp("PDM", "Column", "Check constraint", "COLUMN_CHECK_CONSTRAINT (I)", notes="presence on the erwin column"),
    _imp("PDM", "Column", "Identity / auto-increment", "COLUMN_IDENTITY (I)"),
    _step1("PDM", "Column", "DOCUMENTATION sheet + documentation component"),
    _step2("PDM", "Column"),
    _excluded("PDM", "Column", "Order", INTENTIONALLY_OUT_OF_SCOPE, "set CHECK_COLUMN_ORDER=True"),
    _imp("PDM", "Primary Key", "Membership", "PRIMARY_KEY (C)"),
    _imp("PDM", "Primary Key", "Name", "KEY_NAME (I)"),
    _imp("PDM", "Alternate Key", "Membership / uniqueness", "INDEX_* signature (I)"),
    _imp("PDM", "Alternate Key", "Name", "KEY_NAME (I)"),
    _imp("PDM", "Reference (FK)", "Parent / child / join columns", "FOREIGN_KEY_MISSING/EXTRA (W/I)"),
    _imp("PDM", "Reference (FK)", "Name", "REFERENCE_NAME (I)"),
    Row("PDM", "Reference (FK)", "RI update / delete rule", method="REFERENCE_RI_RULE (I)", status=PARTIALLY_SUPPORTED,
        remediation="confirm ERWIN_RI_RULE_CODES", notes="provisional erwin code map"),
    _imp("PDM", "Reference (FK)", "Cardinality / parent optionality", "REFERENCE_CARDINALITY (I)"),
    _imp("PDM", "Index", "Member columns / unique", "INDEX_MISSING/EXTRA (I)"),
    _imp("PDM", "Index", "Name", "INDEX_NAME (I)"),
    _imp("PDM", "Index", "Column sort order", "INDEX_SORT_ORDER (I)"),
    _excluded("PDM", "Index", "Clustered / fill factor / DBMS options", FUTURE_ENHANCEMENT,
              "needs one real PDM export to fix erwin tag names"),
    _imp("PDM", "View", "Presence (code)", "VIEW_MISSING (W) / VIEW_EXTRA (I)"),
    Row("PDM", "View", "SQL definition", method="VIEW_SQL_MISMATCH (W)", status=PARTIALLY_SUPPORTED,
        remediation="lower SQL_SIMILARITY_THRESHOLD for literal fidelity", notes="tolerant compare (>= 90 % similar after normalisation)"),
    _imp("PDM", "View", "Columns", "VIEW_COLUMNS (I)"),
    _step1("PDM", "View", "DOCUMENTATION sheet; VIEW_DEFINITION (I) when still missing"),
    _imp("PDM", "Procedure / Function", "Presence (code)", "PROCEDURE_MISSING/EXTRA (W/I)"),
    Row("PDM", "Procedure / Function", "Body", method="PROCEDURE_BODY_MISMATCH (W)", status=PARTIALLY_SUPPORTED,
        remediation="lower SQL_SIMILARITY_THRESHOLD", notes="tolerant compare"),
    _excluded("PDM", "Procedure / Function", "Parameters (as objects)", NOT_SUPPORTED_BY_ERWIN,
              "parameters live in the SQL body, which is compared", target=N, validated=Y, method="via body comparison"),
    _step1("PDM", "Procedure / Function", "DOCUMENTATION sheet; PROCEDURE_DEFINITION (I)"),
    _imp("PDM", "Trigger", "Presence (code) / owning table", "TRIGGER_MISSING/EXTRA (W/I), TRIGGER_TABLE (I)"),
    Row("PDM", "Trigger", "Body", method="TRIGGER_BODY_MISMATCH (W)", status=PARTIALLY_SUPPORTED,
        remediation="lower SQL_SIMILARITY_THRESHOLD", notes="single literal change inside a >= 90 % similar body passes"),
    Row("PDM", "Trigger", "Event / timing", method="TRIGGER_EVENT (I)", status=NOT_YET_TESTED,
        remediation="confirm Trigger_Fire_On_* tag names on a real export"),
    _step1("PDM", "Trigger", "DOCUMENTATION sheet; TRIGGER_DEFINITION (I)"),
    _imp("PDM", "Sequence", "Presence (code)", "SEQUENCE_MISSING/EXTRA (I)"),
    Row("PDM", "Sequence", "Start / increment / min / max", method="SEQUENCE_PARAMS (I)", status=NOT_YET_TESTED,
        remediation="confirm min/max erwin tag names on a real export"),
    _step1("PDM", "Sequence", "DOCUMENTATION sheet; SEQUENCE_DEFINITION (I)"),
    _imp("PDM", "Tablespace", "Presence (code)", "TABLESPACE_MISSING/EXTRA (I)"),
    _step1("PDM", "Tablespace", "DOCUMENTATION sheet; TABLESPACE_DEFINITION (I)"),
    _excluded("PDM", "Tablespace", "Physical options (files, size)", FUTURE_ENHANCEMENT, "needs one real PDM export"),
    _imp("PDM", "Domain (physical)", "Existence / data type / default", "DOMAIN_OBJECT (I)"),
    _imp("PDM", "Business Rule", "Existence / expression", "BUSINESS_RULE_OBJECT (I)"),
    _imp("PDM", "Default", "Existence / value", "DEFAULT_OBJECT (I)"),
    Row("PDM", "Data Format", "Existence / expression", target=N, validated=Y,
        method="DATA_FORMAT_NOT_REPRESENTABLE (V census row)", status=NOT_SUPPORTED_BY_ERWIN,
        remediation="carry as a column UDP (Step 2) or in the column definition",
        notes="erwin has no Data Format object; never silently dropped — listed per column in every report"),
    _imp("PDM", "Database target", "DBMS name / version", "DATABASE_TARGET (I)", notes="version compared loosely"),
    Row("PDM", "Diagram", "Name / displayed tables", method="DIAGRAM_MISSING, DIAGRAM_SYMBOLS (I)",
        status=NOT_YET_TESTED, remediation="confirm with one export carrying Stored_Display"),
    _imp("PDM", "Package", "Presence / contents", "PACKAGE_MISSING/EXTRA (I), PACKAGE_CONTENTS (I)"),
    _imp("PDM", "User / Owner", "Owner on table", "TABLE_OWNER (I)", notes="erwin has no separate User object"),
]

BEGIN = "<!-- COVERAGE_MATRIX_ROWS:BEGIN -->"
END = "<!-- COVERAGE_MATRIX_ROWS:END -->"


def render() -> str:
    lines = ["| " + " | ".join(COLUMNS) + " |", "|" + "---|" * len(COLUMNS)]
    for row in ROWS:
        lines.append("| " + " | ".join(str(c).replace("|", "\\|") for c in row.cells()) + " |")
    counts = {}
    for row in ROWS:
        counts[row.status] = counts.get(row.status, 0) + 1
    summary = ", ".join(f"{k} {v}" for k, v in sorted(counts.items(), key=lambda kv: -kv[1]))
    return f"_{len(ROWS)} rows — {summary}._\n\n" + "\n".join(lines) + "\n"


def inject(doc_path: Path) -> bool:
    text = doc_path.read_text(encoding="utf-8")
    if BEGIN not in text or END not in text:
        return False
    pattern = re.compile(re.escape(BEGIN) + r".*?" + re.escape(END), re.S)
    new = pattern.sub(lambda _m: f"{BEGIN}\n{render()}{END}", text)
    if new != text:
        doc_path.write_text(new, encoding="utf-8")
    return True


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    target = Path(argv[0]) if argv else Path(__file__).resolve().parents[1] / "COVERAGE_MATRIX.md"
    if inject(target):
        print(f"{len(ROWS)} rows written into {target}")
        return 0
    print(render())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
