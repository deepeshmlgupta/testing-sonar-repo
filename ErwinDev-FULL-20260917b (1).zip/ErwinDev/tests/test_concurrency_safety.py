"""
Threading safety of the batch runner and the two isolated-import bridges.

  * pre-flight rejects models that would write the same files
  * the stall watchdog reports (and optionally aborts) a wedged worker
  * concurrent loads of the UDP tool and the PDM validator leave sys.path
    and sys.modules intact (the race the shared IMPORT_LOCK exists for)
  * a batch under 4 workers produces the same rows as the sequential run
"""

import os
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.common import isolated_import  # noqa: E402
from app.orchestration import batch_runner, concurrency  # noqa: E402
from app.utils import session_manager  # noqa: E402
from app.validation import udp_bridge  # noqa: E402
from app.validation.pdm_reconcile import pdm_validator_bridge  # noqa: E402

HASH = "3eafce5dd91787f5f61afafbe5ffcf7d"


def _dirs(tmp_path: Path) -> dict:
    return {
        "summary": tmp_path / "batch_summary",
        "final_xml": tmp_path / "final_xml_models",
        "initial": tmp_path / "erwinmodels" / "1_initial",
        "preprocessed": tmp_path / "erwinmodels" / "2_preprocessed",
        "final": tmp_path / "erwinmodels" / "3_final",
        "stages": {"xml_v1": tmp_path / "erwinmodels" / "1_xml_v1"},
    }


# ─── pre-flight ───────────────────────────────────────────────────────────────

def test_preflight_rejects_same_stem_across_tiers(tmp_path):
    models = [tmp_path / "ldm" / "airlines.ldm", tmp_path / "cdm" / "airlines.cdm",
              tmp_path / "pdm" / "warehouse.pdm"]
    result = concurrency.preflight(models, _dirs(tmp_path), max_workers=4)
    assert result.ok == [models[0], models[2]]
    assert models[1] in result.rejected
    assert "same stage artefacts" in result.rejected[models[1]]


def test_preflight_rejects_colliding_short_report_names(tmp_path):
    a = tmp_path / f"{HASH}_46584675_airlines.ldm"
    b = tmp_path / f"{'0' * 32}_99999999_airlines.ldm"
    result = concurrency.preflight([a, b], _dirs(tmp_path), max_workers=2)
    assert result.ok == [a]
    assert "report folder name 'airlines'" in result.rejected[b]


def test_preflight_creates_output_roots_and_probes_the_ledger_lock(tmp_path):
    dirs = _dirs(tmp_path)
    result = concurrency.preflight([tmp_path / "x.ldm"], dirs, max_workers=1)
    assert result.clean
    assert (dirs["summary"] / "audit").is_dir()
    assert (dirs["stages"]["xml_v1"]).is_dir()
    assert not (dirs["summary"] / ".write_probe").exists()


@pytest.mark.skipif(sys.platform == "win32", reason="msvcrt locks are per-handle; probed differently")
def test_preflight_warns_when_another_run_holds_the_ledger_lock(tmp_path):
    dirs = _dirs(tmp_path)
    ledger = dirs["summary"] / "audit" / "pipeline_ledger.jsonl"
    ledger.parent.mkdir(parents=True)
    holder_ready, release = threading.Event(), threading.Event()

    def hold():
        with session_manager.file_lock(ledger, timeout=1):
            holder_ready.set()
            release.wait(5)

    thread = threading.Thread(target=hold)
    thread.start()
    try:
        assert holder_ready.wait(5)
        assert session_manager.lock_is_held(ledger, timeout=0.2)
        result = concurrency.preflight([tmp_path / "x.ldm"], dirs, max_workers=2, lock_probe_timeout=0.2)
        assert any("holds the ledger lock" in w for w in result.warnings)
    finally:
        release.set()
        thread.join(5)
    assert not session_manager.lock_is_held(ledger)


def test_report_preflight_records_rejections_as_skipped(tmp_path):
    concurrency.clear_skipped_models()
    result = concurrency.preflight([tmp_path / "a.ldm", tmp_path / "a.cdm"], _dirs(tmp_path))
    concurrency.report_preflight(result)
    assert any("pre-flight" in reason for reason in concurrency.get_skipped_models())
    concurrency.clear_skipped_models()


# ─── stall watchdog ───────────────────────────────────────────────────────────

def _fake_worker(task):
    index, _total, model = task[0], task[1], task[2]
    if "slow" in model.name:
        time.sleep(0.6)
    return index, object(), [model.stem]


def test_stall_watchdog_reports_then_completes(tmp_path, caplog):
    models = [tmp_path / "slow.ldm", tmp_path / "quick.cdm"]
    with patch.object(batch_runner, "process_single_model_worker", _fake_worker), \
         patch("app.orchestration.batch_runner.get_setting",
               side_effect=lambda n, d: {"BATCH_STALL_TIMEOUT_SECONDS": 0.15,
                                         "BATCH_ABORT_ON_STALL": False}.get(n, d)):
        rows = batch_runner.run_batch(models, _dirs(tmp_path), release=True, max_workers=2)
    assert sorted(r[0] for r in rows) == ["quick", "slow"]
    assert "still pending: slow.ldm" in caplog.text


def test_stall_watchdog_can_abort(tmp_path):
    models = [tmp_path / "slow.ldm", tmp_path / "quick.cdm"]
    with patch.object(batch_runner, "process_single_model_worker", _fake_worker), \
         patch("app.orchestration.batch_runner.get_setting",
               side_effect=lambda n, d: {"BATCH_STALL_TIMEOUT_SECONDS": 0.15,
                                         "BATCH_ABORT_ON_STALL": True}.get(n, d)), \
         pytest.raises(TimeoutError):
        batch_runner.run_batch(models, _dirs(tmp_path), release=True, max_workers=2)


def test_stall_report_names_pending_models_and_worker_threads():
    text = concurrency.stall_report(["a.ldm"], 12)
    assert text.startswith("No model finished in 12s; still pending: a.ldm")


# ─── isolated imports under contention ────────────────────────────────────────

def test_concurrent_bridge_loads_leave_interpreter_state_intact():
    udp_bridge._LOADER.reset()
    pdm_validator_bridge._LOADER.reset()
    path_before = list(sys.path)
    modules_before = set(sys.modules)
    errors = []

    def worker(i):
        try:
            if i % 2:
                assert "pd_extract" in udp_bridge.load()
            else:
                assert "comparator" in pdm_validator_bridge.load()
        except Exception as exc:                               # noqa: BLE001
            errors.append(exc)

    with ThreadPoolExecutor(max_workers=8) as pool:
        list(pool.map(worker, range(32)))

    assert errors == []
    assert sys.path == path_before, "an isolated import window leaked into sys.path"
    leaked = {name for name in set(sys.modules) - modules_before
              if not name.startswith(("udp_tool.", "pdm_validator."))}
    # Only the deliberate private aliases (and their standard-library imports) may be new.
    assert not any(isolated_import.module_belongs_to(sys.modules[n], udp_bridge.TOOL_DIR) for n in leaked)
    assert not any(isolated_import.module_belongs_to(sys.modules[n], pdm_validator_bridge.VALIDATOR_DIR)
                   for n in leaked)
    # The two tools both own a bare "comparator": each bridge still sees its own.
    assert udp_bridge.load()["udp_compare"] is not pdm_validator_bridge.load()["comparator"]


def test_import_lock_is_reentrant():
    with isolated_import.IMPORT_LOCK:
        with isolated_import.IMPORT_LOCK:
            assert udp_bridge.load()
