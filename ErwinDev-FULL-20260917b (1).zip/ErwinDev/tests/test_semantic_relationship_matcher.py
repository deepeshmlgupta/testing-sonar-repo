from types import SimpleNamespace

from app.validation.semantic_relationship_matcher import match_relationships


def relationship(name, first, second, first_card="0,n", second_card="1,1",
                 first_role="", second_role=""):
    return SimpleNamespace(
        name=name,
        code="",
        end1=SimpleNamespace(entity=first, cardinality=first_card, role=first_role),
        end2=SimpleNamespace(entity=second, cardinality=second_card, role=second_role),
    )


def match(source, target):
    return match_relationships(
        [source], [target],
        entity_key=lambda value: " ".join(str(value).casefold().replace("_", " ").split()),
        endpoint_key=lambda value: value,
        full_key=lambda value: (
            tuple(sorted((value.end1.entity.casefold(), value.end2.entity.casefold()))),
            tuple(sorted((value.end1.cardinality, value.end2.cardinality))),
        ),
    )


def test_renamed_reversed_relationship_matches_semantically():
    outcome = match(
        relationship("places", "CUSTOMER", "ORDER"),
        relationship("customer order", "ORDER", "CUSTOMER", "1,1", "0,n"),
    )

    assert len(outcome.pairs) == 1
    assert not outcome.unmatched_left
    assert not outcome.unmatched_right


def test_cardinality_change_matches_and_remains_comparable():
    outcome = match(
        relationship("places", "CUSTOMER", "ORDER", "0,n", "1,1"),
        relationship("places", "CUSTOMER", "ORDER", "0,n", "0,1"),
    )

    assert len(outcome.pairs) == 1
    assert outcome.pairs[0][2] == "semantic endpoints + name"


def test_different_entity_pair_is_not_falsely_matched():
    outcome = match(
        relationship("places", "CUSTOMER", "ORDER"),
        relationship("places", "CUSTOMER", "INVOICE"),
    )

    assert not outcome.pairs
    assert len(outcome.unmatched_left) == 1
    assert len(outcome.unmatched_right) == 1


def test_duplicate_relationships_are_consolidated_by_semantics():
    first = relationship("origin for", "ORDER", "CUSTOMER", "0,n", "1,1")
    second = relationship("destination for", "ORDER", "CUSTOMER", "0,1", "1,1")
    target_first = relationship("origin for/1", "CUSTOMER", "ORDER", "1,1", "0,n")
    target_second = relationship("destination for", "CUSTOMER", "ORDER", "1,1", "0,1")

    outcome = match_relationships(
        [first, second], [target_first, target_second],
        entity_key=lambda value: value.casefold(),
        endpoint_key=lambda value: value,
        full_key=lambda value: tuple(sorted((value.end1.cardinality, value.end2.cardinality))),
    )

    assert len(outcome.pairs) == 2
    assert not outcome.unmatched_left
    assert not outcome.unmatched_right


def test_role_phrase_articles_and_is_prefix_do_not_block_matching():
    outcome = match_relationships(
        [relationship("subject of", "MARITIME_ASSURANCE_SUBJECT", "WATERWAY",
                       first_role="subject of")],
        [relationship("subject of2", "WATERWAY", "MARITIME_ASSURANCE_SUBJECT",
                       first_card="1,1", second_card="0,n",
                       second_role="is subject of")],
        entity_key=lambda value: value.casefold(),
        endpoint_key=lambda value: value,
        full_key=lambda value: tuple(sorted((value.end1.cardinality, value.end2.cardinality))),
    )

    assert len(outcome.pairs) == 1
    assert not outcome.unmatched_left
    assert not outcome.unmatched_right
