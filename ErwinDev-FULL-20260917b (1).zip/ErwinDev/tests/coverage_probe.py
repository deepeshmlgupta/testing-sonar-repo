"""
Property-coverage probes: mutate ONE property on the erwin side of the
extended fixtures and record whether the engine raises a penalising finding.

Each probe is (object type, property, anchor text in the erwin XML, replacement).
"Detected" means a CRITICAL / WARNING / INFO finding appeared (or a category's
count rose) relative to the clean baseline. VERIFIED rows do not count — they
never affect the score, so they cannot flag a loss.

Run as a module to print the matrix:

    python -m tests.coverage_probe            # markdown
    python -m tests.coverage_probe --json     # machine readable

tests/test_property_coverage.py turns the "expected detected" rows into
assertions so a later change cannot silently stop validating a property.
"""

from __future__ import annotations

import json
import os
import sys
import tempfile
from collections import Counter
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Tuple

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tests.fixtures_extended import ERWIN_LDM_FULL, ERWIN_PDM_FULL, PD_LDM_FULL, PD_PDM_FULL  # noqa: E402

PENALISING = ("CRITICAL", "WARNING", "INFO")


@dataclass
class Probe:
    obj: str
    prop: str
    old: str
    new: str
    expect: Optional[bool] = None    # True = must be detected, False = documented gap, None = record only
    note: str = ""


@dataclass
class ProbeResult:
    engine: str
    obj: str
    prop: str
    detected: bool
    categories: List[str]
    expect: Optional[bool]
    note: str

    def status(self) -> str:
        if self.detected:
            return "VALIDATED"
        return "NOT VALIDATED"


# ─────────────────────────────────────────────────────────────────────────────
#  Probe catalogue — LDM / CDM (same erwin vocabulary)
# ─────────────────────────────────────────────────────────────────────────────

LDM_PROBES: List[Probe] = [
    # Entity
    Probe("Entity", "Name", '<Entity id="{E2}+00000000" name="Voyage"><EntityProps><Name>Voyage</Name>',
          '<Entity id="{E2}+00000000" name="Journey"><EntityProps><Name>Journey</Name>', True, "renamed → missing/extra"),
    Probe("Entity", "Definition/Comment", "<Definition>A journey made by a vessel.</Definition>", "<Definition>Something else entirely.</Definition>", True),
    Probe("Entity", "Definition lost", "<Definition>A journey made by a vessel.</Definition>", "", True),
    Probe("Entity", "Extended attribute (UDP) value", "<UDP:BIMType>Master</UDP:BIMType>", "<UDP:BIMType>Reference</UDP:BIMType>", None,
          "scored by udp_fidelity (UDP component), not a finding"),
    Probe("Entity", "Subject area / package membership", "<Entity_Ref>{E3}+00000000</Entity_Ref>", "", None, "PACKAGE_CONTENTS fires when contents differ (next Package rows); when the ONLY subject area loses all its Entity_Ref the export is indistinguishable from one that never writes contents"),
    # Attribute
    Probe("Attribute", "Name", 'name="Departure Date"><AttributeProps><Name>Departure Date</Name>', 'name="Arrival Date"><AttributeProps><Name>Arrival Date</Name>', True),
    Probe("Attribute", "Code / physical name", "<Physical_Name>DEPARTURE_DATE</Physical_Name>", "<Physical_Name>DEP_DT</Physical_Name>", True),
    Probe("Attribute", "Definition", "<Definition>When the voyage started.</Definition>", "<Definition>Different text.</Definition>", True),
    Probe("Attribute", "Data type", "<Logical_Data_Type>DATE</Logical_Data_Type>", "<Logical_Data_Type>VARCHAR(30)</Logical_Data_Type>", True),
    Probe("Attribute", "Length", "<Logical_Data_Type>VARCHAR(100)</Logical_Data_Type><Length>100</Length>",
          "<Logical_Data_Type>VARCHAR(50)</Logical_Data_Type><Length>50</Length>", True),
    Probe("Attribute", "Precision / scale", "<Logical_Data_Type>DECIMAL(12,2)</Logical_Data_Type><Length>12</Length><Scale>2</Scale>",
          "<Logical_Data_Type>DECIMAL(12,4)</Logical_Data_Type><Length>12</Length><Scale>4</Scale>", True),
    Probe("Attribute", "Mandatory / optional", "<Null_Option_Type>1</Null_Option_Type></AttributeProps></Attribute>",
          "<Null_Option_Type>0</Null_Option_Type></AttributeProps></Attribute>", True),
    Probe("Attribute", "Domain assignment", "<Domain_Name>Status Domain</Domain_Name>", "<Domain_Name>Identifier Domain</Domain_Name>", True, "ATTRIBUTE_DOMAIN (extended_properties)"),
    Probe("Attribute", "Domain binding lost", "<Domain_Name>Status Domain</Domain_Name>", "", True, "ATTRIBUTE_DOMAIN"),
    Probe("Attribute", "Default value", "<Default_Value>'ACTIVE'</Default_Value>", "<Default_Value>'RETIRED'</Default_Value>", True, "ATTRIBUTE_DEFAULT (extended_properties)"),
    Probe("Attribute", "Default value lost", "<Default_Value>'ACTIVE'</Default_Value>", "", True, "ATTRIBUTE_DEFAULT"),
    Probe("Attribute", "Extended attribute (UDP)", "<UDP:BIMType>Master</UDP:BIMType></EntityProps>", "</EntityProps>", None, "UDP component"),
    Probe("Attribute", "Order / sequence", "", "", None, "CHECK_ATTRIBUTE_ORDER=False by default"),
    # Identifiers
    Probe("Identifier", "PK membership", "<Key_Group_Member id=\"{KM1}+00000000\"><Key_Group_MemberProps><Attribute_Ref>{A1}+00000000</Attribute_Ref>",
          "<Key_Group_Member id=\"{KM1}+00000000\"><Key_Group_MemberProps><Attribute_Ref>{A2}+00000000</Attribute_Ref>", True),
    Probe("Identifier", "AK membership", "<Attribute_Ref>{A4}+00000000</Attribute_Ref><Key_Group_Member_Order>2</Key_Group_Member_Order>",
          "<Attribute_Ref>{A3}+00000000</Attribute_Ref><Key_Group_Member_Order>2</Key_Group_Member_Order>", True),
    Probe("Identifier", "AK member order", "{A2}+00000000</Attribute_Ref><Key_Group_Member_Order>1<", "{A2}+00000000</Attribute_Ref><Key_Group_Member_Order>3<", True, "IDENTIFIER_MEMBER_ORDER (extended_properties)"),
    Probe("Identifier", "Name", "<Name>AK Vessel Name</Name><Physical_Name>AK_VESSEL_NAME</Physical_Name>", "<Name>AK Something</Name><Physical_Name>AK_X</Physical_Name>", True, "IDENTIFIER_NAME (extended_properties)"),
    Probe("Identifier", "PK lost", "<Physical_Name>PK_VOYAGE</Physical_Name><Key_Group_Type>PK</Key_Group_Type>",
          "<Physical_Name>PK_VOYAGE</Physical_Name><Key_Group_Type>AK</Key_Group_Type>", True),
    # Relationship
    Probe("Relationship", "Name / verb phrase", "<Parent_To_Child_Verb_Phrase>makes</Parent_To_Child_Verb_Phrase>", "<Parent_To_Child_Verb_Phrase>operates</Parent_To_Child_Verb_Phrase>", True, "ROLE_NAME"),
    Probe("Relationship", "Inverse role", "<Child_To_Parent_Verb_Phrase>is made by</Child_To_Parent_Verb_Phrase>", "<Child_To_Parent_Verb_Phrase>belongs to</Child_To_Parent_Verb_Phrase>", True),
    Probe("Relationship", "Definition", "<Definition>A vessel makes voyages.</Definition>", "<Definition>Changed.</Definition>", True),
    Probe("Relationship", "Cardinality (many end)", "<Cardinality>-3</Cardinality>", "<Cardinality>-1</Cardinality>", True),
    Probe("Relationship", "Mandatory parent (optionality)", "<Null_Option_Type>101</Null_Option_Type><Cardinality>-3</Cardinality>",
          "<Null_Option_Type>100</Null_Option_Type><Cardinality>-3</Cardinality>", True),
    Probe("Relationship", "Identifying flag", "<Type>7</Type><Null_Option_Type>101</Null_Option_Type>",
          "<Type>2</Type><Null_Option_Type>101</Null_Option_Type>", True),
    Probe("Relationship", "Parent / child entity", "<Parent_Entity_Ref>{E1}+00000000</Parent_Entity_Ref><Child_Entity_Ref>{E2}+00000000</Child_Entity_Ref>",
          "<Parent_Entity_Ref>{E3}+00000000</Parent_Entity_Ref><Child_Entity_Ref>{E2}+00000000</Child_Entity_Ref>", True),
    Probe("Relationship", "Referential integrity (update rule)", "<Parent_Update_Rule>10000</Parent_Update_Rule>", "<Parent_Update_Rule>10002</Parent_Update_Rule>", True, "RELATIONSHIP_RI_RULE (extended_properties); erwin code map is provisional"),
    Probe("Relationship", "Referential integrity (rule lost)", "<Parent_Update_Rule>10000</Parent_Update_Rule>", "", True,
          "no per-relationship rule and no model default → reported as not carried"),
    Probe("Relationship", "Referential integrity (delete rule)", "<Parent_Delete_Rule>10005</Parent_Delete_Rule>", "<Parent_Delete_Rule>10006</Parent_Delete_Rule>", True, "RELATIONSHIP_RI_RULE"),
    Probe("Relationship", "Dominance", "", "", False, "PD DominantRole not read; erwin has no dominance field"),
    # Inheritance
    Probe("Inheritance", "Parent entity", "<Parent_Entity_Ref>{E1}+00000000</Parent_Entity_Ref><Completeness>", "<Parent_Entity_Ref>{E2}+00000000</Parent_Entity_Ref><Completeness>", True),
    Probe("Inheritance", "Child entities", "<Subtype_Member><Entity_Ref>{E3}+00000000</Entity_Ref></Subtype_Member>", "<Subtype_Member><Entity_Ref>{E2}+00000000</Entity_Ref></Subtype_Member>", True),
    Probe("Inheritance", "Complete / incomplete", "<Completeness>Incomplete</Completeness>", "<Completeness>Complete</Completeness>", True),
    Probe("Inheritance", "Mutually exclusive", "<Exclusivity>Exclusive</Exclusivity>", "<Exclusivity>Inclusive</Exclusivity>", True),
    Probe("Inheritance", "Name", '<Subtype_Relationship id="{H1}+00000000" name="Vessel Kind"><Subtype_RelationshipProps><Name>Vessel Kind</Name>',
          '<Subtype_Relationship id="{H1}+00000000" name="Kind"><Subtype_RelationshipProps><Name>Kind</Name>', True, "INHERITANCE_NAME (extended_properties)"),
    # Domain
    Probe("Domain", "Data type", "<Logical_Datatype>VARCHAR(10)</Logical_Datatype><Length>10</Length>",
          "<Logical_Datatype>NUMBER(10)</Logical_Datatype><Length>10</Length>", True),
    Probe("Domain", "Length", "<Logical_Datatype>NUMBER(10)</Logical_Datatype><Length>10</Length><Scale>0</Scale>", "<Logical_Datatype>NUMBER(10)</Logical_Datatype><Length>12</Length><Scale>0</Scale>", True, "DOMAIN_LENGTH (extended_properties)"),
    Probe("Domain", "Definition", "<Definition>Surrogate identifier.</Definition><Logical_Datatype>", "<Definition>Changed.</Definition><Logical_Datatype>", True),
    Probe("Domain", "Default value", "<Default_Value>0</Default_Value><Min_Value>1</Min_Value>", "<Default_Value>1</Default_Value><Min_Value>1</Min_Value>", True, "DOMAIN_DEFAULT (extended_properties)"),
    Probe("Domain", "Check parameters (low/high/list/format)", "<Min_Value>1</Min_Value><Max_Value>9999999999</Max_Value>", "", True, "DOMAIN_CHECK_PARAMS (extended_properties): PD Low/High/List/Format vs erwin Min/Max/Valid_Value_Rule_Ref"),
    Probe("Domain", "Check parameters (high value changed)", "<Max_Value>9999999999</Max_Value>", "<Max_Value>99</Max_Value>", True, "DOMAIN_CHECK_PARAMS"),
    Probe("Domain", "Name", "<Domain id=\"{D2}+00000000\" name=\"Status Domain\"><DomainProps><Name>Status Domain</Name>", "<Domain id=\"{D2}+00000000\" name=\"State Domain\"><DomainProps><Name>State Domain</Name>", True, "matched by code → name mismatch not itself compared; here code also carries"),
    # Business rule
    Probe("Business Rule", "Name", "<Validation_Rule id=\"{BR1}+00000000\" name=\"Positive Capacity\"><Validation_RuleProps><Name>Positive Capacity</Name>",
          "<Validation_Rule id=\"{BR1}+00000000\" name=\"Capacity Check\"><Validation_RuleProps><Name>Capacity Check</Name>", True),
    Probe("Business Rule", "Expression", "<Expression>CAPACITY &gt; 0</Expression>", "<Expression>CAPACITY &gt;= 1</Expression>", True),
    Probe("Business Rule", "Type", "<Rule_Type>Validation</Rule_Type>", "<Rule_Type>Constraint</Rule_Type>", True, "BUSINESS_RULE_TYPE (extended_properties)"),
    Probe("Business Rule", "Definition", "<Definition>Capacity must be positive.</Definition><Rule_Type>", "<Definition>Changed.</Definition><Rule_Type>", True),
    # Package
    Probe("Package", "Name", "<Subject_Area id=\"{SA2}+00000000\" name=\"Vessels\"><Subject_AreaProps><Name>Vessels</Name>",
          "<Subject_Area id=\"{SA2}+00000000\" name=\"Ships\"><Subject_AreaProps><Name>Ships</Name>", True),
    Probe("Package", "Hierarchy (parent changed)", "<Parent_Subject_Area>Assets</Parent_Subject_Area>", "<Parent_Subject_Area>Other</Parent_Subject_Area>", True),
    Probe("Package", "Hierarchy (parent lost → root)", "<Parent_Subject_Area>Assets</Parent_Subject_Area>", "", None,
          "PACKAGE_HIERARCHY fires only when the export still carries Parent_Subject_Area somewhere; with one nested package the loss is indistinguishable from an export that never writes parents"),
    Probe("Package", "Contents (entities)", "<Entity_Ref>{E3}+00000000</Entity_Ref>", "<Entity_Ref>{E1}+00000000</Entity_Ref>", True, "PACKAGE_CONTENTS (extended_properties)"),
    Probe("Package", "Definition", "<Definition>Asset subject area.</Definition>", "<Definition>Changed.</Definition>", True, "PACKAGE_DEFINITION (extended_properties)"),
    # Diagram
    Probe("Diagram", "Name", "<Stored_Display id=\"{SD1}+00000000\" name=\"Fleet Overview\"><Stored_DisplayProps><Name>Fleet Overview</Name>",
          "<Stored_Display id=\"{SD1}+00000000\" name=\"Overview\"><Stored_DisplayProps><Name>Overview</Name>", True, "DIAGRAM_MISSING (extended_properties); only when the export carries Stored_Display"),
    Probe("Diagram", "Symbols displayed", "<Drawing_Object_EntityProps><Entity_Ref>{E2}+00000000</Entity_Ref>", "<Drawing_Object_EntityProps><Entity_Ref>{E3}+00000000</Entity_Ref>", True, "DIAGRAM_SYMBOLS (extended_properties); erwin drawing-object tag names unverified"),
    # Model
    Probe("Model", "Name", '<ModelProps><Name>Fleet</Name>', '<ModelProps><Name>Armada</Name>', True,
          "the EMX:Model name attribute is read first; probe changes both via two anchors below"),
    Probe("Model", "Definition", "<Definition>Fleet logical model.</Definition>", "<Definition>Other.</Definition>", True, "MODEL_DEFINITION (extended_properties)"),
]

# ─────────────────────────────────────────────────────────────────────────────
#  Probe catalogue — PDM
# ─────────────────────────────────────────────────────────────────────────────

PDM_PROBES: List[Probe] = [
    # Table
    Probe("Table", "Code / physical name", "<Physical_Name>VOYAGE</Physical_Name>", "<Physical_Name>JOURNEY</Physical_Name>", True),
    Probe("Table", "Name (logical)", "<Name>Voyage</Name><Physical_Name>VOYAGE</Physical_Name>", "<Name>Journey</Name><Physical_Name>VOYAGE</Physical_Name>", True, "TABLE_LOGICAL_NAME (extended_properties)"),
    Probe("Table", "Owner / schema", "<Physical_Name>VOYAGE</Physical_Name><Owner>dbo</Owner>", "<Physical_Name>VOYAGE</Physical_Name><Owner>sales</Owner>", True, "TABLE_OWNER (extended_properties)"),
    Probe("Table", "Definition / comment", "<Definition>A journey made by a vessel.</Definition>", "<Definition>Changed.</Definition>", None, "scored by the documentation component (25 %) via the DOCUMENTATION sheet, not a finding; PD Comment maps to erwin Definition directly, and PD Description is carried by Step 1 into an erwin Note (client-confirmed mapping, 2026-09-16)"),
    Probe("Table", "Tablespace assignment", "<Tablespace_Ref>{TS1}+00000000</Tablespace_Ref>", "<Tablespace_Ref>{TSX}+00000000</Tablespace_Ref>", True, "TABLE_TABLESPACE (extended_properties)"),
    Probe("Table", "Extended attributes (UDP)", "", "", None, "udp_fidelity component"),
    # Column
    Probe("Column", "Code / physical name", "<Physical_Name>DEPARTURE_DATE</Physical_Name>", "<Physical_Name>DEP_DT</Physical_Name>", True),
    Probe("Column", "Name (logical)", "<Name>Departure Date</Name>", "<Name>Departure Dt</Name>", True, "COLUMN_LOGICAL_NAME (extended_properties)"),
    Probe("Column", "Data type", "<Physical_Data_Type>date</Physical_Data_Type>", "<Physical_Data_Type>varchar(30)</Physical_Data_Type>", True),
    Probe("Column", "Length", "<Physical_Data_Type>varchar(100)</Physical_Data_Type><Null_Option_Type>1</Null_Option_Type>",
          "<Physical_Data_Type>varchar(50)</Physical_Data_Type><Null_Option_Type>1</Null_Option_Type>", True),
    Probe("Column", "Precision", "<Physical_Data_Type>decimal(12,2)</Physical_Data_Type><Null_Option_Type>0</Null_Option_Type>",
          "<Physical_Data_Type>decimal(12,4)</Physical_Data_Type><Null_Option_Type>0</Null_Option_Type>", True),
    Probe("Column", "Nullable flag", "<Physical_Data_Type>date</Physical_Data_Type><Null_Option_Type>0</Null_Option_Type>", "<Physical_Data_Type>date</Physical_Data_Type><Null_Option_Type>1</Null_Option_Type>", True),
    Probe("Column", "Default value", "<Default_Value>0</Default_Value><Domain_Name>Money</Domain_Name>", "<Default_Value>1</Default_Value><Domain_Name>Money</Domain_Name>", True),
    Probe("Column", "Domain binding", "<Domain_Name>Money</Domain_Name>", "<Domain_Name>Other</Domain_Name>", True, "COLUMN_DOMAIN (extended_properties)"),
    Probe("Column", "Check constraint", "<Valid_Value_Rule_Ref>{BR1}+00000000</Valid_Value_Rule_Ref>", "<Min_Value></Min_Value>", True, "COLUMN_CHECK_CONSTRAINT (extended_properties): a rule / min / max must exist on the erwin column"),
    Probe("Column", "Identity / auto-increment", "<Identity>true</Identity>", "<Identity>false</Identity>", True, "COLUMN_IDENTITY (extended_properties)"),
    Probe("Column", "Definition / comment", "", "", None, "documentation component (25 %), as for tables"),
    # Keys
    Probe("Key", "PK membership", "<Key_Group_Member id=\"{KM2}+00000000\"><Key_Group_MemberProps><Attribute_Ref>{C5}+00000000</Attribute_Ref>",
          "<Key_Group_Member id=\"{KM2}+00000000\"><Key_Group_MemberProps><Attribute_Ref>{C7}+00000000</Attribute_Ref>", True),
    Probe("Key", "PK name", "<Name>PK_VOYAGE</Name><Physical_Name>PK_VOYAGE</Physical_Name>", "<Name>PK_JOURNEY</Name><Physical_Name>PK_JOURNEY</Physical_Name>", True, "KEY_NAME (extended_properties)"),
    Probe("Key", "AK (unique key) membership", "<Key_Group_Member id=\"{KM4}+00000000\"><Key_Group_MemberProps><Attribute_Ref>{C2}+00000000</Attribute_Ref>",
          "<Key_Group_Member id=\"{KM4}+00000000\"><Key_Group_MemberProps><Attribute_Ref>{C3}+00000000</Attribute_Ref>", True, "via index-signature comparison"),
    Probe("Key", "AK uniqueness flag", "<Key_Group_Type>AK</Key_Group_Type><Is_Unique>true</Is_Unique>", "<Key_Group_Type>IE</Key_Group_Type><Is_Unique>false</Is_Unique>", True, "U:/I: signature prefix"),
    # Reference
    Probe("Reference", "Parent / child table", "<Parent_Entity_Ref>{T1}+00000000</Parent_Entity_Ref><Child_Entity_Ref>{T2}+00000000</Child_Entity_Ref>",
          "<Parent_Entity_Ref>{T3}+00000000</Parent_Entity_Ref><Child_Entity_Ref>{T2}+00000000</Child_Entity_Ref>", True),
    Probe("Reference", "Join columns", "<Parent_Attribute_Ref>{C1}+00000000</Parent_Attribute_Ref><Parent_Relationship_Ref>{R1}+00000000</Parent_Relationship_Ref>",
          "<Parent_Attribute_Ref>{C2}+00000000</Parent_Attribute_Ref><Parent_Relationship_Ref>{R1}+00000000</Parent_Relationship_Ref>", True),
    Probe("Reference", "Name / constraint name", "<Name>makes</Name><Physical_Name>FK_VOYAGE_VESSEL</Physical_Name>", "<Name>owns</Name><Physical_Name>FK_X</Physical_Name>", True, "REFERENCE_NAME (extended_properties)"),
    Probe("Reference", "Referential integrity (update)", "<Parent_Update_Rule>10000</Parent_Update_Rule>", "<Parent_Update_Rule>10002</Parent_Update_Rule>", True, "REFERENCE_RI_RULE (extended_properties); erwin code map is provisional"),
    Probe("Reference", "Referential integrity (delete)", "<Parent_Delete_Rule>10005</Parent_Delete_Rule>", "<Parent_Delete_Rule>10006</Parent_Delete_Rule>", True, "REFERENCE_RI_RULE"),
    Probe("Reference", "Cardinality / optionality", "<Null_Option_Type>101</Null_Option_Type><Cardinality>-3</Cardinality>",
          "<Null_Option_Type>100</Null_Option_Type><Cardinality>-1</Cardinality>", True, "REFERENCE_CARDINALITY (extended_properties): PD Cardinality / ParentMandatory vs erwin Cardinality / Null_Option_Type"),
    # Index
    Probe("Index", "Member columns", "<Attribute_Ref>{C4}+00000000</Attribute_Ref><Key_Group_Sort_Order>ASC</Key_Group_Sort_Order>",
          "<Attribute_Ref>{C3}+00000000</Attribute_Ref><Key_Group_Sort_Order>ASC</Key_Group_Sort_Order>", True),
    Probe("Index", "Unique flag", "<Key_Group_Type>IE</Key_Group_Type><Is_Unique>false</Is_Unique>", "<Key_Group_Type>IE</Key_Group_Type><Is_Unique>true</Is_Unique>", True),
    Probe("Index", "Name", "<Name>IX_VESSEL_TYPE</Name><Physical_Name>IX_VESSEL_TYPE</Physical_Name>", "<Name>IX_OTHER</Name><Physical_Name>IX_OTHER</Physical_Name>", True, "INDEX_NAME (extended_properties)"),
    Probe("Index", "Column sort order", "<Key_Group_Sort_Order>ASC</Key_Group_Sort_Order>", "<Key_Group_Sort_Order>DESC</Key_Group_Sort_Order>", True, "INDEX_SORT_ORDER (extended_properties)"),
    # View
    Probe("View", "Code", "<View id=\"{V1}+00000000\" name=\"V_ACTIVE_VESSELS\"><ViewProps><Name>V_ACTIVE_VESSELS</Name><Physical_Name>V_ACTIVE_VESSELS</Physical_Name>",
          "<View id=\"{V1}+00000000\" name=\"V_X\"><ViewProps><Name>V_X</Name><Physical_Name>V_X</Physical_Name>", True),
    Probe("View", "SQL definition", "<User_Defined_SQL>SELECT VESSEL_ID, VESSEL_NAME FROM VESSEL WHERE CAPACITY &gt; 0</User_Defined_SQL>",
          "<User_Defined_SQL>SELECT VESSEL_ID FROM VOYAGE</User_Defined_SQL>", True),
    Probe("View", "Columns", "<View_Attribute id=\"{VC2}+00000000\" name=\"VESSEL_NAME\"><View_AttributeProps><Name>VESSEL_NAME</Name><Physical_Name>VESSEL_NAME</Physical_Name></View_AttributeProps></View_Attribute>",
          "", True, "VIEW_COLUMNS (extended_properties)"),
    Probe("View", "Definition / comment", "<Definition>Vessels in service.</Definition>", "<Definition>Changed.</Definition>", True, "VIEW_DEFINITION (extended_properties)"),
    # Procedure / function / trigger
    Probe("Procedure", "Code", "<Stored_Procedure id=\"{PR1}+00000000\" name=\"SP_ADD_VESSEL\"><Stored_ProcedureProps><Name>SP_ADD_VESSEL</Name><Physical_Name>SP_ADD_VESSEL</Physical_Name>",
          "<Stored_Procedure id=\"{PR1}+00000000\" name=\"SP_X\"><Stored_ProcedureProps><Name>SP_X</Name><Physical_Name>SP_X</Physical_Name>", True),
    Probe("Procedure", "Body", "INSERT INTO VESSEL (VESSEL_NAME) VALUES (@name)</User_Defined_SQL>", "DELETE FROM VESSEL</User_Defined_SQL>", True),
    Probe("Procedure", "Parameters", "", "", False, "PD parameters not read; erwin has no parameter element parsed"),
    Probe("Procedure", "Definition / comment", "<Definition>Inserts a vessel.</Definition>", "<Definition>Changed.</Definition>", True, "PROCEDURE_DEFINITION (extended_properties)"),
    Probe("Function", "Code", "<Function id=\"{FN1}+00000000\" name=\"FN_VESSEL_COUNT\"><FunctionProps><Name>FN_VESSEL_COUNT</Name><Physical_Name>FN_VESSEL_COUNT</Physical_Name>",
          "<Function id=\"{FN1}+00000000\" name=\"FN_X\"><FunctionProps><Name>FN_X</Name><Physical_Name>FN_X</Physical_Name>", True, "pooled with procedures"),
    Probe("Function", "Body", "RETURN (SELECT COUNT(*) FROM VESSEL) END</User_Defined_SQL>", "RETURN 0 END</User_Defined_SQL>", True),
    Probe("Trigger", "Code", "<Trigger id=\"{TG1}+00000000\" name=\"TR_AUDIT_VESSEL\"><TriggerProps><Name>TR_AUDIT_VESSEL</Name><Physical_Name>TR_AUDIT_VESSEL</Physical_Name>",
          "<Trigger id=\"{TG1}+00000000\" name=\"TR_X\"><TriggerProps><Name>TR_X</Name><Physical_Name>TR_X</Physical_Name>", True),
    Probe("Trigger", "Body (small literal change)", "<User_Defined_SQL>INSERT INTO AUDIT_LOG VALUES ('VESSEL')</User_Defined_SQL>", "<User_Defined_SQL>INSERT INTO AUDIT_LOG VALUES ('X')</User_Defined_SQL>", None,
          "SQL bodies compared with a >=90% similarity tolerance (compare_sql); a small literal edit passes"),
    Probe("Trigger", "Body (rewritten)", "<User_Defined_SQL>INSERT INTO AUDIT_LOG VALUES ('VESSEL')</User_Defined_SQL>", "<User_Defined_SQL>DELETE FROM AUDIT_LOG</User_Defined_SQL>", True),
    Probe("Trigger", "Event / timing", "<Trigger_Fire_On_Insert>true</Trigger_Fire_On_Insert>", "<Trigger_Fire_On_Insert>false</Trigger_Fire_On_Insert>", True, "TRIGGER_EVENT (extended_properties); erwin flag tag names unverified"),
    Probe("Trigger", "Owning table", "", "", None, "TRIGGER_TABLE (extended_properties): trigger re-parented under another table is flagged — exercised by tests/test_property_coverage.py (multi-line move, not a single-line probe)"),
    # Sequence
    Probe("Sequence", "Code", "<Sequence id=\"{SQ1}+00000000\" name=\"SEQ_VOYAGE\"><SequenceProps><Name>SEQ_VOYAGE</Name><Physical_Name>SEQ_VOYAGE</Physical_Name>",
          "<Sequence id=\"{SQ1}+00000000\" name=\"SEQ_X\"><SequenceProps><Name>SEQ_X</Name><Physical_Name>SEQ_X</Physical_Name>", True),
    Probe("Sequence", "Start value", "<Start_Value>1000</Start_Value>", "<Start_Value>1</Start_Value>", True, "SEQUENCE_PARAMS (extended_properties)"),
    Probe("Sequence", "Increment", "<Increment_Value>1</Increment_Value>", "<Increment_Value>10</Increment_Value>", True, "SEQUENCE_PARAMS"),
    Probe("Sequence", "Min / max", "<Max_Value>999999</Max_Value>", "<Max_Value>5</Max_Value>", True, "SEQUENCE_PARAMS; erwin Min_Value / Max_Value tag names unverified"),
    # Tablespace
    Probe("Tablespace", "Code", "<Tablespace id=\"{TS1}+00000000\" name=\"TS_FLEET_DATA\"><TablespaceProps><Name>TS_FLEET_DATA</Name><Physical_Name>TS_FLEET_DATA</Physical_Name>",
          "<Tablespace id=\"{TS1}+00000000\" name=\"TS_X\"><TablespaceProps><Name>TS_X</Name><Physical_Name>TS_X</Physical_Name>", True),
    # Domain / rule / default / format / dbms / diagram / package
    Probe("Domain", "Existence", "<Domain id=\"{PD1}+00000000\" name=\"Money\"><DomainProps><Name>Money</Name><Physical_Name>MONEY_D</Physical_Name>", "<Domain id=\"{PD1}+00000000\" name=\"Cash\"><DomainProps><Name>Cash</Name><Physical_Name>CASH</Physical_Name>", True, "DOMAIN_OBJECT (extended_properties)"),
    Probe("Domain", "Data type", "<Physical_Datatype>decimal(12,2)</Physical_Datatype>", "<Physical_Datatype>money</Physical_Datatype>", True, "DOMAIN_OBJECT"),
    Probe("Business Rule", "Existence / expression", "<Expression>CAPACITY &gt; 0</Expression>", "<Expression>1=1</Expression>", True, "BUSINESS_RULE_OBJECT (extended_properties)"),
    Probe("Default", "Existence / value", "<Default id=\"{DF1}+00000000\" name=\"DEF_ZERO\"><DefaultProps><Name>DEF_ZERO</Name><Default_Value>0</Default_Value>",
          "<Default id=\"{DF1}+00000000\" name=\"DEF_X\"><DefaultProps><Name>DEF_X</Name><Default_Value>9</Default_Value>", True, "DEFAULT_OBJECT (extended_properties)"),
    Probe("Data Format", "Existence", "", "", False, "erwin has no Data Format object — reported as a VERIFIED census row (DATA_FORMAT_NOT_REPRESENTABLE), never scored"),
    Probe("Database Target", "DBMS", "<Target_Server>SQL Server</Target_Server>", "<Target_Server>Oracle</Target_Server>", True, "DATABASE_TARGET (extended_properties)"),
    Probe("Database Target", "DBMS not set", "<Target_Server>SQL Server</Target_Server>", "<Target_Server></Target_Server>", True, "DATABASE_TARGET"),
    Probe("Diagram", "Name / symbols", "<Stored_Display id=\"{SD1}+00000000\" name=\"FLEETDB_OVERVIEW\"><Stored_DisplayProps><Name>FLEETDB_OVERVIEW</Name>",
          "<Stored_Display id=\"{SD1}+00000000\" name=\"X\"><Stored_DisplayProps><Name>X</Name>", True, "DIAGRAM_MISSING (extended_properties)"),
    Probe("Diagram", "Symbols displayed", "<Drawing_Object_EntityProps><Entity_Ref>{T2}+00000000</Entity_Ref>", "<Drawing_Object_EntityProps><Entity_Ref>{T3}+00000000</Entity_Ref>", True, "DIAGRAM_SYMBOLS"),
    Probe("Package", "Code", "<Subject_Area id=\"{SA1}+00000000\" name=\"REFERENCE\"><Subject_AreaProps><Name>REFERENCE</Name>",
          "<Subject_Area id=\"{SA1}+00000000\" name=\"LOOKUP\"><Subject_AreaProps><Name>LOOKUP</Name>", True),
    Probe("Package", "Contents (tables)", "<Entity_Ref>{T3}+00000000</Entity_Ref>", "<Entity_Ref>{T1}+00000000</Entity_Ref>", True, "PACKAGE_CONTENTS (extended_properties)"),
]


# ─────────────────────────────────────────────────────────────────────────────
#  Engines
# ─────────────────────────────────────────────────────────────────────────────

def _write(directory: str, name: str, text: str) -> str:
    path = os.path.join(directory, name)
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(text)
    return path


def _ldm(pd_path: str, erwin_path: str):
    from app.validation.ldm_reconcile.comparator import compare
    from app.validation.ldm_reconcile.erwin_ldm_parser import parse_erwin_ldm
    from app.validation.ldm_reconcile.pd_ldm_parser import parse_ldm
    return compare(parse_ldm(pd_path), parse_erwin_ldm(erwin_path))


def _cdm(pd_path: str, erwin_path: str):
    from app.validation.cdm_reconcile import compare, parse_cdm, parse_erwin
    return compare(parse_cdm(pd_path), parse_erwin(erwin_path))


def _pdm(pd_path: str, erwin_path: str):
    from app.validation.pdm_reconcile import pdm_validator_bridge as bridge
    return bridge.compare(bridge.parse_pdm(pd_path), bridge.parse_erwin(erwin_path))


ENGINES: Dict[str, Tuple[Callable, str, str, str, List[Probe]]] = {
    "LDM": (_ldm, PD_LDM_FULL, ERWIN_LDM_FULL, ".ldm", LDM_PROBES),
    "CDM": (_cdm, PD_LDM_FULL, ERWIN_LDM_FULL, ".cdm", LDM_PROBES),
    "PDM": (_pdm, PD_PDM_FULL, ERWIN_PDM_FULL, ".pdm", PDM_PROBES),
}


def _penalising(result) -> Counter:
    return Counter(f.category for f in result.findings if f.severity in PENALISING)


def run_probes(engine: str) -> List[ProbeResult]:
    compare, pd_text, erwin_text, suffix, probes = ENGINES[engine]
    results: List[ProbeResult] = []
    with tempfile.TemporaryDirectory() as tmp:
        pd_path = _write(tmp, f"model{suffix}", pd_text)
        baseline = _penalising(compare(pd_path, _write(tmp, "base.xml", erwin_text)))
        for probe in probes:
            if not probe.old:
                results.append(ProbeResult(engine, probe.obj, probe.prop, False, [], probe.expect, probe.note or "no erwin field to mutate"))
                continue
            mutated = erwin_text.replace(probe.old, probe.new, 1)
            if probe.obj == "Model" and probe.prop == "Name":
                mutated = mutated.replace('id="{M}+00000001" name="Fleet"', 'id="{M}+00000001" name="Armada"', 1)
            if mutated == erwin_text:
                raise AssertionError(f"[{engine}] anchor not found for {probe.obj}.{probe.prop}: {probe.old[:60]!r}")
            after = _penalising(compare(pd_path, _write(tmp, "mut.xml", mutated)))
            new_cats = sorted(cat for cat, n in after.items() if n > baseline.get(cat, 0))
            results.append(ProbeResult(engine, probe.obj, probe.prop, bool(new_cats), new_cats, probe.expect, probe.note))
    return results


def matrix_markdown(results: List[ProbeResult]) -> str:
    lines = ["| Engine | Object | Property | Result | Finding(s) | Note |", "|---|---|---|---|---|---|"]
    for r in results:
        lines.append(f"| {r.engine} | {r.obj} | {r.prop} | {'✅ ' if r.detected else '❌ '}{r.status()} | "
                     f"{', '.join(r.categories) or '—'} | {r.note} |")
    return "\n".join(lines)


def main(argv=None) -> int:
    argv = argv if argv is not None else sys.argv[1:]
    results = [r for engine in ENGINES for r in run_probes(engine)]
    if "--json" in argv:
        print(json.dumps([r.__dict__ for r in results], indent=1))
    else:
        print(matrix_markdown(results))
        detected = sum(r.detected for r in results)
        print(f"\n{detected} / {len(results)} probes detected")
    return 0


if __name__ == "__main__":
    sys.exit(main())
