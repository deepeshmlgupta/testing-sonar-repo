"""
Extended synthetic models for coverage testing.

Each PowerDesigner model carries EVERY object type on the client's list and
every property they asked about, and each erwin export is its faithful
migration — so the baseline reconciliation is clean and a single mutation
of the erwin side isolates whether the framework detects that property.

    PD_LDM_FULL / ERWIN_LDM_FULL   Entity, Attribute (type/length/precision/
        mandatory/domain/default), Identifier (PK + AK, ordered), Relationship
        (cardinality, roles, identifying, RI rules, dominance), Inheritance
        (complete/exclusive), Domain (type/len/prec/default/check params),
        Business Rule, Package hierarchy, Diagram, Extended Attributes.
        Also parsed by the CDM engine (same tag vocabulary).

    PD_PDM_FULL / ERWIN_PDM_FULL   Table (owner/tablespace), Column (type/
        length/precision/nullable/default/domain/check), PK, AK, Reference
        (joins, RI rules), Index (unique, order), View (+columns, SQL),
        Procedure (+parameters), Function, Trigger (+event), Sequence
        (start/incr/min/max), Tablespace, Domain, Business Rule, Default,
        Data Format, DBMS target, Diagram, Package.

The models are deliberately small (3 entities / 3 tables) so a failure is
readable; breadth of object types is the point, not volume.
"""

import textwrap

# ─────────────────────────────────────────────────────────────────────────────
#  LDM / CDM
# ─────────────────────────────────────────────────────────────────────────────

PD_LDM_FULL = textwrap.dedent("""\
    <?xml version="1.0" encoding="UTF-8"?>
    <?PowerDesigner AppLocale="UTF16" ExtractionId="90000001" Name="Fleet" ModelType="Logical"?>
    <Model xmlns:a="attribute" xmlns:c="collection" xmlns:o="object">
    <o:RootObject Id="o1"><c:Children>
    <o:Model Id="o2"><a:Name>Fleet</a:Name><a:Code>FLEET</a:Code><a:ModelType>Logical</a:ModelType>
    <a:Comment>Fleet logical model.</a:Comment>
    <a:ExtendedAttributesText>{11111111-1111-1111-1111-111111111111},BIM,29={22222222-2222-2222-2222-222222222222},EnterpriseLevel,4=Core
    </a:ExtendedAttributesText>

    <c:Domains>
      <o:Domain Id="d1"><a:ObjectID>D1</a:ObjectID><a:Name>Identifier Domain</a:Name><a:Code>ID_DOMAIN</a:Code>
        <a:Comment>Surrogate identifier.</a:Comment>
        <a:DataType>N10</a:DataType><a:Length>10</a:Length><a:Precision>0</a:Precision>
        <a:DefaultValue>0</a:DefaultValue><a:LowValue>1</a:LowValue><a:HighValue>9999999999</a:HighValue>
        <a:Mandatory>1</a:Mandatory></o:Domain>
      <o:Domain Id="d2"><a:ObjectID>D2</a:ObjectID><a:Name>Status Domain</a:Name><a:Code>STATUS_DOMAIN</a:Code>
        <a:Comment>Lifecycle status.</a:Comment>
        <a:DataType>VA10</a:DataType><a:Length>10</a:Length>
        <a:ListOfValues>ACTIVE&#10;INACTIVE</a:ListOfValues><a:Format>AAAAAAAAAA</a:Format></o:Domain>
    </c:Domains>

    <c:BusinessRules>
      <o:BusinessRule Id="br1"><a:ObjectID>BR1</a:ObjectID><a:Name>Positive Capacity</a:Name><a:Code>POSITIVE_CAPACITY</a:Code>
        <a:Comment>Capacity must be positive.</a:Comment><a:RuleType>Validation</a:RuleType>
        <a:ServerExpression>CAPACITY &gt; 0</a:ServerExpression></o:BusinessRule>
    </c:BusinessRules>

    <c:Packages>
      <o:Package Id="p1"><a:ObjectID>P1</a:ObjectID><a:Name>Assets</a:Name><a:Code>ASSETS</a:Code>
        <a:Comment>Asset subject area.</a:Comment>
        <c:Packages>
          <o:Package Id="p2"><a:ObjectID>P2</a:ObjectID><a:Name>Vessels</a:Name><a:Code>VESSELS</a:Code>
            <c:Entities>
              <o:Entity Id="e3"><a:ObjectID>E3</a:ObjectID><a:Name>Tanker</a:Name><a:Code>TANKER</a:Code>
                <a:Comment>A tanker is a vessel that carries liquids.</a:Comment>
                <c:Attributes>
                  <o:EntityAttribute Id="a5"><a:ObjectID>A5</a:ObjectID><a:Name>Hull Type</a:Name><a:Code>HULL_TYPE</a:Code>
                    <a:Comment>Single or double hull.</a:Comment><a:DataType>VA20</a:DataType><a:Length>20</a:Length></o:EntityAttribute>
                </c:Attributes>
              </o:Entity>
            </c:Entities>
          </o:Package>
        </c:Packages>
      </o:Package>
    </c:Packages>

    <c:Entities>
      <o:Entity Id="e1"><a:ObjectID>E1</a:ObjectID><a:Name>Vessel</a:Name><a:Code>VESSEL</a:Code>
        <a:Comment>A ship operated by the fleet.</a:Comment>
        <a:Description>{\\rtf1 Detailed description of Vessel.}</a:Description>
        <a:Annotation>Reviewed 2026.</a:Annotation>
        <a:ExtendedAttributesText>{11111111-1111-1111-1111-111111111111},BIM,32={33333333-3333-3333-3333-333333333333},BIMType,6=Master
    </a:ExtendedAttributesText>
        <c:Attributes>
          <o:EntityAttribute Id="a1"><a:ObjectID>A1</a:ObjectID><a:Name>Vessel Id</a:Name><a:Code>VESSEL_ID</a:Code>
            <a:Comment>Surrogate key.</a:Comment><a:DataType>N10</a:DataType><a:Length>10</a:Length><a:Precision>0</a:Precision>
            <a:LogicalAttribute.Mandatory>1</a:LogicalAttribute.Mandatory>
            <c:Domain><o:Domain Ref="d1"/></c:Domain></o:EntityAttribute>
          <o:EntityAttribute Id="a2"><a:ObjectID>A2</a:ObjectID><a:Name>Vessel Name</a:Name><a:Code>VESSEL_NAME</a:Code>
            <a:Comment>Registered name.</a:Comment><a:DataType>VA100</a:DataType><a:Length>100</a:Length>
            <a:LogicalAttribute.Mandatory>1</a:LogicalAttribute.Mandatory></o:EntityAttribute>
          <o:EntityAttribute Id="a3"><a:ObjectID>A3</a:ObjectID><a:Name>Capacity</a:Name><a:Code>CAPACITY</a:Code>
            <a:Comment>Deadweight tonnage.</a:Comment><a:DataType>DC12,2</a:DataType><a:Length>12</a:Length><a:Precision>2</a:Precision>
            <a:DefaultValue>0</a:DefaultValue></o:EntityAttribute>
          <o:EntityAttribute Id="a4"><a:ObjectID>A4</a:ObjectID><a:Name>Status</a:Name><a:Code>STATUS</a:Code>
            <a:Comment>Lifecycle status.</a:Comment><a:DataType>VA10</a:DataType><a:Length>10</a:Length>
            <a:DefaultValue>'ACTIVE'</a:DefaultValue>
            <c:Domain><o:Domain Ref="d2"/></c:Domain></o:EntityAttribute>
        </c:Attributes>
        <c:Identifiers>
          <o:Identifier Id="i1"><a:ObjectID>I1</a:ObjectID><a:Name>PK Vessel</a:Name><a:Code>PK_VESSEL</a:Code>
            <c:Identifier.Attributes><o:EntityAttribute Ref="a1"/></c:Identifier.Attributes></o:Identifier>
          <o:Identifier Id="i2"><a:ObjectID>I2</a:ObjectID><a:Name>AK Vessel Name</a:Name><a:Code>AK_VESSEL_NAME</a:Code>
            <c:Identifier.Attributes><o:EntityAttribute Ref="a2"/><o:EntityAttribute Ref="a4"/></c:Identifier.Attributes></o:Identifier>
        </c:Identifiers>
        <c:PrimaryIdentifier><o:Identifier Ref="i1"/></c:PrimaryIdentifier>
      </o:Entity>

      <o:Entity Id="e2"><a:ObjectID>E2</a:ObjectID><a:Name>Voyage</a:Name><a:Code>VOYAGE</a:Code>
        <a:Comment>A journey made by a vessel.</a:Comment>
        <c:Attributes>
          <o:EntityAttribute Id="a6"><a:ObjectID>A6</a:ObjectID><a:Name>Voyage Id</a:Name><a:Code>VOYAGE_ID</a:Code>
            <a:Comment>Surrogate key.</a:Comment><a:DataType>N10</a:DataType><a:Length>10</a:Length>
            <a:LogicalAttribute.Mandatory>1</a:LogicalAttribute.Mandatory></o:EntityAttribute>
          <o:EntityAttribute Id="a7"><a:ObjectID>A7</a:ObjectID><a:Name>Departure Date</a:Name><a:Code>DEPARTURE_DATE</a:Code>
            <a:Comment>When the voyage started.</a:Comment><a:DataType>D</a:DataType></o:EntityAttribute>
        </c:Attributes>
        <c:Identifiers>
          <o:Identifier Id="i3"><a:ObjectID>I3</a:ObjectID><a:Name>PK Voyage</a:Name><a:Code>PK_VOYAGE</a:Code>
            <c:Identifier.Attributes><o:EntityAttribute Ref="a6"/></c:Identifier.Attributes></o:Identifier>
        </c:Identifiers>
        <c:PrimaryIdentifier><o:Identifier Ref="i3"/></c:PrimaryIdentifier>
      </o:Entity>
    </c:Entities>

    <c:Relationships>
      <o:Relationship Id="r1"><a:ObjectID>R1</a:ObjectID><a:Name>makes</a:Name><a:Code>MAKES</a:Code>
        <a:Comment>A vessel makes voyages.</a:Comment>
        <a:Entity1ToEntity2RoleCardinality>1..1</a:Entity1ToEntity2RoleCardinality>
        <a:Entity2ToEntity1RoleCardinality>0..n</a:Entity2ToEntity1RoleCardinality>
        <a:Entity1ToEntity2Role>is made by</a:Entity1ToEntity2Role>
        <a:Entity2ToEntity1Role>makes</a:Entity2ToEntity1Role>
        <a:UpdateConstraint>2</a:UpdateConstraint><a:DeleteConstraint>1</a:DeleteConstraint>
        <c:Object1><o:Entity Ref="e1"/></c:Object1>
        <c:Object2><o:Entity Ref="e2"/></c:Object2>
        <c:ParentIdentifier><o:Identifier Ref="i1"/></c:ParentIdentifier>
      </o:Relationship>
    </c:Relationships>

    <c:Inheritances>
      <o:Inheritance Id="h1"><a:ObjectID>H1</a:ObjectID><a:Name>Vessel Kind</a:Name><a:Code>VESSEL_KIND</a:Code>
        <a:Complete>0</a:Complete><a:MutuallyExclusive>1</a:MutuallyExclusive>
        <c:ParentEntity><o:Entity Ref="e1"/></c:ParentEntity>
        <c:InheritanceLinks>
          <o:InheritanceLink Id="hl1"><c:Object1><o:Inheritance Ref="h1"/></c:Object1><c:Object2><o:Entity Ref="e3"/></c:Object2></o:InheritanceLink>
        </c:InheritanceLinks>
      </o:Inheritance>
    </c:Inheritances>

    <c:LogicalDiagrams>
      <o:LogicalDiagram Id="dg1"><a:ObjectID>DG1</a:ObjectID><a:Name>Fleet Overview</a:Name><a:Code>FLEET_OVERVIEW</a:Code>
        <c:Symbols>
          <o:EntitySymbol Id="s1"><c:Object><o:Entity Ref="e1"/></c:Object></o:EntitySymbol>
          <o:EntitySymbol Id="s2"><c:Object><o:Entity Ref="e2"/></c:Object></o:EntitySymbol>
          <o:RelationshipSymbol Id="s3"><c:Object><o:Relationship Ref="r1"/></c:Object></o:RelationshipSymbol>
        </c:Symbols>
      </o:LogicalDiagram>
    </c:LogicalDiagrams>
    </o:Model></c:Children></o:RootObject></Model>
""")

_NOTE = ("1\\#x1F2026-01-01\\#x1FBot\\#x1F2026-01-01\\#x1FBot\\#x1F\\#x1F{text}"
         "\\#x1FF\\#x1F\\#x1F\\#x1F{{{guid}}}\\#x1F")


def _note(text, guid):
    return ('<Note_List_Array><Note_List HandleNonPrintableChar="Y" index="0">'
            + _NOTE.format(text=text, guid=guid) + '</Note_List></Note_List_Array>')


ERWIN_LDM_FULL = textwrap.dedent("""\
    <?xml version="1.0" encoding="UTF-8"?>
    <erwin xmlns="http://www.erwin.com/dm" xmlns:UDP="http://www.erwin.com/dm/metadata" xmlns:EMX="http://www.erwin.com/dm/data">
    <EMX:Model id="{M}+00000001" name="Fleet" xmlns="http://www.erwin.com/dm/data">
    <ModelProps><Name>Fleet</Name><Type>1</Type><Definition>Fleet logical model.</Definition>
      <UDP:EnterpriseLevel>Core</UDP:EnterpriseLevel></ModelProps>

    <Domain_Groups>
      <Domain id="{D1}+00000000" name="Identifier Domain"><DomainProps><Name>Identifier Domain</Name><Physical_Name>ID_DOMAIN</Physical_Name>
        <Definition>Surrogate identifier.</Definition><Logical_Datatype>NUMBER(10)</Logical_Datatype><Length>10</Length><Scale>0</Scale>
        <Default_Value>0</Default_Value><Min_Value>1</Min_Value><Max_Value>9999999999</Max_Value><Null_Option_Type>1</Null_Option_Type></DomainProps></Domain>
      <Domain id="{D2}+00000000" name="Status Domain"><DomainProps><Name>Status Domain</Name><Physical_Name>STATUS_DOMAIN</Physical_Name>
        <Definition>Lifecycle status.</Definition><Logical_Datatype>VARCHAR(10)</Logical_Datatype><Length>10</Length>
        <Valid_Value_Rule_Ref>{VR1}+00000000</Valid_Value_Rule_Ref></DomainProps></Domain>
    </Domain_Groups>

    <Validation_Rule_Groups>
      <Validation_Rule id="{BR1}+00000000" name="Positive Capacity"><Validation_RuleProps><Name>Positive Capacity</Name><Physical_Name>POSITIVE_CAPACITY</Physical_Name>
        <Definition>Capacity must be positive.</Definition><Rule_Type>Validation</Rule_Type><Expression>CAPACITY &gt; 0</Expression></Validation_RuleProps></Validation_Rule>
    </Validation_Rule_Groups>

    <Subject_Area_Groups>
      <Subject_Area id="{SA1}+00000000" name="Assets"><Subject_AreaProps><Name>Assets</Name><Definition>Asset subject area.</Definition></Subject_AreaProps></Subject_Area>
      <Subject_Area id="{SA2}+00000000" name="Vessels"><Subject_AreaProps><Name>Vessels</Name><Parent_Subject_Area>Assets</Parent_Subject_Area>
        <Entity_Ref>{E3}+00000000</Entity_Ref></Subject_AreaProps>
        <Stored_Display id="{SD1}+00000000" name="Fleet Overview"><Stored_DisplayProps><Name>Fleet Overview</Name></Stored_DisplayProps>
          <Drawing_Object_Entity id="{DOE1}+00000000"><Drawing_Object_EntityProps><Entity_Ref>{E1}+00000000</Entity_Ref></Drawing_Object_EntityProps></Drawing_Object_Entity>
          <Drawing_Object_Entity id="{DOE2}+00000000"><Drawing_Object_EntityProps><Entity_Ref>{E2}+00000000</Entity_Ref></Drawing_Object_EntityProps></Drawing_Object_Entity></Stored_Display>
      </Subject_Area>
    </Subject_Area_Groups>

    <Entity id="{E1}+00000000" name="Vessel"><EntityProps><Name>Vessel</Name>
      <Definition>A ship operated by the fleet.</Definition>
      <UDP:BIMType>Master</UDP:BIMType></EntityProps>
      <Attribute id="{A1}+00000000" name="Vessel Id"><AttributeProps><Name>Vessel Id</Name><Physical_Name>VESSEL_ID</Physical_Name>
        <Definition>Surrogate key.</Definition><Logical_Data_Type>NUMBER(10)</Logical_Data_Type><Length>10</Length><Scale>0</Scale>
        <Null_Option_Type>1</Null_Option_Type><Domain_Name>Identifier Domain</Domain_Name><Attribute_Type>PK</Attribute_Type></AttributeProps></Attribute>
      <Attribute id="{A2}+00000000" name="Vessel Name"><AttributeProps><Name>Vessel Name</Name><Physical_Name>VESSEL_NAME</Physical_Name>
        <Definition>Registered name.</Definition><Logical_Data_Type>VARCHAR(100)</Logical_Data_Type><Length>100</Length>
        <Null_Option_Type>1</Null_Option_Type></AttributeProps></Attribute>
      <Attribute id="{A3}+00000000" name="Capacity"><AttributeProps><Name>Capacity</Name><Physical_Name>CAPACITY</Physical_Name>
        <Definition>Deadweight tonnage.</Definition><Logical_Data_Type>DECIMAL(12,2)</Logical_Data_Type><Length>12</Length><Scale>2</Scale>
        <Null_Option_Type>0</Null_Option_Type><Default_Value>0</Default_Value></AttributeProps></Attribute>
      <Attribute id="{A4}+00000000" name="Status"><AttributeProps><Name>Status</Name><Physical_Name>STATUS</Physical_Name>
        <Definition>Lifecycle status.</Definition><Logical_Data_Type>VARCHAR(10)</Logical_Data_Type><Length>10</Length>
        <Null_Option_Type>0</Null_Option_Type><Default_Value>'ACTIVE'</Default_Value><Domain_Name>Status Domain</Domain_Name></AttributeProps></Attribute>
      <Key_Group id="{K1}+00000000" name="PK Vessel"><Key_GroupProps><Name>PK Vessel</Name><Physical_Name>PK_VESSEL</Physical_Name><Key_Group_Type>PK</Key_Group_Type></Key_GroupProps>
        <Key_Group_Member id="{KM1}+00000000"><Key_Group_MemberProps><Attribute_Ref>{A1}+00000000</Attribute_Ref><Key_Group_Member_Order>1</Key_Group_Member_Order></Key_Group_MemberProps></Key_Group_Member></Key_Group>
      <Key_Group id="{K2}+00000000" name="AK Vessel Name"><Key_GroupProps><Name>AK Vessel Name</Name><Physical_Name>AK_VESSEL_NAME</Physical_Name><Key_Group_Type>AK</Key_Group_Type></Key_GroupProps>
        <Key_Group_Member id="{KM2}+00000000"><Key_Group_MemberProps><Attribute_Ref>{A2}+00000000</Attribute_Ref><Key_Group_Member_Order>1</Key_Group_Member_Order></Key_Group_MemberProps></Key_Group_Member>
        <Key_Group_Member id="{KM3}+00000000"><Key_Group_MemberProps><Attribute_Ref>{A4}+00000000</Attribute_Ref><Key_Group_Member_Order>2</Key_Group_Member_Order></Key_Group_MemberProps></Key_Group_Member></Key_Group>
    </Entity>

    <Entity id="{E2}+00000000" name="Voyage"><EntityProps><Name>Voyage</Name>
      <Definition>A journey made by a vessel.</Definition></EntityProps>
      <Attribute id="{A6}+00000000" name="Voyage Id"><AttributeProps><Name>Voyage Id</Name><Physical_Name>VOYAGE_ID</Physical_Name>
        <Definition>Surrogate key.</Definition><Logical_Data_Type>NUMBER(10)</Logical_Data_Type><Length>10</Length><Null_Option_Type>1</Null_Option_Type><Attribute_Type>PK</Attribute_Type></AttributeProps></Attribute>
      <Attribute id="{A7}+00000000" name="Departure Date"><AttributeProps><Name>Departure Date</Name><Physical_Name>DEPARTURE_DATE</Physical_Name>
        <Definition>When the voyage started.</Definition><Logical_Data_Type>DATE</Logical_Data_Type><Null_Option_Type>0</Null_Option_Type></AttributeProps></Attribute>
      <Attribute id="{A8}+00000000" name="Vessel Id"><AttributeProps><Name>Vessel Id</Name><Physical_Name>VESSEL_ID</Physical_Name>
        <Logical_Data_Type>NUMBER(10)</Logical_Data_Type><Null_Option_Type>1</Null_Option_Type><Attribute_Type>FK</Attribute_Type>
        <Parent_Attribute_Ref>{A1}+00000000</Parent_Attribute_Ref><Parent_Relationship_Ref>{R1}+00000000</Parent_Relationship_Ref></AttributeProps></Attribute>
      <Key_Group id="{K3}+00000000" name="PK Voyage"><Key_GroupProps><Name>PK Voyage</Name><Physical_Name>PK_VOYAGE</Physical_Name><Key_Group_Type>PK</Key_Group_Type></Key_GroupProps>
        <Key_Group_Member id="{KM4}+00000000"><Key_Group_MemberProps><Attribute_Ref>{A6}+00000000</Attribute_Ref></Key_Group_MemberProps></Key_Group_Member></Key_Group>
    </Entity>

    <Entity id="{E3}+00000000" name="Tanker"><EntityProps><Name>Tanker</Name>
      <Definition>A tanker is a vessel that carries liquids.</Definition></EntityProps>
      <Attribute id="{A5}+00000000" name="Hull Type"><AttributeProps><Name>Hull Type</Name><Physical_Name>HULL_TYPE</Physical_Name>
        <Definition>Single or double hull.</Definition><Logical_Data_Type>VARCHAR(20)</Logical_Data_Type><Length>20</Length><Null_Option_Type>0</Null_Option_Type></AttributeProps></Attribute>
    </Entity>

    <Relationship id="{R1}+00000000" name="makes"><RelationshipProps><Name>makes</Name><Physical_Name>MAKES</Physical_Name>
      <Definition>A vessel makes voyages.</Definition>
      <Type>7</Type><Null_Option_Type>101</Null_Option_Type><Cardinality>-3</Cardinality>
      <Parent_To_Child_Verb_Phrase>makes</Parent_To_Child_Verb_Phrase><Child_To_Parent_Verb_Phrase>is made by</Child_To_Parent_Verb_Phrase>
      <Parent_Update_Rule>10000</Parent_Update_Rule><Parent_Delete_Rule>10005</Parent_Delete_Rule>
      <Parent_Entity_Ref>{E1}+00000000</Parent_Entity_Ref><Child_Entity_Ref>{E2}+00000000</Child_Entity_Ref>
    </RelationshipProps></Relationship>

    <Subtype_Relationship id="{H1}+00000000" name="Vessel Kind"><Subtype_RelationshipProps><Name>Vessel Kind</Name>
      <Parent_Entity_Ref>{E1}+00000000</Parent_Entity_Ref><Completeness>Incomplete</Completeness><Exclusivity>Exclusive</Exclusivity>
      <Subtype_Member><Entity_Ref>{E3}+00000000</Entity_Ref></Subtype_Member>
    </Subtype_RelationshipProps></Subtype_Relationship>
    </EMX:Model></erwin>
""")

# The erwin export BEFORE the comments were injected (XML V1): same model,
# no Definition on entities/attributes.


def strip_definitions(xml: str) -> str:
    import re
    return re.sub(r"<Definition>[^<]*</Definition>", "", xml)


# ─────────────────────────────────────────────────────────────────────────────
#  PDM
# ─────────────────────────────────────────────────────────────────────────────

PD_PDM_FULL = textwrap.dedent("""\
    <?xml version="1.0" encoding="UTF-8"?>
    <?PowerDesigner AppLocale="UTF16" ExtractionId="90000002" Name="FleetDB"?>
    <Model xmlns:a="attribute" xmlns:c="collection" xmlns:o="object">
    <o:RootObject Id="o1"><c:Children>
    <o:Model Id="o2"><a:Name>FleetDB</a:Name><a:Code>FLEETDB</a:Code>
    <c:DBMS><o:Shortcut Id="dbms1"><a:ObjectID>DBMS1</a:ObjectID><a:Name>Microsoft SQL Server 2019</a:Name><a:Code>MSSQLSRV2019</a:Code></o:Shortcut></c:DBMS>

    <c:Tablespaces>
      <o:Tablespace Id="ts1"><a:ObjectID>TS1</a:ObjectID><a:Name>Fleet Data</a:Name><a:Code>TS_FLEET_DATA</a:Code><a:Comment>Primary data files.</a:Comment><a:Description>Primary data files.</a:Description></o:Tablespace>
    </c:Tablespaces>

    <c:Domains>
      <o:PhysicalDomain Id="pd1"><a:ObjectID>PD1</a:ObjectID><a:Name>Money</a:Name><a:Code>MONEY_D</a:Code>
        <a:DataType>decimal(12,2)</a:DataType><a:Length>12</a:Length><a:Precision>2</a:Precision><a:DefaultValue>0</a:DefaultValue></o:PhysicalDomain>
    </c:Domains>

    <c:Defaults>
      <o:Default Id="df1"><a:ObjectID>DF1</a:ObjectID><a:Name>Default Zero</a:Name><a:Code>DEF_ZERO</a:Code><a:Value>0</a:Value></o:Default>
    </c:Defaults>

    <c:DataFormats>
      <o:DataFormat Id="fmt1"><a:ObjectID>FMT1</a:ObjectID><a:Name>ISO Date</a:Name><a:Code>ISO_DATE</a:Code><a:Expression>YYYY-MM-DD</a:Expression></o:DataFormat>
    </c:DataFormats>

    <c:BusinessRules>
      <o:BusinessRule Id="br1"><a:ObjectID>BR1</a:ObjectID><a:Name>Positive Capacity</a:Name><a:Code>CK_POSITIVE_CAPACITY</a:Code>
        <a:RuleType>Constraint</a:RuleType><a:ServerExpression>CAPACITY &gt; 0</a:ServerExpression></o:BusinessRule>
    </c:BusinessRules>

    <c:Packages>
      <o:Package Id="p1"><a:ObjectID>P1</a:ObjectID><a:Name>Reference</a:Name><a:Code>REFERENCE</a:Code><a:Comment>Reference data.</a:Comment><a:Description>Reference data.</a:Description>
        <c:Tables>
          <o:Table Id="t3"><a:ObjectID>T3</a:ObjectID><a:Name>Vessel Type</a:Name><a:Code>VESSEL_TYPE</a:Code><a:Comment>Kinds of vessel.</a:Comment><a:Description>Kinds of vessel.</a:Description>
            <c:Columns>
              <o:Column Id="c9"><a:ObjectID>C9</a:ObjectID><a:Name>Vessel Type Code</a:Name><a:Code>VESSEL_TYPE_CODE</a:Code><a:DataType>char(3)</a:DataType><a:Length>3</a:Length><a:Column.Mandatory>1</a:Column.Mandatory></o:Column>
            </c:Columns>
            <c:Keys><o:Key Id="k3"><a:ObjectID>K3</a:ObjectID><a:Name>PK Vessel Type</a:Name><a:Code>PK_VESSEL_TYPE</a:Code><c:Key.Columns><o:Column Ref="c9"/></c:Key.Columns></o:Key></c:Keys>
            <c:PrimaryKey><o:Key Ref="k3"/></c:PrimaryKey>
          </o:Table>
        </c:Tables>
      </o:Package>
    </c:Packages>

    <c:Tables>
      <o:Table Id="t1"><a:ObjectID>T1</a:ObjectID><a:Name>Vessel</a:Name><a:Code>VESSEL</a:Code><a:Comment>A ship operated by the fleet.</a:Comment><a:Description>A ship operated by the fleet.</a:Description>
        <a:Owner>dbo</a:Owner>
        <c:Tablespace><o:Tablespace Ref="ts1"/></c:Tablespace>
        <c:Columns>
          <o:Column Id="c1"><a:ObjectID>C1</a:ObjectID><a:Name>Vessel Id</a:Name><a:Code>VESSEL_ID</a:Code><a:Comment>Surrogate key.</a:Comment><a:Description>Surrogate key.</a:Description>
            <a:DataType>int</a:DataType><a:Column.Mandatory>1</a:Column.Mandatory><a:Identity>1</a:Identity></o:Column>
          <o:Column Id="c2"><a:ObjectID>C2</a:ObjectID><a:Name>Vessel Name</a:Name><a:Code>VESSEL_NAME</a:Code>
            <a:DataType>varchar(100)</a:DataType><a:Length>100</a:Length><a:Column.Mandatory>1</a:Column.Mandatory></o:Column>
          <o:Column Id="c3"><a:ObjectID>C3</a:ObjectID><a:Name>Capacity</a:Name><a:Code>CAPACITY</a:Code>
            <a:DataType>decimal(12,2)</a:DataType><a:Length>12</a:Length><a:Precision>2</a:Precision><a:DefaultValue>0</a:DefaultValue>
            <c:Domain><o:PhysicalDomain Ref="pd1"/></c:Domain>
            <a:ConstraintName>CK_VESSEL_CAPACITY</a:ConstraintName><a:LowValue>0</a:LowValue></o:Column>
          <o:Column Id="c4"><a:ObjectID>C4</a:ObjectID><a:Name>Vessel Type Code</a:Name><a:Code>VESSEL_TYPE_CODE</a:Code>
            <a:DataType>char(3)</a:DataType><a:Length>3</a:Length></o:Column>
        </c:Columns>
        <c:Keys>
          <o:Key Id="k1"><a:ObjectID>K1</a:ObjectID><a:Name>PK Vessel</a:Name><a:Code>PK_VESSEL</a:Code><c:Key.Columns><o:Column Ref="c1"/></c:Key.Columns></o:Key>
          <o:Key Id="k4"><a:ObjectID>K4</a:ObjectID><a:Name>AK Vessel Name</a:Name><a:Code>AK_VESSEL_NAME</a:Code><a:UniqueConstraint>1</a:UniqueConstraint><c:Key.Columns><o:Column Ref="c2"/></c:Key.Columns></o:Key>
        </c:Keys>
        <c:PrimaryKey><o:Key Ref="k1"/></c:PrimaryKey>
        <c:Indexes>
          <o:Index Id="ix1"><a:ObjectID>IX1</a:ObjectID><a:Name>IX Vessel Type</a:Name><a:Code>IX_VESSEL_TYPE</a:Code><a:Unique>0</a:Unique>
            <c:IndexColumns><o:IndexColumn Id="ixc1"><a:Ascending>1</a:Ascending><c:Column><o:Column Ref="c4"/></c:Column></o:IndexColumn></c:IndexColumns></o:Index>
        </c:Indexes>
        <c:Triggers>
          <o:Trigger Id="tg1"><a:ObjectID>TG1</a:ObjectID><a:Name>Audit Vessel</a:Name><a:Code>TR_AUDIT_VESSEL</a:Code><a:Comment>Writes an audit row on insert.</a:Comment><a:Description>Writes an audit row on insert.</a:Description>
            <a:TriggerEvent>INSERT</a:TriggerEvent><a:Trigger.Body>INSERT INTO AUDIT_LOG VALUES ('VESSEL')</a:Trigger.Body></o:Trigger>
        </c:Triggers>
      </o:Table>

      <o:Table Id="t2"><a:ObjectID>T2</a:ObjectID><a:Name>Voyage</a:Name><a:Code>VOYAGE</a:Code><a:Comment>A journey made by a vessel.</a:Comment><a:Description>A journey made by a vessel.</a:Description>
        <a:Owner>dbo</a:Owner>
        <c:Columns>
          <o:Column Id="c5"><a:ObjectID>C5</a:ObjectID><a:Name>Voyage Id</a:Name><a:Code>VOYAGE_ID</a:Code><a:DataType>int</a:DataType><a:Column.Mandatory>1</a:Column.Mandatory></o:Column>
          <o:Column Id="c6"><a:ObjectID>C6</a:ObjectID><a:Name>Vessel Id</a:Name><a:Code>VESSEL_ID</a:Code><a:DataType>int</a:DataType><a:Column.Mandatory>1</a:Column.Mandatory></o:Column>
          <o:Column Id="c7"><a:ObjectID>C7</a:ObjectID><a:Name>Departure Date</a:Name><a:Code>DEPARTURE_DATE</a:Code><a:DataType>date</a:DataType>
            <c:DataFormat><o:DataFormat Ref="fmt1"/></c:DataFormat></o:Column>
        </c:Columns>
        <c:Keys><o:Key Id="k2"><a:ObjectID>K2</a:ObjectID><a:Name>PK Voyage</a:Name><a:Code>PK_VOYAGE</a:Code><c:Key.Columns><o:Column Ref="c5"/></c:Key.Columns></o:Key></c:Keys>
        <c:PrimaryKey><o:Key Ref="k2"/></c:PrimaryKey>
      </o:Table>
    </c:Tables>

    <c:References>
      <o:Reference Id="r1"><a:ObjectID>R1</a:ObjectID><a:Name>makes</a:Name><a:Code>FK_VOYAGE_VESSEL</a:Code>
        <a:UpdateConstraint>2</a:UpdateConstraint><a:DeleteConstraint>1</a:DeleteConstraint>
        <a:Cardinality>0..n</a:Cardinality><a:ParentMandatory>1</a:ParentMandatory>
        <c:ParentTable><o:Table Ref="t1"/></c:ParentTable><c:ChildTable><o:Table Ref="t2"/></c:ChildTable>
        <c:Joins><o:ReferenceJoin Id="j1"><c:Object1><o:Column Ref="c1"/></c:Object1><c:Object2><o:Column Ref="c6"/></c:Object2></o:ReferenceJoin></c:Joins>
      </o:Reference>
    </c:References>

    <c:Views>
      <o:View Id="v1"><a:ObjectID>V1</a:ObjectID><a:Name>Active Vessels</a:Name><a:Code>V_ACTIVE_VESSELS</a:Code><a:Comment>Vessels in service.</a:Comment><a:Description>Vessels in service.</a:Description>
        <a:View.SQLQuery>SELECT VESSEL_ID, VESSEL_NAME FROM VESSEL WHERE CAPACITY &gt; 0</a:View.SQLQuery>
        <c:Columns>
          <o:ViewColumn Id="vc1"><a:ObjectID>VC1</a:ObjectID><a:Name>Vessel Id</a:Name><a:Code>VESSEL_ID</a:Code><a:DataType>int</a:DataType></o:ViewColumn>
          <o:ViewColumn Id="vc2"><a:ObjectID>VC2</a:ObjectID><a:Name>Vessel Name</a:Name><a:Code>VESSEL_NAME</a:Code><a:DataType>varchar(100)</a:DataType></o:ViewColumn>
        </c:Columns>
      </o:View>
    </c:Views>

    <c:Procedures>
      <o:Procedure Id="pr1"><a:ObjectID>PR1</a:ObjectID><a:Name>Add Vessel</a:Name><a:Code>SP_ADD_VESSEL</a:Code><a:Comment>Inserts a vessel.</a:Comment><a:Description>Inserts a vessel.</a:Description>
        <a:Procedure.Body>CREATE PROCEDURE SP_ADD_VESSEL @name varchar(100) AS INSERT INTO VESSEL (VESSEL_NAME) VALUES (@name)</a:Procedure.Body>
        <c:Parameters><o:ProcedureParameter Id="pp1"><a:Name>name</a:Name><a:Code>@name</a:Code><a:DataType>varchar(100)</a:DataType></o:ProcedureParameter></c:Parameters>
      </o:Procedure>
      <o:Function Id="fn1"><a:ObjectID>FN1</a:ObjectID><a:Name>Vessel Count</a:Name><a:Code>FN_VESSEL_COUNT</a:Code><a:Comment>Number of vessels.</a:Comment><a:Description>Number of vessels.</a:Description>
        <a:Function.Body>CREATE FUNCTION FN_VESSEL_COUNT() RETURNS int AS BEGIN RETURN (SELECT COUNT(*) FROM VESSEL) END</a:Function.Body></o:Function>
    </c:Procedures>

    <c:Sequences>
      <o:Sequence Id="sq1"><a:ObjectID>SQ1</a:ObjectID><a:Name>Voyage Sequence</a:Name><a:Code>SEQ_VOYAGE</a:Code><a:Comment>Voyage identifiers.</a:Comment><a:Description>Voyage identifiers.</a:Description>
        <a:StartValue>1000</a:StartValue><a:IncrementValue>1</a:IncrementValue><a:MinValue>1</a:MinValue><a:MaxValue>999999</a:MaxValue></o:Sequence>
    </c:Sequences>

    <c:PhysicalDiagrams>
      <o:PhysicalDiagram Id="dg1"><a:ObjectID>DG1</a:ObjectID><a:Name>FleetDB Overview</a:Name><a:Code>FLEETDB_OVERVIEW</a:Code>
        <c:Symbols><o:TableSymbol Id="s1"><c:Object><o:Table Ref="t1"/></c:Object></o:TableSymbol><o:TableSymbol Id="s2"><c:Object><o:Table Ref="t2"/></c:Object></o:TableSymbol></c:Symbols>
      </o:PhysicalDiagram>
    </c:PhysicalDiagrams>
    </o:Model></c:Children></o:RootObject></Model>
""")

ERWIN_PDM_FULL = textwrap.dedent("""\
    <?xml version="1.0" encoding="UTF-8"?>
    <erwin xmlns="http://www.erwin.com/dm" xmlns:UDP="http://www.erwin.com/dm/metadata" xmlns:EMX="http://www.erwin.com/dm/data">
    <EMX:Model id="{M}+00000001" name="FleetDB" xmlns="http://www.erwin.com/dm/data">
    <ModelEnvProps><Target_Server>SQL Server</Target_Server><Target_Server_Version>2019</Target_Server_Version></ModelEnvProps>
    <ModelProps><Name>FleetDB</Name><Type>2</Type></ModelProps>

    <Tablespace id="{TS1}+00000000" name="TS_FLEET_DATA"><TablespaceProps><Name>TS_FLEET_DATA</Name><Physical_Name>TS_FLEET_DATA</Physical_Name><Definition>Primary data files.</Definition></TablespaceProps></Tablespace>
    <Domain id="{PD1}+00000000" name="Money"><DomainProps><Name>Money</Name><Physical_Name>MONEY_D</Physical_Name><Physical_Datatype>decimal(12,2)</Physical_Datatype><Default_Value>0</Default_Value></DomainProps></Domain>
    <Default id="{DF1}+00000000" name="DEF_ZERO"><DefaultProps><Name>DEF_ZERO</Name><Default_Value>0</Default_Value></DefaultProps></Default>
    <Validation_Rule id="{BR1}+00000000" name="CK_POSITIVE_CAPACITY"><Validation_RuleProps><Name>CK_POSITIVE_CAPACITY</Name><Expression>CAPACITY &gt; 0</Expression></Validation_RuleProps></Validation_Rule>
    <Subject_Area id="{SA1}+00000000" name="REFERENCE"><Subject_AreaProps><Name>REFERENCE</Name><Definition>Reference data.</Definition><Entity_Ref>{T3}+00000000</Entity_Ref>
      <Stored_Display id="{SD1}+00000000" name="FLEETDB_OVERVIEW"><Stored_DisplayProps><Name>FLEETDB_OVERVIEW</Name></Stored_DisplayProps>
        <Drawing_Object_Entity id="{DOE1}+00000000"><Drawing_Object_EntityProps><Entity_Ref>{T1}+00000000</Entity_Ref></Drawing_Object_EntityProps></Drawing_Object_Entity>
        <Drawing_Object_Entity id="{DOE2}+00000000"><Drawing_Object_EntityProps><Entity_Ref>{T2}+00000000</Entity_Ref></Drawing_Object_EntityProps></Drawing_Object_Entity></Stored_Display></Subject_AreaProps></Subject_Area>

    <Entity id="{T1}+00000000" name="Vessel"><EntityProps><Name>Vessel</Name><Physical_Name>VESSEL</Physical_Name><Owner>dbo</Owner>
      <Definition>A ship operated by the fleet.</Definition><Tablespace_Ref>{TS1}+00000000</Tablespace_Ref></EntityProps>
      <Attribute id="{C1}+00000000" name="Vessel Id"><AttributeProps><Name>Vessel Id</Name><Physical_Name>VESSEL_ID</Physical_Name><Physical_Data_Type>int</Physical_Data_Type><Null_Option_Type>1</Null_Option_Type><Identity>true</Identity></AttributeProps></Attribute>
      <Attribute id="{C2}+00000000" name="Vessel Name"><AttributeProps><Name>Vessel Name</Name><Physical_Name>VESSEL_NAME</Physical_Name><Physical_Data_Type>varchar(100)</Physical_Data_Type><Null_Option_Type>1</Null_Option_Type></AttributeProps></Attribute>
      <Attribute id="{C3}+00000000" name="Capacity"><AttributeProps><Name>Capacity</Name><Physical_Name>CAPACITY</Physical_Name><Physical_Data_Type>decimal(12,2)</Physical_Data_Type><Null_Option_Type>0</Null_Option_Type>
        <Default_Value>0</Default_Value><Domain_Name>Money</Domain_Name><Valid_Value_Rule_Ref>{BR1}+00000000</Valid_Value_Rule_Ref></AttributeProps></Attribute>
      <Attribute id="{C4}+00000000" name="Vessel Type Code"><AttributeProps><Name>Vessel Type Code</Name><Physical_Name>VESSEL_TYPE_CODE</Physical_Name><Physical_Data_Type>char(3)</Physical_Data_Type><Null_Option_Type>0</Null_Option_Type></AttributeProps></Attribute>
      <Key_Group id="{K1}+00000000" name="PK_VESSEL"><Key_GroupProps><Name>PK_VESSEL</Name><Physical_Name>PK_VESSEL</Physical_Name><Key_Group_Type>PK</Key_Group_Type></Key_GroupProps>
        <Key_Group_Member id="{KM1}+00000000"><Key_Group_MemberProps><Attribute_Ref>{C1}+00000000</Attribute_Ref></Key_Group_MemberProps></Key_Group_Member></Key_Group>
      <Key_Group id="{K4}+00000000" name="AK_VESSEL_NAME"><Key_GroupProps><Name>AK_VESSEL_NAME</Name><Physical_Name>AK_VESSEL_NAME</Physical_Name><Key_Group_Type>AK</Key_Group_Type><Is_Unique>true</Is_Unique></Key_GroupProps>
        <Key_Group_Member id="{KM4}+00000000"><Key_Group_MemberProps><Attribute_Ref>{C2}+00000000</Attribute_Ref></Key_Group_MemberProps></Key_Group_Member></Key_Group>
      <Key_Group id="{IX1}+00000000" name="IX_VESSEL_TYPE"><Key_GroupProps><Name>IX_VESSEL_TYPE</Name><Physical_Name>IX_VESSEL_TYPE</Physical_Name><Key_Group_Type>IE</Key_Group_Type><Is_Unique>false</Is_Unique></Key_GroupProps>
        <Key_Group_Member id="{KM5}+00000000"><Key_Group_MemberProps><Attribute_Ref>{C4}+00000000</Attribute_Ref><Key_Group_Sort_Order>ASC</Key_Group_Sort_Order></Key_Group_MemberProps></Key_Group_Member></Key_Group>
      <Trigger id="{TG1}+00000000" name="TR_AUDIT_VESSEL"><TriggerProps><Name>TR_AUDIT_VESSEL</Name><Physical_Name>TR_AUDIT_VESSEL</Physical_Name><Definition>Writes an audit row on insert.</Definition>
        <User_Defined_SQL>INSERT INTO AUDIT_LOG VALUES ('VESSEL')</User_Defined_SQL><Trigger_Fire_On_Insert>true</Trigger_Fire_On_Insert></TriggerProps></Trigger>
    </Entity>

    <Entity id="{T2}+00000000" name="Voyage"><EntityProps><Name>Voyage</Name><Physical_Name>VOYAGE</Physical_Name><Owner>dbo</Owner><Definition>A journey made by a vessel.</Definition></EntityProps>
      <Attribute id="{C5}+00000000" name="Voyage Id"><AttributeProps><Name>Voyage Id</Name><Physical_Name>VOYAGE_ID</Physical_Name><Physical_Data_Type>int</Physical_Data_Type><Null_Option_Type>1</Null_Option_Type></AttributeProps></Attribute>
      <Attribute id="{C6}+00000000" name="Vessel Id"><AttributeProps><Name>Vessel Id</Name><Physical_Name>VESSEL_ID</Physical_Name><Physical_Data_Type>int</Physical_Data_Type><Null_Option_Type>1</Null_Option_Type>
        <Parent_Attribute_Ref>{C1}+00000000</Parent_Attribute_Ref><Parent_Relationship_Ref>{R1}+00000000</Parent_Relationship_Ref></AttributeProps></Attribute>
      <Attribute id="{C7}+00000000" name="Departure Date"><AttributeProps><Name>Departure Date</Name><Physical_Name>DEPARTURE_DATE</Physical_Name><Physical_Data_Type>date</Physical_Data_Type><Null_Option_Type>0</Null_Option_Type></AttributeProps></Attribute>
      <Key_Group id="{K2}+00000000" name="PK_VOYAGE"><Key_GroupProps><Name>PK_VOYAGE</Name><Physical_Name>PK_VOYAGE</Physical_Name><Key_Group_Type>PK</Key_Group_Type></Key_GroupProps>
        <Key_Group_Member id="{KM2}+00000000"><Key_Group_MemberProps><Attribute_Ref>{C5}+00000000</Attribute_Ref></Key_Group_MemberProps></Key_Group_Member></Key_Group>
    </Entity>

    <Entity id="{T3}+00000000" name="Vessel Type"><EntityProps><Name>Vessel Type</Name><Physical_Name>VESSEL_TYPE</Physical_Name><Definition>Kinds of vessel.</Definition></EntityProps>
      <Attribute id="{C9}+00000000" name="Vessel Type Code"><AttributeProps><Name>Vessel Type Code</Name><Physical_Name>VESSEL_TYPE_CODE</Physical_Name><Physical_Data_Type>char(3)</Physical_Data_Type><Null_Option_Type>1</Null_Option_Type></AttributeProps></Attribute>
      <Key_Group id="{K3}+00000000" name="PK_VESSEL_TYPE"><Key_GroupProps><Name>PK_VESSEL_TYPE</Name><Physical_Name>PK_VESSEL_TYPE</Physical_Name><Key_Group_Type>PK</Key_Group_Type></Key_GroupProps>
        <Key_Group_Member id="{KM3}+00000000"><Key_Group_MemberProps><Attribute_Ref>{C9}+00000000</Attribute_Ref></Key_Group_MemberProps></Key_Group_Member></Key_Group>
    </Entity>

    <Relationship id="{R1}+00000000" name="makes"><RelationshipProps><Name>makes</Name><Physical_Name>FK_VOYAGE_VESSEL</Physical_Name>
      <Type>7</Type><Null_Option_Type>101</Null_Option_Type><Cardinality>-3</Cardinality>
      <Parent_Update_Rule>10000</Parent_Update_Rule><Parent_Delete_Rule>10005</Parent_Delete_Rule>
      <Parent_Entity_Ref>{T1}+00000000</Parent_Entity_Ref><Child_Entity_Ref>{T2}+00000000</Child_Entity_Ref>
    </RelationshipProps></Relationship>

    <View id="{V1}+00000000" name="V_ACTIVE_VESSELS"><ViewProps><Name>V_ACTIVE_VESSELS</Name><Physical_Name>V_ACTIVE_VESSELS</Physical_Name>
      <Definition>Vessels in service.</Definition>
      <User_Defined_SQL>SELECT VESSEL_ID, VESSEL_NAME FROM VESSEL WHERE CAPACITY &gt; 0</User_Defined_SQL></ViewProps>
      <View_Attribute id="{VC1}+00000000" name="VESSEL_ID"><View_AttributeProps><Name>VESSEL_ID</Name><Physical_Name>VESSEL_ID</Physical_Name></View_AttributeProps></View_Attribute>
      <View_Attribute id="{VC2}+00000000" name="VESSEL_NAME"><View_AttributeProps><Name>VESSEL_NAME</Name><Physical_Name>VESSEL_NAME</Physical_Name></View_AttributeProps></View_Attribute>
    </View>

    <Stored_Procedure id="{PR1}+00000000" name="SP_ADD_VESSEL"><Stored_ProcedureProps><Name>SP_ADD_VESSEL</Name><Physical_Name>SP_ADD_VESSEL</Physical_Name><Definition>Inserts a vessel.</Definition>
      <User_Defined_SQL>CREATE PROCEDURE SP_ADD_VESSEL @name varchar(100) AS INSERT INTO VESSEL (VESSEL_NAME) VALUES (@name)</User_Defined_SQL></Stored_ProcedureProps></Stored_Procedure>
    <Function id="{FN1}+00000000" name="FN_VESSEL_COUNT"><FunctionProps><Name>FN_VESSEL_COUNT</Name><Physical_Name>FN_VESSEL_COUNT</Physical_Name><Definition>Number of vessels.</Definition>
      <User_Defined_SQL>CREATE FUNCTION FN_VESSEL_COUNT() RETURNS int AS BEGIN RETURN (SELECT COUNT(*) FROM VESSEL) END</User_Defined_SQL></FunctionProps></Function>
    <Sequence id="{SQ1}+00000000" name="SEQ_VOYAGE"><SequenceProps><Name>SEQ_VOYAGE</Name><Physical_Name>SEQ_VOYAGE</Physical_Name><Definition>Voyage identifiers.</Definition><Start_Value>1000</Start_Value><Increment_Value>1</Increment_Value><Min_Value>1</Min_Value><Max_Value>999999</Max_Value></SequenceProps></Sequence>
    </EMX:Model></erwin>
""")


def mutate(xml: str, old: str, new: str) -> str:
    """Replace exactly one occurrence, failing loudly if the anchor is absent."""
    assert xml.count(old) >= 1, f"mutation anchor not found: {old!r}"
    return xml.replace(old, new, 1)
