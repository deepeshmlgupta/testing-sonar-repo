"""
Which field a definition came from is evidence, not an implementation detail.

SAP PD accepts Comment / Description / Annotation / Definition and erwin
accepts Definition / Comment / Note / Description / … plus the Notes tab, each
first-match-wins. So the framework legitimately compares a PD *Description*
against an erwin *Note* — but it used to report that as a plain "definition
matches", which is how Definition, Comment and Note quietly became
interchangeable with nothing in the report to show it.

The comparison is still made: refusing it would turn a genuine match into a
false DEFINITION_LOSS. It is simply no longer silent about what it compared.
"""

import os
import sys
import unittest
import xml.etree.ElementTree as ET

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.validation.ldm_reconcile import comparator as ldm
from app.validation.ldm_reconcile.comparator import ValidationResult
from app.validation.ldm_reconcile.erwin_ldm_parser import (
    ERWIN_DEFINITION_FIELDS,
    _definition_with_field,
)
from app.validation.ldm_reconcile.pd_ldm_parser import (
    PD_DEFINITION_FIELDS,
    _description_with_field,
)

A = "{attribute}"


def _pd(**fields):
    elem = ET.Element("{object}Entity")
    for name, value in fields.items():
        child = ET.SubElement(elem, A + name)
        child.text = value
    return elem


def _result():
    return ValidationResult(pd_model="m", erwin_model="m", pd_file="m.ldm", erwin_file="m.xml")


class PdProvenanceTests(unittest.TestCase):
    def test_the_winning_field_is_reported(self):
        self.assertEqual(("Business meaning.", "Comment"),
                         _description_with_field(_pd(Comment="Business meaning.")))
        self.assertEqual(("From description.", "Description"),
                         _description_with_field(_pd(Description="From description.")))
        self.assertEqual(("From annotation.", "Annotation"),
                         _description_with_field(_pd(Annotation="From annotation.")))

    def test_first_match_wins_in_the_documented_order(self):
        text, field = _description_with_field(
            _pd(Description="second", Comment="first", Annotation="third"))
        self.assertEqual(("first", "Comment"), (text, field))
        self.assertEqual("Comment", PD_DEFINITION_FIELDS[0])

    def test_nothing_found_reports_no_field(self):
        self.assertEqual(("", ""), _description_with_field(_pd()))

    def test_rtf_is_still_stripped(self):
        rtf = r"{\rtf1\ansi\ansicpg1252\deff0 \pard A real definition.\par}"
        text, field = _description_with_field(_pd(Comment=rtf))
        self.assertEqual("Comment", field)
        self.assertNotIn("rtf1", text)


class ErwinProvenanceTests(unittest.TestCase):
    @staticmethod
    def _erwin(**fields):
        elem = ET.Element("Entity")
        for name, value in fields.items():
            ET.SubElement(elem, name).text = value
        return elem

    def test_the_winning_property_is_reported(self):
        self.assertEqual(("D.", "Definition"), _definition_with_field(self._erwin(Definition="D.")))
        self.assertEqual(("C.", "Comment"), _definition_with_field(self._erwin(Comment="C.")))

    def test_definition_outranks_comment(self):
        text, field = _definition_with_field(self._erwin(Comment="c", Definition="d"))
        self.assertEqual(("d", "Definition"), (text, field))
        self.assertEqual("Definition", ERWIN_DEFINITION_FIELDS[0])

    def test_a_definition_resolved_from_the_notes_tab_says_so(self):
        # This is the real_estate / modeling_and_simulation case: Step 1 writes
        # the PD Comment into the Notes tab, so erwin's definition comes from
        # there and NOT from <Definition>.
        elem = ET.Element("Entity")
        props = ET.SubElement(elem, "EntityProps")
        array = ET.SubElement(props, "Note_List_Array")
        note = ET.SubElement(array, "Note_List")
        sep = r"\#x1F"
        note.text = sep.join(["1", "d", "a", "d", "a", "", "The business definition.",
                              "F", "", "", "{GUID}", ""])
        text, field = _definition_with_field(elem)
        self.assertEqual("The business definition.", text)
        self.assertIn("Note", field)

    def test_nothing_found_reports_no_field(self):
        self.assertEqual(("", ""), _definition_with_field(ET.Element("Entity")))


class ProvenanceOnFindingsTests(unittest.TestCase):
    def test_a_cross_field_comparison_is_stated_on_the_finding(self):
        result = _result()
        ldm._compare_definition(result, "ENTITY", "ADDRESS", "",
                                "The official location.", "The official location.",
                                "Comment", "Note_List (Notes tab)")
        message = result.findings[0].message
        self.assertIn("compared SAP PD Comment against erwin Note_List", message)

    def test_the_same_field_on_both_sides_adds_no_noise(self):
        result = _result()
        ldm._compare_definition(result, "ENTITY", "ADDRESS", "",
                                "Same text.", "Same text.", "Definition", "Definition")
        self.assertNotIn("compared SAP PD", result.findings[0].message)

    def test_case_differences_in_the_field_name_are_not_a_mismatch(self):
        self.assertEqual("", ldm._definition_provenance("Comment", "comment"))

    def test_provenance_is_recorded_on_a_loss_too(self):
        result = _result()
        ldm._compare_definition(result, "ENTITY", "ADDRESS", "",
                                "Only in SAP PD.", "", "Description", "")
        finding = result.findings[0]
        self.assertEqual("DEFINITION_LOSS", finding.category)
        self.assertIn("SAP PD Description", finding.message)

    def test_the_comparison_still_happens(self):
        """Provenance must not turn a real match into a loss."""
        result = _result()
        ldm._compare_definition(result, "ENTITY", "A", "", "Same.", "Same.",
                                "Description", "Note_List (Notes tab)")
        self.assertEqual("DEFINITION_EXACT", result.findings[0].category)
        self.assertEqual("VERIFIED", result.findings[0].severity)

    def test_unknown_provenance_is_silent_rather_than_misleading(self):
        self.assertEqual("", ldm._definition_provenance("", ""))


if __name__ == "__main__":       # pragma: no cover
    unittest.main()
