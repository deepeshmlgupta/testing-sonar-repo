"""
UDP evidence: carrying the verified read-back forward from Step 2 to V3.

erwin's Save-As-XML does not carry UDPs, so the artefact V3 measures physically
cannot show whether they migrated. The only evidence that can is the UDP
engine's read-back of the .erwin model, performed by run_udp.py in a different
process. This module pins the contract that carry-forward has to satisfy:

  * the verified pass rate is persisted by run_udp.py, per model, as JSON;
  * run_v3.py reads it, and prefers it to re-reading a report workbook;
  * a V3 XML that DOES carry UDPs still wins — evidence is the fallback, not
    an override;
  * stale or wrong-model evidence is refused, with a reason;
  * nothing synthetic is ever written into a model file, and no report page is
    created just to make scoring succeed;
  * the record is independently auditable — what was measured, from which
    files, by which method, when, and by whom.
"""

import json
import os
import sys
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.orchestration import udp_evidence as ev
from app.orchestration.udp_helpers import udp_engine_pass_rate, udp_stage_override

MODEL = "4d95b17a5883fbeb69fb9088bf1767c1_46007266_real_estate"


def _outcome(pass_rate=99.88, passed=1674, comparable=1676, reliable=True,
             method="com", stage="COMPARED"):
    result = SimpleNamespace(
        comparable=comparable,
        counts={"PASS": passed, "MISMATCH": 0, "MISSING": comparable - passed},
        readback=SimpleNamespace(method=method, reliable=reliable),
    )
    return SimpleNamespace(
        stage=stage, pass_rate=pass_rate, comparison_result=result,
        verdict="PASS", readback_method=method, readback_reliable=reliable,
        comparison_report_path="real_estate_udp_comparison.xlsx",
        migration_report_path="real_estate_udp_migration_report.xlsx",
        manifest_path="", erwin_read="",
    )


class EvidenceStoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.dirs = {"summary": self.root / "batch_summary"}
        self.pd = self.root / f"{MODEL}.ldm"
        self.pd.write_text("<Model><o:Entity/></Model>", encoding="utf-8")
        self.erwin = self.root / f"{MODEL}.erwin"
        self.erwin.write_bytes(b"erwin-binary-with-udps")

    def tearDown(self):
        self.tmp.cleanup()

    def _record(self, outcome=None, pd_path=None):
        outcome = outcome if outcome is not None else _outcome()
        outcome.erwin_read = str(self.erwin)
        return ev.record(self.dirs, MODEL, "LDM",
                         outcome, pd_path if pd_path is not None else self.pd)

    # ── persisted, machine-readable ──────────────────────────────────────────

    def test_the_verified_pass_rate_is_persisted_as_json(self):
        self._record()
        path = ev.path_for(self.dirs, MODEL)
        self.assertTrue(path.is_file(), "evidence must survive the process")
        payload = json.loads(path.read_text(encoding="utf-8"))
        self.assertEqual(99.88, payload["pass_rate"])
        self.assertEqual(1674, payload["passed"])
        self.assertEqual(1676, payload["comparable"])
        self.assertEqual("LDM", payload["model_type"])

    def test_it_is_stored_per_model(self):
        self._record()
        other = _outcome(pass_rate=12.5, passed=1, comparable=8)
        other.erwin_read = str(self.erwin)
        ev.record(self.dirs, "some_other_model", "LDM", other, self.pd)
        self.assertEqual(99.88, ev.load(self.dirs, MODEL).pass_rate)
        self.assertEqual(12.5, ev.load(self.dirs, "some_other_model").pass_rate)

    def test_it_is_not_a_report_page(self):
        """Requirement: no report created solely to make V3 scoring work."""
        self._record()
        produced = [p.name for p in ev.evidence_dir(self.dirs).iterdir()]
        self.assertEqual([f"{MODEL}.json"], produced)
        self.assertEqual([], list(self.root.rglob("*.xlsx")))

    def test_nothing_is_written_into_any_model_file(self):
        """Requirement: never inject synthetic UDP values into XML."""
        before = (self.pd.read_bytes(), self.erwin.read_bytes())
        self._record()
        self.assertEqual(before, (self.pd.read_bytes(), self.erwin.read_bytes()))

    # ── independently auditable ──────────────────────────────────────────────

    def test_the_record_says_what_it_measured_and_how(self):
        evidence = self._record()
        self.assertEqual(str(self.erwin), evidence.erwin_path)
        self.assertEqual(ev.sha256_of(self.erwin), evidence.erwin_sha256)
        self.assertEqual(str(self.pd), evidence.pd_path)
        self.assertEqual(ev.sha256_of(self.pd), evidence.pd_sha256)
        self.assertEqual("com", evidence.readback_method)
        self.assertTrue(evidence.readback_reliable)
        self.assertIn("udp_comparison", evidence.comparison_report)
        self.assertTrue(evidence.recorded_at and evidence.recorded_by)

    def test_the_audit_rows_expose_the_trail_without_the_dataclass(self):
        rows = ev.as_report_rows(self._record())
        self.assertTrue(rows["available"])
        for key in ("pass_rate", "passed", "comparable", "erwin_sha256",
                    "sap_sha256", "comparison_report", "recorded_at"):
            self.assertIn(key, rows)

    def test_the_audit_rows_explain_an_absence(self):
        rows = ev.as_report_rows(None, ev.REJECT_SOURCE_CHANGED)
        self.assertFalse(rows["available"])
        self.assertEqual(ev.REJECT_SOURCE_CHANGED, rows["reason"])

    # ── rejection rules ──────────────────────────────────────────────────────

    def test_absent_evidence_is_reported_not_guessed(self):
        rate, reason = ev.pass_rate_for(self.dirs, MODEL, "LDM", self.pd)
        self.assertIsNone(rate)
        self.assertEqual(ev.REJECT_ABSENT, reason)

    def test_a_changed_sap_source_makes_the_evidence_stale(self):
        self._record()
        self.pd.write_text("<Model><o:Entity/><o:Entity/></Model>", encoding="utf-8")
        rate, reason = ev.pass_rate_for(self.dirs, MODEL, "LDM", self.pd)
        self.assertIsNone(rate, "a rate measured against a different source is not evidence")
        self.assertEqual(ev.REJECT_SOURCE_CHANGED, reason)

    def test_a_missing_sap_source_is_refused(self):
        self._record()
        self.pd.unlink()
        self.assertEqual(ev.REJECT_SOURCE_MISSING,
                         ev.pass_rate_for(self.dirs, MODEL, "LDM", self.pd)[1])

    def test_evidence_for_another_model_is_refused(self):
        self._record()
        stored = ev.load(self.dirs, MODEL)
        ok, reason = ev.verify(stored, "a_completely_different_model", "LDM", self.pd)
        self.assertFalse(ok)
        self.assertIn(ev.REJECT_MODEL, reason)

    def test_evidence_from_another_tier_is_refused(self):
        self._record()
        ok, reason = ev.verify(ev.load(self.dirs, MODEL), MODEL, "PDM", self.pd)
        self.assertFalse(ok)
        self.assertIn(ev.REJECT_MODEL, reason)

    def test_an_unreliable_readback_is_refused(self):
        self._record(_outcome(reliable=False))
        self.assertEqual(ev.REJECT_UNRELIABLE,
                         ev.pass_rate_for(self.dirs, MODEL, "LDM", self.pd)[1])

    def test_a_run_that_produced_no_verdict_is_refused(self):
        self._record(_outcome(pass_rate=None, comparable=0, passed=0))
        self.assertEqual(ev.REJECT_NOT_MEASURED,
                         ev.pass_rate_for(self.dirs, MODEL, "LDM", self.pd)[1])

    def test_an_older_schema_is_refused_rather_than_half_read(self):
        self._record()
        path = ev.path_for(self.dirs, MODEL)
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["schema_version"] = ev.SCHEMA_VERSION + 99
        path.write_text(json.dumps(payload), encoding="utf-8")
        self.assertEqual(ev.REJECT_SCHEMA,
                         ev.pass_rate_for(self.dirs, MODEL, "LDM", self.pd)[1])

    def test_evidence_can_be_aged_out_when_configured(self):
        self._record()
        path = ev.path_for(self.dirs, MODEL)
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["recorded_at"] = (datetime.now(timezone.utc) - timedelta(days=40)).isoformat()
        path.write_text(json.dumps(payload), encoding="utf-8")
        self.assertEqual(ev.REJECT_STALE,
                         ev.pass_rate_for(self.dirs, MODEL, "LDM", self.pd, max_age_days=30)[1])
        self.assertEqual(99.88,
                         ev.pass_rate_for(self.dirs, MODEL, "LDM", self.pd, max_age_days=0)[0])

    def test_corrupt_evidence_is_ignored_not_fatal(self):
        ev.path_for(self.dirs, MODEL).write_text("{not json", encoding="utf-8")
        self.assertIsNone(ev.load(self.dirs, MODEL))

    def test_a_rerun_that_fails_supersedes_a_good_record(self):
        """A stale success must not survive a failed re-run of the same model."""
        self._record()
        self.assertEqual(99.88, ev.pass_rate_for(self.dirs, MODEL, "LDM", self.pd)[0])
        self._record(_outcome(pass_rate=None, comparable=0, passed=0, stage="FAILED"))
        self.assertIsNone(ev.pass_rate_for(self.dirs, MODEL, "LDM", self.pd)[0])


class CarryForwardTests(unittest.TestCase):
    """How V3 actually consumes it."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.dirs = {"summary": self.root / "batch_summary"}
        self.pd = self.root / f"{MODEL}.ldm"
        self.pd.write_text("<Model/>", encoding="utf-8")
        outcome = _outcome()
        outcome.erwin_read = ""
        ev.record(self.dirs, MODEL, "LDM", outcome, self.pd)

    def tearDown(self):
        self.tmp.cleanup()

    @staticmethod
    def _result(udp_values_erwin=0, udp_matched=0, udp_definitions_erwin=0):
        return SimpleNamespace(udp_fidelity=SimpleNamespace(
            udp_values_erwin=udp_values_erwin, udp_matched=udp_matched,
            udp_definitions_erwin=udp_definitions_erwin))

    def test_v3_with_no_live_outcome_carries_the_persisted_rate_forward(self):
        rate = udp_stage_override(self._result(), None, MODEL, "LDM",
                                  dirs=self.dirs, pd_path=self.pd)
        self.assertEqual(99.88, rate)

    def test_the_real_estate_case_end_to_end(self):
        """105 unrelated UDP values in the export must not beat the evidence."""
        rate = udp_stage_override(self._result(udp_values_erwin=105), None, MODEL, "LDM",
                                  dirs=self.dirs, pd_path=self.pd)
        self.assertEqual(99.88, rate)

    def test_a_v3_xml_that_really_carries_udps_still_wins(self):
        """Evidence is the fallback, never an override of a measurable XML."""
        rate = udp_stage_override(self._result(udp_values_erwin=1156, udp_matched=1156),
                                  None, MODEL, "LDM", dirs=self.dirs, pd_path=self.pd)
        self.assertIsNone(rate, "the XML measured it; the XML is the authority")

    def test_a_live_outcome_beats_the_stored_record(self):
        live = SimpleNamespace(pass_rate=42.0, comparison_result=object())
        self.assertEqual(42.0, udp_engine_pass_rate(MODEL, "LDM", live,
                                                    dirs=self.dirs, pd_path=self.pd))

    def test_the_workbook_is_not_consulted_when_evidence_is_usable(self):
        with patch("app.orchestration.udp_helpers.report_layout.resolve_udp_workbooks") as wb:
            rate = udp_engine_pass_rate(MODEL, "LDM", None, dirs=self.dirs, pd_path=self.pd)
        wb.assert_not_called()
        self.assertEqual(99.88, rate)

    def test_stale_evidence_falls_through_to_the_workbook(self):
        self.pd.write_text("<Model><changed/></Model>", encoding="utf-8")
        with patch("app.orchestration.udp_helpers.report_layout.resolve_udp_workbooks",
                   return_value={"comparison": ""}) as wb:
            udp_engine_pass_rate(MODEL, "LDM", None, dirs=self.dirs, pd_path=self.pd)
        wb.assert_called_once()

    def test_no_dirs_means_the_old_workbook_path_still_works(self):
        with patch("app.orchestration.udp_helpers.report_layout.resolve_udp_workbooks",
                   return_value={"comparison": ""}) as wb:
            udp_engine_pass_rate(MODEL, "LDM", None)
        wb.assert_called_once()


if __name__ == "__main__":       # pragma: no cover
    unittest.main()
