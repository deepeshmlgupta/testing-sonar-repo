"""
SQL body comparison for the programmable PDM objects (views, procedures,
functions, triggers).

Three defects in the existing path, all of the same family as the UDP
``pass_rate`` fix — a number invented where a measurement was missing:

  * ``compare_sql("", "")`` returned SQL_EXACT_MATCH with confidence 1.0, so a
    definition that exists nowhere read as perfectly migrated;
  * the erwin parser used the prose ``Definition`` property as the last-resort
    SQL BODY, so an English sentence was diffed against PowerDesigner's SQL;
  * ``SQL_SIMILARITY_THRESHOLD`` was named in COVERAGE_MATRIX.md and
    FINAL_AUDIT.md as the knob to turn, but lived in no config file — the 0.90
    was hard-coded, so following that remediation changed nothing.
"""

import os
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.config.validation_config import PDM_CONFIG
from app.validation.pdm_reconcile.pdm_erwin_validator import data_type_mapper, erwin_parser
from app.validation.pdm_reconcile.pdm_erwin_validator.data_type_mapper import (
    SQL_NOT_COMPARED,
    compare_sql,
    normalize_sql,
    sql_similarity_threshold,
)

VIEW_SQL = "SELECT VESSEL_ID, VESSEL_NAME FROM VESSEL WHERE CAPACITY > 0"


class NothingToCompareTests(unittest.TestCase):
    def test_absent_on_both_sides_is_not_a_match(self):
        status, similarity, message = compare_sql("", "")
        self.assertEqual(SQL_NOT_COMPARED, status)
        self.assertIsNone(similarity, "a missing measurement must not be a 1.0")
        self.assertIn("nothing to compare", message)

    def test_whitespace_only_counts_as_absent(self):
        self.assertEqual(SQL_NOT_COMPARED, compare_sql("   \n ", "\t")[0])

    def test_absent_on_one_side_is_still_a_mismatch(self):
        status, similarity, message = compare_sql(VIEW_SQL, "")
        self.assertEqual("SQL_MISMATCH", status)
        self.assertEqual(0.0, similarity)
        self.assertIn("ERwin", message, "says which side is missing it")
        self.assertIn("PowerDesigner", compare_sql("", VIEW_SQL)[2])

    def test_a_real_match_is_still_a_match(self):
        self.assertEqual("SQL_EXACT_MATCH", compare_sql(VIEW_SQL, VIEW_SQL)[0])
        self.assertEqual(1.0, compare_sql(VIEW_SQL, VIEW_SQL)[1])

    def test_formatting_differences_still_normalise_away(self):
        reformatted = "select vessel_id,\n  vessel_name\nfrom [VESSEL]  -- all of them\nwhere capacity > 0"
        status, similarity, _ = compare_sql(VIEW_SQL, reformatted)
        self.assertEqual("SQL_NORMALIZED_MATCH", status)
        self.assertEqual(1.0, similarity)
        self.assertEqual(normalize_sql(VIEW_SQL), normalize_sql(reformatted))


class ConfigurableThresholdTests(unittest.TestCase):
    """The documented knob has to actually turn something."""

    # ~85% similar: one literal changed inside a short body.
    NEARLY = "SELECT VESSEL_ID, VESSEL_NAME FROM VESSEL WHERE CAPACITY > 500"

    def test_the_threshold_comes_from_config(self):
        self.assertEqual(float(PDM_CONFIG.SQL_SIMILARITY_THRESHOLD), sql_similarity_threshold())

    def test_raising_the_threshold_turns_a_pass_into_a_mismatch(self):
        with patch.object(PDM_CONFIG, "SQL_SIMILARITY_THRESHOLD", 0.50):
            lenient = compare_sql(VIEW_SQL, self.NEARLY)
        with patch.object(PDM_CONFIG, "SQL_SIMILARITY_THRESHOLD", 0.999):
            strict = compare_sql(VIEW_SQL, self.NEARLY)
        self.assertEqual("SQL_NORMALIZED_MATCH", lenient[0])
        self.assertEqual("SQL_MISMATCH", strict[0])
        self.assertAlmostEqual(lenient[1], strict[1], places=6,
                               msg="the measurement does not move, only the verdict")

    def test_the_threshold_is_quoted_in_the_message(self):
        with patch.object(PDM_CONFIG, "SQL_SIMILARITY_THRESHOLD", 0.75):
            self.assertIn("75%", compare_sql(VIEW_SQL, self.NEARLY)[2])

    def test_a_nonsense_threshold_is_clamped_not_obeyed(self):
        for value in (-3.0, 12.0):
            with patch.object(PDM_CONFIG, "SQL_SIMILARITY_THRESHOLD", value):
                self.assertTrue(0.0 <= sql_similarity_threshold() <= 1.0)

    def test_an_unreadable_threshold_falls_back_to_the_default(self):
        with patch.object(PDM_CONFIG, "SQL_SIMILARITY_THRESHOLD", "not a number"):
            self.assertEqual(data_type_mapper.DEFAULT_SQL_SIMILARITY_THRESHOLD,
                             sql_similarity_threshold())


class ProseIsNotSqlTests(unittest.TestCase):
    """erwin's Definition property is a comment; it must not be read as a body."""

    def _view(self, body_property, text):
        return f"""<?xml version="1.0"?>
<ERwin_Data_Model><View Name="V_ACTIVE" Physical_Name="V_ACTIVE">
  <{body_property}>{text}</{body_property}>
</View></ERwin_Data_Model>"""

    def _parse_views(self, xml):
        import xml.etree.ElementTree as ET
        return erwin_parser._parse_views(ET.fromstring(xml))      # noqa: S314 - test fixture

    def test_a_prose_definition_is_not_used_as_the_sql_body(self):
        views = self._parse_views(self._view(
            "Definition", "Returns the vessels that are currently in service."))
        self.assertEqual("", views["V_ACTIVE"]["sql"],
                         "an English sentence must never be diffed against SQL")
        self.assertIn("currently in service", views["V_ACTIVE"]["definition"],
                      "it is still kept as the definition, which is its real job")

    def test_a_definition_that_really_is_sql_is_still_used(self):
        views = self._parse_views(self._view("Definition", VIEW_SQL))
        self.assertEqual(VIEW_SQL, views["V_ACTIVE"]["sql"])

    def test_a_sql_specific_property_always_wins(self):
        xml = """<?xml version="1.0"?>
<ERwin_Data_Model><View Name="V_ACTIVE" Physical_Name="V_ACTIVE">
  <User_Defined_SQL>SELECT 1 FROM DUAL</User_Defined_SQL>
  <Definition>SELECT 2 FROM DUAL</Definition>
</View></ERwin_Data_Model>"""
        self.assertEqual("SELECT 1 FROM DUAL", self._parse_views(xml)["V_ACTIVE"]["sql"])

    def test_the_prose_case_no_longer_produces_a_false_mismatch(self):
        # The defect end to end: PD has real SQL, erwin has only a prose
        # definition. Before, the sentence was compared to the SQL and reported
        # as a body mismatch at some arbitrary similarity; now the erwin side is
        # correctly empty and it is reported as missing from erwin.
        views = self._parse_views(self._view("Definition", "Active vessels only."))
        status, similarity, message = compare_sql(VIEW_SQL, views["V_ACTIVE"]["sql"])
        self.assertEqual("SQL_MISMATCH", status)
        self.assertEqual(0.0, similarity)
        self.assertIn("missing on the ERwin side", message)

    def test_sql_detection_covers_the_common_statement_openers(self):
        for sql in ("SELECT * FROM T", "create view v as select 1",
                    "  BEGIN\n  INSERT INTO T VALUES (1);\nEND",
                    "WITH x AS (SELECT 1) SELECT * FROM x",
                    "DECLARE @i INT"):
            self.assertTrue(erwin_parser._looks_like_sql(sql), sql)
        for prose in ("", "   ", "Returns the active vessels.",
                      "A list of vessels, selected from the fleet.",
                      "Updates nothing; kept for backwards compatibility."):
            self.assertFalse(erwin_parser._looks_like_sql(prose), prose)


if __name__ == "__main__":       # pragma: no cover
    unittest.main()
