"""
Tests for SAP-extract filename normalization
(directory_setup._normalize_input_models / normalize_named_file and
stage_paths.StagePaths._hash_normalized).

A SAP PD repository extract arrives as ``<32-hex-hash>_<extraction id>_<name>``.
Normalization copies it into a ``normalized/`` sub-folder with the hash
stripped, leaves the original in place, and the pipeline keys off the short
name from then on.

WHY THESE TESTS EXIST
---------------------
Normalization changes the model's KEY, so every artefact that may already sit
on disk under the pre-normalization name has to stay resolvable under the short
one. The first cut of this feature gave that fallback to the hand-off files
(xml_v1, erwin_v1, xml_v3) but NOT to the pipeline's own outputs, on the
reasoning that those "are already written with the model's name". True for a
fresh tree; false for every existing one. The UDP-enriched
erwinmodels/2_preprocessed/<model>.erwin stopped resolving, the read-back fell
through to the UN-enriched app/udp_tool/input_erwin_models copy — which DID
have the fallback — and a model that had migrated 1779/1781 values was reported
as 0 PASS / 1794 MISSING.

Nothing failed a test when that happened. That is what these tests fix.
"""

import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.orchestration import directory_setup as ds  # noqa: E402
from app.orchestration import stage_paths as sp  # noqa: E402

FULL = "4d95b17a5883fbeb69fb9088bf1767c1_46007266_real_estate"
SHORT = "46007266_real_estate"


def _tiers(tmp_path):
    dirs = {key: tmp_path / "sappdmodels" / key for key in ("ldm", "cdm", "pdm")}
    for path in dirs.values():
        path.mkdir(parents=True)
    return dirs


def _stages(tmp_path):
    stages = sp.stage_folders(tmp_path / "erwinmodels",
                              tmp_path / "final_xml_models",
                              tmp_path / "input_erwin_models")
    for path in stages.values():
        path.mkdir(parents=True, exist_ok=True)
    return stages


# ─── the normalization itself ─────────────────────────────────────────────────

def test_the_hash_is_stripped_and_the_original_is_left_alone(tmp_path):
    dirs = _tiers(tmp_path)
    source = dirs["ldm"] / f"{FULL}.ldm"
    source.write_text("SRC", encoding="utf-8")

    found = ds.find_models(dirs, mirror=False)

    assert [m.name for m in found] == [f"{SHORT}.ldm"]
    assert found[0].parent.name == ds.NORMALIZED_SUBDIR
    assert source.is_file(), "the original hash-named file is the source-of-record"


def test_a_name_without_the_prefix_is_carried_through_unchanged(tmp_path):
    dirs = _tiers(tmp_path)
    (dirs["cdm"] / "airlines.cdm").write_text("PLAIN", encoding="utf-8")
    assert [m.name for m in ds.find_models(dirs, mirror=False)] == ["airlines.cdm"]


def test_the_extraction_id_survives_so_two_extracts_never_collide(tmp_path):
    """
    The strip removes ONLY the 32-hex hash. The extraction id is what keeps two
    extracts of the same model apart — report_layout.short_model_name would
    strip that too and collapse both onto 'real_estate'.
    """
    dirs = _tiers(tmp_path)
    (dirs["ldm"] / f"{'a' * 32}_46007266_real_estate.ldm").write_text("A", encoding="utf-8")
    (dirs["ldm"] / f"{'b' * 32}_99999999_real_estate.ldm").write_text("B", encoding="utf-8")

    names = sorted(m.name for m in ds.find_models(dirs, mirror=False))
    assert names == ["46007266_real_estate.ldm", "99999999_real_estate.ldm"]


def test_normalizing_twice_does_not_duplicate_or_rewrite(tmp_path):
    dirs = _tiers(tmp_path)
    (dirs["ldm"] / f"{FULL}.ldm").write_text("SRC", encoding="utf-8")
    first = [m.name for m in ds.find_models(dirs, mirror=False)]
    assert [m.name for m in ds.find_models(dirs, mirror=False)] == first


# ─── the part that broke: artefacts under the pre-normalization name ──────────

@pytest.mark.parametrize("key,suffix", [
    ("xml_v1", ".xml"), ("xml_v2", ".xml"),
    ("erwin_v1", ".erwin"), ("erwin_v2", ".erwin"),
])
def test_every_stage_artefact_resolves_under_the_pre_normalization_name(
        tmp_path, key, suffix):
    """A tree written before normalization was switched on must still resolve."""
    stages = _stages(tmp_path)
    (stages[key] / f"{FULL}{suffix}").write_text("ARTEFACT", encoding="utf-8")

    paths = sp.StagePaths({"stages": stages, "initial": stages["xml_v1"]},
                          model_type="LDM")
    resolved = [c for c in paths.candidates(key, SHORT) if c.is_file()]

    assert resolved, f"{key} did not resolve under the normalized name"


def test_the_udp_readback_finds_the_enriched_model_not_the_un_enriched_input(tmp_path):
    """
    The exact regression: erwin_v2 (the UDP-enriched output) and erwin_v1 (the
    un-enriched input handed TO the tool) are different files. If erwin_v2 does
    not resolve, the read-back silently uses erwin_v1 and reports every
    migrated value as MISSING.
    """
    stages = _stages(tmp_path)
    (stages["erwin_v2"] / f"{FULL}.erwin").write_text("ENRICHED", encoding="utf-8")
    (stages["erwin_v1"] / f"{FULL}.erwin").write_text("UNENRICHED", encoding="utf-8")

    paths = sp.StagePaths({"stages": stages, "initial": stages["xml_v1"]},
                          model_type="LDM")
    resolved = [c for c in paths.candidates("erwin_v2", SHORT) if c.is_file()]

    assert resolved, "erwin_v2 must resolve — otherwise the read-back falls back to erwin_v1"
    assert resolved[0].read_text(encoding="utf-8") == "ENRICHED"


def test_a_correctly_named_artefact_beats_a_stale_hash_named_one(tmp_path):
    """expected() is tried first, so the fallback only fires when it has to."""
    stages = _stages(tmp_path)
    (stages["erwin_v2"] / f"{FULL}.erwin").write_text("OLD_STALE", encoding="utf-8")
    (stages["erwin_v2"] / f"{SHORT}.erwin").write_text("CURRENT", encoding="utf-8")

    paths = sp.StagePaths({"stages": stages, "initial": stages["xml_v1"]},
                          model_type="LDM")
    resolved = [c for c in paths.candidates("erwin_v2", SHORT) if c.is_file()]

    assert resolved[0].read_text(encoding="utf-8") == "CURRENT"


def test_the_fallback_covers_the_pipelines_own_outputs(tmp_path):
    """
    Pins the fix itself. Restricting _HASH_FALLBACK_KEYS to the hand-off files
    is what caused the 0 PASS / 1794 MISSING report.
    """
    for key in ("xml_v2", "erwin_v2"):
        assert key in sp._HASH_FALLBACK_KEYS, (
            f"{key} is a pipeline OUTPUT and still needs the hash fallback for "
            f"any tree written before normalization was switched on")
