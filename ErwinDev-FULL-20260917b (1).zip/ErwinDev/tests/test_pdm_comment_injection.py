"""
Step 1 (PD Comments -> erwin Notes) for PDM objects.

Before this change the injector only knew Entity / EntityAttribute, so a PDM
never received a single note (tables and columns are <o:Table> / <o:Column>
in PowerDesigner) and the PDM flow did not call it at all. Now:

  * pd_comment_to_erwin_note reads Table, Column, View, Procedure, Function,
    Trigger, Sequence and Tablespace comments and writes them into the
    matching erwin <XxxProps> block as a Note_List_Array;
  * pdm_flow runs it as Step 1 (before structural remediation) and measures V2
    against the annotated XML;
  * pdm_documentation decodes the note records and reports the programmable
    objects on the DOCUMENTATION sheet, so the documentation component of the
    fidelity score moves from V1 to V2 exactly as it does for CDM / LDM.
"""

import csv
import os
import sys
import tempfile
import unittest
from collections import Counter
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from defusedxml import ElementTree as ET

from app.config.validation_config import PDM_CONFIG
from app.preprocessing.scripts import pd_comment_to_erwin_note as pcen
from app.validation import extended_properties, fidelity_stages
from app.validation.pdm_reconcile import pdm_documentation, pdm_flow
from tests.fixtures_extended import ERWIN_PDM_FULL, PD_PDM_FULL, mutate, strip_definitions

# The erwin export as it comes out of the import: no Definitions, no Notes.
ERWIN_PDM_RAW = strip_definitions(ERWIN_PDM_FULL)

# What the PD fixture says about each programmable object.
PD_COMMENTS = {
    ("View", "V_ACTIVE_VESSELS"): "Vessels in service.",
    ("Procedure", "SP_ADD_VESSEL"): "Inserts a vessel.",
    ("Procedure", "FN_VESSEL_COUNT"): "Number of vessels.",
    ("Trigger", "TR_AUDIT_VESSEL"): "Writes an audit row on insert.",
    ("Sequence", "SEQ_VOYAGE"): "Voyage identifiers.",
    ("Tablespace", "TS_FLEET_DATA"): "Primary data files.",
}


def _local(tag):
    return tag.rsplit("}", 1)[-1]


def _notes_by_object(xml_path):
    """{(props tag, Physical_Name or Name): decoded note text} for every object carrying a note."""
    out = {}
    root = ET.parse(xml_path).getroot()
    for props in root.iter():
        if not _local(props.tag).endswith("Props"):
            continue
        name = None
        for child in props:
            if _local(child.tag) == "Physical_Name" and child.text:
                name = child.text
        if name is None:
            for child in props:
                if _local(child.tag) == "Name" and child.text:
                    name = child.text
        for child in props:
            if _local(child.tag) == "Note_List_Array":
                for note in child:
                    text = pcen.decode_note_record(note.text or "")["text"]
                    if text:
                        out[(_local(props.tag), name)] = text
    return out


class Files(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmp.name)
        self.pdm = self.dir / "fleet.pdm"
        self.pdm.write_text(PD_PDM_FULL, encoding="utf-8")
        self.raw_xml = self.dir / "fleet_raw.xml"
        self.raw_xml.write_text(ERWIN_PDM_RAW, encoding="utf-8")

    def tearDown(self):
        self.tmp.cleanup()


class PdModelTests(Files):
    def test_pdm_objects_are_read_with_their_comments(self):
        pd = pcen.PDModel.load(str(self.pdm))
        self.assertEqual(3, pd.count(pcen.KIND_ENTITY), "tables land in the entity map")
        self.assertEqual(8, pd.count(pcen.KIND_ATTRIBUTE), "columns land in the attribute map")
        self.assertEqual({("Active Vessels", "V_ACTIVE_VESSELS"): "Vessels in service."}, dict(pd.objects["View"]))
        self.assertEqual({("Add Vessel", "SP_ADD_VESSEL"): "Inserts a vessel.",
                          ("Vessel Count", "FN_VESSEL_COUNT"): "Number of vessels."}, dict(pd.objects["Procedure"]))
        self.assertEqual({("Voyage Sequence", "SEQ_VOYAGE"): "Voyage identifiers."}, dict(pd.objects["Sequence"]))
        self.assertEqual({("Fleet Data", "TS_FLEET_DATA"): "Primary data files."}, dict(pd.objects["Tablespace"]))
        # triggers are keyed by their owning table
        self.assertEqual({("Vessel", "Audit Vessel", "TR_AUDIT_VESSEL"): "Writes an audit row on insert."}, dict(pd.triggers))
        # tables inside a package are definitions too
        self.assertIn(("Vessel Type", "VESSEL_TYPE"), pd.entities)


class ErwinScanTests(Files):
    def test_every_programmable_props_block_becomes_an_object(self):
        objects = pcen.scan_erwin(self.raw_xml.read_bytes())
        kinds = Counter(o.kind for o in objects)
        self.assertEqual(3, kinds["Entity"])
        self.assertEqual(1, kinds["View"])
        self.assertEqual(2, kinds["Procedure"], "Stored_Procedure and Function are pooled")
        self.assertEqual(1, kinds["Trigger"])
        self.assertEqual(1, kinds["Sequence"])
        self.assertEqual(1, kinds["Tablespace"])
        trigger = next(o for o in objects if o.kind == "Trigger")
        self.assertEqual("Vessel", trigger.entity, "a trigger belongs to the enclosing entity")
        view = next(o for o in objects if o.kind == "View")
        self.assertIsNone(view.entity, "standalone objects carry no owner")
        self.assertEqual("View 'V_ACTIVE_VESSELS'", view.label)
        # every object has an insertion point even without User_Formatted_Physical_Name
        self.assertTrue(all(o.props_close is not None for o in objects))

    def test_view_attributes_are_not_mistaken_for_objects(self):
        objects = pcen.scan_erwin(self.raw_xml.read_bytes())
        self.assertFalse(any(o.name == "VESSEL_ID" and o.kind != "Attribute" for o in objects))


class MatchingTests(Files):
    def test_all_programmable_objects_match_exactly(self):
        pd = pcen.PDModel.load(str(self.pdm))
        objects = pcen.scan_erwin(self.raw_xml.read_bytes())
        matches, unmatched = pcen.match_objects(pd, objects)
        self.assertEqual([], [o.label for o in unmatched])
        by_label = {o.label: matches[id(o)] for o in objects}
        for (kind, code), comment in PD_COMMENTS.items():
            label = f"{kind} 'Vessel.{code}'" if kind == "Trigger" else f"{kind} '{code}'"
            self.assertEqual(comment, by_label[label][0], label)

    def test_case_and_punctuation_insensitive_fallback(self):
        pd = pcen.PDModel.load(str(self.pdm))
        xml = mutate(ERWIN_PDM_RAW, "<Name>SP_ADD_VESSEL</Name><Physical_Name>SP_ADD_VESSEL</Physical_Name>",
                     "<Name>sp add vessel</Name><Physical_Name>sp-add-vessel</Physical_Name>")
        objects = pcen.scan_erwin(xml.encode("utf-8"))
        matches, unmatched = pcen.match_objects(pd, objects)
        proc = next(o for o in objects if o.kind == "Procedure" and o.physical_name == "sp-add-vessel")
        self.assertIn(id(proc), matches)
        self.assertEqual(("Inserts a vessel.", 4), matches[id(proc)])

    def test_trigger_with_same_code_on_another_table_does_not_match(self):
        pd = pcen.PDModel.load(str(self.pdm))
        trigger = pcen.ErwinObject()
        trigger.kind, trigger.entity, trigger.name, trigger.physical_name = "Trigger", "Voyage", "TR_AUDIT_VESSEL", "TR_AUDIT_VESSEL"
        matches, unmatched = pcen.match_objects(pd, [trigger])
        self.assertEqual([trigger], unmatched)


class MigrateFileTests(Files):
    def test_notes_are_written_for_every_kind(self):
        out = self.dir / "fleet_notes.xml"
        result = pcen.migrate_file(str(self.pdm), str(self.raw_xml), str(out))
        self.assertEqual(0, result.unmatched)
        self.assertEqual({"Entity": 3, "Attribute": 1, "View": 1, "Procedure": 2,
                          "Trigger": 1, "Sequence": 1, "Tablespace": 1, "Package": 1},
                         dict(result.written_by_kind))
        notes = _notes_by_object(str(out))
        self.assertEqual("Vessels in service.", notes[("ViewProps", "V_ACTIVE_VESSELS")])
        self.assertEqual("Inserts a vessel.", notes[("Stored_ProcedureProps", "SP_ADD_VESSEL")])
        self.assertEqual("Number of vessels.", notes[("FunctionProps", "FN_VESSEL_COUNT")])
        self.assertEqual("Writes an audit row on insert.", notes[("TriggerProps", "TR_AUDIT_VESSEL")])
        self.assertEqual("Voyage identifiers.", notes[("SequenceProps", "SEQ_VOYAGE")])
        self.assertEqual("Primary data files.", notes[("TablespaceProps", "TS_FLEET_DATA")])
        self.assertEqual("A ship operated by the fleet.", notes[("EntityProps", "VESSEL")])
        self.assertIn("View 1", result.summary())
        # the output is still well-formed XML and nothing but notes changed
        self.assertEqual(ERWIN_PDM_RAW.count("<Attribute "), out.read_text(encoding="utf-8").count("<Attribute "))

    def test_second_run_is_idempotent_under_on_existing_skip(self):
        out = self.dir / "fleet_notes.xml"
        pcen.migrate_file(str(self.pdm), str(self.raw_xml), str(out))
        after_first = out.read_text(encoding="utf-8")
        again = pcen.migrate_file(str(self.pdm), str(out), str(out))
        self.assertEqual(0, again.written)
        self.assertTrue(all("already present" in r["reason"] for r in again.rows if r["kind"] == "View"))
        # Idempotency is "the second run changes nothing", not "the text occurs
        # once": the View carries the same wording in PD Comment AND PD
        # Description, so one run legitimately lands it in erwin's Definition
        # and in its Note — two occurrences, by design, after a single run.
        self.assertEqual(after_first, out.read_text(encoding="utf-8"))
        self.assertEqual(2, after_first.count("Vessels in service."))

    def test_only_restricts_the_kinds_written(self):
        out = self.dir / "views_only.xml"
        result = pcen.migrate_file(str(self.pdm), str(self.raw_xml), str(out), only=["View", "Sequence"])
        self.assertEqual({"View": 1, "Sequence": 1}, dict(result.written_by_kind))
        self.assertTrue(any(r["reason"] == "object kind excluded by --only" for r in result.rows if r["kind"] == "Entity"))

    def test_cli_migrate_writes_report_with_kind_column(self):
        out = self.dir / "cli.xml"
        report = self.dir / "report.csv"
        pcen.main(["migrate", "--ldm", str(self.pdm), "--erwin", str(self.raw_xml),
                   "--out", str(out), "--report", str(report)])
        self.assertTrue(out.is_file())
        with open(report, newline="", encoding="utf-8") as handle:
            rows = list(csv.DictReader(handle))
        kinds = {r["kind"] for r in rows}
        self.assertTrue({"View", "Procedure", "Trigger", "Sequence", "Tablespace"} <= kinds)
        self.assertEqual("PASS", next(r for r in rows if r["physical_name"] == "TR_AUDIT_VESSEL")["status"])


class DocumentationTests(Files):
    def test_programmable_rows_go_from_missing_to_matched(self):
        before = pdm_documentation.build_rows(str(self.pdm), str(self.raw_xml))
        status_before = {(r.object_type, r.object_code): r.status for r in before}
        for object_type, code in (("VIEW", "V_ACTIVE_VESSELS"), ("PROCEDURE", "SP_ADD_VESSEL"), ("PROCEDURE", "FN_VESSEL_COUNT"),
                                  ("TRIGGER", "TR_AUDIT_VESSEL"), ("SEQUENCE", "SEQ_VOYAGE"), ("TABLESPACE", "TS_FLEET_DATA")):
            self.assertEqual("MISSING_IN_ERWIN", status_before[(object_type, code)], (object_type, code))

        out = self.dir / "fleet_notes.xml"
        pcen.migrate_file(str(self.pdm), str(self.raw_xml), str(out))
        after = pdm_documentation.build_rows(str(self.pdm), str(out))
        status_after = {(r.object_type, r.object_code): r.status for r in after}
        for key in status_before:
            if key[0] in ("VIEW", "PROCEDURE", "TRIGGER", "SEQUENCE", "TABLESPACE", "TABLE"):
                self.assertEqual("MATCHED", status_after[key], key)
        trigger_row = next(r for r in after if r.object_type == "TRIGGER"
                          and r.mapping == pdm_documentation.DESCRIPTION_TO_NOTE)
        self.assertEqual("VESSEL.Audit Vessel", trigger_row.object_name)
        self.assertEqual("erwin Note", trigger_row.target_field)

    def test_table_note_is_not_taken_from_its_columns(self):
        # Only the column carries a comment/description: the table row must stay empty on the erwin side.
        pd_xml = PD_PDM_FULL.replace(
            "<a:Comment>A ship operated by the fleet.</a:Comment>"
            "<a:Description>A ship operated by the fleet.</a:Description>",
            "", 1,
        )
        pdm = self.dir / "col_only.pdm"
        pdm.write_text(pd_xml, encoding="utf-8")
        out = self.dir / "col_only.xml"
        pcen.migrate_file(str(pdm), str(self.raw_xml), str(out))
        rows = pdm_documentation.build_rows(str(pdm), str(out))
        vessel = next(r for r in rows if r.object_type == "TABLE" and r.object_code == "VESSEL")
        self.assertEqual("", vessel.target_value)
        column = next(r for r in rows if r.object_type == "COLUMN" and r.object_name == "VESSEL.Vessel Id"
                     and r.mapping == pdm_documentation.DESCRIPTION_TO_NOTE)
        self.assertEqual("MATCHED", column.status)

    def test_definition_fallback_still_credits_older_imports(self):
        # An import that landed the comment in <Definition> is not reported as a loss.
        full = self.dir / "full.xml"
        full.write_text(ERWIN_PDM_FULL, encoding="utf-8")
        rows = pdm_documentation.build_rows(str(self.pdm), str(full))
        self.assertTrue(all(r.status == "MATCHED" for r in rows if r.object_type == "VIEW"))

    def test_extended_definition_checks_read_notes_too(self):
        out = self.dir / "fleet_notes.xml"
        pcen.migrate_file(str(self.pdm), str(self.raw_xml), str(out))
        findings = extended_properties.run(str(self.pdm), str(out), "pdm", PDM_CONFIG)
        self.assertEqual([], [f.category for f in findings if f.category.endswith("_DEFINITION")])


class PdmFlowTests(Files):
    def _run(self, **overrides):
        kwargs = dict(
            pdm_path=str(self.pdm),
            initial_erwin=str(self.dir / "1_initial" / "fleet.erwin"),
            initial_xml=str(self.raw_xml),
            preprocessed_erwin=str(self.dir / "2_preprocessed" / "fleet.erwin"),
            preprocessed_xml=str(self.dir / "2_preprocessed" / "fleet.xml"),
            final_erwin=str(self.dir / "3_final" / "fleet.erwin"),
            final_xml=str(self.dir / "3_final" / "fleet.xml"),
            target_fidelity=90.0,
        )
        kwargs.update(overrides)
        return pdm_flow.run_pdm_flow(**kwargs)

    def test_step_one_runs_before_remediation_and_moves_the_documentation_score(self):
        # erwin's Definition side is stripped in this fixture, and Step 1 now
        # rebuilds it: PD Comment -> erwin Definition and PD Description ->
        # erwin Note are both written, so documentation goes all the way to
        # 100%. Before 2026-09-17 this capped at 50%, because nothing in the
        # pipeline wrote Definition and the mapping could only ever be reported
        # lost.
        outcome = self._run(target_fidelity=80.0)
        self.assertIsNotNone(outcome.comment_injection)
        self.assertTrue(any(m.startswith("Comments -> erwin Notes") for m in outcome.messages), outcome.messages)
        history = fidelity_stages.history(outcome.final_result)
        self.assertEqual(0.0, history["V1"].component("documentation"))
        self.assertEqual(100.0, history["V2"].component("documentation"))
        self.assertGreater(history["V2"].overall, history["V1"].overall)
        # >= 80 after Step 1 -> promoted: the annotated XML moved on to 3_final.
        self.assertTrue(outcome.promoted, outcome.messages)
        final = Path(outcome.artifacts["final_xml"])
        self.assertTrue(final.is_file())
        notes = _notes_by_object(str(final))
        self.assertIn(("ViewProps", "V_ACTIVE_VESSELS"), notes, "notes survive structural remediation and promotion")
        self.assertIn(("TriggerProps", "TR_AUDIT_VESSEL"), notes)

    def test_complete_model_still_gets_its_comments_and_a_v2(self):
        # Definitions already present -> structurally and documentation-wise complete at V1;
        # Step 1 still runs (notes are the agreed carrier) and V2 is measured on the annotated file.
        full = self.dir / "full.xml"
        full.write_text(ERWIN_PDM_FULL, encoding="utf-8")
        outcome = self._run(initial_xml=str(full))
        self.assertTrue(any("no remediation needed" in m for m in outcome.messages), outcome.messages)
        self.assertIn("V2", fidelity_stages.history(outcome.final_result))
        self.assertIn("V1", fidelity_stages.history(outcome.final_result))

    def test_injection_can_be_switched_off(self):
        from unittest.mock import patch
        with patch.object(PDM_CONFIG, "PDM_COMMENT_INJECTION_ENABLED", False, create=True):
            outcome = self._run()
        self.assertIsNone(outcome.comment_injection)
        self.assertFalse(any(m.startswith("Comments -> erwin Notes") for m in outcome.messages))

    def test_preprocess_disabled_skips_step_one(self):
        outcome = self._run(preprocess_enabled=False)
        self.assertIsNone(outcome.comment_injection)


if __name__ == "__main__":
    unittest.main()
