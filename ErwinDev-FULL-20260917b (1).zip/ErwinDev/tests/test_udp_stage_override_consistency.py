"""
Regression test: V2 and V3 must use the same UDP-evidence rule.

Before this fix, only V3 fell back to the UDP engine's read-back pass rate
when the erwin XML it measured carried no UDPs; V2 always scored the raw
(often 0%) XML-vs-XML match. That let V2 report a passing UDP fidelity while
V3 reported a failure for the exact same underlying migration.
"""

from types import SimpleNamespace

from app.orchestration.udp_helpers import erwin_xml_carries_udps, udp_stage_override
from app.validation.pdm_reconcile.pdm_flow import _erwin_xml_carries_udps, _udp_stage_override


def _result(udp_values_erwin=0, udp_definitions_erwin=0, udp_matched=0):
    fidelity = SimpleNamespace(udp_values_erwin=udp_values_erwin,
                               udp_definitions_erwin=udp_definitions_erwin,
                               udp_matched=udp_matched)
    return SimpleNamespace(udp_fidelity=fidelity)


def test_stage_falls_back_to_engine_pass_rate_when_xml_carries_no_udps():
    result = _result(udp_values_erwin=0, udp_definitions_erwin=0)
    udp_outcome = SimpleNamespace(pass_rate=97.5)

    assert not erwin_xml_carries_udps(result)
    assert udp_stage_override(result, udp_outcome, "model", "LDM") == 97.5


def test_stage_trusts_xml_when_it_carries_matched_udps():
    result = _result(udp_values_erwin=12, udp_matched=12)
    udp_outcome = SimpleNamespace(pass_rate=0.0)

    assert erwin_xml_carries_udps(result)
    assert udp_stage_override(result, udp_outcome, "model", "LDM") is None


def test_stage_trusts_xml_when_it_carries_a_udp_dictionary():
    # Definitions present but nothing matched yet is still the XML speaking
    # about UDPs — the comparison had something to look for and found none.
    result = _result(udp_values_erwin=0, udp_definitions_erwin=7)
    assert erwin_xml_carries_udps(result)


def test_values_that_match_no_sap_udp_are_not_evidence():
    """
    real_estate, measured: the validated export carried 105 UDP values, of
    which 0 matched a SAP PD UDP and 0 were UDP definitions — every one
    classified "extra in erwin". Accepting that as evidence discarded the
    engine's verified 99.88% read-back of the .erwin model and scored the V3
    UDP component 0%, reporting 1156 migrated values as lost and making V3
    (73.69%) look 25 points worse than V2 (98.66%) for an identical migration.
    """
    result = _result(udp_values_erwin=105, udp_definitions_erwin=0, udp_matched=0)
    udp_outcome = SimpleNamespace(pass_rate=99.88)

    assert not erwin_xml_carries_udps(result)
    assert udp_stage_override(result, udp_outcome, "real_estate", "LDM") == 99.88


def test_v2_and_v3_cannot_disagree_on_the_real_estate_numbers():
    """The reported symptom: V2 99.88% UDP, V3 0% UDP, same migration."""
    udp_outcome = SimpleNamespace(pass_rate=99.88)
    v2 = _result(udp_values_erwin=0)                       # 2_preprocessed XML: no UDPs
    v3 = _result(udp_values_erwin=105, udp_matched=0)      # validated XML: 105 unrelated
    assert (udp_stage_override(v2, udp_outcome, "real_estate", "LDM")
            == udp_stage_override(v3, udp_outcome, "real_estate", "LDM") == 99.88)


def test_v2_and_v3_agree_on_the_same_override_rule():
    """
    The exact regression this fixes: V2 (2_preprocessed/xml has no UDPs) and
    V3 (final validated XML also has none) must resolve to the SAME override,
    so a passing engine result cannot show as V2 PASS / V3 FAIL.
    """
    v2_result = _result(udp_values_erwin=0, udp_definitions_erwin=0)
    v3_result = _result(udp_values_erwin=0, udp_definitions_erwin=0)
    udp_outcome = SimpleNamespace(pass_rate=100.0)

    v2_override = udp_stage_override(v2_result, udp_outcome, "model", "LDM")
    v3_override = udp_stage_override(v3_result, udp_outcome, "model", "LDM")
    assert v2_override == v3_override == 100.0


def test_pdm_flow_shares_the_same_rule():
    result = _result(udp_values_erwin=0, udp_definitions_erwin=0)
    assert not _erwin_xml_carries_udps(result)
    assert _udp_stage_override(result, 88.0) == 88.0

    carried = _result(udp_values_erwin=5, udp_matched=5)
    assert _erwin_xml_carries_udps(carried)

    unrelated = _result(udp_values_erwin=105, udp_matched=0)
    assert not _erwin_xml_carries_udps(unrelated), (
        "values matching no SAP PD UDP must not overrule the engine read-back")
    assert _udp_stage_override(carried, 88.0) is None
