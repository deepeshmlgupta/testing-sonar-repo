"""
sappdmodels/{cdm,ldm,pdm} -> app/udp_tool/input_erwin_models/{cdm,ldm,pdm}
"""
import os
import time
from pathlib import Path

from app.orchestration.directory_setup import mirror_models_to_udp_input


def _model(folder: Path, name: str, body: str = "<Model/>") -> Path:
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / name
    path.write_text(body, encoding="utf-8")
    return path


def test_models_are_copied_into_tier_folders_named_by_extension(tmp_path):
    src = tmp_path / "sappdmodels"
    models = [
        _model(src / "ldm", "airlines.ldm"),
        _model(src / "cdm", "logistics.cdm"),
        _model(src / "pdm", "warehouse.PDM"),          # extension case is irrelevant
    ]
    target = tmp_path / "input_erwin_models"

    written = mirror_models_to_udp_input(models, target_root=target)

    assert sorted(p.relative_to(target).as_posix() for p in written) == [
        "cdm/logistics.cdm", "ldm/airlines.ldm", "pdm/warehouse.PDM"]
    assert (target / "ldm" / "airlines.ldm").read_text(encoding="utf-8") == "<Model/>"


def test_a_current_copy_is_left_alone_and_a_newer_source_replaces_it(tmp_path):
    src = _model(tmp_path / "sappdmodels" / "ldm", "airlines.ldm", "v1")
    target = tmp_path / "input_erwin_models"

    assert len(mirror_models_to_udp_input([src], target_root=target)) == 1
    # Second run: nothing to do.
    assert mirror_models_to_udp_input([src], target_root=target) == []

    # Source edited later -> copy refreshed.
    src.write_text("v2-longer", encoding="utf-8")
    later = time.time() + 5
    os.utime(src, (later, later))
    assert len(mirror_models_to_udp_input([src], target_root=target)) == 1
    assert (target / "ldm" / "airlines.ldm").read_text(encoding="utf-8") == "v2-longer"


def test_non_model_files_and_unreadable_sources_never_raise(tmp_path):
    stray = _model(tmp_path / "sappdmodels" / "ldm", "notes.txt")
    missing = tmp_path / "sappdmodels" / "cdm" / "gone.cdm"
    target = tmp_path / "input_erwin_models"

    assert mirror_models_to_udp_input([stray, missing], target_root=target) == []
    assert not (target / "ldm" / "notes.txt").exists()
