"""
The three stage scripts on the synthetic model, in the order the operator
runs them, with the two MANUAL hand-offs (.erwin to the UDP tool, XML export
of the enriched model) played by the test:

    run_v1.process_model   -> V1 report, 2_preprocessed/<m>.xml, ERWIN_HANDOFF = WAITING
    [operator copies <m>.erwin to udp_tool/input_erwin_models]
    run_udp.process_model  -> ERWIN_HANDOFF = VALIDATED, UDP stage recorded, V3_XML_EXPORT = WAITING
    [operator exports the enriched .erwin as XML into final_xml_models/ldm]
    run_v3.process_model   -> V2, V3, gate, 3_final, ledger with hashes

Plus the negative cases the flow must refuse: corrupt XML V1, empty .erwin,
an XML V3 of a different model, a rerun that must not overwrite inputs, and
the complexity triage.
"""

import hashlib
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import run_udp, run_v1, run_v3
from app.config import settings
from app.orchestration import concurrency, directory_setup, stage_state
from app.orchestration.model_record import (
    COMPLEXITY_COMPLEX,
    COMPLEXITY_MEDIUM,
    COMPLEXITY_SIMPLE,
    COMPLEXITY_UNKNOWN,
    classify_complexity,
)
from app.orchestration.stage_paths import StagePaths
from tests.fixtures_extended import ERWIN_PDM_FULL, PD_PDM_FULL, strip_definitions
from tests.test_vessel_reconciliation_fixes import ERWIN_XML, PD_LDM

ERWIN_XML_RAW = "\n".join(line for line in ERWIN_XML.splitlines() if "Note_List" not in line)

OTHER_MODEL_XML = """<?xml version="1.0" encoding="UTF-8"?>
<EMX xmlns="http://www.ca.com/erwin/data"><Model id="{m1}" name="Other"><ModelProps><Name>Other</Name></ModelProps>
<Entity_Groups><Entity id="{e1}" name="ZZ_UNRELATED"><EntityProps><Name>ZZ_UNRELATED</Name></EntityProps>
<Attribute_Groups><Attribute id="{a1}" name="ZZ_ID"><AttributeProps><Name>ZZ_ID</Name></AttributeProps></Attribute>
</Attribute_Groups></Entity></Entity_Groups></Model></EMX>
"""


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class ManualHandoffFlowTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        self.root = root
        for tier in ("ldm", "cdm", "pdm"):
            (root / "sappdmodels" / tier).mkdir(parents=True)
        (root / "sappdmodels" / "ldm" / "synthetic.ldm").write_text(PD_LDM, encoding="utf-8")
        reports_root = root / "reports_out"
        self.udp_input = root / "app" / "udp_tool" / "input_erwin_models"
        self.patches = [
            patch.object(settings, "BASE_DIR", root),
            patch.object(settings, "SAMPLES_DIR", str(root / "sappdmodels")),
            patch.object(settings, "OUTPUT_DIR", str(root / "erwinmodels")),
            patch.object(settings, "FINAL_XML_DIR", str(root / "final_xml_models")),
            patch.object(settings, "MAX_WORKERS", 1),
            patch.object(settings, "PROMOTION_FIDELITY_THRESHOLD", 90.0),
            patch.object(settings, "MANUAL_EXPORT_WAIT_SECONDS", 0),
            # strict hand-off flow for these tests: a missing XML V3 is a hard stop
            patch.object(settings, "FINAL_XML_FALLBACK_TO_PREPROCESSED", False),
            patch.object(directory_setup, "UDP_INPUT_MODELS_DIR", self.udp_input),
            patch.object(directory_setup, "SCRATCH_REPORT_DIR", root / "scratch"),
            patch("app.reporting.model_reports.SCRATCH_REPORT_DIR", root / "scratch"),
            patch("app.reporting.report_layout.model_dir",
                  side_effect=lambda t, n, create=True: (reports_root / t / n).mkdir(parents=True, exist_ok=True)
                  or (reports_root / t / n)),
            patch("app.reporting.report_layout.manual_review_dir",
                  side_effect=lambda t, n, create=True: reports_root / t / n / "manual_review_report"),
            patch("app.reporting.report_layout.tier_dir", side_effect=lambda t: reports_root / t),
            patch("app.common.config_helpers.udp_reports_dir", side_effect=lambda t: reports_root / "udp" / t),
        ]
        for p in self.patches:
            p.start()
        concurrency.clear_skipped_models()
        self.dirs = directory_setup.setup_directories()
        self.stages = StagePaths(self.dirs, "LDM")
        self.model = self.root / "sappdmodels" / "ldm" / "synthetic.ldm"

    def tearDown(self):
        for p in reversed(self.patches):
            p.stop()
        self.tmp.cleanup()

    def _status(self, stage):
        return stage_state.stage_status(self.dirs, "synthetic", stage)

    # ── the happy path, one script at a time ──────────────────────────────────

    def test_stage_scripts_in_sequence_with_manual_handoffs(self):
        # run_v1 before the operator exported anything: WAITING, nothing written to 1_initial
        self.assertIsNone(run_v1.process_model(self.model, "synthetic", "LDM", self.dirs))
        self.assertEqual(stage_state.STATUS_WAITING, self._status(stage_state.STAGE_V1_XML))
        self.assertEqual([], list(self.dirs["initial"].iterdir()))
        self.assertTrue(any("erwinmodels/1_initial" in a for a in stage_state.pending_actions(self.dirs, "synthetic")))

        # operator: export the imported model from erwin as XML
        xml_v1 = self.stages.xml_v1("synthetic")
        xml_v1.write_text(ERWIN_XML_RAW, encoding="utf-8")
        v1_hash = _sha(xml_v1)

        record = run_v1.process_model(self.model, "synthetic", "LDM", self.dirs)
        self.assertIsNotNone(record)
        self.assertTrue(record.v1_report_path and Path(record.v1_report_path).is_file())
        self.assertEqual(stage_state.STATUS_VALIDATED, self._status(stage_state.STAGE_V1_XML))
        self.assertEqual(stage_state.STATUS_READY, self._status(stage_state.STAGE_V1_FIDELITY))
        self.assertEqual(stage_state.STATUS_READY, self._status(stage_state.STAGE_XML_V2))
        self.assertEqual(stage_state.STATUS_WAITING, self._status(stage_state.STAGE_ERWIN_HANDOFF))
        xml_v2 = self.stages.xml_v2("synthetic")
        self.assertTrue(xml_v2.is_file() and "Note_List" in xml_v2.read_text(encoding="utf-8"))
        # run_v1 produced no .erwin anywhere — there is no bridge
        self.assertEqual([], list(self.root.rglob("*.erwin")))
        self.assertEqual(v1_hash, _sha(xml_v1), "input XML V1 untouched")
        # the handoff record carries the artefact identity
        events = {e["stage"]: e for e in stage_state.history(self.dirs, "synthetic")}
        self.assertEqual(v1_hash, events[stage_state.STAGE_V1_XML]["artifact"]["sha256"])
        self.assertTrue(events[stage_state.STAGE_V1_XML]["manual"])
        self.assertEqual(str(xml_v1), events[stage_state.STAGE_XML_V2]["artifact"]["parent"])
        self.assertIn(events[stage_state.STAGE_V1_FIDELITY]["complexity"],
                      (COMPLEXITY_SIMPLE, COMPLEXITY_MEDIUM, COMPLEXITY_COMPLEX))
        for event in events.values():
            self.assertTrue(event["timestamp"] and event["model"] == "synthetic" and event["model_type"] == "LDM")

        # run_udp before the operator handed off the .erwin: WAITING, no output .erwin
        run_udp.process_model(self.model, "synthetic", "LDM", self.dirs)
        self.assertEqual(stage_state.STATUS_WAITING, self._status(stage_state.STAGE_ERWIN_HANDOFF))
        self.assertEqual(stage_state.STATUS_WAITING, self._status(stage_state.STAGE_UDP))
        self.assertFalse(self.stages.erwin_v2("synthetic").exists())
        self.assertTrue(any("input_erwin_models" in r for r in concurrency.get_skipped_models()))

        # operator: save the commented model as .erwin into the UDP tool's input folder
        erwin_v1 = self.stages.erwin_v1("synthetic")
        erwin_v1.parent.mkdir(parents=True, exist_ok=True)
        erwin_v1.write_bytes(b"erwin-binary-stand-in")
        in_hash = _sha(erwin_v1)
        concurrency.clear_skipped_models()
        run_udp.process_model(self.model, "synthetic", "LDM", self.dirs)
        self.assertEqual(stage_state.STATUS_VALIDATED, self._status(stage_state.STAGE_ERWIN_HANDOFF))
        self.assertEqual(in_hash, _sha(erwin_v1), "handed-off .erwin never overwritten")
        # without erwin COM on this host injection cannot run: FAILED with the remedy, never faked
        udp_event = stage_state.history(self.dirs, "synthetic")[-1]
        self.assertIn(self._status(stage_state.STAGE_UDP), (stage_state.STATUS_FAILED, stage_state.STATUS_READY))
        if self._status(stage_state.STAGE_UDP) == stage_state.STATUS_FAILED:
            self.assertIn("Windows", udp_event["next_action"])
            # operator (Windows host) produces the enriched model
            self.stages.erwin_v2("synthetic").write_bytes(b"erwin-binary-with-udps")

        # run_v3 before the operator exported the enriched model: hard stop
        self.assertIsNone(run_v3.process_model(self.model, "synthetic", "LDM", self.dirs))
        self.assertEqual(stage_state.STATUS_WAITING, self._status(stage_state.STAGE_V3_XML))
        self.assertEqual([], list(self.dirs["final"].iterdir()))

        # operator: export the enriched .erwin as XML
        xml_v3 = self.stages.xml_v3("synthetic")
        xml_v3.parent.mkdir(parents=True, exist_ok=True)
        xml_v3.write_text(ERWIN_XML, encoding="utf-8")
        self.assertTrue(xml_v3.parent.name == "ldm")

        # This test supplies the erwin XML directly instead of running Step 1,
        # and that fixture carries Notes but no <Definition>, so Comment ->
        # Definition stays MISSING_IN_ERWIN and documentation caps at 50% —
        # overall 82.5%, still enough to clear an 80% promotion bar.
        with patch.object(settings, "PROMOTION_FIDELITY_THRESHOLD", 80.0):
            record = run_v3.process_model(self.model, "synthetic", "LDM", self.dirs)
        self.assertIsNotNone(record)
        self.assertEqual(stage_state.STATUS_VALIDATED, self._status(stage_state.STAGE_V3_XML))
        self.assertEqual(stage_state.STATUS_READY, self._status(stage_state.STAGE_V3_FIDELITY))
        self.assertEqual("PASS", record.status)
        self.assertTrue(self.stages.erwin_v3("synthetic").is_file())
        self.assertTrue((self.dirs["final"] / "synthetic.xml").is_file())
        self.assertEqual(_sha(xml_v3), _sha(self.dirs["final"] / "synthetic.xml"), "copied, not altered")
        self.assertTrue(xml_v3.is_file(), "input XML V3 not moved")
        # V1 -> V2 -> V3 progression on the V3 result, V1 read back from run_v1's state
        self.assertEqual({"V1", "V2", "V3"}, set(record.result.stage_scores))
        # ledger line: lineage with hashes
        ledger = self.dirs["summary"] / "audit" / "pipeline_ledger.jsonl"
        entry = json.loads(ledger.read_text(encoding="utf-8").splitlines()[-1])
        self.assertEqual("synthetic", entry["model"])
        self.assertEqual("3_final", entry["destination"])
        self.assertEqual("manual", entry["artefact_origin"]["xml_v1"])
        for key in ("source_model", "xml_v1", "xml_v2", "erwin_v2", "xml_v3", "final_xml"):
            self.assertIn(key, entry["artefact_hashes"], key)
        self.assertEqual(v1_hash, entry["artefact_hashes"]["xml_v1"]["sha256"])
        self.assertIn(entry["complexity"], (COMPLEXITY_SIMPLE, COMPLEXITY_MEDIUM, COMPLEXITY_COMPLEX))
        self.assertTrue(entry["reports"]["v1"].endswith(".xlsx"))

    # ── erwin COM present: Step 2 runs end to end with no hand-off at all ─────

    def test_run_udp_produces_both_erwin_artefacts_when_erwin_com_is_available(self):
        """
        The whole point of Step 2: on a Windows host with erwin Data Modeler,
        ``run_udp.py`` converts XML V2 to .ERWIN V1 itself, injects the UDPs and
        writes .ERWIN V2 — no operator, no hand-off folder, no waiting.

        This is the case that never happened before the hand-off gate existed:
        the converter had no caller, so the .erwin input never appeared and the
        stage ended at EXTRACTED with no output file on every host alike.
        """
        from app.erwin import erwin_converter
        from app.validation import udp_bridge

        self.stages.xml_v1("synthetic").write_text(ERWIN_XML_RAW, encoding="utf-8")
        run_v1.process_model(self.model, "synthetic", "LDM", self.dirs)
        xml_v2 = self.stages.xml_v2("synthetic")
        self.assertTrue(xml_v2.is_file())

        converted = {}

        def fake_convert(src, dst, timeout):
            converted["src"], converted["dst"] = Path(src), Path(dst)
            Path(dst).parent.mkdir(parents=True, exist_ok=True)
            Path(dst).write_bytes(b"erwin-binary-from-scapi")
            return 0

        injected = {}

        def fake_inject(request):
            injected["in"] = Path(request.erwin_in)
            injected["out"] = Path(request.erwin_out)
            Path(request.erwin_out).parent.mkdir(parents=True, exist_ok=True)
            Path(request.erwin_out).write_bytes(b"erwin-binary-with-udps")
            Path(request.results_path).parent.mkdir(parents=True, exist_ok=True)
            Path(request.results_path).write_text(json.dumps({"applied": 1}), encoding="utf-8")
            return True

        with patch.object(erwin_converter, "com_available", return_value=True), \
             patch.object(erwin_converter, "run_convert", side_effect=fake_convert), \
             patch.object(udp_bridge, "com_available", return_value=True), \
             patch.object(udp_bridge, "inject", side_effect=fake_inject):
            run_udp.process_model(self.model, "synthetic", "LDM", self.dirs)

        # .ERWIN V1 was converted from the Step 1 output, into the hand-off folder
        self.assertEqual(xml_v2, converted["src"])
        self.assertEqual(self.stages.erwin_v1("synthetic"), converted["dst"])
        self.assertTrue(self.stages.erwin_v1("synthetic").is_file())

        # .ERWIN V2 was injected from it, and the input was not the output
        self.assertEqual(self.stages.erwin_v1("synthetic"), injected["in"])
        self.assertEqual(self.stages.erwin_v2("synthetic"), injected["out"])
        self.assertNotEqual(injected["in"], injected["out"])
        self.assertTrue(self.stages.erwin_v2("synthetic").is_file())

        self.assertEqual(stage_state.STATUS_VALIDATED, self._status(stage_state.STAGE_ERWIN_HANDOFF))
        self.assertEqual(stage_state.STATUS_READY, self._status(stage_state.STAGE_UDP))
        self.assertEqual([], concurrency.get_skipped_models())

    def test_a_handed_off_erwin_in_the_tier_subfolder_is_used(self):
        """
        ``mirror_models_to_udp_input`` puts the SAP sources in
        input_erwin_models/ldm/, so that is where an operator saves the .erwin.
        Looking only at the flat folder is what reported WAITING while the file
        the operator had produced was sitting on disk.
        """
        self.stages.xml_v1("synthetic").write_text(ERWIN_XML_RAW, encoding="utf-8")
        run_v1.process_model(self.model, "synthetic", "LDM", self.dirs)

        tiered = self.udp_input / "ldm" / "synthetic.erwin"
        tiered.parent.mkdir(parents=True, exist_ok=True)
        tiered.write_bytes(b"erwin-binary-stand-in")
        self.assertFalse(self.stages.erwin_v1("synthetic").exists(), "not in the flat folder")

        concurrency.clear_skipped_models()
        run_udp.process_model(self.model, "synthetic", "LDM", self.dirs)

        self.assertEqual(stage_state.STATUS_VALIDATED, self._status(stage_state.STAGE_ERWIN_HANDOFF))
        event = {e["stage"]: e for e in stage_state.history(self.dirs, "synthetic")}[
            stage_state.STAGE_ERWIN_HANDOFF]
        self.assertEqual(str(tiered), event["artifact"]["path"])

    # ── negative cases ────────────────────────────────────────────────────────

    def test_corrupt_xml_v1_is_rejected_not_scored(self):
        self.stages.xml_v1("synthetic").write_text("<EMX><Model><Entity", encoding="utf-8")
        self.assertIsNone(run_v1.process_model(self.model, "synthetic", "LDM", self.dirs))
        self.assertEqual(stage_state.STATUS_FAILED, self._status(stage_state.STAGE_V1_XML))
        self.assertTrue(any("invalid" in r for r in concurrency.get_skipped_models()))
        self.assertFalse(self.stages.xml_v2("synthetic").exists())

    def test_empty_erwin_handoff_is_rejected(self):
        self.stages.xml_v1("synthetic").write_text(ERWIN_XML_RAW, encoding="utf-8")
        run_v1.process_model(self.model, "synthetic", "LDM", self.dirs)
        erwin_v1 = self.stages.erwin_v1("synthetic")
        erwin_v1.parent.mkdir(parents=True, exist_ok=True)
        erwin_v1.write_bytes(b"")
        run_udp.process_model(self.model, "synthetic", "LDM", self.dirs)
        self.assertEqual(stage_state.STATUS_FAILED, self._status(stage_state.STAGE_ERWIN_HANDOFF))
        self.assertIn("empty", stage_state.history(self.dirs, "synthetic")[-2]["message"]
                      + stage_state.history(self.dirs, "synthetic")[-1]["message"])
        self.assertFalse(self.stages.erwin_v2("synthetic").exists())

    def test_xml_v3_of_a_different_model_is_refused(self):
        self.stages.xml_v1("synthetic").write_text(ERWIN_XML_RAW, encoding="utf-8")
        run_v1.process_model(self.model, "synthetic", "LDM", self.dirs)
        xml_v3 = self.stages.xml_v3("synthetic")
        xml_v3.parent.mkdir(parents=True, exist_ok=True)
        xml_v3.write_text(OTHER_MODEL_XML.format(m1="{1}", e1="{2}", a1="{3}"), encoding="utf-8")
        self.assertIsNone(run_v3.process_model(self.model, "synthetic", "LDM", self.dirs))
        self.assertEqual(stage_state.STATUS_FAILED, self._status(stage_state.STAGE_V3_XML))
        self.assertTrue(any("different model" in r for r in concurrency.get_skipped_models()))
        self.assertEqual([], list(self.dirs["final"].iterdir()))

    def test_corrupt_xml_v3_is_refused(self):
        self.stages.xml_v1("synthetic").write_text(ERWIN_XML_RAW, encoding="utf-8")
        run_v1.process_model(self.model, "synthetic", "LDM", self.dirs)
        xml_v3 = self.stages.xml_v3("synthetic")
        xml_v3.parent.mkdir(parents=True, exist_ok=True)
        xml_v3.write_text("not xml at all", encoding="utf-8")
        self.assertIsNone(run_v3.process_model(self.model, "synthetic", "LDM", self.dirs))
        self.assertEqual(stage_state.STATUS_FAILED, self._status(stage_state.STAGE_V3_XML))

    def test_rerun_of_run_v1_keeps_the_step1_output_the_operator_already_loaded(self):
        self.stages.xml_v1("synthetic").write_text(ERWIN_XML_RAW, encoding="utf-8")
        run_v1.process_model(self.model, "synthetic", "LDM", self.dirs)
        xml_v2 = self.stages.xml_v2("synthetic")
        before = (_sha(xml_v2), xml_v2.stat().st_mtime_ns)
        run_v1.process_model(self.model, "synthetic", "LDM", self.dirs)
        self.assertEqual(before, (_sha(xml_v2), xml_v2.stat().st_mtime_ns))

    def test_wrong_tier_folder_for_xml_v3_is_not_silently_accepted(self):
        """An LDM's export dropped into final_xml_models/cdm is found only via the legacy sweep and named."""
        self.stages.xml_v1("synthetic").write_text(ERWIN_XML_RAW, encoding="utf-8")
        run_v1.process_model(self.model, "synthetic", "LDM", self.dirs)
        wrong = self.dirs["final_xml"] / "cdm" / "synthetic.xml"
        wrong.parent.mkdir(parents=True, exist_ok=True)
        wrong.write_text(ERWIN_XML, encoding="utf-8")
        with patch.object(settings, "LEGACY_STAGE_FALLBACK", False, create=True):
            self.assertIsNone(run_v3.process_model(self.model, "synthetic", "LDM", self.dirs))
            self.assertEqual(stage_state.STATUS_WAITING, self._status(stage_state.STAGE_V3_XML))


class PdmManualHandoffTests(ManualHandoffFlowTests):
    """The PDM route through the same three scripts (isolated PDM validator underneath)."""

    def setUp(self):
        super().setUp()
        (self.root / "sappdmodels" / "pdm" / "fleet.pdm").write_text(PD_PDM_FULL, encoding="utf-8")
        self.pdm = self.root / "sappdmodels" / "pdm" / "fleet.pdm"
        self.pstages = StagePaths(self.dirs, "PDM")
        self.pstages.xml_v1("fleet").write_text(strip_definitions(ERWIN_PDM_FULL), encoding="utf-8")

    def _pstatus(self, stage):
        return stage_state.stage_status(self.dirs, "fleet", stage)

    def test_stage_scripts_in_sequence_with_manual_handoffs(self):
        record = run_v1.process_model(self.pdm, "fleet", "PDM", self.dirs)
        self.assertIsNotNone(record)
        self.assertEqual(stage_state.STATUS_READY, self._pstatus(stage_state.STAGE_V1_FIDELITY))
        self.assertEqual(stage_state.STATUS_READY, self._pstatus(stage_state.STAGE_XML_V2))
        self.assertEqual(stage_state.STATUS_WAITING, self._pstatus(stage_state.STAGE_ERWIN_HANDOFF))
        self.assertTrue(self.pstages.xml_v2("fleet").is_file())
        self.assertEqual([], list(self.root.rglob("*.erwin")))

        # run_v3 without the XML V3 export: hard stop, nothing promoted, nothing moved
        self.assertIsNone(run_v3.process_model(self.pdm, "fleet", "PDM", self.dirs))
        self.assertEqual(stage_state.STATUS_WAITING, self._pstatus(stage_state.STAGE_V3_XML))
        self.assertEqual([], list(self.dirs["final"].iterdir()))
        self.assertTrue(self.pstages.xml_v2("fleet").is_file(), "V2 artefact left in place")
        self.assertTrue(any("final_xml_models" in a for a in stage_state.pending_actions(self.dirs, "fleet")))

        # operator: export the enriched model as XML into final_xml_models/pdm
        xml_v3 = self.pstages.xml_v3("fleet")
        xml_v3.parent.mkdir(parents=True, exist_ok=True)
        xml_v3.write_text(ERWIN_PDM_FULL, encoding="utf-8")
        self.assertEqual("pdm", xml_v3.parent.name)
        record = run_v3.process_model(self.pdm, "fleet", "PDM", self.dirs)
        self.assertIsNotNone(record)
        self.assertEqual(stage_state.STATUS_VALIDATED, self._pstatus(stage_state.STAGE_V3_XML))
        self.assertEqual("3_final", record.destination)
        self.assertEqual({"V1", "V2", "V3"}, set(record.result.stage_scores))
        self.assertTrue((self.dirs["final"] / "fleet.xml").is_file())
        ledger = self.dirs["summary"] / "audit" / "pipeline_ledger.jsonl"
        entry = json.loads(ledger.read_text(encoding="utf-8").splitlines()[-1])
        self.assertEqual(("fleet", "PDM"), (entry["model"], entry["model_type"]))
        self.assertIn("xml_v3", entry["artefact_hashes"])

    def test_pdm_xml_v3_of_another_model_is_refused(self):
        run_v1.process_model(self.pdm, "fleet", "PDM", self.dirs)
        xml_v3 = self.pstages.xml_v3("fleet")
        xml_v3.parent.mkdir(parents=True, exist_ok=True)
        xml_v3.write_text(ERWIN_XML, encoding="utf-8")      # an LDM export: no table in common
        self.assertIsNone(run_v3.process_model(self.pdm, "fleet", "PDM", self.dirs))
        self.assertEqual(stage_state.STATUS_FAILED, self._pstatus(stage_state.STAGE_V3_XML))
        self.assertEqual([], list(self.dirs["final"].iterdir()))

    # the LDM negatives are inherited and still run against the LDM model


class ComplexityTests(unittest.TestCase):
    def test_thresholds(self):
        self.assertEqual(COMPLEXITY_UNKNOWN, classify_complexity({"objects": 0, "members": 0}))
        self.assertEqual(COMPLEXITY_SIMPLE, classify_complexity({"objects": 25, "members": 200}))
        self.assertEqual(COMPLEXITY_MEDIUM, classify_complexity({"objects": 26, "members": 200}))
        self.assertEqual(COMPLEXITY_MEDIUM, classify_complexity({"objects": 100, "members": 1000}))
        self.assertEqual(COMPLEXITY_COMPLEX, classify_complexity({"objects": 101, "members": 10}))
        self.assertEqual(COMPLEXITY_COMPLEX, classify_complexity({"objects": 10, "members": 1001}))

    def test_reads_cdm_ldm_and_pdm_vocabularies(self):
        from types import SimpleNamespace
        ldm = SimpleNamespace(entities_pd=3, attributes_pd=30, relationships_pd=2)
        pdm = SimpleNamespace(tables_pd=120, columns_pd=900, fk_pd=50)
        self.assertEqual(COMPLEXITY_SIMPLE, classify_complexity(ldm))
        self.assertEqual(COMPLEXITY_COMPLEX, classify_complexity(pdm))
        self.assertEqual(COMPLEXITY_UNKNOWN, classify_complexity(None))

    def test_is_a_label_only_and_never_changes_the_score(self):
        """Complexity is triage metadata; the same result scores the same whatever the label."""
        from app.validation import fidelity_stages
        from tests.test_run_v3_stage_history import _fake_result
        small, large = _fake_result(), _fake_result()
        small.entities_pd, small.attributes_pd = 2, 10
        large.entities_pd, large.attributes_pd = 500, 5000
        s1 = fidelity_stages.apply(small, "V1", model_type="LDM")
        s2 = fidelity_stages.apply(large, "V1", model_type="LDM")
        self.assertEqual(s1.overall, s2.overall)
        self.assertNotEqual(classify_complexity(small), classify_complexity(large))
