import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.validation.ldm_reconcile.comparator import (
    ValidationResult as LDMValidationResult,
)
from app.validation.ldm_reconcile.comparator import (
    _compare_definition as ldm_compare_definition,
)


class DefinitionMatchingTests(unittest.TestCase):
    def test_definition_exact(self):
        result = LDMValidationResult(pd_file="m.ldm", erwin_file="m.xml")
        t1 = "Primary customer record table for retail and wholesale banking."
        t2 = "Primary customer record table for retail and wholesale banking."

        ldm_compare_definition(result, "ENTITY", "CUSTOMER", "", t1, t2)
        findings = [f for f in result.findings if f.category == "DEFINITION_EXACT"]
        self.assertEqual(1, len(findings))
        self.assertEqual("VERIFIED", findings[0].severity)

    def test_definition_high_similarity(self):
        result = LDMValidationResult(pd_file="m.ldm", erwin_file="m.xml")
        t1 = "Customer account balance and ledger transactions."
        t2 = "Customer accounts balance and ledger transactions."

        ldm_compare_definition(result, "ENTITY", "ACCOUNT", "", t1, t2)
        findings = [f for f in result.findings if f.category == "DEFINITION_HIGH_SIMILARITY"]
        self.assertEqual(1, len(findings))
        self.assertEqual("VERIFIED", findings[0].severity)
        self.assertIn("%", findings[0].message)

    def test_definition_partial(self):
        result = LDMValidationResult(pd_file="m.ldm", erwin_file="m.xml")
        t1 = "Customer account balance and ledger transactions in core banking."
        t2 = "Customer accounts balance and summary reports."

        ldm_compare_definition(result, "ENTITY", "ACCOUNT", "", t1, t2)
        findings = [f for f in result.findings if f.category == "DEFINITION_PARTIAL"]
        self.assertEqual(1, len(findings))
        self.assertEqual("INFO", findings[0].severity)

    def test_definition_mismatch(self):
        result = LDMValidationResult(pd_file="m.ldm", erwin_file="m.xml")
        t1 = "Customer account balance details."
        t2 = "Completely unrelated inventory item records."

        ldm_compare_definition(result, "ENTITY", "ACCOUNT", "", t1, t2)
        findings = [f for f in result.findings if f.category in ("DEFINITION_MISMATCH", "DEFINITION")]
        self.assertEqual(1, len(findings))
        self.assertEqual("WARNING", findings[0].severity)


if __name__ == "__main__":
    unittest.main()
