import os
import sys
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.validation.ldm_reconcile.comparator import (
    ValidationResult,
    _compare_attribute_pair,
    compare,
)
from app.validation.ldm_reconcile.erwin_ldm_parser import parse_erwin_ldm
from app.validation.ldm_reconcile.ldm_model import Attribute
from app.validation.ldm_reconcile.pd_ldm_parser import parse_ldm


class AttributeMultiplicityTests(unittest.TestCase):
    def _compare(self, pd_value: str, erwin_value: str) -> ValidationResult:
        result = ValidationResult(pd_file="source.ldm", erwin_file="target.xml")
        pd_attribute = Attribute(name="Orders", code="ORDERS", multiplicity=pd_value)
        erwin_attribute = Attribute(name="Orders", code="ORDERS", multiplicity=erwin_value)

        _compare_attribute_pair(
            result, "CUSTOMER", pd_attribute, erwin_attribute, "code"
        )
        return result

    def test_equivalent_multiplicity_spellings_do_not_emit_finding(self):
        result = self._compare("0..1", "0,1")

        self.assertFalse(
            any(finding.category in ("MULTIPLICITY_MISMATCH", "ATTRIBUTE_MULTIPLICITY")
                for finding in result.findings)
        )
        verified = [f for f in result.findings if f.category == "MULTIPLICITY_VERIFIED"]
        self.assertEqual(1, len(verified))
        self.assertEqual("VERIFIED", verified[0].severity)

    def test_different_multiplicity_emits_info_finding(self):
        result = self._compare("0..1", "1..1")

        findings = [finding for finding in result.findings
                    if finding.category in ("MULTIPLICITY_MISMATCH", "ATTRIBUTE_MULTIPLICITY")]
        self.assertEqual(1, len(findings))
        self.assertEqual("INFO", findings[0].severity)
        self.assertEqual("0,1", findings[0].pd_value)
        self.assertEqual("1,1", findings[0].erwin_value)

    def test_missing_target_multiplicity_is_reported(self):
        result = self._compare("1..*", "")

        findings = [finding for finding in result.findings
                    if finding.category in ("MULTIPLICITY_MISMATCH", "ATTRIBUTE_MULTIPLICITY")]
        self.assertEqual(1, len(findings))
        self.assertEqual("1,n", findings[0].pd_value)
        self.assertEqual("(none)", findings[0].erwin_value)

    def test_disabled_check_preserves_existing_behavior(self):
        with patch(
            "app.validation.ldm_reconcile.comparator.config.CHECK_ATTRIBUTE_MULTIPLICITY",
            False,
        ):
            result = self._compare("0..1", "1..1")

        self.assertFalse(
            any(finding.category in ("MULTIPLICITY_MISMATCH", "ATTRIBUTE_MULTIPLICITY", "MULTIPLICITY_VERIFIED")
                for finding in result.findings)
        )

    @patch("app.validation.ldm_reconcile.comparator.udp_fidelity.apply")
    def test_parsers_feed_multiplicity_into_reconciliation(self, _apply_udp):
        pd_xml = """<?xml version="1.0"?>
<o:RootObject xmlns:o="object" xmlns:c="collection" xmlns:a="attribute">
    <o:Model Id="m1">
        <a:Name>Sales</a:Name><a:Code>SALES</a:Code>
        <c:Entities><o:Entity Id="e1">
            <a:Name>Customer</a:Name><a:Code>CUSTOMER</a:Code>
            <c:Attributes><o:EntityAttribute Id="a1">
                <a:Name>Orders</a:Name><a:Code>ORDERS</a:Code>
                <a:Multiplicity>0..1</a:Multiplicity>
            </o:EntityAttribute></c:Attributes>
        </o:Entity></c:Entities>
    </o:Model>
</o:RootObject>"""
        erwin_xml = """<?xml version="1.0"?>
<Model><ModelProps><Name>Sales</Name><ModelType>Logical</ModelType></ModelProps>
    <Entity id="e1" Name="Customer" Physical_Name="CUSTOMER">
        <Attribute id="a1" Name="Orders" Physical_Name="ORDERS" Multiplicity="1..1" />
    </Entity>
</Model>"""

        with TemporaryDirectory() as directory:
            pd_path = Path(directory) / "Sales.ldm"
            erwin_path = Path(directory) / "Sales.xml"
            pd_path.write_text(pd_xml, encoding="utf-8")
            erwin_path.write_text(erwin_xml, encoding="utf-8")

            result = compare(parse_ldm(str(pd_path)), parse_erwin_ldm(str(erwin_path)))

        findings = [finding for finding in result.findings
                    if finding.category in ("MULTIPLICITY_MISMATCH", "ATTRIBUTE_MULTIPLICITY")]
        self.assertEqual(1, len(findings))
        self.assertEqual("0,1", findings[0].pd_value)
        self.assertEqual("1,1", findings[0].erwin_value)


if __name__ == "__main__":
    unittest.main()
