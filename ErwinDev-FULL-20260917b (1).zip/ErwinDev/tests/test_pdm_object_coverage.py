import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.validation.pdm_reconcile.pdm_erwin_validator.comparator import (
    ValidationResult,
    _compare_procedures_and_functions,
    _compare_views,
)
from app.validation.pdm_reconcile.pdm_erwin_validator.data_type_mapper import compare_sql


class PDMObjectCoverageAndSQLTests(unittest.TestCase):
    def test_sql_semantic_normalization(self):
        sql_pd = """
            -- PowerDesigner view definition
            SELECT [c].[CustomerID], [c].[CustomerName]
            FROM [dbo].[Customer] AS [c]
            WHERE [c].[Status] = 'ACTIVE'
        """
        sql_erwin = """
            /* ERwin exported view definition */
            select c.customerid, c.customername
            from dbo.customer as c
            where c.status = 'ACTIVE'
        """
        status, sim, msg = compare_sql(sql_pd, sql_erwin)
        self.assertEqual("SQL_NORMALIZED_MATCH", status)
        self.assertEqual(1.0, sim)

    def test_views_comparison(self):
        pd_model = {
            "source_file": "pdm.pdm", "model_name": "PDM",
            "tables": {}, "references": [],
            "views": {
                "V_ACTIVE_CUSTOMERS": {
                    "name": "V_ACTIVE_CUSTOMERS", "code": "V_ACTIVE_CUSTOMERS",
                    "sql": "SELECT id, name FROM customer WHERE active = 1",
                }
            }
        }
        erwin_model = {
            "source_file": "pdm.xml", "model_name": "PDM",
            "tables": {}, "references": [],
            "views": {
                "V_ACTIVE_CUSTOMERS": {
                    "name": "V_ACTIVE_CUSTOMERS", "code": "V_ACTIVE_CUSTOMERS",
                    "sql": "SELECT id, name FROM customer WHERE active = 1",
                }
            }
        }
        result = ValidationResult(pd_file="pdm.pdm", erwin_file="pdm.xml")
        _compare_views(result, pd_model, erwin_model)
        verified = [f for f in result.findings if f.category == "VIEW" and f.severity == "VERIFIED"]
        self.assertEqual(1, len(verified))

    def test_procedure_body_mismatch(self):
        pd_model = {
            "source_file": "pdm.pdm", "model_name": "PDM",
            "tables": {}, "references": [],
            "procedures": {
                "SP_CALC_TOTAL": {
                    "name": "SP_CALC_TOTAL", "code": "SP_CALC_TOTAL",
                    "body": "BEGIN UPDATE orders SET total = qty * price; END;",
                }
            }
        }
        erwin_model = {
            "source_file": "pdm.xml", "model_name": "PDM",
            "tables": {}, "references": [],
            "procedures": {
                "SP_CALC_TOTAL": {
                    "name": "SP_CALC_TOTAL", "code": "SP_CALC_TOTAL",
                    "body": "BEGIN DELETE FROM orders WHERE status = 'CANCEL'; END;",
                }
            }
        }
        result = ValidationResult(pd_file="pdm.pdm", erwin_file="pdm.xml")
        _compare_procedures_and_functions(result, pd_model, erwin_model)
        mismatches = [f for f in result.findings if f.category == "PROCEDURE" and f.severity == "WARNING"]
        self.assertEqual(1, len(mismatches))


if __name__ == "__main__":
    unittest.main()
