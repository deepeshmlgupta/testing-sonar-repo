import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.validation.pdm_reconcile.pdm_erwin_validator.advanced_datatype_mapper import (
    classify,
    datatype_fidelity_pct,
)


class AdvancedDatatypeMapperTests(unittest.TestCase):
    def test_oracle_xmltype_is_exact_match(self):
        result = classify("XMLTYPE", "XMLTYPE")
        self.assertEqual("EXACT", result.category)
        self.assertEqual(1.0, result.fidelity_weight)

    def test_oracle_json_to_clob_is_compatible(self):
        result = classify("JSON", "CLOB")
        self.assertEqual("COMPATIBLE", result.category)

    def test_postgres_jsonb_is_compatible(self):
        result = classify("JSONB", "JSON")
        self.assertEqual("COMPATIBLE", result.category)

    def test_postgres_array_is_convertible(self):
        result = classify("ARRAY", "TEXT")
        self.assertEqual("CONVERTIBLE", result.category)

    def test_unrecognised_type_is_unsupported(self):
        result = classify("VARCHAR(100)", "VARCHAR2(100)")
        self.assertEqual("UNSUPPORTED", result.category)
        self.assertEqual(0.0, result.fidelity_weight)

    def test_recognised_pd_type_with_unmapped_target_is_unsupported(self):
        result = classify("XMLTYPE", "SOME_UNKNOWN_TYPE")
        self.assertEqual("UNSUPPORTED", result.category)

    def test_length_precision_stripped_before_lookup(self):
        result = classify("HIERARCHYID(10)", "HIERARCHYID")
        self.assertEqual("COMPATIBLE", result.category)

    def test_fidelity_pct_empty_list_is_none(self):
        self.assertIsNone(datatype_fidelity_pct([]))

    def test_fidelity_pct_averages_weights(self):
        results = [classify("XMLTYPE", "XMLTYPE"), classify("JSON", "CLOB")]
        pct = datatype_fidelity_pct(results)
        self.assertAlmostEqual((1.0 + 0.75) / 2 * 100, pct)


if __name__ == "__main__":
    unittest.main()
