import os
import sys
import unittest
from dataclasses import dataclass, field
from typing import Optional

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.validation import fidelity_stages


@dataclass
class _FakeResult:
    pd_file: str = "a.ldm"
    erwin_file: str = "a.xml"
    status: str = "PASS"
    fidelity_score: float = 90.0
    structural_fidelity_score: float = 90.0
    documentation_rows: list = field(default_factory=list)
    udp_total: int = 0
    hierarchy_fidelity_pct: Optional[float] = None
    relationship_semantic_fidelity_pct: Optional[float] = None
    datatype_fidelity_pct: Optional[float] = None
    stage_scores: dict = field(default_factory=dict)


class _FakeConfig:
    FIDELITY_STAGE_WEIGHTS = {"structural": 1.0}
    NO_UDP_FIDELITY_CAP = None


class FidelityStagesBlendingTests(unittest.TestCase):
    def test_new_components_are_none_when_not_measured(self):
        result = _FakeResult()
        stage_score = fidelity_stages.score(result, "V3", config=_FakeConfig())
        self.assertIsNone(stage_score.component(fidelity_stages.COMPONENT_HIERARCHY))
        self.assertIsNone(stage_score.component(fidelity_stages.COMPONENT_RELATIONSHIP_SEMANTIC))
        self.assertIsNone(stage_score.component(fidelity_stages.COMPONENT_DATATYPE))

    def test_inert_by_default_even_when_measured(self):
        """A measured hierarchy_fidelity_pct with weight 0.0 must not move the score."""
        result = _FakeResult(structural_fidelity_score=90.0, hierarchy_fidelity_pct=10.0)
        config = _FakeConfig()
        config.FIDELITY_STAGE_WEIGHTS = {"structural": 1.0, "hierarchy": 0.0}
        stage_score = fidelity_stages.score(result, "V3", config=config)
        self.assertEqual(90.0, stage_score.overall)

    def test_blends_when_weight_configured(self):
        result = _FakeResult(structural_fidelity_score=100.0, hierarchy_fidelity_pct=50.0)
        config = _FakeConfig()
        config.FIDELITY_STAGE_WEIGHTS = {"structural": 0.5, "hierarchy": 0.5}
        stage_score = fidelity_stages.score(result, "V3", config=config)
        self.assertEqual(75.0, stage_score.overall)

    def test_helper_functions_read_result_attributes(self):
        result = _FakeResult(hierarchy_fidelity_pct=42.0,
                             relationship_semantic_fidelity_pct=88.0,
                             datatype_fidelity_pct=95.5)
        self.assertEqual(42.0, fidelity_stages.hierarchy_fidelity(result))
        self.assertEqual(88.0, fidelity_stages.relationship_semantic_fidelity(result))
        self.assertEqual(95.5, fidelity_stages.datatype_fidelity(result))


if __name__ == "__main__":
    unittest.main()
