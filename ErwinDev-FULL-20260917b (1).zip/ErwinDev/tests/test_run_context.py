"""
Multi-user run context: session-scoped roots, shared-input fallbacks, CLI
overrides, and two isolated runs on one checkout that never touch each other.
"""

import json
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.config import settings  # noqa: E402
from app.orchestration import concurrency, directory_setup, run_context  # noqa: E402
from app.orchestration.batch_runner import run_batch  # noqa: E402
from app.orchestration.stage_paths import StagePaths  # noqa: E402
from app.reporting import report_layout  # noqa: E402
from app.utils import session_manager  # noqa: E402
from tests.test_vessel_reconciliation_fixes import ERWIN_XML, PD_LDM  # noqa: E402

ERWIN_XML_RAW = "\n".join(line for line in ERWIN_XML.splitlines() if "Note_List" not in line)


@pytest.fixture
def checkout(tmp_path, monkeypatch):
    """A throw-away checkout: inputs in place, every settings root under tmp."""
    root = tmp_path
    (root / "sappdmodels" / "ldm").mkdir(parents=True)
    (root / "sappdmodels" / "cdm").mkdir(parents=True)
    (root / "sappdmodels" / "pdm").mkdir(parents=True)
    (root / "sappdmodels" / "ldm" / "synthetic.ldm").write_text(PD_LDM, encoding="utf-8")
    for name, value in {
        "BASE_DIR": root, "SAMPLES_DIR": str(root / "sappdmodels"),
        "OUTPUT_DIR": str(root / "erwinmodels"), "FINAL_XML_DIR": str(root / "final_xml_models"),
        "SESSIONS_DIR": str(root / "sessions"), "MAX_WORKERS": 1,
        "ERWIN_CONVERT_ENABLED": False, "MANUAL_EXPORT_WAIT_SECONDS": 0,
        "ENABLE_SESSION_ISOLATION": False, "FORCE_USERNAME": "", "FORCE_SESSION_ID": "",
        "MIRROR_MODELS_TO_UDP_INPUT": False,
    }.items():
        monkeypatch.setattr(settings, name, value, raising=False)
    monkeypatch.setattr(report_layout, "REPORTING_ROOT", root / "app" / "reporting")
    monkeypatch.setattr(directory_setup, "UDP_INPUT_MODELS_DIR", root / "udp_in")
    concurrency.clear_skipped_models()
    return root


def test_safe_component_makes_a_single_path_segment():
    assert session_manager._safe_component("CORP\\alice.smith") == "CORP_alice.smith"
    assert session_manager._safe_component("  ../evil ") == "evil"
    assert session_manager._safe_component("") == "unknown"


def test_forced_identity_is_honoured(checkout, monkeypatch):
    monkeypatch.setattr(settings, "FORCE_USERNAME", "alice")
    monkeypatch.setattr(settings, "FORCE_SESSION_ID", "job42")
    run = run_context.build_run_context(isolate=True)
    assert run.isolated
    assert run.roots["session"] == checkout / "sessions" / "alice_job42"
    assert run.roots["reports_root"] == checkout / "sessions" / "alice_job42" / "reports"
    # Explicit arguments beat the settings.
    run2 = run_context.build_run_context(isolate=True, user="bob", session_id="s9")
    assert run2.roots["session"] == checkout / "sessions" / "bob_s9"


def test_shared_layout_when_isolation_is_off(checkout):
    run = run_context.build_run_context(isolate=False)
    assert not run.isolated
    dirs = directory_setup.setup_directories(run)
    assert dirs["summary"] == checkout / "batch_summary"
    assert dirs["reports_root"] == checkout / "app" / "reporting"
    assert "shared_stages" not in dirs
    assert report_layout.tier_dir("LDM") == checkout / "app" / "reporting" / "ldm_reports"


def test_isolated_layout_scopes_every_output_and_keeps_shared_inputs(checkout):
    run = run_context.build_run_context(isolate=True, user="alice", session_id="s1")
    dirs = directory_setup.setup_directories(run)
    session = checkout / "sessions" / "alice_s1"
    assert dirs["summary"] == session / "batch_summary"
    assert dirs["scratch"] == session / "data" / "interim_reports"
    assert dirs["udp_work"] == session / "data" / "udp"
    assert dirs["udp_reports"] == session / "udp_reports"
    assert dirs["stages"]["xml_v2"] == session / "erwinmodels" / "2_preprocessed"
    assert report_layout.model_dir("LDM", "synthetic") == session / "reports" / "ldm_reports" / "synthetic"
    # Inputs stay shared and are still found from the shared stage folder.
    assert dirs["ldm"] == checkout / "sappdmodels" / "ldm"
    shared_xml = checkout / "erwinmodels" / "1_initial" / "synthetic.xml"
    shared_xml.parent.mkdir(parents=True, exist_ok=True)
    shared_xml.write_text("<x/>", encoding="utf-8")
    stages = StagePaths(dirs)
    assert stages.find_xml_v1("synthetic") == shared_xml
    assert stages.xml_v2("synthetic").parent == session / "erwinmodels" / "2_preprocessed"
    assert "other location" in stages.describe("xml_v1", "synthetic")


def test_two_isolated_runs_on_one_checkout_do_not_share_any_output(checkout):
    shared = checkout / "erwinmodels"
    (shared / "1_initial").mkdir(parents=True)
    (shared / "1_initial" / "synthetic.xml").write_text(ERWIN_XML_RAW, encoding="utf-8")

    outputs = {}
    for user in ("alice", "bob"):
        run = run_context.build_run_context(isolate=True, user=user, session_id="same")
        dirs = directory_setup.setup_directories(run)
        # The XML V3 "erwin export" is an input each session has to see; drop
        # it where that session expects it (the shared folder is searched only
        # for V1 / .erwin inputs — V3 is what the run itself asks erwin for).
        StagePaths(dirs).xml_v3("synthetic").write_text(ERWIN_XML, encoding="utf-8")
        models = directory_setup.find_models(dirs)
        rows = run_batch(models, dirs, release=True, max_workers=1, session_context=run.session_context)
        assert len(rows) == 1
        session = run.roots["session"]
        outputs[user] = {
            "reports": sorted(p.relative_to(session).as_posix()
                              for p in (session / "reports").rglob("*.xlsx")),
            "ledger": (session / "batch_summary" / "audit" / "pipeline_ledger.jsonl"),
        }
        assert outputs[user]["reports"], f"{user} produced no reports"
        assert outputs[user]["ledger"].is_file()
        assert not (session / "batch_summary" / "audit" / f"{user}_same").exists(), "ledger nested twice"

    assert (checkout / "sessions" / "alice_same").is_dir() and (checkout / "sessions" / "bob_same").is_dir()
    # Nothing landed in the shared reporting or summary roots.
    assert not (checkout / "app" / "reporting" / "ldm_reports" / "synthetic").exists()
    assert not (checkout / "batch_summary" / "audit" / "pipeline_ledger.jsonl").exists()
    for user in ("alice", "bob"):
        entry = json.loads(outputs[user]["ledger"].read_text(encoding="utf-8").splitlines()[-1])
        assert entry["model"] == "synthetic"


def test_cli_overrides_land_in_settings(checkout, monkeypatch):
    args = run_context.build_parser("t", "t").parse_args(
        ["--workers", "3", "--isolate", "--user", "carol", "--session-id", "j7",
         "--stall-timeout", "12", "--abort-on-stall", "--no-mirror", "--max-models", "5"])
    run_context.apply_overrides(args)
    assert settings.MAX_WORKERS == 3
    assert settings.ENABLE_SESSION_ISOLATION is True
    assert settings.FORCE_USERNAME == "carol" and settings.FORCE_SESSION_ID == "j7"
    assert settings.BATCH_STALL_TIMEOUT_SECONDS == 12
    assert settings.BATCH_ABORT_ON_STALL is True
    assert settings.MIRROR_MODELS_TO_UDP_INPUT is False
    assert settings.MAX_MODELS_PER_RUN == 5

    run = run_context.start_run("t", "t", ["--no-isolate"])
    assert not run.isolated and settings.ENABLE_SESSION_ISOLATION is False


def test_legacy_session_context_argument_still_works(checkout, monkeypatch):
    monkeypatch.setattr(settings, "ENABLE_SESSION_ISOLATION", True)
    ctx = session_manager.SessionContext(str(checkout / "sessions"), user="dan", session_id="old")
    dirs = directory_setup.setup_directories(ctx)
    assert dirs["summary"] == checkout / "sessions" / "dan_old" / "batch_summary"
    assert dirs["session_context"] is ctx
