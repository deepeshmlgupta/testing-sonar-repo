#!/usr/bin/env python3
"""
test_multiuser_functionality.py
===============================

Quick validation that multi-user session isolation works correctly.

Run with:
    python test_multiuser_functionality.py
"""

import sys
import tempfile
from pathlib import Path

# Add app root to path
app_root = Path(__file__).parent.parent
sys.path.insert(0, str(app_root))

from app.config import settings
from app.utils.session_manager import (
    SessionContext,
    append_jsonl_line_safely,
    file_lock,
    generate_session_id,
    get_current_user,
)


def test_user_detection():
    """Test 1: User detection works"""
    print("\n[TEST 1] User Detection")
    print("-" * 60)
    user = get_current_user()
    print(f"✓ Detected user: {user}")
    assert user and user != "unknown_user", "Failed to detect user"
    return user


def test_session_id_generation():
    """Test 2: Session ID generation is unique"""
    print("\n[TEST 2] Session ID Generation")
    print("-" * 60)
    sid1 = generate_session_id()
    sid2 = generate_session_id()
    print(f"✓ Generated session ID 1: {sid1}")
    print(f"✓ Generated session ID 2: {sid2}")
    assert sid1 != sid2, "Session IDs should be unique"
    # Check format: YYYYMMDD_HHMMSS_<uuid>
    # 8 + 1 + 6 + 1 + 8 = 24 characters
    assert len(sid1) == 24, f"Session ID format invalid: {sid1} (len={len(sid1)})"
    print("✓ Session IDs have correct format")
    return sid1


def test_session_context():
    """Test 3: SessionContext creates proper directory structure"""
    print("\n[TEST 3] SessionContext Directory Structure")
    print("-" * 60)

    with tempfile.TemporaryDirectory() as tmpdir:
        ctx = SessionContext(tmpdir, auto_create=True)
        print(f"✓ Session context created: {ctx.session_suffix}")
        print(f"✓ Session output dir: {ctx.session_output_dir}")

        # Verify directory was created
        assert ctx.session_output_dir.exists(), "Session output directory not created"
        print("✓ Session output directory exists")

        # Test get_scoped_path
        reports_dir = ctx.get_scoped_path("reports")
        assert reports_dir.exists(), "Reports subdirectory not created"
        assert "reports" in str(reports_dir), "Reports path incorrect"
        print(f"✓ Scoped path works: {reports_dir}")

        # Test create_session_log_file
        log_file = ctx.create_session_log_file(tmpdir, "test.jsonl")
        assert log_file.parent.exists(), "Log directory not created"
        assert ctx.session_suffix in str(log_file), "Log file not in session directory"
        print(f"✓ Session log file path: {log_file}")

        return True


def test_file_locking():
    """Test 4: File locking works"""
    print("\n[TEST 4] File Locking")
    print("-" * 60)

    with tempfile.TemporaryDirectory() as tmpdir:
        test_file = Path(tmpdir) / "test_lock.txt"

        # Test basic file lock
        with file_lock(test_file):
            test_file.write_text("test content")
            print(f"✓ File lock acquired and content written: {test_file}")

        # Verify content
        content = test_file.read_text()
        assert content == "test content", "File content mismatch"
        print("✓ File content preserved after lock release")

        assert Path(str(test_file) + '.lock').exists(), "lock file should be created"
        print("✓ Lock mechanism working on this platform")

        return True


def test_atomic_json_append():
    """Test 5: Atomic JSONL append is safe"""
    print("\n[TEST 5] Atomic JSONL Append")
    print("-" * 60)

    with tempfile.TemporaryDirectory() as tmpdir:
        jsonl_file = Path(tmpdir) / "test.jsonl"

        # Append multiple entries
        for i in range(3):
            data = {"index": i, "message": f"Entry {i}"}
            append_jsonl_line_safely(jsonl_file, data)

        # Verify all entries were written
        lines = jsonl_file.read_text().strip().split('\n')
        assert len(lines) == 3, f"Expected 3 lines, got {len(lines)}"
        print("✓ Appended 3 JSONL lines safely")

        # Verify each line is valid JSON
        import json
        for i, line in enumerate(lines):
            data = json.loads(line)
            assert data["index"] == i, f"Entry {i} data mismatch"
        print("✓ All JSONL entries are valid and in order")

        return True


def test_session_config():
    """Test 6: Configuration settings work"""
    print("\n[TEST 6] Configuration Settings")
    print("-" * 60)

    # Check if session isolation setting exists
    isolation_enabled = getattr(settings, 'ENABLE_SESSION_ISOLATION', False)
    print(f"✓ ENABLE_SESSION_ISOLATION: {isolation_enabled}")

    # The run-context module is the one place that resolves session roots.
    from app.orchestration import run_context
    assert hasattr(settings, 'SESSIONS_DIR'), "SESSIONS_DIR not found"
    roots = run_context.session_roots(Path(settings.SESSIONS_DIR) / "user_session")
    assert roots["erwin_out"].name == "erwinmodels" and roots["summary"].name == "batch_summary"
    print("✓ Session roots resolve under SESSIONS_DIR")

    return True


def test_concurrent_writes(num_processes=2):
    """Test 7: Concurrent writes don't corrupt data"""
    print(f"\n[TEST 7] Concurrent Writes ({num_processes} processes)")
    print("-" * 60)

    with tempfile.TemporaryDirectory() as tmpdir:
        jsonl_file = Path(tmpdir) / "concurrent.jsonl"

        # Simulate concurrent writes using file locking
        for proc_id in range(num_processes):
            for entry in range(3):
                data = {"process": proc_id, "entry": entry, "value": f"p{proc_id}e{entry}"}
                append_jsonl_line_safely(jsonl_file, data)

        # Verify all entries were written
        lines = jsonl_file.read_text().strip().split('\n')
        assert len(lines) == num_processes * 3, f"Expected {num_processes*3} lines, got {len(lines)}"
        print(f"✓ All {len(lines)} entries written safely (no corruption)")

        # Verify no lines are truncated or malformed
        import json
        valid_count = 0
        for line in lines:
            try:
                json.loads(line)
                valid_count += 1
            except json.JSONDecodeError:
                print(f"✗ Invalid JSON line: {line[:50]}...")

        assert valid_count == len(lines), f"Only {valid_count}/{len(lines)} lines are valid JSON"
        print(f"✓ All {valid_count} entries are valid JSON")

        return True


def main():
    """Run all tests"""
    print("=" * 60)
    print("MULTI-USER FUNCTIONALITY TEST SUITE")
    print("=" * 60)

    tests = [
        ("User Detection", test_user_detection),
        ("Session ID Generation", test_session_id_generation),
        ("SessionContext", test_session_context),
        ("File Locking", test_file_locking),
        ("Atomic JSONL Append", test_atomic_json_append),
        ("Configuration", test_session_config),
        ("Concurrent Writes", test_concurrent_writes),
    ]

    passed = 0
    failed = 0

    for test_name, test_func in tests:
        try:
            test_func()
            passed += 1
            print(f"✓ {test_name} PASSED")
        except Exception as e:
            failed += 1
            print(f"✗ {test_name} FAILED: {e}")
            import traceback
            traceback.print_exc()

    print("\n" + "=" * 60)
    print(f"RESULTS: {passed} passed, {failed} failed")
    print("=" * 60)

    if failed == 0:
        print("\n✓ ALL TESTS PASSED - Multi-user functionality is working correctly!")
        return 0
    else:
        print(f"\n✗ {failed} test(s) failed - Please review the errors above")
        return 1


if __name__ == "__main__":
    sys.exit(main())
