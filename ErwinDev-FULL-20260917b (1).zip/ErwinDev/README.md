# README - ERwin Data Modeler Migration Platform

> **For setup:** See [REQUIREMENTS.md](REQUIREMENTS.md) for setup instructions!

---

## Overview

An automated SAP PowerDesigner → erwin Data Modeler migration validation platform with:
- ✅ Multi-model batch processing
- ✅ 3-stage validation (V1/V2/V3 fidelity reports)
- ✅ UDP (User-Defined Properties) tracking
- ✅ Multi-user safe execution (session isolation)
- ✅ Cross-platform support (Windows/Linux/Mac)
- ✅ Comprehensive audit trails

---

## Quick Start 

```bash
# Windows
setup.bat

# Linux/Mac
python setup.py
```

Done! Then place your SAP models in `sappdmodels/` and run:
```bash
python -m app.main          # from the checkout root
```

### Full Setup Guide
→ See [REQUIREMENTS.md](REQUIREMENTS.md) (detailed, step-by-step)  
→ Or [QUICK_START.md](QUICK_START.md) (quick reference)

---

## What you Need to Do

### Prerequisites (5 min setup)
1. Install Python 3.8+ (if not already installed)
2. Run setup script: `python setup.py` (automated)
3. Create input directories (auto-created or manual: `mkdir sappdmodels/{ldm,cdm,pdm}`)

### Then Use It — the operating flow (two manual erwin hand-offs, no automated bridge)
1. Place SAP PD models in `sappdmodels/ldm/`, `sappdmodels/cdm/`, `sappdmodels/pdm/`
2. **MANUAL** — import each model into erwin Data Modeler, Save As XML into `erwinmodels/1_initial/<model>.xml`
3. `python -m app.run_v1` → Fidelity **V1** report + `erwinmodels/2_preprocessed/<model>.xml` (PD Comments written as erwin Notes)
4. **AUTO on a host with erwin COM, otherwise MANUAL** — `.ERWIN V1` at `app/udp_tool/input_erwin_models/<model>.erwin`. `run_udp` converts it from `2_preprocessed/<model>.xml` through erwin's SCAPI; without erwin COM it prints exactly what to save and where, writes the same text beside the target as a `.HOWTO.txt`, and waits at a prompt (or records `WAITING_FOR_MANUAL_INPUT` in an unattended run)
5. `python -m app.run_udp` → UDPs injected → `erwinmodels/2_preprocessed/<model>.erwin` (needs Windows + erwin COM; mapping reports are produced everywhere)
6. **MANUAL** — open `2_preprocessed/<model>.erwin` (the **`.erwin`**, not the `.xml` beside it) in erwin, Save As XML into `final_xml_models/<ldm|cdm|pdm>/<model>.xml`
7. `python -m app.run_v3` → Fidelity **V2** + **V3** report (V1 / UDP / V3 / combined), gate: ≥ 90 % → `erwinmodels/3_final/<model>.xml` (+ `.erwin`); below → stays in `2_preprocessed`
8. Check `app/reporting/<tier>_reports/<model>/`, `batch_summary/summary_report/Pass_Fail_Summary.xlsx`, `batch_summary/audit/pipeline_ledger.jsonl` and the per-model hand-off ledger `batch_summary/stage_state/<model>.json` (status of every stage: `AUTOMATED / MANUAL / WAITING_FOR_MANUAL_INPUT / VALIDATED / FAILED / READY_FOR_NEXT_STAGE`, artefact hashes, next action).

`python -m app.main` runs the same steps in one process when all manual artefacts are already in place; a model whose manual artefact is missing is reported as `WAITING_FOR_MANUAL_INPUT` and skipped — never substituted. `erwinmodels/` has exactly three flat folders: `1_initial` (your exports, never modified), `2_preprocessed` (generated), `3_final` (gate PASS only).

**Reading `2_preprocessed/`.** The folder is named after the phase, not the file type, so it holds two different artefacts and the extension is what tells them apart: `<model>.xml` is **XML V2**, `run_v1`'s output and Step 2's input; `<model>.erwin` is **.ERWIN V2**, `run_udp`'s output. **.ERWIN V1** — the un-enriched binary Step 2 consumes — deliberately lives elsewhere, in `app/udp_tool/input_erwin_models/`, so that an input can never be confused with or overwritten by an output. Throughout the code and these docs, say "XML V2" or ".ERWIN V2"; "the preprocessed model" is ambiguous and is not used.

### Documentation They Should Know
- **[REQUIREMENTS.md](REQUIREMENTS.md)** - Complete setup + troubleshooting
- **[QUICK_START.md](QUICK_START.md)** - Quick reference checklist  
- **[SETUP.md](SETUP.md)** - Detailed setup with configuration options

---

## Installation

### Automated (Recommended)
```bash
# Windows
setup.bat

# Linux/Mac/WSL
python setup.py
```

Takes ~2-5 minutes. Creates all directories, installs dependencies, runs tests.

### Manual
```bash
# 1. Create environment
python -m venv venv
source venv/bin/activate        # Linux/Mac
venv\Scripts\activate           # Windows

# 2. Install dependencies
pip install -r requirements.txt

# 3. Create directories
mkdir -p sappdmodels/{ldm,cdm,pdm}
mkdir -p final_xml_models/{ldm,cdm,pdm}
mkdir -p batch_summary/audit
mkdir -p app/udp_tool/input_sap_models/{ldm,cdm,pdm}

# 4. Verify
python -m pytest tests/test_multiuser_functionality.py
```

---

## Usage

### Basic
```bash
python -m app.main          # from the checkout root
```

### With Custom Paths
```bash
export SAP_PD_MODELS_DIR="/path/to/models"
export ERWIN_MODELS_DIR="/path/to/output"
python -m app.main          # from the checkout root
```

### Multi-User / Concurrent Runs
```bash
python -m app.main --isolate                     # all outputs under sessions/<user>_<timestamp>_<id>/
python -m app.main --isolate --session-id nightly --workers 2
python -m app.main --help                        # every flag
```
See SETUP.md → "Session Isolation (Multi-User Mode)" for the folder layout,
the pre-flight collision checks and the stall watchdog.

### Debug Mode
```bash
export LOG_LEVEL=DEBUG
python -m app.main          # from the checkout root
```

---

## File Structure

```
ErwinDev/
├── README.md                              ← You are here
├── REQUIREMENTS.md                        ← For colleagues: READ FIRST
├── QUICK_START.md                         ← Quick reference
├── SETUP.md                               ← Detailed setup guide
├── setup.py                               ← Automated setup (Python)
├── setup.bat                              ← Automated setup (Windows)
│
├── app/
│   ├── main.py                            ← Entry point
│   ├── promote_model.py                   ← Promotion gate
│   ├── requirements-dev.txt               ← pytest-cov / ruff / bandit
│   │
│   ├── config/
│   │   ├── settings.py                    ← Configuration
│   │   └── validation_config.py
│   │
│   ├── utils/
│   │   └── session_manager.py             ← Multi-user support (NEW)
│   │
│   ├── validation/
│   │   ├── ldm_reconcile/                 ← LDM validation
│   │   ├── cdm_reconcile/                 ← CDM validation
│   │   ├── pdm_reconcile/                 ← PDM validation
│   │   ├── promotion_gate.py              ← Promotion logic
│   │   └── ...
│   │
│   ├── reporting/
│   │   ├── migration_audit.py             ← Audit trails
│   │   ├── v3_report.py                   ← V3 reporting
│   │   └── ...
│   │
│   ├── preprocessing/                     ← PDM preprocessing
│   ├── erwin/                             ← erwin integration
│   └── udp_tool/                          ← UDP tools
├── tests/                                 ← the whole test suite (pytest)
├── ruff.toml / .coveragerc / sonar-project.properties
│
├── sappdmodels/                           ← INPUT: SAP models (user provides)
│   ├── ldm/                               ← Place .ldm files here
│   ├── cdm/                               ← Place .cdm files here
│   └── pdm/                               ← Place .pdm files here
│
├── final_xml_models/                      ← INPUT: Validated erwin XML (optional)
│   ├── ldm/
│   ├── cdm/
│   └── pdm/
│
├── erwinmodels/                           ← OUTPUT: Generated by app
│   ├── <user>_<timestamp>_<uuid>/         ← Session-scoped (isolation enabled)
│   │   ├── 1_initial/
│   │   ├── 2_preprocessed/
│   │   └── 3_final/
│   └── ...
│
└── batch_summary/                         ← OUTPUT: Reports & audit logs
    ├── audit/
    │   ├── <session>/
    │   │   ├── ledger.jsonl
    │   │   ├── timings.jsonl
    │   │   └── migration_audit_report.xlsx
    │   └── ...
    └── summary_report/
        └── Pass_Fail_Summary.xlsx
```

---

## Key Features

### 1. Multi-Model Batch Processing
- Process 100+ models in one run
- Automatic result tracking
- Per-model result release (memory efficient)

### 2. Three-Stage Validation
- **V1**: Initial erwin XML vs SAP model
- **V2**: Preprocessed erwin XML vs SAP model
- **V3**: Final validated erwin XML vs SAP model

### 3. UDP Support
- Extract UDPs from SAP models
- Inject into erwin files
- Track migration fidelity

### 4. Multi-User Safe (NEW!)
- Session isolation by default
- File locking for concurrent writes
- Per-user audit trails
- Configurable isolation toggle

### 5. Promotion Gate
- Automatic fidelity-based routing
- Manual review workflow
- Configurable thresholds

### 6. Audit Trails
- WHO ran it (user detection)
- WHEN it ran (timestamps)
- WHAT happened (detailed logs)
- WHERE files went (output paths)

---

## Requirements

### System
- **Python 3.8+** (3.10+ recommended)
- Windows, Linux, or Mac
- ~200 MB disk space minimum

### Dependencies
```
defusedxml>=0.7.1      # Safe XML parsing
openpyxl>=3.1.5        # Excel generation
pytest>=8.0.0          # Testing framework
pywin32>=306           # Windows COM (Windows only)
```

Runtime: `pip install -r requirements.txt`. Dev/CI extras (pytest-cov, ruff, bandit): `pip install -r app/requirements-dev.txt`.

---

## Configuration

### Environment Variables (Optional)

Every setting below is read through `app/config/settings.py` and can be overridden from
the environment — nothing here requires editing code. **This table is the complete list;
the defaults are the ones the code actually resolves to.**

#### Input / output paths

| Variable | Default | What it does |
|---|---|---|
| `SAP_PD_MODELS_DIR` | `sappdmodels/` | Where the SAP PD `.cdm` / `.ldm` / `.pdm` inputs are read from |
| `ERWIN_MODELS_DIR` | `erwinmodels/` | Root of the pipeline's own stage folders |
| `FINAL_XML_DIR` | `final_xml_models/` | Where the manually validated XML V3 exports are read from |
| `FINAL_XML_MAP` | *(empty)* | Optional model → final-XML-filename map (JSON or 2-column CSV). Empty = resolve by name |
| `SESSIONS_DIR` | `sessions/` | Root for isolated per-run output folders |

#### Folder names (rename a folder without editing code)

| Variable | Default | What it does |
|---|---|---|
| `STAGE_INITIAL_DIR` | `1_initial` | Stage folder holding XML V1 |
| `STAGE_PREPROCESSED_DIR` | `2_preprocessed` | Stage folder holding XML V2 **and** .ERWIN V2 |
| `STAGE_FINAL_DIR` | `3_final` | Stage folder the promotion gate writes PASS output to |
| `ERWIN_MODELS_DIRNAME` | `erwinmodels` | Folder-name component used when composing relative paths |
| `SAP_PD_MODELS_DIRNAME` | `sappdmodels` | As above, for the SAP PD side |
| `MANUAL_REVIEW_REPORTS_DIRNAME` | `manual_review_reports` | Where sub-threshold models are routed |

> ⚠️ **These names are also written literally in `.gitignore` and `sonar-project.properties`,
> which cannot read Python settings.** If you override a stage folder name, update those two
> files by hand or the new folder will be committed to git and scanned by SonarQube.

#### Stage layout / flow alignment

Layout: `erwinmodels/1_initial | 2_preprocessed | 3_final` (flat),
`app/udp_tool/input_erwin_models`, `final_xml_models/<tier>`.

| Variable | Default | What it does |
|---|---|---|
| `LEGACY_STAGE_FALLBACK` | `true` | Also search the retired `1_xml_v1`…`6_erwin_v3` and `1_initial/xml` layouts for **inputs** |
| `FINAL_XML_FALLBACK_TO_PREPROCESSED` | `false` | Missing XML V3 is a hard stop. `true` = labelled dry run measured against V2 |
| `STAGE_XML_V1_DIR` … `STAGE_ERWIN_V3_DIR` | `1_xml_v1` … `6_erwin_v3` | Folder names of the retired six-folder layout, used only by the legacy input search |

#### erwin conversions and manual hand-off

| Variable | Default | What it does |
|---|---|---|
| `ERWIN_CONVERT_ENABLED` | `true` | Drive erwin's SCAPI to convert XML ↔ .erwin. On a host without erwin COM this is a no-op that falls through to the manual path |
| `ERWIN_CONVERT_TIMEOUT_SECONDS` | `900` | Per-conversion timeout |
| `ERWIN_MANUAL_PROMPT_ENABLED` | `true` | Prompt at the terminal when COM is unavailable and a person is present |
| `ERWIN_MANUAL_PROMPT_ATTEMPTS` | `10` | How many times to re-prompt |
| `SHORT_NAME_HANDOFF_FALLBACK` | `true` | Accept a hand-made artefact saved under the short model name instead of the full pipeline key (always logged as a warning) |
| `MANUAL_EXPORT_WAIT_SECONDS` | `0` | Seconds to poll for a manual erwin export. `0` = one-shot check, no waiting |
| `MANUAL_EXPORT_POLL_INTERVAL_SECONDS` | `5.0` | Poll cadence while waiting |

#### Promotion gate

| Variable | Default | What it does |
|---|---|---|
| `PROMOTION_FIDELITY_THRESHOLD` | `90.0` | Measured fidelity at or above which a model is promoted to `3_final` |

`PROMOTION_FIDELITY_BASIS` (`"overall"`) and `PROMOTION_BANDS` (`"two"`) are settings-file
values, not environment overrides — edit `app/config/settings.py` to change them.

#### Batch scale and triage

| Variable | Default | What it does |
|---|---|---|
| `MAX_WORKERS` | `4` | Parallel worker threads (`1` = sequential) |
| `MAX_MODELS_PER_RUN` | `0` | Cap models per run (`0` = no limit) — useful for smoke tests |
| `BATCH_STALL_TIMEOUT_SECONDS` | `1800` | Watchdog: dump every worker's stack after this long with no model finishing (`0` disables) |
| `BATCH_ABORT_ON_STALL` | `false` | Stop the run on a stall instead of continuing to wait |
| `MIRROR_MODELS_TO_UDP_INPUT` | `true` | Mirror discovered SAP PD models into `app/udp_tool/input_erwin_models/{cdm,ldm,pdm}` |
| `COMPLEXITY_SIMPLE_MAX_OBJECTS` / `_MEMBERS` | `25` / `200` | Simple/Medium/Complex triage label only — every model gets the same validation |
| `COMPLEXITY_MEDIUM_MAX_OBJECTS` / `_MEMBERS` | `100` / `1000` | As above |

#### UDP injection

| Variable | Default | What it does |
|---|---|---|
| `UDP_EXTRACTION_ID` | `46603045` | Last-resort PowerDesigner repository extraction id. The model's own header value always wins where it is known — this is only the fallback |

#### Multi-user / session isolation

| Variable | Default | What it does |
|---|---|---|
| `ENABLE_SESSION_ISOLATION` | `false` | **Off by default**, so a single-user checkout keeps its deterministic layout. On: every output of a run lands under `<SESSIONS_DIR>/<user>_<timestamp>_<uuid>/` |
| `FORCE_SESSION_ID` | *(auto-generated)* | Pin a specific session id |
| `FORCE_USERNAME` | *(auto-detected)* | Pin a specific username |
| `FILE_LOCK_POLL_INTERVAL_SECONDS` | `0.05` | Retry cadence for a blocked writer waiting on a file lock |

#### Logging and audit

| Variable | Default | What it does |
|---|---|---|
| `LOG_LEVEL` | `WARNING` | Standard Python log level |
| `PIPELINE_LEDGER_ENABLED` | `true` | Write `batch_summary/audit/pipeline_ledger.jsonl` (artefact lineage + SHA-256) |

See PROJECT_STRUCTURE_AND_FLOW.md §2 for the stage layout, the manual hand-offs and the
order the pipeline runs the migration flow in.

No configuration needed to run! All defaults work.

---

## Testing

```bash
# Everything CI runs, locally:
pip install -r requirements.txt -r app/requirements-dev.txt
ruff check .                                  # coding standard (ruff.toml)
bandit -q -r app -x app/udp_tool --severity-level medium
pytest --cov=app --cov-report=term            # 239 tests, ~71% line coverage

# One file
pytest tests/test_ldm_model_metadata.py -v
```

CI (`.github/workflows/python-app.yml`) runs the same three steps and
publishes `coverage.xml`, `pytest-report.xml`, `ruff-report.json` and
`bandit-report.json`; the SonarQube workflow imports them
(`sonar-project.properties`). The erwin COM modules (`erwin_load.py`,
`erwin_convert.py`, `udp_readback.py`, `batch_run.py`) are excluded from the
coverage denominator because they cannot execute on the Linux runner.

---

## Multi-User Support (NEW!)

### Default: Session Isolation Enabled ✅
Each user gets isolated output:
```bash
# User A
python -m app.main
# Output: erwinmodels/alice_20250912_143022_a1b2c3d4/

# User B (simultaneously)
python -m app.main
# Output: erwinmodels/bob_20250912_143025_b3c4d5e6/
```

**No conflicts. No data loss. Safe for concurrent use.**

### Features
- ✅ Automatic session ID generation
- ✅ User detection (Windows/Unix)
- ✅ Per-session audit logs
- ✅ File locking for concurrent writes
- ✅ Atomic JSONL appends
- ✅ Cross-platform (Windows/Unix/Mac)
- ✅ Optional toggle if needed

---

## Troubleshooting

### Setup Issues
→ See [REQUIREMENTS.md](REQUIREMENTS.md#troubleshooting)

### Runtime Issues
```bash
# Enable debug logging
export LOG_LEVEL=DEBUG
python -m app.main

# What happened to each model, one JSON line per model per run
tail -n 5 batch_summary/audit/pipeline_ledger.jsonl
```

### Common Issues
| Issue | Solution |
|-------|----------|
| `No models found` | Place .ldm/.cdm/.pdm files in `sappdmodels/` |
| `Python not found` | Install Python 3.8+ |
| `ModuleNotFoundError` | Run: `pip install -r requirements.txt` |
| `Permission denied` | Check file/directory permissions |

---

## For Colleagues Sharing This Code

**Start here:** [REQUIREMENTS.md](REQUIREMENTS.md)

**Quick version:** Run `python setup.py` (or `setup.bat` on Windows)

**Questions:** See [QUICK_START.md](QUICK_START.md) or [SETUP.md](SETUP.md)

---

## Documentation

| File | Purpose |
|------|---------|
| **REQUIREMENTS.md** | ⭐ START HERE - Complete setup + deps |
| **QUICK_START.md** | Quick reference checklist |
| **SETUP.md** | Detailed setup with config options |
| **README.md** | This file - Overview |

---

## Development

### Adding Tests
Put new tests in `tests/` (pytest collects only that folder) and keep
`ruff check .` clean — CI fails on either.

### Modifying Configuration
Edit `app/config/settings.py` or use environment variables.

### Adding Validation Logic
See `app/validation/` subdirectories for model-specific validators.

---

## License & Support

Contact the development team for issues or enhancements.

---

## Changelog

### Recent: Multi-User Support
- ✨ Session isolation (user-scoped output directories)
- ✨ File locking for concurrent writes
- ✨ Per-session audit logs
- ✨ Automated setup scripts
- ✨ Comprehensive documentation

---

**Ready to share! Just have colleagues run `setup.py` or read [REQUIREMENTS.md](REQUIREMENTS.md). 🚀**

## Object × property coverage

`COVERAGE_MATRIX.md` lists every SAP PD object type and property, whether it is migrated, validated (and by which finding category), intentionally excluded, or planned. The "validated" column is generated empirically:

    python -m tests.coverage_probe            # markdown matrix (tests/property_probe_matrix.md)
    python -m tests.coverage_probe --json

`tests/test_property_coverage.py` fails when a validated property stops being detected. The extended checks live in `app/validation/extended_properties.py` (all INFO; toggles in `validation_config.EXTENDED_PROPERTY_CHECKS`).
