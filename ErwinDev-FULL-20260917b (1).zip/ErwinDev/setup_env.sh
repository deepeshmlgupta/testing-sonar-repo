#!/usr/bin/env bash
# ==========================================================================
#  setup_env.sh — Automated Virtual Environment Setup for Linux / macOS
# ==========================================================================
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "=========================================================================="
echo " Setting up Python Virtual Environment (.venv)..."
echo "=========================================================================="

if ! command -v python3 &> /dev/null; then
    echo "[ERROR] Python 3 was not found. Please install Python 3.8+."
    exit 1
fi

if [ ! -d ".venv" ]; then
    echo "Creating .venv virtual environment..."
    python3 -m venv .venv
fi

echo "Activating virtual environment..."
source .venv/bin/activate

echo "Installing requirements..."
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if [ "${1:-}" = "--dev" ]; then python -m pip install -r app/requirements-dev.txt; fi

echo "=========================================================================="
echo " [SUCCESS] Environment setup complete!"
echo " Run from this folder:  python -m app.main        (python -m app.main --help for flags)"
echo " Concurrent users:      python -m app.main --isolate"
echo " Self-check:            python setup.py --multi-user"
echo "=========================================================================="
