@echo off
REM ==========================================================================
REM  setup_env.bat — Automated Virtual Environment Setup for Windows
REM ==========================================================================
cd /d "%~dp0"

echo.
echo ==========================================================================
echo  Setting up Python Virtual Environment (.venv)...
echo ==========================================================================

REM Check if Python is installed and accessible
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python was not found on your PATH.
    echo Please install Python 3.8+ from https://www.python.org/ and check "Add to PATH".
    pause
    exit /b 1
)

REM Remove any broken/existing .venv if pyvenv.cfg points to another machine
if exist ".venv" (
    echo Checking existing .venv environment...
)

if not exist ".venv" (
    echo Creating fresh .venv virtual environment...
    python -m venv .venv
    if errorlevel 1 (
        echo [ERROR] Failed to create virtual environment.
        pause
        exit /b 1
    )
)

echo.
echo Activating virtual environment...
call .venv\Scripts\activate.bat

echo.
echo Upgrading pip and installing requirements...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if /i "%~1"=="--dev" python -m pip install -r app\requirements-dev.txt

echo.
echo ==========================================================================
echo  [SUCCESS] Environment setup complete!
echo  Run the pipeline from this folder:  python -m app.main  (or run_all_reports.bat)
echo  Concurrent users / scheduled jobs:   python -m app.main --isolate
echo  Full self-check incl. multi-user:    python setup.py --multi-user
echo ==========================================================================
pause
