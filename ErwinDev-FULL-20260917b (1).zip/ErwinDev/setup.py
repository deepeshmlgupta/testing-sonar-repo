#!/usr/bin/env python3
"""
Quick setup for the SAP PowerDesigner -> erwin Migration Platform.
Run once after extracting the ZIP, from the checkout root:

    python setup.py                 install runtime deps, create folders, run the tests
    python setup.py --dev           also install the dev/CI extras (ruff, bandit, pytest-cov)
    python setup.py --no-tests      skip the test run
    python setup.py --multi-user    additionally check the shared-checkout / concurrent-run setup

The script never modifies configuration; it only creates the folder tree the
pipeline expects, installs dependencies and tells you what to fix.
"""

from __future__ import annotations

import argparse
import os
import subprocess  # nosec B404 - only ever runs sys.executable with literal arguments
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

if sys.platform.startswith('win')
    os.environ['PYTHONIOENCODING']='utf-8'
    
# Every folder a first run needs. Inputs first, then the shared outputs, then
# the per-session root used when ENABLE_SESSION_ISOLATION / --isolate is on.
DIRECTORIES = (
    "sappdmodels/ldm", "sappdmodels/cdm", "sappdmodels/pdm",
    "final_xml_models/ldm", "final_xml_models/cdm", "final_xml_models/pdm",
    # erwinmodels is exactly three FLAT stage folders (see app/orchestration/stage_paths.py)
    "erwinmodels/1_initial", "erwinmodels/2_preprocessed", "erwinmodels/3_final",
    "batch_summary/summary_report", "batch_summary/audit",
    "app/udp_tool/input_erwin_models/ldm", "app/udp_tool/input_erwin_models/cdm",
    "app/udp_tool/input_erwin_models/pdm",
    # The STANDALONE UDP tool's own input/output tiers. setup_directories()
    # creates these on every run too; they are listed here as well so a fresh
    # checkout has them BEFORE the first run, which is when an operator is told
    # to paste a source model into input_sap_models/.
    "app/udp_tool/input_sap_models/ldm", "app/udp_tool/input_sap_models/cdm",
    "app/udp_tool/input_sap_models/pdm",
    "app/udp_tool/output_erwin_models",
    "app/udp_tool/output_excel_reports/ldm", "app/udp_tool/output_excel_reports/cdm",
    "app/udp_tool/output_excel_reports/pdm",
    "manual_review_reports", "logs", "outputs", "reports", "temp",
    "data/udp", "data/interim_reports", "sessions",
)

# Windows MAX_PATH is 260 characters. The pipeline keeps its own file names
# short, but a checkout this deep leaves too little headroom for the UDP
# tool's workbook names (see report_layout.short_model_name).
WINDOWS_BASE_PATH_WARN = 100


def header(text: str) -> None:
    print(f"\n{'=' * 70}\n  {text}\n{'=' * 70}")


def check_python() -> None:
    header("1. Python")
    v = sys.version_info
    print(f"   Python {v.major}.{v.minor}.{v.micro} at {sys.executable}")
    if (v.major, v.minor) < (3, 8):
        sys.exit("  ERROR: Python 3.8+ is required.")


def check_location() -> None:
    header("2. Checkout location")
    print(f"   {BASE_DIR}  ({len(str(BASE_DIR))} characters)")
    if sys.platform == "win32" and len(str(BASE_DIR)) > WINDOWS_BASE_PATH_WARN:
        print("   WARNING: this path is long. Windows caps paths at 260 characters and\n"
              "   report/UDP file names add ~130. Either move the checkout to a short\n"
              "   path (e.g. C:\\dev\\erwin) or enable long paths:\n"
              "     HKLM\\SYSTEM\\CurrentControlSet\\Control\\FileSystem\\LongPathsEnabled = 1")
    if "onedrive" in str(BASE_DIR).lower():
        print("   WARNING: the checkout is inside OneDrive. Sync can hold files open while\n"
              "   the pipeline writes them; pause sync during a batch or move the checkout.")


def create_directories() -> None:
    header("3. Folder tree")
    for rel in DIRECTORIES:
        (BASE_DIR / rel).mkdir(parents=True, exist_ok=True)
    print(f"   {len(DIRECTORIES)} folders present under {BASE_DIR.name}/")


def pip_install(*files: Path) -> None:
    args = [sys.executable, "-m", "pip", "install"]
    for f in files:
        if not f.is_file():
            sys.exit(f"  ERROR: {f} not found")
        args += ["-r", str(f)]
    print("   " + " ".join(a if " " not in a else f'"{a}"' for a in args[2:]))
    result = subprocess.run(args, text=True)  # nosec B603
    if result.returncode != 0:
        sys.exit("  ERROR: dependency installation failed (see pip output above).")


def install_dependencies(dev: bool) -> None:
    header("4. Dependencies")
    files = [BASE_DIR / "requirements.txt"]
    if dev:
        files.append(BASE_DIR / "app" / "requirements-dev.txt")
    pip_install(*files)
    if sys.platform != "win32":
        print("   Note: erwin COM (pywin32) is Windows-only; UDP injection and .erwin\n"
              "   conversion are skipped on this platform, everything else runs.")


def run_tests() -> bool:
    header("5. Tests")
    result = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:warnings", "tests"],
                            cwd=str(BASE_DIR), text=True)  # nosec B603
    ok = result.returncode == 0
    print("   All tests passed." if ok else "   Tests FAILED - fix before running a batch.")
    return ok


def check_multi_user() -> None:
    """Sanity checks for a checkout several people or scheduled jobs will share."""
    header("6. Multi-user readiness")
    sys.path.insert(0, str(BASE_DIR))
    from app.orchestration import run_context
    from app.utils.session_manager import file_lock, get_current_user, lock_is_held

    user = get_current_user()
    sessions = Path(os.environ.get("SESSIONS_DIR", BASE_DIR / "sessions"))
    print(f"   OS user detected as: {user}")
    print(f"   Session folders will be created under: {sessions}")
    roots = run_context.session_roots(sessions / f"{user}_<timestamp>_<id>")
    for key in ("erwin_out", "reports_root", "summary", "udp_work"):
        print(f"     {key:13} -> {roots[key]}")

    probe = sessions / ".setup_probe"
    try:
        probe.mkdir(parents=True, exist_ok=True)
        (probe / "w").write_text("", encoding="utf-8")
        (probe / "w").unlink()
        probe.rmdir()
        print("   Session root is writable.")
    except OSError as exc:
        print(f"   ERROR: session root is not writable: {exc}")

    ledger = BASE_DIR / "batch_summary" / "audit" / "pipeline_ledger.jsonl"
    if lock_is_held(ledger, timeout=0.5):
        print("   WARNING: another run currently holds the shared ledger lock.")
    else:
        with file_lock(ledger, timeout=2):
            pass
        print("   Ledger lock acquired and released - OS file locking works here.")

    isolation = os.environ.get("ENABLE_SESSION_ISOLATION", "false")
    print(f"   ENABLE_SESSION_ISOLATION={isolation}"
          + ("" if isolation.lower() in ("true", "1", "yes") else
             "  (set it to true, or pass --isolate, before two people run at once)"))


def next_steps() -> None:
    header("Setup complete")
    print(f"""
   1. Inputs
        SAP models          -> sappdmodels/ldm | cdm | pdm
        erwin XML V1 export -> erwinmodels/1_initial/<model>.xml   (erwin: Save As XML)
        final validated XML -> final_xml_models/ldm | cdm | pdm    (optional, for a true V3)

   2. Run (always from this folder, never from app/)
        python -m app.main                       shared layout, {os.cpu_count() or 4} CPUs -> MAX_WORKERS
        python -m app.main --isolate             per-user session folder under sessions/
        python -m app.main --workers 2 --max-models 5
        python -m app.main --help                every flag

      Split stages (share one folder with --session-id):
        python -m app.run_v1  --isolate --session-id nightly
        python -m app.run_udp --isolate --session-id nightly
        python -m app.run_v3  --isolate --session-id nightly

   3. Outputs
        shared:   app/reporting/<tier>_reports/<model>/   batch_summary/summary_report/
        isolated: sessions/<user>_<timestamp>_<id>/reports | batch_summary | erwinmodels

   Docs: SETUP.md (install, multi-user), QUICK_START.md, README.md
   Debug: python -m app.main --log-level DEBUG
""")


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--dev", action="store_true", help="also install app/requirements-dev.txt")
    parser.add_argument("--no-tests", action="store_true", help="skip the test suite")
    parser.add_argument("--multi-user", action="store_true", help="check the shared-checkout setup")
    args = parser.parse_args(argv)

    try:
        check_python()
        check_location()
        create_directories()
        install_dependencies(args.dev)
        ok = True if args.no_tests else run_tests()
        if args.multi_user:
            check_multi_user()
        next_steps()
        print(f"{'=' * 70}\n  Setup status: {'SUCCESS' if ok else 'COMPLETED WITH TEST FAILURES'}\n{'=' * 70}\n")
        return 0 if ok else 1
    except KeyboardInterrupt:
        print("\nSetup cancelled.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
