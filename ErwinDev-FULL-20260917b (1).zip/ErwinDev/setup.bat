@echo off
REM ==========================================================================
REM  setup.bat - Windows one-shot setup. Thin wrapper over setup.py so the
REM  folder list, dependency install and checks live in ONE place.
REM
REM    setup.bat                  install deps, create folders, run tests
REM    setup.bat --dev            also install ruff / bandit / pytest-cov
REM    setup.bat --no-tests       skip the test suite
REM    setup.bat --multi-user     check the shared-checkout / concurrent setup
REM ==========================================================================
cd /d "%~dp0"

python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python is not installed or not on PATH. Install Python 3.8+ from https://www.python.org
    pause
    exit /b 1
)

if exist ".venv\Scripts\activate.bat" call .venv\Scripts\activate.bat

python setup.py %*
set RC=%errorlevel%
echo.
if %RC% NEQ 0 echo Setup finished with errors - see above.
pause
exit /b %RC%
