# Setup Guide for ERwin Migration Platform

**TL;DR:** Yes, colleagues can unzip and run it, but they need to follow these simple steps first (takes ~5 minutes).

---

## Prerequisites

Before starting, ensure you have:

### Required
- ✅ **Python 3.8+** (3.10+ recommended)
  - Check: `python --version`
  
### Platform-Specific
- **Windows**: Nothing extra needed (pywin32 installed automatically)
- **Linux/Mac**: erwin tools won't work (source parser only), but everything else does

---

## Step-by-Step Setup (5 minutes)

### Step 1: Extract the ZIP
```bash
unzip erwin-migration-platform.zip
cd ErwinDev
```

### Step 2: Create Python Virtual Environment (Recommended)
```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Linux/Mac
python -m venv venv
source venv/bin/activate
```

### Step 3: Install Dependencies
```bash
pip install -r requirements.txt
```

**What's being installed:**
- `defusedxml>=0.7.1` - Safe XML parsing
- `openpyxl>=3.1.5` - Excel workbook generation
- `pytest>=8.0.0` - Test framework
- `pywin32>=306` - Windows COM API (Windows only, auto-skipped on Linux/Mac)

### Step 4: Create Required Directories
```bash
# Automatic: The app creates missing directories at runtime
# But you can pre-create them for faster startup:

mkdir -p sappdmodels/{ldm,cdm,pdm}
mkdir -p final_xml_models/{ldm,cdm,pdm}
mkdir -p erwinmodels/{1_initial,2_preprocessed,3_final}
mkdir -p batch_summary/audit
```

### Step 5: Verify Installation
```bash
python -m pytest -q
# Should see: all tests passed

# Or quick test:
python -m pytest
# Should see: "ALL TESTS PASSED"
```

---

## Configuration (Optional)

### Default Configuration
The app works **out of the box** with no configuration. All paths are auto-created.

### Custom Paths (Optional)
If you want to use different locations, set environment variables:

```bash
# Windows PowerShell
$env:SAP_PD_MODELS_DIR = "D:\my_sap_models"
$env:ERWIN_MODELS_DIR = "D:\my_erwin_output"
$env:FINAL_XML_DIR = "D:\my_final_xml"

# Windows CMD
set SAP_PD_MODELS_DIR=D:\my_sap_models
set ERWIN_MODELS_DIR=D:\my_erwin_output

# Linux/Mac
export SAP_PD_MODELS_DIR="/home/user/sap_models"
export ERWIN_MODELS_DIR="/home/user/erwin_output"
export FINAL_XML_DIR="/home/user/final_xml"
```

### Session Isolation (Multi-User Mode)

Off by default: a single-user checkout keeps the deterministic layout
(`erwinmodels/`, `app/reporting/<tier>_reports/`, `batch_summary/`).

Turn it on whenever **two people or two scheduled jobs may run the same
checkout at the same time**. Every output of the run then lands under one
session folder and nothing is shared except the inputs:

```
sessions/<user>_<YYYYMMDD_HHMMSS>_<id>/
    erwinmodels/          1_initial / 2_preprocessed / 3_final of this run
    reports/              <tier>_reports/<model>/  V1 / V2 / V3 workbooks + migration log
    batch_summary/        Pass_Fail_Summary.xlsx, audit/pipeline_ledger.jsonl
    data/udp/             UDP tool per-model working folders
    udp_reports/          UDP tool workbooks
```

Inputs stay shared: `sappdmodels/`, `final_xml_models/`,
`app/udp_tool/input_erwin_models/` and the shared `erwinmodels/1_initial/`
(an isolated run still picks up the manual erwin artefacts dropped there, so
the person working in erwin does not need to know the session folder).

```bash
# per run (recommended)
python -m app.main --isolate
python -m app.main --isolate --user alice --session-id sprint12   # fixed, predictable folder

# or as the default for the whole machine
export ENABLE_SESSION_ISOLATION=true         # PowerShell: $env:ENABLE_SESSION_ISOLATION="true"
export SESSIONS_DIR=/shared/erwin_sessions   # optional; default <checkout>/sessions
```

The three split stages share one folder through `--session-id`:

```bash
python -m app.run_v1  --isolate --session-id nightly
python -m app.run_udp --isolate --session-id nightly
python -m app.run_v3  --isolate --session-id nightly
```

Concurrency safeguards that are always on, isolated or not:

* **Pre-flight** (`app/orchestration/concurrency.py`) runs before the worker
  pool starts. It rejects two models that would write the same files
  (`x.ldm` + `x.cdm`, or two repository extracts whose readable names
  collide), probes every output root for write access, and reports when
  another live run holds the ledger lock. Rejected models are listed at the
  end of the run like a missing export; they are never run.
* **Stall watchdog**: with `MAX_WORKERS > 1`, if no model finishes within
  `BATCH_STALL_TIMEOUT_SECONDS` (default 1800) the runner logs every worker
  thread's stack so you can see whether it is waiting on erwin COM, a
  subprocess or a lock. `--abort-on-stall` / `BATCH_ABORT_ON_STALL=true` turns
  that into a hard stop for unattended jobs.
* Shared files (`pipeline_ledger.jsonl`) are appended under an OS file lock
  with a timeout; the two tool bridges (UDP tool, PDM validator) share one
  import lock, so parallel workers cannot corrupt `sys.path` while loading them.

`python setup.py --multi-user` checks the session root, OS user detection and
file locking on the machine.

---

## Project Structure

After setup, you should have this structure:

```
ErwinDev/
├── README.md                              ← Main documentation
├── requirements.txt                        ← Dependencies list
├── app/
│   ├── __init__.py
│   ├── main.py                            ← Entry point
│   ├── promote_model.py                   ← Promotion engine
│   ├── requirements.txt                   ← App dependencies

│   ├── config/
│   │   ├── settings.py                    ← Configuration
│   │   └── validation_config.py
│   ├── utils/
│   │   └── session_manager.py             ← Session isolation module (NEW!)
│   ├── validation/
│   │   ├── ldm_reconcile/
│   │   ├── cdm_reconcile/
│   │   ├── pdm_reconcile/
│   │   └── ...
│   ├── reporting/
│   │   ├── migration_audit.py
│   │   └── ...
│   ├── preprocessing/
│   ├── erwin/
│   ├── udp_tool/
│   │   ├── batch_run.py
│   │   └── ...
│   └── tests/
│
├── sappdmodels/                           ← Input: SAP models (user provides)
│   ├── ldm/
│   ├── cdm/
│   └── pdm/
├── final_xml_models/                      ← Input (MANUAL): erwin's XML export of the UDP-enriched .erwin — required for V3
│   ├── ldm/
│   ├── cdm/
│   └── pdm/
├── erwinmodels/                           ← exactly three flat folders
│   ├── 1_initial/                         ← Input (MANUAL): erwin's XML export of the imported model
│   ├── 2_preprocessed/                    ← Output: <model>.xml (comments as notes), <model>.erwin (UDPs)
│   └── 3_final/                           ← Output: <model>.xml + .erwin, only when V3 fidelity ≥ 90 %
├── app/udp_tool/input_erwin_models/       ← Input (MANUAL): <model>.erwin saved from 2_preprocessed/<model>.xml
├── sessions/<user>_<id>/                  ← Session-scoped outputs (only with --isolate)
└── batch_summary/                         ← Output: Audit logs & reports
    ├── audit/
    └── summary_report/
```

---

## Running the Application

### Basic Run
```bash
# from the checkout root — never from app/
python -m app.main
python -m app.main --help      # every flag: --workers, --isolate, --max-models, --stall-timeout …
```

Expected output:
```
Starting SAP PowerDesigner to erwin Migration Pipeline...
Run: shared layout (session isolation off)  |  workers=4  |  pid=1234
Found N model(s) to process.
...
Pipeline execution completed.
```

### With Custom Configuration
```bash
export SAP_PD_MODELS_DIR="/path/to/models"
export ERWIN_MODELS_DIR="/path/to/output"
python -m app.main
```

### Run Specific Tests
```bash
pytest tests/test_ldm_model_metadata.py -v
pytest tests/test_ldm_attribute_multiplicity.py -v
```

### Run the Concurrency / Multi-User Tests
```bash
pytest tests/test_concurrency_safety.py tests/test_run_context.py tests/test_multiuser_functionality.py -v
```

---

## Input Data Preparation

### Place SAP Models
Your client need to provide SAP PowerDesigner models:

```
sappdmodels/
├── ldm/
│   ├── model1.ldm
│   ├── model2.ldm
│   └── ...
├── cdm/
│   ├── model1.cdm
│   └── ...
└── pdm/
    ├── model1.pdm
    └── ...
```

### Place Final Validated erwin XML (Optional)
For V3 validation phase:

```
final_xml_models/
├── ldm/
│   ├── model1.xml
│   └── ...
├── cdm/
│   ├── model1.xml
│   └── ...
└── pdm/
    ├── model1.xml
    └── ...
```

---

## Troubleshooting

### Issue: "No module named 'app'"
**Solution:** Make sure you're running from the correct directory:
```bash
cd path/to/ErwinDev
python -m app.main   # ✓ Correct
# NOT: python app/main.py  (might fail on imports)
```

### Issue: "ModuleNotFoundError: No module named 'defusedxml'"
**Solution:** Install dependencies:
```bash
pip install -r requirements.txt
```

### Issue: "Directory not found: sappdmodels"
**Solution:** Create required directories (Step 4) or place models there:
```bash
mkdir -p sappdmodels/{ldm,cdm,pdm}
# Place .ldm, .cdm, .pdm files in the respective folders
```

### Issue: "pywin32 not installed" (Windows)
**Solution:** Install pywin32:
```bash
pip install pywin32
```

### Issue: Permission Denied on Windows
**Solution:** Run command prompt as Administrator or use WSL:
```bash
# Option 1: run isolated so nothing is written into the shared tree
python -m app.main --isolate

# Option 2: pause OneDrive sync while the batch runs, or move the checkout out of OneDrive
```

### Issue: "No models found"
**Solution:** 
1. Check SAP models are in `sappdmodels/ldm/`, `sappdmodels/cdm/`, or `sappdmodels/pdm/`
2. Verify model files have correct extensions (`.ldm`, `.cdm`, `.pdm`)
3. Use custom path if models are elsewhere:
   ```bash
   export SAP_PD_MODELS_DIR="/path/to/your/models"
   python -m app.main
   ```

---

## Platform-Specific Notes

### Windows
✅ **Fully supported**
- erwin COM API access (pywin32)
- File locking via msvcrt
- All features available
```bash
python -m app.main
```

### Linux / Mac
✅ **Mostly supported** (no erwin integration)
- Can parse SAP PowerDesigner models (source analysis)
- Can generate reports
- Cannot access live erwin via COM API
- File locking via fcntl (more robust than Windows)
```bash
python -m app.main
```

### WSL (Windows Subsystem for Linux)
✅ **Recommended for Linux users on Windows**
```bash
wsl
cd /mnt/c/Users/username/ErwinDev
python -m app.main
```

---

## Multi-User / Concurrent Execution

### Default: Safe Multi-User Mode
Each user gets isolated output directories:
```bash
# User A
python -m app.main
# Output: erwinmodels/alice_20250912_143022_a1b2c3d4/

# User B (simultaneously)
python -m app.main
# Output: erwinmodels/bob_20250912_143025_b3c4d5e6/
```

### Legacy Single-User Mode
```bash
export ENABLE_SESSION_ISOLATION=false
python -m app.main
# Output: erwinmodels/1_initial/, etc. (shared, NOT recommended for concurrent use)
```


---

## Common Commands 

```bash
# 1. First time setup
python -m venv venv
source venv/bin/activate  # or: venv\Scripts\activate on Windows
pip install -r requirements.txt

# 2. Run migration
python -m app.main

# 3. Run tests
pytest

# 4. Run multi-user test
python -m pytest

# 5. Set custom paths
export SAP_PD_MODELS_DIR="/custom/path"
export ERWIN_MODELS_DIR="/custom/output"
python -m app.main

# 6. Disable session isolation (if needed)
export ENABLE_SESSION_ISOLATION=false
python -m app.main

# 7. Check configuration
python -c "from app.config import settings; print(f'BASE_DIR: {settings.BASE_DIR}')"
```

---

## Next Steps 
1. ✅ Extract ZIP
2. ✅ Follow Steps 1-5 above
3. ✅ Place SAP models in `sappdmodels/`
4. ✅ Place final XML in `final_xml_models/` (optional for V3)
5. ✅ Run `python -m app.main`
6. ✅ Check output in `erwinmodels/` or `batch_summary/`

---

## Getting Help

If you encounter issues:

1. **Check logs:**
   ```bash
   tail -f batch_summary/audit/*/migration_audit_report.xlsx
   ```

2. **Enable debug logging:**
   ```bash
   export LOG_LEVEL=DEBUG
   python -m app.main
   ```

3. **Run test suite:**
   ```bash
   pytest
   ```

4. **Check configuration:**
   ```bash
   python -c "from app.config import settings; print(vars(settings))"
   ```

5. **Refer to documentation:**
   - `README.md` (if exists) - General info
   - Code docstrings - Detailed technical info

---

## Checklist for Ready-to-Share

Before sharing the ZIP with anyone:

- ✅ All dependencies in `requirements.txt`
- ✅ All paths are relative or environment-configurable
- ✅ No hardcoded usernames or paths
- ✅ Session isolation module included (`app/utils/session_manager.py`)
- ✅ Test suite included (`app/test_multiuser_functionality.py`)
- ✅ Multi-user mode works by default
- ✅ Single-user mode available (opt-in)
- ✅ Cross-platform compatible (Windows/Unix)
- ✅ No special setup scripts required

---

## Summary

| Aspect | Status | Notes |
|--------|--------|-------|
| **Setup Time** | ~5 min | Python 3.8+, venv, pip install, mkdir |
| **No Setup Run** | ❌ No | Requires Step 1-5 |
| **Configuration Needed** | ❌ No | All defaults work |
| **Multi-User Ready** | ✅ Yes | Enabled by default |
| **Cross-Platform** | ✅ Yes | Windows, Linux, Mac (partial) |
| **Dependencies** | ✅ Listed | `requirements.txt` |
| **Platform-Specific Setup** | ✅ Minimal | Windows: msvcrt auto-installed |
| **Input Data Required** | ✅ Yes | SAP models in `sappdmodels/` |

---

## For IT/DevOps Teams

If deploying in production or shared environments:

1. **Create shared venv:**
   ```bash
   python -m venv /shared/erwin-venv
   /shared/erwin-venv/bin/pip install -r requirements.txt
   ```

2. **Use shared session directory:**
   ```bash
   export ERWIN_MODELS_DIR="/shared/erwin-output"
   export SAP_PD_MODELS_DIR="/shared/sap-models"
   ```

3. **Enable audit logging:**
   ```bash
   export LOG_LEVEL=INFO
   ```

4. **Disable session isolation if single-user:**
   ```bash
   export ENABLE_SESSION_ISOLATION=false
   ```

---

---

## Folders the framework creates for you

`python -m app.run_v1` creates everything on first run. You should not create any of these
by hand — a folder made under a slightly different name is a folder the pipeline will not
look in.

```
sappdmodels/{cdm,ldm,pdm}/              your SAP PD sources go here
erwinmodels/1_initial/                  your manual erwin XML export (INPUT, never written)
erwinmodels/2_preprocessed/             Step 1 and Step 2 outputs
erwinmodels/3_final/                    promoted models (PASS only)
final_xml_models/{cdm,ldm,pdm}/         your manual erwin XML V3 export
app/udp_tool/input_erwin_models/        the handed-off .erwin (flat)
app/udp_tool/input_erwin_models/{cdm,ldm,pdm}/   ...or beside the mirrored source
app/udp_tool/input_sap_models/          the standalone tool's SAP source folder
batch_summary/stage_state/              per-model stage state and next actions
batch_summary/udp_evidence/             the verified .erwin UDP read-back
batch_summary/code_ledger/              the attribute code preservation ledger
```

If a folder named in an instruction is missing, run `run_v1.py` once rather than creating
it — earlier versions did not create the tier sub-folders or `input_sap_models`, which is
why an operator could be told to paste into a folder that did not exist.
