# 🏗️ PROJECT STRUCTURE, WORKFLOW & CLEANUP ASSESSMENT

An overview of the **SAP PowerDesigner → erwin Data Modeler Migration Platform**, including folder structure, execution flow, component responsibilities, folder management rules, and cleanup recommendations.

---

## 1. 📂 Complete Repository Folder Structure

```text
ErwinDev/
│
├── .github/                           [SYSTEM] CI/CD Workflows
│   └── workflows/
│       ├── batch_migration.yml        # GitHub Action for batch pipeline
│       ├── python-app.yml             # CI build & test run
│       └── sonar.yml                  # SonarQube code quality scan
│
├── app/                               [CORE APPLICATION CODE]
│   ├── .github/agents/                # Copilot Agent definitions (.agent.md)
│   ├── config/                        # Configuration settings
│   │   ├── settings.py                # Main paths, environment variables & toggles
│   │   └── validation_config.py       # Tier thresholds, check toggles & weights
│   ├── erwin/                         # erwin_converter.py: OPTIONAL SCAPI utility (off; not used by the flow)
│   ├── preprocessing/                 # Phase B comment/note preprocessor
│   │   ├── orchestrator.py            # Preprocessing orchestrator
│   │   ├── pdm_preprocessor.py        # PDM XML comment injection
│   │   └── scripts/                   # Auxiliary conversion scripts
│   ├── reporting/                     # V1/V2/V3 report assembly & audit trail
│   │   ├── migration_audit.py         # JSONL ledger logging & audit report
│   │   ├── report_layout.py           # Shared Excel styling & formatting
│   │   ├── v2_report.py               # Preprocessed gap report
│   │   └── v3_report.py               # Final fidelity report generator
│   ├── udp_tool/                      # Standalone & integrated UDP engine
│   │   ├── batch_run.py               # Standalone UDP batch runner
│   │   ├── erwin_load.py              # Inject UDPs into erwin XML via COM
│   │   ├── erwin_prepare.py           # Prepare UDP injection payload
│   │   ├── pd_extract.py              # Extract extended attributes from SAP PD
│   │   ├── sow_classify.py            # Extended attribute taxonomy classification
│   │   ├── udp_compare.py             # Reconcile SAP extended attributes vs erwin UDPs
│   │   ├── udp_readback.py            # Read back saved erwin XML for validation
│   │   └── udp_report.py              # Standalone UDP Excel report generator
│   ├── utils/                         # Shared utilities
│   │   ├── session_manager.py         # Multi-user isolation, file locking, atomic writes
│   │   └── manual_export_wait.py      # Poll/validate a hand-made erwin export
│   ├── orchestration/                 # batch_runner, stage_paths (flat layout), stage_state (hand-off ledger), pipeline_ledger, run_context
│   ├── workflows/                     # conceptual (CDM/LDM) and PDM per-model pipelines, gate routing
│   ├── validation/                    # Core 3-tier Reconciliation Engines
│   │   ├── cdm_reconcile/             # Conceptual Data Model (CDM) reconciliation
│   │   ├── ldm_reconcile/             # Logical Data Model (LDM) reconciliation
│   │   ├── pdm_reconcile/             # Physical Data Model (PDM) reconciliation
│   │   ├── fidelity_stages.py         # V1/V2/V3 stage application & scoring
│   │   ├── promotion_gate.py          # PASS/WARN/FAIL promotion gate thresholds
│   │   └── udp_flow.py                # Integrated UDP flow runner
│   ├── __init__.py
│   ├── main.py                        # one-process run (all manual artefacts already in place)
│   ├── run_v1.py                      # ★ Stage 1: Fidelity V1 + Step 1 (comments -> notes)
│   ├── run_udp.py                     # ★ Stage 2: UDP tool on the handed-off .erwin
│   ├── run_v3.py                      # ★ Stage 3: Fidelity V2 + V3, gate, summary
│   ├── erwin/erwin_handoff.py         # obtains .ERWIN V1/.ERWIN V2: erwin COM, else guided manual hand-off
│   ├── udp_tool/input_erwin_models/   # .ERWIN V1: made from 2_preprocessed/<model>.xml (auto via COM, else by hand)
│   └── promote_model.py               # Human-in-the-loop report promotion tool
│
├── sappdmodels/                       [INPUT DIRECTORY]
│   ├── cdm/                           # Place source .cdm files here
│   ├── ldm/                           # Place source .ldm files here
│   └── pdm/                           # Place source .pdm files here
│
├── final_xml_models/                  [INPUT DIRECTORY - MANUAL, REQUIRED FOR V3]
│   ├── cdm/                           # XML V3: erwin's export of 2_preprocessed/<model>.erwin (CDM)
│   ├── ldm/                           #   … LDM
│   └── pdm/                           #   … PDM
│
├── erwinmodels/                       [THREE FLAT STAGE FOLDERS - no sub-folders]
│   ├── 1_initial/                     # <model>.xml  MANUAL: erwin's XML export of the imported model (never modified)
│   ├── 2_preprocessed/                # NAMED FOR THE PHASE, holds TWO artefacts — the extension tells them apart:
│   │                                  #   <model>.xml   = XML V2    run_v1 output (PD Comments -> erwin Notes), Step 2 input
│   │                                  #   <model>.erwin = .ERWIN V2 run_udp output (UDPs injected)
│   │                                  # (.ERWIN V1, Step 2's input, lives in udp_tool/input_erwin_models/ instead,
│   │                                  #  so an input can never be confused with or overwritten by an output.)
│   │                                  # Models below 90 % stay here.
│   └── 3_final/                       # <model>.xml + <model>.erwin  copied here by run_v3 only when V3 fidelity >= 90 %
│
├── batch_summary/                     [OUTPUT DIRECTORY - AUTO-CREATED]
│   ├── audit/pipeline_ledger.jsonl    # one line per model per run: scores, artefact paths + SHA-256, reports
│   ├── stage_state/<model>.json       # hand-off ledger: status of every stage, artefact identity, next action
│   └── summary_report/                # Consolidated Pass_Fail_Summary.xlsx
│
├── tests/                             [THE TEST SUITE — 376 tests, pytest]
├── ruff.toml                          # coding standard (CI fails on findings)
├── .coveragerc                        # coverage denominator aligned with Sonar exclusions
│
├── create_clean_zip.py                # Cleanup & ZIP packaging script
├── export_clean_zip.bat               # One-click Windows ZIP packager
├── setup.py                           # Cross-platform automated setup script
├── setup.bat                          # Windows automated setup script
├── pytest.ini                         # Pytest configuration
├── requirements.txt                   # Master Python dependencies list
├── README.md                          # Project overview documentation
├── REQUIREMENTS.md                    # Detailed setup & requirements guide
├── QUICK_START.md                     # Fast-track user guide
└── SETUP.md                           # Comprehensive configuration guide
```

---

## 2. 🔄 The operating flow (CDM / LDM / PDM)

There is **no automated erwin bridge**. erwin Data Modeler is driven by a person
twice; the framework measures fidelity around those hand-offs and never
fabricates an artefact it did not receive.

| # | Stage | Kind | Artefact | Produced by |
|---|---|---|---|---|
| 1 | SAP PD source | input | `sappdmodels/<tier>/<model>.(cdm\|ldm\|pdm)` | the modeller |
| 2 | **XML V1** | **MANUAL** | `erwinmodels/1_initial/<model>.xml` | erwin: import the PD model, Save As XML |
| 3 | Fidelity **V1** | AUTOMATED | `app/reporting/<tier>_reports/<model>/*_v1_fidelity_report.xlsx` | `run_v1.py` |
| 4 | **XML V2** (Step 1) | AUTOMATED | `erwinmodels/2_preprocessed/<model>.xml` — PD Comments written as erwin Notes (entities, attributes; PDM: tables, columns, views, procedures, triggers, sequences, tablespaces) | `run_v1.py` |
| 5 | **.ERWIN V1** | AUTO \| MANUAL | `app/udp_tool/input_erwin_models/<model>.erwin` — converted from XML V2 through erwin SCAPI when erwin COM is on the host; otherwise the run prints what to save and where, writes a `.HOWTO.txt` beside it, and waits at a prompt | `run_udp.py` / operator |
| 6 | **.ERWIN V2** (Step 2) | AUTOMATED | `erwinmodels/2_preprocessed/<model>.erwin` — SAP extended attributes injected as erwin UDPs (Windows + erwin COM); extraction/mapping/comparison reports under `app/udp_tool/output_excel_reports/` | `run_udp.py` |
| 7 | **XML V3** | **MANUAL** | `final_xml_models/<tier>/<model>.xml` — open .ERWIN V2 (the `.erwin` in `2_preprocessed`, not the `.xml` beside it) in erwin, Save As XML | operator |
| 8 | Fidelity **V2 + V3**, gate | AUTOMATED | V2 against XML V2, V3 against XML V3; report shows V1 / UDP / V3 / combined; PASS (≥ `PROMOTION_FIDELITY_THRESHOLD`, 90) → `erwinmodels/3_final/<model>.xml` + `.erwin`; FAIL → stays in `2_preprocessed`, findings filed under `manual_review_report/` | `run_v3.py` |

```mermaid
flowchart LR
    PD[SAP PD model] -->|MANUAL: erwin import + Save As XML| V1[1_initial/m.xml]
    V1 -->|run_v1: Fidelity V1 + Step 1 comments→notes| V2[2_preprocessed/m.xml]
    V2 -->|run_udp: erwin SCAPI, else guided hand-off| H[udp_tool/input_erwin_models/m.erwin]
    H -->|run_udp: UDP inject (COM)| E2[2_preprocessed/m.erwin]
    E2 -->|MANUAL: erwin Save As XML| X3[final_xml_models/tier/m.xml]
    X3 -->|run_v3: Fidelity V2 + V3| G{gate ≥ 90 %}
    G -->|PASS| F[3_final/m.xml + m.erwin]
    G -->|FAIL| R[stays in 2_preprocessed + manual_review_report]
```

**Statuses.** Every stage of every model is recorded in
`batch_summary/stage_state/<model>.json` with one of
`AUTOMATED / MANUAL / WAITING_FOR_MANUAL_INPUT / VALIDATED / FAILED / READY_FOR_NEXT_STAGE`,
the artefact's path / size / mtime / SHA-256 / parent artefact, the model type and
complexity (Simple ≤ 25 objects & 200 members, Medium ≤ 100 & 1000, else Complex),
a timestamp, the OS user and — for a waiting manual stage — the exact next action.
`python -m app.run_* ` prints those pending actions at the end of each model.

**Rules the code enforces.**

* Inputs are never modified or moved: `1_initial/*.xml`, the handed-off `.erwin` and `final_xml_models/*.xml` are read and copied only. Re-running `run_v1` keeps a `2_preprocessed/<model>.xml` that is newer than its XML V1 (the operator may already have loaded it into erwin).
* A missing manual artefact is `WAITING_FOR_MANUAL_INPUT` and the model is skipped (recorded in the pipeline ledger) — nothing is substituted. A missing **XML V3 is a hard stop**; `FINAL_XML_FALLBACK_TO_PREPROCESSED=true` gives a clearly labelled *dry run* on the V2 result.
* **Model identity.** An XML V3 with no entity / table in common with the SAP source is refused (`FAILED`, "belongs to a different model"). A UDP comparison workbook that names entities of another model, or whose verdict is `NOT VERIFIED`, is ignored rather than scored as 0 %.
* An invalid or corrupt XML, or an empty `.erwin`, is `FAILED` with the reason, never scored.
* UDP injection needs erwin's COM API (Windows). Elsewhere `run_udp.py` still produces the extraction and mapping reports and records the UDP stage `FAILED` with the remedy — it never pretends to have injected.
* Every processed or skipped model appends one line to `batch_summary/audit/pipeline_ledger.jsonl` (run id, user, host, complexity, V1/V2/V3 stage scores by component, artefact paths, how each was produced, SHA-256 of each, report paths, gate note).
* `LEGACY_STAGE_FALLBACK` (default on) also searches the retired layouts (`1_initial/xml/`, `2_preprocessed/erwin/`, `1_xml_v1 … 6_erwin_v3`) for **inputs**, so an older checkout still resolves; nothing is written there.

**Fidelity formula** (`app/validation/fidelity_stages.py`): each stage score is the
weighted mean of the components that could be measured — structural 0.50,
documentation 0.25, UDP 0.25 — renormalised over the components present
(a component that could not be measured is *n/a*, not 0). Structural fidelity is
the engines' property-level reconciliation (every finding carries object, property,
PD value, erwin value, severity, remediation); documentation is the match rate of PD
Comments against erwin Notes; UDP is the UDP tool's read-back pass rate (or the
XML's own UDP census when the export carries UDPs). The V3 report's
`FIDELITY_PROGRESSION` sheet shows V1, V2, V3 and the combined score with their
components. No prediction, regression or history is involved — a stage score is a
deterministic function of the two files compared.

## 3. 🔄 One-process run (`python -m app.main`)

Runs the same steps for every discovered model in one process — useful once all
manual artefacts exist. A model whose XML V1, `.erwin` or XML V3 is missing is
reported and skipped exactly as with the split scripts.

```mermaid
flowchart TD
    A[python -m app.main] --> B[setup_directories: erwinmodels/1_initial, 2_preprocessed, 3_final]
    B --> C[find_models in sappdmodels/ldm, cdm, pdm]
    subgraph ModelLoop ["per model (batch_runner, MAX_WORKERS)"]
        C --> D{1_initial/m.xml present & valid?}
        D -- no --> E[WAITING_FOR_MANUAL_INPUT: skip, ledger line]
        D -- yes --> F[Fidelity V1]
        F --> G[Step 1: comments -> notes -> 2_preprocessed/m.xml]
        G --> H{udp_tool/input_erwin_models/m.erwin?}
        H -- no --> I[UDP: WAITING; mapping reports only]
        H -- yes --> J[Step 2: inject UDPs -> 2_preprocessed/m.erwin; compare]
        I --> K[Fidelity V2]
        J --> K
        K --> L{final_xml_models/tier/m.xml?}
        L -- no --> M[HARD STOP: WAITING; skip]
        L -- other model --> N[FAILED: refused]
        L -- yes --> O[Fidelity V3]
        O --> P{>= 90 %}
        P -- PASS --> Q[copy to 3_final/m.xml + m.erwin]
        P -- FAIL --> R[stays in 2_preprocessed; manual_review_report]
        Q --> S[V1/V2/V3 reports, model log, ledger line]
        R --> S
    end
    S --> T[Pass_Fail_Summary.xlsx]
```

---

## 4. 🧩 Key Component Responsibilities

| Component / File | Purpose & Responsibility |
| :--- | :--- |
| [app/run_v1.py](app/run_v1.py) / [run_udp.py](app/run_udp.py) / [run_v3.py](app/run_v3.py) | **The three stage scripts** of the operating flow, run between the manual erwin hand-offs. |
| [app/main.py](app/main.py) | **One-process run** of the same steps (batch_runner) when every manual artefact is already in place. |
| [app/orchestration/stage_paths.py](app/orchestration/stage_paths.py) | **Where every artefact lives**: the flat `1_initial / 2_preprocessed / 3_final` layout, the UDP hand-off folder and `final_xml_models/<tier>`; legacy-location search for inputs. |
| [app/orchestration/stage_state.py](app/orchestration/stage_state.py) | **Hand-off ledger**: per-model stage status, artefact identity (SHA-256), next action; persists V1 for `run_v3`. |
| [app/workflows/conceptual_workflow.py](app/workflows/conceptual_workflow.py) / [pdm_workflow.py](app/workflows/pdm_workflow.py) | **Per-model pipelines** (CDM/LDM and PDM) shared by the stage scripts and `main.py`: locate/validate manual artefacts, V1, Step 1, Step 2, V2, V3 identity check, gate. |
| [app/config/settings.py](app/config/settings.py) | **Central Settings**: Defines paths, environment variable overrides (`SAMPLES_DIR`, `OUTPUT_DIR`, `FINAL_XML_DIR`), and configuration toggles. |
| [app/config/validation_config.py](app/config/validation_config.py) | **Validation Policy**: Defines tier thresholds, check toggles (e.g. `CHECK_ATTRIBUTE_MULTIPLICITY`), and severity weights. |
| [app/utils/session_manager.py](app/utils/session_manager.py) | **Multi-User & Concurrency Utilities**: Provides user detection, session ID generation, cross-platform file locking (`msvcrt` / `fcntl`), and atomic JSONL appends. |
| [app/preprocessing/](app/preprocessing) | **Phase B Preprocessing**: Extracts comments/notes from SAP PowerDesigner and injects them into erwin XML files. |
| [app/validation/](app/validation) | **Reconciliation Comparators**: Contains CDM, LDM, and PDM parser engines and comparators that calculate field-level fidelity scores. |
| [app/reporting/](app/reporting) | **Report Generators**: Formats and writes detailed Excel reports (V1, V2, V3) and maintains the audit ledger. |
| [app/udp_tool/](app/udp_tool) | **UDP Engine**: Extracts User-Defined Properties / Extended Attributes from SAP PD and injects/compares them in erwin models. |
| [app/promote_model.py](app/promote_model.py) | **Human-in-the-Loop Promotion**: Scans reviewed reports and promotes qualifying models to `erwinmodels/3_final/`. |
| [create_clean_zip.py](create_clean_zip.py) | **Packaging Script**: Cleans local caches/logs/reports and packages clean source code into `migration-platform-dist.zip`. |

---

## 5. 📁 Folder Management & Cleanup Assessment

### Folder Creation Rules
1. **Deterministic Folders**: Standard allowed directories (`logs/`, `reports/`, `outputs/`, `temp/`, `sappdmodels/`, `erwinmodels/`, `batch_summary/`) are created only if missing using `mkdir(parents=True, exist_ok=True)`.
2. **Reuse Existing Locations**: Output files overwrite or append to standard paths without creating new timestamped root directories unless session isolation (`ENABLE_SESSION_ISOLATION=true`) is explicitly enabled.

---

### 🧹 Completed Cleanups for Distribution

| Path / Artifact | Action Taken | Status |
| :--- | :--- | :--- |
| Duplicate `app/requirements.txt` | Consolidated into master [requirements.txt](requirements.txt); dev extras in `app/requirements-dev.txt`. | ✅ |
| Loose `app/test_*.py` scripts | Moved into [tests/](tests/) so CI collects them. | ✅ |
| Dead code | Removed empty packages (`assessment/`, `dependency/`, `extractors/`), the unused `app/erwin/` session/exporter/importer/validator/provider modules, the old standalone PDM validator leftovers (`main.py`, `highlight_mismatches.py`, `test_runner.py`, `tempCodeRunnerFile.py`, superseded `report_generator.py`), never-called sheet builders in `udp_fidelity.py`, and the commented-out first half of `v3_report.py`. | ✅ |
| Nested `app/.venv/` | Excluded from zip archive in [create_clean_zip.py](create_clean_zip.py). | ✅ Excluded from distribution |
| Generated `.xlsx` and `.log` files | Automatically cleaned when running [create_clean_zip.py](create_clean_zip.py). | ✅ Automatically cleaned |

---

## 6. 🚀 Execution Quick Start

### Automated Setup
```bash
# Windows
setup.bat

# Linux / Mac / WSL
python setup.py
```

### Run the migration flow (from the checkout root)
```bash
python -m app.run_v1     # after placing erwinmodels/1_initial/<model>.xml
python -m app.run_udp    # after copying <model>.erwin to app/udp_tool/input_erwin_models/
python -m app.run_v3     # after placing final_xml_models/<tier>/<model>.xml
python -m app.main       # everything in one process once all manual artefacts exist
```

### Quality gate (what CI runs)
```bash
pip install -r requirements.txt -r app/requirements-dev.txt
ruff check .
bandit -q -r app -x app/udp_tool --severity-level medium
pytest --cov=app --cov-report=term
```

### Create Clean ZIP Distribution
```bash
python create_clean_zip.py
```
