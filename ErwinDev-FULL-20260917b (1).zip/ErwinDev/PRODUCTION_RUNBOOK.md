# Production runbook — SAP PowerDesigner → Quest erwin migration validation

**Status:** READY FOR PILOT. Read "What this does not tell you" before signing anything off.

This describes the flow the code **actually implements**, verified by running it. Where an
earlier document disagrees with this one, this one was checked against the code.

---

## 0. The rule everything else follows

> A missing or unverified artefact produces **WAITING**, **FAILED** or
> **EXTERNAL_VERIFICATION_REQUIRED** — never a fabricated score and never a successful
> validation.

Three consequences you will see in normal operation, all of them intended:

* a model with no final erwin XML is **not scored at all** — it is not a low score, it is
  no score;
* a component that could not be measured is **dropped and the weights renormalised**, and
  the model is then **refused promotion** rather than passed on the remaining components;
* a check that could not run because erwin's element name was absent is reported as
  `EXTERNAL_VERIFICATION_REQUIRED`, not as a check that passed.

---

## 1. Install

```bash
python -m venv .venv
.venv\Scripts\activate            # Windows
pip install -r requirements.txt    # defusedxml, lxml, openpyxl, pytest, pywin32
python -m pytest -q                # expect 0 failures
```

`pywin32` is needed only on the Windows host that drives erwin (Steps 2 and the
conversions). Everything else — parsing, reconciliation, scoring, reporting — runs on any
platform.

### Folders

`python -m app.run_v1` creates everything it needs on first run, including
`app/udp_tool/input_erwin_models/{cdm,ldm,pdm}/` and `app/udp_tool/input_sap_models/`.
If you are looking for a folder the instructions mention and it is not there, run
`run_v1.py` once — do not create it by hand under a different name.

---

## 2. The flow, as implemented

```
sappdmodels/{cdm,ldm,pdm}/<model>.<cdm|ldm|pdm>        YOUR SAP PD source (never modified)
        │
        │  MANUAL — import into erwin, File > Save As > XML
        ▼
erwinmodels/1_initial/<model>.xml                      INPUT to run_v1, not its output
        │
        ├─ run_v1.py ─► Fidelity V1  (the honest size of the initial gap)
        └─ run_v1.py ─► erwinmodels/2_preprocessed/<model>.xml     Step 1: Comments → Notes
                │
                │  MANUAL — open THIS file in erwin, save as <model>.erwin,
                │           copy to app/udp_tool/input_erwin_models/<model>.erwin
                ▼
        run_udp.py ─► erwinmodels/2_preprocessed/<model>.erwin     Step 2: UDP injection
                │        + batch_summary/udp_evidence/<model>.json  (verified read-back)
                │        + batch_summary/code_ledger/<model>.json   (attribute codes)
                │
                │  MANUAL — open the .erwin in erwin, Save As XML,
                │           place as final_xml_models/<tier>/<model>.xml
                ▼
        run_v3.py ─► Fidelity V2, Fidelity V3, promotion gate
                └─► erwinmodels/3_final/<model>.xml   only on PASS
```

Three manual handoffs. Each is recorded as `WAITING_FOR_MANUAL_INPUT` with the exact
instruction and the exact path it looked in, in `batch_summary/stage_state/<model>.json`.

**`erwinmodels/1_initial/` is an input.** Nothing in the pipeline writes to it, and
nothing writes to `sappdmodels/`. Your source models and your three manual exports cannot
be overwritten by this framework.

---

## 3. Running it

```bash
python -m app.run_v1        # V1 fidelity + Step 1 (comments → notes)
# ... manual: XML V2 → erwin → .erwin → input_erwin_models/
python -m app.run_udp       # Step 2: UDP injection + read-back (Windows + erwin)
# ... manual: .erwin → erwin → XML → final_xml_models/<tier>/
python -m app.run_v3        # V2, V3, gate, batch summary
```

Each stage prints, for every model it could not complete, the next manual action and the
path it searched. A model that is waiting is listed at the end under
`N model(s) not scored (waiting for a manual step or rejected)`.

### Verifying a run

```bash
python -m tools.production_verify      # recomputes every score from its own finding rows
```

It fails loudly if a reported score is not what its rows produce, if a NOT MEASURED
component was scored as 0%, or if a code ledger payload does not round-trip.

---

## 4. Reading the reports

The V3 workbook carries four sheets that matter for sign-off:

| Sheet | What to check |
|---|---|
| `FIDELITY_PROGRESSION` | One row per stage. Read the **"What was compared"** column: if the V3 row says `FALLBACK`, the V3 number is the V2 artefact measured twice and is **not** evidence about the final erwin model. A delta marked *"not directly comparable"* means the two stages measured different components. |
| `SCORE_RECONCILIATION` | The score rebuilt from this workbook's own FINDINGS rows, with an explicit **AGREES / DISAGREES** verdict. If it says DISAGREES, do not use the number. |
| `FINDINGS` | Severities that score: `CRITICAL` (1.0), `WARNING` (0.35), `INFO` (0.05). Severities that never score but stay visible: `VERIFIED`, `SOURCE_PRE_EXISTING`, `EXTERNAL_VERIFICATION_REQUIRED`. |
| `UDP_RECONCILIATION` | Whether the UDP number came from the XML or from the `.erwin` read-back. |

### The severities, in one line each

* `CRITICAL` / `WARNING` / `INFO` — the migration lost or changed something. These score.
* `VERIFIED` — evidence something migrated intact. Never scores.
* `SOURCE_PRE_EXISTING` — identical in **both** models; the migration neither caused it nor
  could fix it (an entity with no primary identifier in SAP PD either). Visible, never
  scores. These are not suppressed findings — they are findings correctly attributed.
* `EXTERNAL_VERIFICATION_REQUIRED` — the framework **did not look**. Never scores, and
  blocks promotion when it means a scoring component could not be measured.

---

## 5. Settings that change the verdict

| Setting | Default | Effect |
|---|---|---|
| `FINAL_XML_FALLBACK_TO_PREPROCESSED` | **false** | `true` scores V3 against the XML V2 artefact as a dry run. The model is **never promoted** in that mode and every report says `FALLBACK`. Leave it off for anything you will sign. |
| `PROMOTION_BLOCK_ON_UNVERIFIED` | **true** | Refuses to promote a model whose score was computed with a scoring component dropped for want of evidence. Turning this off re-opens the hole where a model with no `.erwin` handoff scores 100.00 and is promoted. |
| `PROMOTION_FIDELITY_THRESHOLD` | see `settings.py` | The pass mark. |
| `PROMOTION_BLOCK_ON_CRITICAL` / `_ON_WARNING` | false | Set `true` to hold any model with such findings for human sign-off. |
| `MIRROR_MODELS_TO_UDP_INPUT` | true | Copies the SAP sources beside the handoff folder so the operator can see what to save. |

---

## 6. What this does not tell you

Read this section before treating a green run as a validated migration.

* **The UDP number is not measured from the V3 XML.** erwin's XML export does not
  serialise UDPs. The only evidence is the `.erwin` read-back that `run_udp.py` performs
  and persists to `batch_summary/udp_evidence/`. Without Step 2 on a Windows host with
  erwin, the UDP component is `EXTERNAL_VERIFICATION_REQUIRED` and the model will not be
  promoted. That is correct behaviour, not a defect.
* **Attribute codes are encoded for transport, not proven delivered.** erwin's logical
  export has no `Physical_Name`, so attribute codes travel as the `PD_Attribute_Codes` UDP
  (`batch_summary/code_ledger/<model>.json` records exactly which, and which could not be
  identified deterministically). Confirming they arrived needs the erwin read-back.
* **Only LDM is verified against real models.** `sappdmodels/cdm/` and `sappdmodels/pdm/`
  are empty in this checkout. Every CDM and PDM result rests on synthetic fixtures, which
  verify the code path but not erwin's conceptual or physical export vocabulary. This is
  marked `TEST_DATA_GAP` throughout.
* **28 erwin element names have never been seen in a real export.** Where one of those
  checks could not run, the report says so at `EXTERNAL_VERIFICATION_REQUIRED` rather than
  leaving a clean sheet. Confirming a spelling needs one erwin export that definitely
  contains the construct.
* **Artefacts are reused by name across runs.** A `.erwin` older than the SAP source it is
  compared against now produces a `STALE READ-BACK` warning, and XML V2 is regenerated
  when the SAP source is newer — but `final_xml_models/` and the UDP workbooks are still
  resolved by filename. Between separate runs of the **same** model, clear the stage
  folders if you are not certain which run an artefact came from.

---

## 7. If something looks wrong

| Symptom | What it means |
|---|---|
| A model produced no report at all | It is waiting on a manual artefact. Run the stage again and read the `NEXT (manual):` lines, or open `batch_summary/stage_state/<model>.json`. |
| `V3` row says `FALLBACK` | `FINAL_XML_FALLBACK_TO_PREPROCESSED` is on and there is no final XML. The number is not final validation. |
| Score is high but the model was not promoted | Check the gate reasons in the summary. `EXTERNAL_VERIFICATION_REQUIRED` means a scoring component was not measured — usually a missing `.erwin` handoff. |
| `SCORE_RECONCILIATION` says DISAGREES | The scoring path and the finding rows have diverged. Do not use the number; raise it. |
| `STALE READ-BACK` in the Step 2 messages | The `.erwin` is older than the SAP source. Re-do the handoff or confirm it is still the right file. |
| `Step 1 ... FAILED` | Comment injection failed and **no XML V2 was produced**. Fix the cause and re-run `run_v1.py`. Do not hand off an `.erwin` built from XML V1 — it has no comments in it. |
