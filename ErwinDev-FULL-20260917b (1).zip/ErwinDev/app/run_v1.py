"""
run_v1.py
===========
Stage 1 of the split pipeline — Fidelity V1 and Step 1:

    sappdmodels/<tier>/<model>.(cdm|ldm|pdm)     SAP PD source
    erwinmodels/1_initial/<model>.xml             MANUAL: erwin's XML export of the imported model
      -> Fidelity V1 report                       (SAP PD vs the raw export)
      -> erwinmodels/2_preprocessed/<model>.xml   Step 1: PD Comments -> erwin Notes

It does NOT produce a .erwin: there is no automated erwin bridge. When this
stage is done the operator opens 2_preprocessed/<model>.xml in erwin, saves it
as <model>.erwin and copies it to app/udp_tool/input_erwin_models/ — that
hand-off is recorded as WAITING_FOR_MANUAL_INPUT until run_udp.py finds it.

A model whose XML V1 is missing or invalid is skipped and recorded (never
substituted). Nothing in 1_initial is modified.

Usage:
    python -m app.run_v1 [--isolate] [--user NAME] [--session-id ID]
"""

import logging
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.common.config_helpers import get_setting
from app.config.settings import LOG_LEVEL
from app.orchestration import concurrency, pipeline_ledger, stage_state
from app.orchestration.directory_setup import MODEL_TYPE_BY_SUFFIX, find_models, setup_directories
from app.orchestration.model_record import ModelRecord, classify_complexity
from app.orchestration.run_context import start_run
from app.orchestration.stage_paths import StagePaths
from app.reporting.model_reports import build_v1_report
from app.validation import fidelity_stages
from app.validation.pdm_reconcile import pdm_flow
from app.workflows.conceptual_workflow import inject_comments, locate_xml_v1, measure_v1

logging.basicConfig(
    level=getattr(logging, str(LOG_LEVEL).upper(), logging.WARNING),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


def _run_v1_conceptual(record, model_path, xml_v1, stages, dirs):
    v1 = measure_v1(record, model_path, xml_v1, dirs)
    xml_v2 = inject_comments(record, model_path, xml_v1, stages, dirs)
    print(f"  -> Step 1 (comments -> notes): {xml_v2}")
    return v1


def _run_v1_pdm(record, model_path, xml_v1, stages, dirs):
    outcome = pdm_flow.validate_initial_only(
        pdm_path=str(model_path.resolve()),
        initial_xml=str(xml_v1),
        initial_erwin=str(stages.find_erwin_v1(record.base_name) or stages.erwin_v1(record.base_name)),
    )
    if outcome.initial_result is None:
        reason = f"{record.base_name} (PDM): {'; '.join(outcome.messages) or 'no initial result produced'}"
        print(f"  -> {reason}")
        concurrency.record_skipped_model(reason)
        stage_state.record_stage(dirs, record.base_name, stage_state.STAGE_V1_FIDELITY, stage_state.STATUS_FAILED,
                                 model_type="PDM", message=reason)
        return None
    record.initial_result = outcome.initial_result
    record.artefacts["source_model"] = str(model_path)
    record.artefacts["xml_v1"] = str(xml_v1)
    record.artefacts["xml_v1_how"] = "manual"
    v1 = outcome.initial_result.stage_scores.get(fidelity_stages.STAGE_V1)
    print(f"  -> V1 fidelity {outcome.initial_result.fidelity_score:.2f}%")
    stage_state.record_stage(dirs, record.base_name, stage_state.STAGE_V1_FIDELITY, stage_state.STATUS_READY,
                             model_type="PDM", complexity=classify_complexity(outcome.initial_result),
                             message=f"V1 fidelity {outcome.initial_result.fidelity_score:.2f}%")

    # Step 1 for the PDM: same injector, same target folder.
    xml_v2 = stages.xml_v2(record.base_name)
    if xml_v2.is_file() and xml_v2.stat().st_mtime >= xml_v1.stat().st_mtime:
        print(f"  -> Step 1 output already present: {xml_v2.name} (kept)")
        how = "existing"
    else:
        result = pdm_flow._inject_comments(outcome, str(model_path.resolve()), str(xml_v1), str(xml_v2))
        if result is None:
            print("  -> Step 1 (comments -> notes) did not run; see messages above.")
            return v1
        print(f"  -> Step 1 (comments -> notes): {result.summary()}")
        how = "converted"
    record.artefacts["xml_v2"] = str(xml_v2)
    record.artefacts["xml_v2_how"] = how
    stage_state.record_stage(dirs, record.base_name, stage_state.STAGE_XML_V2, stage_state.STATUS_READY,
                             model_type="PDM", artifact=xml_v2, artifact_kind="xml_v2", parent=str(xml_v1))
    erwin_in = stages.find_erwin_v1(record.base_name)
    stage_state.record_stage(dirs, record.base_name, stage_state.STAGE_ERWIN_HANDOFF,
                             stage_state.STATUS_VALIDATED if erwin_in else stage_state.STATUS_WAITING,
                             model_type="PDM", artifact=erwin_in, artifact_kind="erwin_v1", parent=str(xml_v2))
    return v1


def process_model(model_path, base_name, model_type, dirs, session_context=None):
    stages = StagePaths(dirs, model_type)
    record = ModelRecord(base_name=base_name, model_type=model_type)

    xml_v1 = locate_xml_v1(stages, base_name, model_type, dirs)
    if xml_v1 is None:
        pipeline_ledger.record_skip(dirs, base_name, model_type,
                                    f"XML V1 not found or invalid at {stages.describe('xml_v1', base_name)}",
                                    session_context=session_context)
        return None

    if model_type == "PDM":
        v1_score = _run_v1_pdm(record, model_path, xml_v1, stages, dirs)
    else:
        v1_score = _run_v1_conceptual(record, model_path, xml_v1, stages, dirs)
    if v1_score is None and record.initial_result is None:
        return None

    outdir = record.report_dir()
    v1_report_path = build_v1_report(record, outdir)
    record.v1_report_path = v1_report_path
    stage_state.save_v1(dirs, base_name, v1_report_path, v1_score)
    print(f"  -> V1 report: {v1_report_path or 'not generated'}")
    for line in stage_state.pending_actions(dirs, base_name):
        print(f"  -> NEXT (manual): {line}")
    return record


def main(argv=None):
    print("\nStage 1/3 — Fidelity V1 + Step 1 (PD comments -> erwin notes)\n")
    concurrency.clear_skipped_models()

    run = start_run("python -m app.run_v1", "Stage 1/3 - V1 fidelity and Step 1.", argv)
    dirs = setup_directories(run)
    models = find_models(dirs, mirror=True)   # PD copies for the UDP tool (never .erwin)
    if not models:
        print(f"No models found under {get_setting('SAMPLES_DIR', '')}.")
        return []

    print(f"Found {len(models)} model(s) to process.")
    records = []
    for index, model in enumerate(models, start=1):
        base_name = model.stem
        model_type = MODEL_TYPE_BY_SUFFIX.get(model.suffix.lower(), "LDM")
        print(f"\n{'=' * 60}\n--- [{index}/{len(models)}] {model_type}: {model.name} ---\n{'=' * 60}")
        try:
            record = process_model(model, base_name, model_type, dirs, run.session_context)
            if record is not None:
                records.append(record)
        except Exception as exc:                               # noqa: BLE001
            logger.exception("V1 stage failed for %s: %s", model.resolve(), exc)
            stage_state.record_stage(dirs, base_name, stage_state.STAGE_V1_FIDELITY, stage_state.STATUS_FAILED,
                                     model_type=model_type, message=f"{type(exc).__name__}: {exc}")

    skipped = concurrency.get_skipped_models()
    if skipped:
        print(f"\n{len(skipped)} model(s) skipped — awaiting manual erwin export or re-export:")
        for reason in skipped:
            print(f"  - {reason}")

    print("\nStage 1/3 complete. MANUAL STEP: open erwinmodels/2_preprocessed/<model>.xml in erwin, "
          "save as <model>.erwin into app/udp_tool/input_erwin_models/, then run run_udp.py.\n")
    return records


if __name__ == "__main__":  # pragma: no cover
    main()
