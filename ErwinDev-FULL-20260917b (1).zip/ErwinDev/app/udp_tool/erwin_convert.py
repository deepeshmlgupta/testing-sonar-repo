"""
erwin_convert.py
----------------
Convert one erwin model between its two on-disk forms through erwin Data
Modeler's SCAPI:

    XML V2    -> .ERWIN V1     (before Step 2 enrichment)
    .ERWIN V2 -> XML V3        (before Step 3 reconciliation)

The direction is taken from the file extensions. The script is Windows-only
(pywin32 + erwin Data Modeler installed) and is always launched as a
subprocess by app/erwin/erwin_converter.py, because importing pywin32 fails
everywhere else and because a wedged erwin session must not take the pipeline
down with it.

Known erwin limitation, inherited from erwin_load.py: loading an XML into an
erwin instance whose UI is hidden crashes erwin. So when the SOURCE is XML the
script requires an erwin window to already be open on the desktop and exits
with code 2 (not 1) if there is none, so the caller can fall back to waiting
for a manual conversion rather than treating it as a hard failure.

Exit codes:
    0  converted; the output file exists
    1  error (erwin not installed, load failed, save failed)
    2  cannot convert XML headless — open erwin on the desktop and retry
    3  bad arguments

Usage:
    python erwin_convert.py --in model.xml   --out model.erwin
    python erwin_convert.py --in model.erwin --out model.xml
"""

import argparse
import os
import stat
import sys
from pathlib import Path

EXIT_OK = 0
EXIT_ERROR = 1
EXIT_NEEDS_VISIBLE_UI = 2
EXIT_BAD_ARGS = 3

try:
    import pythoncom
    import win32com.client
except ImportError:
    print("erwin_convert: pywin32 is not installed; erwin COM automation is unavailable on this host.")
    sys.exit(EXIT_ERROR)

_ERWIN_CLSID = "{6774E2C3-06E9-4943-A8D4-E3007AB1F42E}"


def connect_scapi():
    """(scapi, is_visible): reuse an open erwin window if there is one, else start a hidden instance."""
    try:
        return win32com.client.GetActiveObject(_ERWIN_CLSID), True
    except Exception:                                          # noqa: BLE001
        try:
            return win32com.client.Dispatch(_ERWIN_CLSID), False
        except pythoncom.com_error as exc:
            print(f"erwin_convert: could not start erwin Data Modeler ({exc}). Is it installed?")
            sys.exit(EXIT_ERROR)


# Windows read-only attribute bit. os.access(..., os.W_OK) does NOT consult it
# reliably (it ignores NTFS ACLs entirely), so a file the user cannot write can
# read as writable and the chmod below would never run.
_FILE_ATTRIBUTE_READONLY = 0x0001


def _is_read_only(path: Path) -> bool:
    try:
        attrs = int(getattr(os.stat(path), "st_file_attributes", 0) or 0)
    except OSError:
        return False
    if attrs:
        return bool(attrs & _FILE_ATTRIBUTE_READONLY)
    return not os.access(path, os.W_OK)


def _clear_read_only(path: Path) -> bool:
    """
    Clear the read-only attribute. erwin refuses to OPEN a read-only file
    ("File exists and read only.") and cannot DELETE one when replacing an
    output — both common after Extract All from a zip or a OneDrive restore.
    Returns True when the file is writable afterwards; never raises.
    """
    try:
        if not path.exists() or not _is_read_only(path):
            return True
        os.chmod(path, stat.S_IWRITE | stat.S_IREAD)
        return not _is_read_only(path)
    except OSError as exc:
        print(f"erwin_convert: warning - could not clear read-only attribute on {path}: {exc}")
        return False


def _load_path(src: Path) -> str:
    # erwin requires the erwin:// scheme in front of an XML path.
    return f"erwin://{src}" if src.suffix.lower() == ".xml" else str(src)


def convert(src: Path, dst: Path) -> int:
    src = src.resolve()
    dst = dst.resolve()
    if not src.is_file():
        print(f"erwin_convert: source not found: {src}")
        return EXIT_ERROR
    if src.suffix.lower() not in (".xml", ".erwin") or dst.suffix.lower() not in (".xml", ".erwin"):
        print("erwin_convert: --in and --out must be .xml or .erwin files")
        return EXIT_BAD_ARGS

    pythoncom.CoInitialize()
    scapi, is_visible = connect_scapi()
    try:
        if src.suffix.lower() == ".xml" and not is_visible:
            print("erwin_convert: loading an XML with the erwin UI hidden crashes erwin. "
                  "Open erwin Data Modeler on the desktop and retry.")
            return EXIT_NEEDS_VISIBLE_UI

        _clear_read_only(src)
        print(f"erwin_convert: loading  {src}")
        unit = scapi.PersistenceUnits.Add(_load_path(src))

        dst.parent.mkdir(parents=True, exist_ok=True)
        if dst.exists():
            # Clear the attribute FIRST: a read-only target cannot be deleted,
            # and the old code reported that as "open or locked", which it
            # almost never was.
            cleared = _clear_read_only(dst)
            try:
                dst.unlink()
            except PermissionError:
                print(f"erwin_convert: cannot overwrite {dst} — "
                      + ("it is open in another process (erwin, a preview pane, a sync client)."
                         if cleared else
                         "it is read-only and the attribute could not be cleared."))
                return EXIT_ERROR

        if dst.suffix.lower() == ".xml" and not is_visible:
            # Same erwin limitation on the way out: Save As .xml needs the UI.
            print("erwin_convert: Save As .xml requires a visible erwin UI. "
                  "Open erwin Data Modeler on the desktop and retry.")
            return EXIT_NEEDS_VISIBLE_UI

        print(f"erwin_convert: saving   {dst}")
        unit.Save(str(dst))

        try:
            scapi.PersistenceUnits.Remove(unit)
        except Exception:                                      # noqa: BLE001
            pass

        if not dst.is_file() or dst.stat().st_size == 0:
            print(f"erwin_convert: erwin reported success but {dst} is missing or empty.")
            return EXIT_ERROR
        print(f"erwin_convert: done ({dst.stat().st_size} bytes)")
        return EXIT_OK
    except pythoncom.com_error as exc:
        print(f"erwin_convert: erwin COM error: {exc}")
        return EXIT_ERROR
    finally:
        try:
            pythoncom.CoUninitialize()
        except Exception:                                      # noqa: BLE001
            pass


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Convert an erwin model between .xml and .erwin via SCAPI.")
    ap.add_argument("--in", dest="src", required=True, help="source .xml or .erwin")
    ap.add_argument("--out", dest="dst", required=True, help="destination .erwin or .xml")
    args = ap.parse_args(argv)
    return convert(Path(args.src), Path(args.dst))


if __name__ == "__main__":
    sys.exit(main())
