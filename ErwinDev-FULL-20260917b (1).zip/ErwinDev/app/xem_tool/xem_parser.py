from __future__ import annotations

import csv
import json
import re
import xml.etree.ElementTree as ET  # nosec B405 - parsing is done by defusedxml below
from collections import Counter
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Iterable

from defusedxml.ElementTree import parse as safe_parse

SAFE_UDP = re.compile(r"[^A-Za-z0-9_]+")


def local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1].split(":")[-1]


def safe_udp_name(value: str) -> str:
    text = SAFE_UDP.sub("_", value.strip()).strip("_")
    return text or "Unnamed_UDP"


def child_text(element: ET.Element, *names: str) -> str:
    wanted = {n.lower() for n in names}
    for child in list(element):
        if local_name(child.tag).lower() in wanted:
            return (child.text or "").strip()
    return ""


def descendant_texts(element: ET.Element, *names: str) -> list[str]:
    wanted = {n.lower() for n in names}
    values: list[str] = []
    for child in element.iter():
        if child is element:
            continue
        if local_name(child.tag).lower() in wanted and (child.text or "").strip():
            values.append((child.text or "").strip())
    return values


def first_attr(element: ET.Element, *names: str) -> str:
    wanted = {n.lower() for n in names}
    for key, value in element.attrib.items():
        if local_name(key).lower() in wanted:
            return str(value).strip()
    return ""


@dataclass
class XEMDefinition:
    element_type: str
    object_id: str
    name: str
    code: str = ""
    data_type: str = ""
    length: str = ""
    precision: str = ""
    scale: str = ""
    default_value: str = ""
    description: str = ""
    applies_to: list[str] = field(default_factory=list)
    allowed_values: list[str] = field(default_factory=list)
    source_path: str = ""
    raw_attributes: dict[str, str] = field(default_factory=dict)


@dataclass
class XEMInventory:
    source_file: str
    root_element: str
    element_counts: dict[str, int]
    definitions: list[XEMDefinition]


class XEMParser:
    """Conservative, namespace-agnostic PowerDesigner XEM parser.

    XEM files vary by PowerDesigner version/profile. This parser deliberately
    inventories the XML generically and promotes likely extended-property
    definitions into structured records. It never claims a mapping is supported
    by erwin solely because it was discovered in XEM.
    """

    CANDIDATE_DEFINITION_NAMES = {
        "ExtendedAttributeType",
        "ExtendedAttribute",
        "ExtendedAttributeDefinition",
        "PropertyType",
        "BaseObject",
        "Extension",
        "Stereotype",
    }

    def parse(self, path: Path) -> XEMInventory:
        # defusedxml, like every other parser in this codebase: a .xem is a
        # supplier-provided file and stdlib ElementTree is vulnerable to
        # entity-expansion attacks (bandit B314).
        root = safe_parse(str(path)).getroot()
        counts = Counter(local_name(e.tag) for e in root.iter())
        definitions: list[XEMDefinition] = []

        for element in root.iter():
            element_type = local_name(element.tag)
            if not self._is_candidate(element, element_type):
                continue
            name = child_text(element, "Name", "Label", "Title") or first_attr(element, "Name", "Label")
            code = child_text(element, "Code", "TechnicalCode") or first_attr(element, "Code")
            if not name and not code:
                continue

            object_id = first_attr(element, "Id", "ObjectID", "ObjectId", "id")
            d = XEMDefinition(
                element_type=element_type,
                object_id=object_id,
                name=name or code,
                code=code,
                data_type=child_text(element, "DataType", "Type", "DataTypeName"),
                length=child_text(element, "Length", "Size"),
                precision=child_text(element, "Precision"),
                scale=child_text(element, "Scale"),
                default_value=child_text(element, "DefaultValue", "Default"),
                description=child_text(element, "Description", "Comment", "Definition"),
                applies_to=descendant_texts(element, "ObjectType", "Target", "AppliesTo"),
                allowed_values=descendant_texts(element, "Value", "Item", "AllowedValue", "ValueItem"),
                source_path=self._element_path(root, element),
                raw_attributes={local_name(k): str(v) for k, v in element.attrib.items()},
            )
            definitions.append(d)

        # De-duplicate exact same source definitions while retaining source path.
        unique: dict[tuple[str, str, str], XEMDefinition] = {}
        for item in definitions:
            key = (item.element_type, item.object_id, item.name)
            unique.setdefault(key, item)

        return XEMInventory(
            source_file=str(path),
            root_element=local_name(root.tag),
            element_counts=dict(sorted(counts.items())),
            definitions=list(unique.values()),
        )

    def _is_candidate(self, element: ET.Element, element_type: str) -> bool:
        if element_type in self.CANDIDATE_DEFINITION_NAMES:
            return True
        lowered = element_type.lower()
        return "extendedattribute" in lowered or lowered.endswith("propertytype")

    @staticmethod
    def _element_path(root: ET.Element, target: ET.Element) -> str:
        # ElementTree has no parent pointers; this compact path uses the
        # element type sequence and is intentionally stable enough for an audit.
        path: list[str] = []
        found = False

        def walk(node: ET.Element) -> Iterable[str]:
            nonlocal found
            path.append(local_name(node.tag))
            if node is target:
                found = True
                yield "/".join(path)
            else:
                for child in list(node):
                    yield from walk(child)
            path.pop()

        for result in walk(root):
            if found:
                return result
        return local_name(target.tag)


def inventory_to_json(inventory: XEMInventory, output: Path) -> None:
    payload = {
        "source_file": inventory.source_file,
        "root_element": inventory.root_element,
        "element_counts": inventory.element_counts,
        "definitions": [asdict(d) for d in inventory.definitions],
    }
    output.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def inventory_to_csv(inventory: XEMInventory, output: Path) -> None:
    headers = [
        "element_type", "object_id", "name", "code", "data_type", "length",
        "precision", "scale", "default_value", "description", "applies_to",
        "allowed_values", "source_path", "raw_attributes",
    ]
    with output.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=headers)
        writer.writeheader()
        for d in inventory.definitions:
            row = asdict(d)
            row["applies_to"] = " | ".join(d.applies_to)
            row["allowed_values"] = " | ".join(d.allowed_values)
            row["raw_attributes"] = json.dumps(d.raw_attributes, ensure_ascii=False)
            writer.writerow(row)
