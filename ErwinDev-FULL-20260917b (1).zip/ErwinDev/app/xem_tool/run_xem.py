"""Standalone PowerDesigner XEM -> erwin UDP preparation utility.

This tool does NOT import .xem directly into erwin. It inventories XEM,
creates a human-review mapping template, and emits an erwin-compatible UDP
schema for the mappings explicitly approved by the reviewer.

Examples:
    python -m app.xem_tool.run_xem --xem input_xem/BIM-core.xem --outdir xem_output
    python -m app.xem_tool.run_xem --xem input_xem/BIM-core.xem --outdir xem_output \
        --mapping xem_output/xem_to_erwin_mapping.csv
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from .xem_mapper import (
    build_mapping_template,
    load_mapping_csv,
    mapping_summary,
    rows_to_udp_schema,
    write_mapping_template,
    write_udp_schema,
)
from .xem_parser import XEMParser, inventory_to_csv, inventory_to_json


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--xem", type=Path, required=True, help="PowerDesigner .xem file")
    parser.add_argument("--outdir", type=Path, default=Path("xem_output"))
    parser.add_argument("--mapping", type=Path, help="Reviewed XEM mapping CSV; omit to create a review template")
    args = parser.parse_args(argv)

    if args.xem.suffix.lower() != ".xem":
        raise SystemExit("ERROR: --xem must point to a .xem file")
    if not args.xem.is_file():
        raise SystemExit(f"ERROR: XEM file not found: {args.xem}")

    args.outdir.mkdir(parents=True, exist_ok=True)
    inventory = XEMParser().parse(args.xem)
    inventory_to_json(inventory, args.outdir / "xem_inventory.json")
    inventory_to_csv(inventory, args.outdir / "xem_inventory.csv")

    template = build_mapping_template(inventory)
    template_path = args.outdir / "xem_to_erwin_mapping.csv"
    write_mapping_template(template, template_path)

    result = {
        "xem": str(args.xem.resolve()),
        "definitions_found": len(inventory.definitions),
        "element_types": inventory.element_counts,
        "mapping_template": str(template_path),
        "approved_mapping": None,
        "udp_schema": None,
        "status": "REVIEW_REQUIRED",
    }

    if args.mapping:
        if not args.mapping.is_file():
            raise SystemExit(f"ERROR: mapping file not found: {args.mapping}")
        rows = load_mapping_csv(args.mapping)
        schema = rows_to_udp_schema(rows)
        schema_path = args.outdir / "udp_schema_from_xem.json"
        write_udp_schema(schema, schema_path)
        result.update({
            "approved_mapping": str(args.mapping.resolve()),
            "udp_schema": str(schema_path),
            "mapping_summary": mapping_summary(rows),
            "status": "READY_FOR_ERWIN_UDP_DEFINITION",
        })

    (args.outdir / "xem_run_summary.json").write_text(
        json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    print(f"XEM definitions found: {len(inventory.definitions)}")
    print(f"Inventory: {args.outdir / 'xem_inventory.json'}")
    print(f"Mapping template: {template_path}")
    if args.mapping:
        print(f"erwin UDP schema: {args.outdir / 'udp_schema_from_xem.json'}")
    else:
        print("Next step: review the mapping CSV, then rerun with --mapping.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
