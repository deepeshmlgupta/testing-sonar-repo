from __future__ import annotations

import csv
import json
from pathlib import Path

from .xem_parser import XEMDefinition, XEMInventory, safe_udp_name

ALLOWED_STATUS = {
    "AUTO_UDP",
    "MANUAL_UDP",
    "NATIVE_ERWIN",
    "UNSUPPORTED",
    "REVIEW",
}


def _lookup(mapping: dict, definition: XEMDefinition) -> dict:
    # Matching precedence: object id, element type + name, then name.
    by_id = mapping.get("by_object_id", {})
    by_type_name = mapping.get("by_type_name", {})
    by_name = mapping.get("by_name", {})
    if definition.object_id and definition.object_id in by_id:
        return dict(by_id[definition.object_id])
    key = f"{definition.element_type}:{definition.name}"
    if key in by_type_name:
        return dict(by_type_name[key])
    if definition.name in by_name:
        return dict(by_name[definition.name])
    return {}


def build_mapping_template(inventory: XEMInventory) -> list[dict]:
    rows: list[dict] = []
    for d in inventory.definitions:
        configured = {
            "erwin_udp": safe_udp_name(d.name),
            "status": "REVIEW",
            "erwin_target_object": "Entity",
            "value_list": "",
            "notes": "Confirm XEM semantics and target erwin object type before injection.",
        }
        rows.append({
            "xem_element_type": d.element_type,
            "xem_object_id": d.object_id,
            "xem_name": d.name,
            "xem_code": d.code,
            "xem_data_type": d.data_type,
            "xem_length": d.length,
            "xem_precision": d.precision,
            "xem_scale": d.scale,
            "xem_default": d.default_value,
            "xem_applies_to": " | ".join(d.applies_to),
            **configured,
        })
    return rows


def rows_to_udp_schema(rows: list[dict]) -> list[dict]:
    schema: list[dict] = []
    for row in rows:
        status = str(row.get("status", "REVIEW")).upper().strip()
        if status not in ALLOWED_STATUS:
            raise ValueError(f"Unknown XEM mapping status: {status}")
        if status == "UNSUPPORTED":
            continue
        udp = str(row.get("erwin_udp") or "").strip()
        if not udp:
            raise ValueError(f"Missing erwin_udp mapping for XEM property {row.get('xem_name')}")
        schema.append({
            "udp": safe_udp_name(udp),
            "type": "List" if row.get("value_list") else "Text",
            "length": 1024,
            "value_list": [v.strip() for v in str(row.get("value_list") or "").split("|") if v.strip()],
            "source_path": f"XEM.{row.get('xem_name', '')}",
            "coverage": status,
            "list_source": "XEM - authoritative only if confirmed against source semantics",
            "purpose": f"PowerDesigner XEM property {row.get('xem_name', '')}",
            "target_object": row.get("erwin_target_object", "Entity"),
            "notes": row.get("notes", ""),
        })
    return schema


def write_mapping_template(rows: list[dict], path: Path) -> None:
    headers = list(rows[0].keys()) if rows else [
        "xem_element_type", "xem_object_id", "xem_name", "erwin_udp", "status",
        "erwin_target_object", "value_list", "notes",
    ]
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=headers)
        writer.writeheader()
        writer.writerows(rows)


def load_mapping_csv(path: Path) -> list[dict]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_udp_schema(schema: list[dict], path: Path) -> None:
    path.write_text(json.dumps(schema, indent=2, ensure_ascii=False), encoding="utf-8")


def mapping_summary(rows: list[dict]) -> dict[str, int]:
    summary = {key: 0 for key in sorted(ALLOWED_STATUS)}
    for row in rows:
        status = str(row.get("status", "REVIEW")).upper().strip()
        summary.setdefault(status, 0)
        summary[status] += 1
    return summary
