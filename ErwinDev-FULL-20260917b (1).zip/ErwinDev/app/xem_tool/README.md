# PowerDesigner XEM → erwin UDP Utility

This is a standalone helper for handling PowerDesigner `.xem` files.

It does **not** directly import `.xem` into erwin. Instead it:

1. Parses the XEM XML conservatively and namespace-independently.
2. Produces a complete element inventory and promoted extended-property definitions.
3. Produces a human-review mapping CSV from XEM properties to erwin UDPs.
4. Converts an approved mapping CSV into `udp_schema_from_xem.json`, which can be supplied to the existing erwin UDP tooling.

## Usage

From the repository root:

```powershell
python -m app.xem_tool.run_xem --xem path\to\BIM-core.xem --outdir xem_output
```

Review:

```text
xem_output/xem_inventory.json
xem_output/xem_inventory.csv
xem_output/xem_to_erwin_mapping.csv
```

Populate `status`, `erwin_udp`, `erwin_target_object`, `value_list`, and `notes` in the mapping CSV. Then:

```powershell
python -m app.xem_tool.run_xem `
  --xem path\to\BIM-core.xem `
  --outdir xem_output `
  --mapping xem_output\xem_to_erwin_mapping.csv
```

This creates:

```text
xem_output/udp_schema_from_xem.json
```

Only rows explicitly classified as `AUTO_UDP`, `MANUAL_UDP`, or `NATIVE_ERWIN` are emitted to the UDP schema. `UNSUPPORTED` is retained in the reviewed mapping but excluded from the injection schema.

## Important limitation

An XEM file normally defines extension/custom-property semantics; it does not by itself contain all object-level values that need to be assigned to an erwin model. Object values remain a separate source-model extraction concern. Therefore this utility intentionally stops at an auditable XEM definition → erwin UDP schema boundary.
