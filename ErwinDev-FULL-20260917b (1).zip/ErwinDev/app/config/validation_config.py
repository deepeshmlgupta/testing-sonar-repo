"""
Validation Configuration — per-tier rule sets
=============================================
Three tiers inherit from a shared base:

    _Shared    ── _Semantic ── CDM
               │            └─ LDM
               └── PDM

`tier("CDM"|"LDM"|"PDM")` returns a flattened, writable view of one tier's
settings. Nothing here is model-specific: a 100+ model batch reads the same
rule set for every model of a given type, and every path is supplied by
app/config/settings.py or the caller.
"""

from app.config import settings as _settings


def _s(name: str, default):
    """A settings value, or ``default`` when settings does not define it.

    Used only for values that also exist in settings.py, so that a folder name
    or an id is declared once there rather than re-typed here.
    """
    return getattr(_settings, name, default)


# Canonical folder names, resolved once so the composed paths below cannot
# drift from the stage folders the pipeline actually writes.
_ERWIN_DIR = str(_s("ERWIN_MODELS_DIRNAME", "erwinmodels"))
_STAGE_INITIAL = str(_s("STAGE_INITIAL_DIRNAME", "1_initial"))
_STAGE_PREPROCESSED = str(_s("STAGE_PREPROCESSED_DIRNAME", "2_preprocessed"))


class _Shared:

    # ─── PATHS ────────────────────────────────────────────────────────────────
    # app/main.py supplies all real paths. Blank = "not configured standalone".
    PD_MODELS_DIR = ""
    ERWIN_MODELS_DIR = ""
    OUTPUT_DIR = ""

    ERWIN_EXTENSIONS = [".xml", ".erwin"]

    # ─── MODEL MATCHING ───────────────────────────────────────────────────────
    # How a PowerDesigner file is paired with its erwin export:
    #   "filename"  → strip extension, match on same base name (Sales.ldm ↔ Sales.xml)
    #   "prefix"    → first PREFIX_LENGTH chars of base name
    #   "csv"       → use MAPPING_CSV to specify pairs explicitly
    MATCH_STRATEGY = "filename"

    MAPPING_CSV = ""

    CASE_INSENSITIVE = True

    CHECK_DATA_TYPES = True

    # ─── EXTENDED PROPERTY CHECKS (app/validation/extended_properties.py) ─────
    # Additive, INFO-severity checks for the properties the core engines do
    # not compare (defaults, domain bindings, RI rules, identifier names,
    # package contents, diagrams, owners, tablespaces, identity, triggers'
    # events, sequence parameters, DBMS target ...). Every check only fires
    # when the erwin export carries the vocabulary at all — an export that
    # never writes <Owner> cannot lose an owner — so a thin export is never
    # flooded. Master switch plus one toggle per check, all overridable per
    # tier below.
    CHECK_EXTENDED_PROPERTIES = True
    EXTENDED_PROPERTY_CHECKS = {
        # CDM / LDM
        "ATTRIBUTE_DEFAULT": True, "ATTRIBUTE_DOMAIN": True,
        "DOMAIN_NAME": True, "DOMAIN_LENGTH": True, "DOMAIN_DEFAULT": True, "DOMAIN_CHECK_PARAMS": True,
        "IDENTIFIER_NAME": True, "IDENTIFIER_MEMBER_ORDER": True,
        "RELATIONSHIP_RI_RULE": True, "INHERITANCE_NAME": True, "BUSINESS_RULE_TYPE": True,
        "PACKAGE_DEFINITION": True, "PACKAGE_HIERARCHY": True, "PACKAGE_CONTENTS": True,
        "DIAGRAM": True, "MODEL_DEFINITION": True,
        # PDM
        "TABLE_LOGICAL_NAME": True, "TABLE_OWNER": True, "TABLE_TABLESPACE": True,
        "COLUMN_LOGICAL_NAME": True, "COLUMN_DOMAIN": True, "COLUMN_CHECK_CONSTRAINT": True, "COLUMN_IDENTITY": True,
        "KEY_NAME": True, "INDEX_NAME": True, "INDEX_SORT_ORDER": True,
        "REFERENCE_NAME": True, "REFERENCE_CARDINALITY": True,
        "VIEW_COLUMNS": True, "TRIGGER_EVENT": True, "TRIGGER_TABLE": True, "SEQUENCE_PARAMS": True,
        "OBJECT_DEFINITION": True,   # view / procedure / trigger / sequence / tablespace comments
        "DOMAIN_OBJECT": True, "BUSINESS_RULE_OBJECT": True, "DEFAULT_OBJECT": True,
        "DATA_FORMAT": True, "DATABASE_TARGET": True,
    }
    # Referential-integrity rule codes. PowerDesigner writes numeric
    # UpdateConstraint / DeleteConstraint values on a Relationship or
    # Reference; erwin writes Parent_Update_Rule / Parent_Delete_Rule (per
    # relationship, or as model-level defaults keyed by relationship kind).
    # The two vocabularies are joined through these maps; a code missing
    # from either map is reported as "unmapped" instead of as a mismatch.
    # PD codes follow the PowerDesigner metamodel (ReferenceConstraint enum).
    PD_RI_RULE_CODES = {"0": "NONE", "1": "RESTRICT", "2": "CASCADE", "3": "SET NULL", "4": "SET DEFAULT"}
    # PROVISIONAL — derived from erwin's model defaults in the sample export
    # (identifying → 10000/10004, non-identifying → 10002/10006, subtype →
    # 10001/10005) and erwin's documented default actions (identifying:
    # cascade, non-identifying nullable: set null, subtype: restrict). Verify
    # against a relationship whose RI action was set by hand before relying
    # on a RELATIONSHIP_RI_RULE finding as a defect.
    ERWIN_RI_RULE_CODES = {
        "update": {"0": "NONE", "10000": "CASCADE", "10001": "RESTRICT", "10002": "SET NULL", "10003": "SET DEFAULT"},
        "delete": {"0": "NONE", "10004": "CASCADE", "10005": "RESTRICT", "10006": "SET NULL", "10007": "SET DEFAULT"},
    }

    FIDELITY_WEIGHTS = {
        "CRITICAL": 1.0,
        "WARNING": 0.35,
        "INFO": 0.05,
    }
    FIDELITY_MAX_PENALTY_PER_OBJECT = 1.0

    # ─── UDP SCORING RULES ────────────────────────────────────────────────────
    # Both values below are FLOORS/CEILINGS that were suppressing honest scores.
    #
    # V1_UDP_BASELINE_WHEN_UNMIGRATED: a floor applied to the V1 UDP component
    # when SAP PD carries UDPs but none have been migrated yet. It LIFTED V1,
    # which hides the very gap V1 exists to report (the CDM read 62.59 with the
    # floor, 47.59 without). None = no floor: V1 reports what was measured.
    V1_UDP_BASELINE_WHEN_UNMIGRATED = None
    #
    # NO_UDP_FIDELITY_CAP: a ceiling applied when a model has NO UDPs at all
    # (SAP PD UDP = 0, erwin UDP = 0, matched = 0). At 60.0 it capped such a
    # model at 60% — a penalty for metadata the model never had, which is
    # exactly what must not happen. None = no cap: the UDP component is dropped
    # and the remaining weights are renormalised, so "nothing to migrate" has
    # no negative effect on the score.
    NO_UDP_FIDELITY_CAP = None

    # ─── PERFORMANCE ──────────────────────────────────────────────────────────
    MAX_WORKERS = 8

    # ─── REPORT SETTINGS ──────────────────────────────────────────────────────
    # Limit detail rows per model in Excel (0 = unlimited)
    MAX_DIFF_ROWS_PER_MODEL = 500


    # ─── UDP FIDELITY (app/validation/udp_fidelity.py) ────────────────────────
    # Scores SAP PD Extended Attributes against the UDPs the erwin XML export
    # carries, and blends that into the fidelity score. Setting
    # UDP_FIDELITY_ENABLED = False removes the layer's effect entirely.
    UDP_FIDELITY_ENABLED = True
    UDP_FIDELITY_WEIGHT = 0.20            # overall = structural x 0.8 + UDP x 0.2
    UDP_FIDELITY_AFFECTS_PROMOTION_GATE = False
    UDP_UNPOPULATED_VALUES = ("", "<unspecified>", "<none>", "<undefined>")
    UDP_COMPARE_IGNORE_CASE = False
    UDP_MAX_DETAIL_ROWS = 5000            # per model, on the UDP_DETAIL sheet

    # ─── UDP ENGINE / PHASE D (app/validation/udp_flow.py) ────────────────────
    # Runs the standalone UDP tool (app/udp_tool) as a phase of app/main.py:
    #   1a classify + baseline   1b schema + manifest
    #   2  inject into .erwin    3 mapping workbook    4 read-back comparison
    #
    # The intended flow is V1 -> UDP injection -> preprocessing -> V2 -> V3 in
    # ONE pipeline run, so the phase is on by default. Every step degrades
    # gracefully: extraction and mapping are pure Python; injection (Phase 2)
    # needs Windows + erwin Data Modeler + pywin32 and records why it was
    # skipped otherwise; the read-back comparison runs only when a .erwin
    # binary exists. Set False to skip the phase entirely, in which case V2
    # and V3 fall back to udp_tool workbooks already present in
    # UDP_TOOL_REPORT_DIR — but only when those workbooks name entities of
    # THIS model (see udp_helpers.workbook_belongs_to_model); a workbook left
    # behind by a different model is ignored rather than scored as 0%.
    UDP_TOOL_ENABLED = True
    # Phase 2 needs Windows + erwin Data Modeler + pywin32. When they are not
    # present the phase records why and continues to phases 3 and 4, which read
    # whatever is on disk.
    UDP_TOOL_INJECT_ENABLED = True
    # "bare"      erwin UDP name = PD_ObjectID          (matches udp_fidelity)
    # "qualified" erwin UDP name = Entity.Logical.PD_ObjectID  (tool default)
    # Bare naming is used here because udp_fidelity.py strips a single owner
    # prefix, so a qualified name never matches its PowerDesigner counterpart.
    UDP_TOOL_NAME_STYLE = "bare"
    UDP_TOOL_READBACK_METHOD = "auto"     # auto | com | binary
    # Per-model working directory. The standalone tool shares one baseline
    # folder across a batch, which is safe only because it runs strictly
    # sequentially; inside the pipeline loop each model gets its own.
    UDP_TOOL_WORKDIR = "data/udp"
    # PowerDesigner repository extraction id — last-resort default only; the
    # model's own header value wins wherever it is known. Declared in
    # settings.UDP_EXTRACTION_ID so the udp_flow and erwin_prepare fallbacks
    # cannot disagree with this one.
    UDP_TOOL_EXTRACTION_ID = str(_s("UDP_EXTRACTION_ID", "46603045"))
    UDP_TOOL_TIMEOUT_SECONDS = 1800
    UDP_TOOL_REQUIRE_ERWIN_BINARY = False
    # Where the source .erwin binary is looked for, in order.
    UDP_TOOL_ERWIN_INPUT_DIRS = (
        f"{_ERWIN_DIR}/{_STAGE_INITIAL}",
        "app/udp_tool/input_erwin_models",
    )
    # Where the binary to READ BACK is looked for, in order: this run's injected
    # output first, then any previously injected model, then the raw input.
    UDP_TOOL_ERWIN_READBACK_DIRS = (
        f"{_ERWIN_DIR}/{_STAGE_PREPROCESSED}",
        "app/udp_tool/output_erwin_models",
        f"{_ERWIN_DIR}/{_STAGE_INITIAL}",
        "app/udp_tool/input_erwin_models",
    )
    # The UDP tool's own raw workbooks stay in its existing report folder.
    UDP_TOOL_REPORT_DIR = "app/udp_tool/output_excel_reports"

    # ─── SHORTCUTS -> UDPs (app/validation/shortcut_udp.py) ───────────────────
    # erwin has no shortcut object, so PowerDesigner Shortcuts used to be
    # censused and then dropped (sow_classify counted them as facts_lost).
    # They are now carried as UDPs, through the same injector, read-back and
    # comparison workbook as every other UDP — additive rows on udp_schema.json
    # and property_manifest.json, with app/udp_tool left untouched.
    UDP_TOOL_INCLUDE_SHORTCUTS = True

    # Collections holding shortcut DEFINITIONS. ExternalObjects is the
    # modeller's "List of Shortcuts" and is what the reconcile parsers read —
    # but it is ABSENT from both real LDMs, whose content is entirely in the
    # glossary collections below (18 and 163 Term shortcuts). Excluding those
    # was why shortcuts_pd read 0 on models that plainly carry them.
    SHORTCUT_COLLECTIONS = ("ExternalObjects", "TermObjects", "SessionShortcuts")

    # Collections holding the per-object glossary BINDINGS — the migratable
    # fact ("this entity's name is built from these glossary terms"). In
    # real_estate: 102 of 105 entities, 797 term references.
    SHORTCUT_BINDING_COLLECTIONS = ("RelatedNameTerms", "RelatedCodeTerms")

    # Longest UDP value written; longer text is truncated with a visible mark
    # rather than being silently cut by erwin.
    SHORTCUT_UDP_MAX_LENGTH = 1024

    # ─── STAGED FIDELITY V1 -> V2 -> V3 (app/validation/fidelity_stages.py) ───
    # Every stage is measured against a DIFFERENT erwin artefact and every
    # component recomputed; nothing is carried forward.
    #   V1  vs erwinmodels/1_initial/xml       raw export: no comments, no UDPs
    #   V2  vs erwinmodels/2_preprocessed/xml  after Comments/Notes or repairs
    #   V3  vs the FINAL validated erwin XML   (settings.FINAL_XML_DIR)
    # Components with nothing to measure for a given model are dropped and the
    # remaining weights renormalised, so a model is never penalised for
    # metadata it never had.
    FIDELITY_STAGE_WEIGHTS = {
        "structural": 0.50,
        "documentation": 0.25,
        "udp": 0.25,
        # Shortcuts and Tags are measured only when the element names below are
        # configured AND the model actually carries them. Left at 0.0 they are
        # excluded from the weighting entirely (see _weights()), so the default
        # behaviour is unchanged and no invented number enters the score.
        "shortcuts": 0.0,
        "tags": 0.0,
        # Workstreams 1/5/7 (hierarchy, relationship semantics, vendor
        # datatypes) are measured only when their ENABLE_* flag is on AND the
        # comparator populated the corresponding result attribute. Left at 0.0
        # they are excluded from the weighting entirely, so enabling a check
        # without also raising its weight here has no effect on fidelity_score.
        "hierarchy": 0.0,
        "relationship_semantic": 0.0,
        "datatype": 0.0,
    }

    # ─── SHORTCUT / TAG MEASUREMENT (config-driven, nothing hard-coded) ───────
    # erwin's XML export has no single agreed element for either construct, and
    # it differs between erwin versions and export options. Rather than guess,
    # both sides are counted by element local-name from the lists below.
    #
    # To start scoring shortcuts: open a FINAL validated erwin XML, find the
    # element that carries them, add its local name here, and give "shortcuts"
    # a non-zero weight above. The same applies to Tags. While a list is empty
    # the component measures None and is dropped, and the report says
    # "not measured" instead of implying zero.
    SHORTCUT_ERWIN_ELEMENTS = ()
    SHORTCUT_PD_ELEMENTS = ("Shortcut",)
    TAG_ERWIN_ELEMENTS = ()
    TAG_PD_ELEMENTS = ()

    # ─── REPORTS (app/reporting/) ─────────────────────────────────────────────
    # Each model gets its own folder inside its model type's reporting folder,
    # holding its V1 initial, V2 UDP mapping and V3 final reports.
    V3_REPORT_ENABLED = True
    # Sheets the consolidated V3 report must never carry. V3_OVERVIEW and
    # V2_OVERVIEW are no longer produced at all; they stay listed so a workbook
    # assembled from an older report cannot reintroduce them.
    V3_REPORT_EXCLUDE_SHEETS = ("V3_OVERVIEW", "V2_OVERVIEW")

    # ─── V2 / V3 UDP WORKBOOK DISCOVERY ───────────────────────────────────────
    # The V2 content is the udp_tool's own workbooks. They are found in
    # UDP_TOOL_REPORT_DIR (and its per-tier sub-folders) by matching the model
    # name against these filename suffixes. A live Phase D run still takes
    # precedence when it produced the paths itself.
    UDP_MIGRATION_REPORT_SUFFIXES = ("_udp_migration_report", "_UDP_Migration_Report")
    UDP_COMPARISON_REPORT_SUFFIXES = ("_udp_comparison", "_UDP_Comparison")
    # Optional model -> udp-workbook-basename map, for estates where the UDP
    # workbook is not named after the source model. JSON object or two-column
    # CSV. Empty = resolve by name (exact, then punctuation/case-insensitive,
    # then unique prefix).
    UDP_REPORT_MAP = ""

# ══════════════════════════════════════════════════════════════════════════════
#  _Semantic — the 41 settings CDM and LDM share and PDM has no use for.
#
#  Both tiers reconcile a *business vocabulary*: entities, attributes,
#  identifiers, relationships, cardinality, inheritance, domains, business rules.
#  A physical model has tables and columns instead, so none of this applies to
#  PDM and none of it is inherited by it.
#
#  Layers protected:
#      STRUCTURE   entities, attributes, identifiers
#      SEMANTICS   relationships, cardinality, optionality, inheritance
#      VOCABULARY  business names, definitions, domains
#      GOVERNANCE  business rules, subject areas, model-quality rules
# ══════════════════════════════════════════════════════════════════════════════
class _Semantic(_Shared):

    # ─── MODEL MATCHING ───────────────────────────────────────────────────────
    PREFIX_LENGTH = 8

    # ─── OBJECT MATCHING ──────────────────────────────────────────────────────
    # These models are keyed on *business* vocabulary, and the two tools do not
    # agree on where that vocabulary lives:
    #
    #   PowerDesigner   Name = "Customer Master (KNA1)"   Code = "KNA1"
    #   erwin logical   Name = "Customer Master (KNA1)"   Physical_Name = "KNA1"
    #
    #   "code"        → match on Code / Physical_Name only
    #   "name"        → match on business Name only
    #   "normalized"  → strip case, spaces, underscores, hyphens, plural "s"
    #   "auto"        → try code, then name, then normalized (recommended)
    ENTITY_MATCH_KEY = "auto"
    ATTRIBUTE_MATCH_KEY = "auto"

    # When an object matches only on a fallback key (e.g. normalized name rather
    # than code), raise a finding so the rename is visible instead of silent.
    REPORT_FALLBACK_MATCHES = True

    # Strip a trailing plural "s" during normalized matching (CUSTOMER ↔ CUSTOMERS).
    NORMALIZE_PLURALS = True

    # ─── VALIDATION TOGGLES : STRUCTURE ───────────────────────────────────────
    CHECK_ENTITIES = True
    CHECK_ATTRIBUTES = True
    CHECK_PRIMARY_IDENTIFIERS = True
    CHECK_ALTERNATE_IDENTIFIERS = True
    CHECK_ATTRIBUTE_ORDER = False        # Attribute order is rarely governed
    CHECK_ATTRIBUTE_MULTIPLICITY = True  # logical min/max occurrences

    # ─── VALIDATION TOGGLES : SEMANTICS ───────────────────────────────────────
    CHECK_RELATIONSHIPS = True
    CHECK_CARDINALITY = True
    CHECK_OPTIONALITY = True             # mandatory / optional at each relationship end
    CHECK_DEPENDENCY = True              # identifying (dependent) vs non-identifying
    CHECK_ROLE_NAMES = True              # verb phrases in both directions
    CHECK_RELATIONSHIP_DOMINANCE = True  # parent-child directional dominance
    CHECK_INHERITANCE = True             # generalisation / supertype-subtype trees
    CHECK_ASSOCIATIONS = True            # many-to-many associations / associative entities
    CHECK_MANDATORY_ATTRS = True         # attribute-level mandatory flag
    # erwin attribute-level <Null_Option_Type> codes — a separate code set from
    # the relationship-level field of the same name. Value = "nulls allowed"
    # (optional). Shared by the CDM and LDM erwin parsers.
    ERWIN_ATTRIBUTE_NULL_OPTION_CODES = {
        "1": False,   # not null      -> mandatory
        "0": True,    # nulls allowed -> optional
    }
    ENABLE_SEMANTIC_RELATIONSHIP_MATCHING = True

    # ─── VALIDATION TOGGLES : VOCABULARY ──────────────────────────────────────
    CHECK_BUSINESS_NAMES = True          # Name differs while Code matches (or vice-versa)
    CHECK_DEFINITIONS = True             # Comment / Description / Definition text
    CHECK_DOMAINS = True                 # domain (reusable semantic type) assignment

    # Definitions are prose; require this much similarity before flagging a change.
    # 1.0 = must be identical, 0.0 = never flag. 0.90 tolerates whitespace/casing.
    DEFINITION_SIMILARITY_THRESHOLD = 0.90
    DEFINITION_HIGH_SIMILARITY_THRESHOLD = 0.85
    DEFINITION_PARTIAL_SIMILARITY_THRESHOLD = 0.50

    # Flag attributes/entities that have a definition on one side and none on the
    # other. Definition loss is the most common silent migration defect.
    FLAG_DEFINITION_LOSS = True

    # ─── VALIDATION TOGGLES : GOVERNANCE ──────────────────────────────────────
    CHECK_BUSINESS_RULES = True
    CHECK_SUBJECT_AREAS = True           # package / subject-area membership
    CHECK_MODEL_QUALITY = True           # orphan entities, entities without identifiers
    CHECK_MODEL_METADATA = True          # model name, code and declared type

    # ─── ROADMAP ENHANCEMENTS (feature-flagged, additive, off by default) ─────
    # Each flag below extends an existing check with a new capability. Leaving
    # it False reproduces the exact pre-enhancement behaviour and output.
    #
    # Recursive package/subject-area tree reconciliation (full ancestor path,
    # depth, missing-ancestor detection) on top of the existing single-level
    # parent-name check. See app/validation/hierarchy_reconciler.py.
    ENABLE_HIERARCHY_RECONCILIATION = False
    #
    # AST-based semantic comparison of business rule expressions ("Amount > 0"
    # == "0 < Amount") instead of raw-text-only comparison, applied only when
    # the existing text comparison already found a difference.
    # See app/validation/business_rule_{parser,normalizer,comparator}.py.
    ENABLE_RULE_SEMANTIC_VALIDATION = False
    #
    # Reclassifies a relationship pair that a name/endpoint match could not
    # pair as a direction reversal ("Customer -> Order" vs "Order -> Customer")
    # instead of one CRITICAL "missing" + one WARNING "extra" finding.
    # See app/validation/relationship_{orientation_analyzer,direction_reconciler}.py.
    ENABLE_DIRECTION_RECONCILIATION = True
    #
    # Recursively validates an external shortcut's target (entities,
    # attributes, domains, relationships, inheritance) when the referenced
    # model file can be located; a missing target is a WARNING, not a failure.
    # See app/validation/external_model_resolver.py, shortcut_validator.py.
    ENABLE_EXTERNAL_SHORTCUT_VALIDATION = False
    #
    # Unified semantic classification of a relationship (identifying /
    # non-identifying, weak entity, mandatory/optional participation) blended
    # into one "Relationship Semantic Fidelity" score per model.
    # See app/validation/relationship_semantic_score.py.
    ENABLE_RELATIONSHIP_SEMANTIC_VALIDATION = True
    #
    # Semantic vocabulary mapping between SAP PD's Dependent/Independent and
    # erwin's Identifying/Non-Identifying, plus a retry against the other
    # erwin end before a direction reversal is reported as a real dependency
    # mismatch. See app/validation/relationship_dependency_mapper.py.
    ENABLE_DEPENDENCY_SEMANTIC_RECONCILIATION = True
    #
    # Before reporting the model Code as mismatched, checks whether the SAP
    # PD value is traceable under erwin's Model Name or a migrated MODEL-level
    # UDP value. See app/validation/model_metadata_resolver.py.
    ENABLE_MODEL_METADATA_RESOLUTION = True

# ERwin XML stores relationship and entity enum values as numeric codes instead of readable text.
# These mappings convert the codes into meaningful values; unknown codes raise a warning instead of being guessed.
# For relationship cardinality, negative codes represent predefined options, while positive values mean "Exactly n".
    # erwin SCAPI <Cardinality> codes on a relationship (the child / "many" end):
    #   -3  Zero, One or More   (0..*)   erwin's default
    #   -2  One or More  (P)    (1..*)
    #   -1  Zero or One  (Z)    (0..1)
    #   n>0 Exactly n
    # "-2" was previously mapped to "0,n" on the strength of a single
    # observation. Cross-checking the Vessel LDM (24 relationships) showed every
    # erwin -2 paired with a PowerDesigner "1..n" and every -3 with a "0..n",
    # with no counter-example; the old mapping produced a false OPTIONALITY
    # warning plus a RELATIONSHIP_SEMANTIC_MISMATCH for every "one or more"
    # relationship in the model.
    ERWIN_CARDINALITY_CODES = {
        "-3": "0,n",   # Zero, One or More  (0..*)
        "-2": "1,n",   # One or More        (1..*)  (P)
        "-1": "0,1",   # Zero or One        (0..1)  (Z)
    }

    # PowerDesigner LDM <a:DependentRole> / <a:DominantRole> hold "A" or "B".
    # Observed on the Vessel LDM: every relationship with DependentRole = "B"
    # is the one erwin exported as Type=2 (identifying) with Entity1 as the
    # child, so "B" marks end 1 (Entity1) as the dependent end and "A" marks
    # end 2 (Entity2). Override here if a model uses the opposite convention.
    PD_DEPENDENT_ROLE_ENDS = {"B": 1, "A": 2}

    # Relationship <Null_Option_Type>: does the child end permit nulls?
    ERWIN_NULL_OPTION_CODES = {
        "101": False,  # nulls NOT allowed -> child participation mandatory
        "100": True,   # nulls allowed     -> child participation optional
    }

    # Relationship <Type>. 4 and 9 are established empirically (every Type=4
    # matched a PowerDesigner M:N; every Type=9 lacks verb phrases and has no
    # PowerDesigner counterpart, which is how erwin encodes a subtype). 2 vs 7
    # are both ordinary parent-child relationships; identifying-ness no longer
    # affects cardinality because Null_Option_Type supplies it directly.
    ERWIN_RELATIONSHIP_TYPE_CODES = {
        "2": "IDENTIFYING",
        "7": "NON_IDENTIFYING",
        "4": "MANY_TO_MANY",
        "9": "SUBTYPE",
    }

    # Treat erwin Type=9 relationships as inheritance rather than as
    # relationships. Leaving them in the relationship list reports each one as
    # EXTRA_IN_ERWIN.
    ERWIN_SUBTYPE_AS_INHERITANCE = True

    # If every relationship in the model resolves to the same cardinality, the
    # validator suspects erwin's values never reached the parser. Real models
    # vary; a constant is the signature of a parse failure.
    ERWIN_FLAG_COLLAPSED_CARDINALITY = True

    # ─── TYPE COMPARISON ──────────────────────────────────────────────────────
    # erwin logical models frequently carry only four coarse logical types
    # (Text / Number / Datetime / Blob) while PowerDesigner keeps a richer set
    # (VA, LA, I, LI, DC, F, MN, D, DT, TS …). Comparing those strictly produces
    # thousands of false positives, so choose the strictness you want:
    #
    #   "exact"      → raw strings must match after trimming
    #   "canonical"  → map both sides to a canonical type
    #                  (VA→VARCHAR, LA→LONG_CHAR, I→INTEGER, DC→DECIMAL …)
    #   "family"     → map both sides to a broad family
    #                  (TEXT | NUMBER | TEMPORAL | BOOLEAN | BINARY | OTHER)
    #
    # "family" is the recommended default: it avoids false mismatches when the
    # two tools use different names for essentially the same type. LDM narrows
    # this further with PD_TO_ERWIN_APPROVED_TYPES.
    TYPE_COMPARISON_MODE = "family"

    # Compare declared length / precision when both sides supply them. Where
    # either side is silent the check is skipped rather than failed.
    CHECK_LENGTH_PRECISION = True

# Controls the severity of finding categories without changing the validation code.
# Only exceptions are listed here; anything not listed uses the default severity.
# Valid values are CRITICAL, WARNING, INFO, or IGNORE.
# This allows known migration differences to be downgraded instead of disabling the check.
# LDM overrides specific findings such as IDENTIFIER_UNDERSPECIFIED and IDENTIFYING_KEY_MIGRATION to INFO.
# PRIMARY_IDENTIFIER remains CRITICAL so genuine key/identity loss is still reported as a failure.

    SEVERITY_OVERRIDES = {}

    # Models scoring below this are flagged for mandatory manual review.
    # PDM deliberately uses a lower bar; see PDM.FIDELITY_REVIEW_THRESHOLD.
    FIDELITY_REVIEW_THRESHOLD = 95.0

    # ─── EXCLUSIONS ───────────────────────────────────────────────────────────
    # Entities / attributes whose name or code matches any of these regexes are
    # ignored on both sides (staging scaffolding, tool-generated artefacts, …).
    EXCLUDE_ENTITY_PATTERNS = [
        # r"^TMP_",
        # r"_BAK$",
    ]
    EXCLUDE_ATTRIBUTE_PATTERNS = [
        # r"^ZZ_",
    ]

    # ─── PERFORMANCE ──────────────────────────────────────────────────────────
    # Save a resume checkpoint every N completed pairs
    CHECKPOINT_EVERY = 100

    # ─── REPORT SETTINGS ──────────────────────────────────────────────────────
    # Emit per-model detail sheets only when the run is this size or smaller.
    # Above this, the FINDINGS sheet remains complete and authoritative.
    MAX_MODELS_FOR_DETAIL_SHEETS = 200

    # Additional machine-readable exports alongside the workbook
    EXPORT_FINDINGS_CSV = False
    EXPORT_JSON_SUMMARY = False

    # Excel body font. Report headers always use bold white on navy.
    REPORT_FONT = "Calibri"


# ══════════════════════════════════════════════════════════════════════════════
#  CDM — Conceptual Data Model
#  Inherits _Semantic. Only what is CDM-specific appears below.
#  A CDM carries semantics, not storage: no foreign keys, no physical types.
# ══════════════════════════════════════════════════════════════════════════════
class CDM(_Semantic):

    PD_EXTENSIONS = [".cdm", ".xml"]
    REPORT_FILENAME = "cdm_validation_report.xlsx"

    # A conceptual model is a business vocabulary; shortcuts to objects owned
    # by other models are a workspace-organisation concern, not a conceptual
    # one, so the CDM report neither counts nor lists them.
    CHECK_SHORTCUTS = False

    # ─── ERWIN KEY MIGRATION ──────────────────────────────────────────────────
# ERWIN may automatically migrate parent key attributes to child entities, while PowerDesigner CDM does not.
# This setting controls whether those migrated attributes are ignored, logged as INFO, or treated as extra attributes;
# LDM uses "relationship" because it handles identifying relationship key migration.

    ERWIN_MIGRATED_KEY_HANDLING = "ignore"

#   # ERWIN may automatically add parent key members to a child's PK, while PowerDesigner only does this for Dependent relationships.
# This setting controls whether such migrated keys are treated as expected migration differences or reported as PRIMARY_IDENTIFIER issues.

    RECOGNISE_ERWIN_KEY_MIGRATION = True

# ERWIN may add parent key members to a child's PK, while PowerDesigner does this only for Dependent relationships.
# This setting decides whether these migrated keys are treated as expected differences or as PRIMARY_IDENTIFIER issues.
    REPORT_ERWIN_INVERSION_ENTRIES = True


# ══════════════════════════════════════════════════════════════════════════════
#  LDM — Logical Data Model
#  Inherits _Semantic. Only what is LDM-specific appears below.
#  An LDM adds the beginnings of storage detail: identifiers are expected to be
#  fully populated, relationships carry dependency, data types are governed.
# ══════════════════════════════════════════════════════════════════════════════
class LDM(_Semantic):

    PD_EXTENSIONS = [".ldm", ".xml"]
    REPORT_FILENAME = "ldm_validation_report.xlsx"

    # Logical models routinely reference shared models (glossary categories,
    # entities of a core model), so PD's "List of Shortcuts" is reported —
    # one FINDINGS row per shortcut, and nothing at all when there are none.
    CHECK_SHORTCUTS = True

# # ERwin migrates parent keys into child entities for identifying relationships, which PD LDM also supports.
# Therefore, only keys migrated through non-identifying relationships are treated as differences.
# "ignore"/"relationship"/"info" handle these as expected migration behavior; "strict" reports them as extra attributes.
# CDM uses "ignore" because CDM does not migrate keys.

    ERWIN_MIGRATED_KEY_HANDLING = "relationship"

    # Which erwin key groups to skip during comparison because erwin generates
    # them automatically and they have no SAP PD LDM counterpart. When erwin
    # creates a migrated foreign key from a relationship it can also create an
    # IF key group.
    ERWIN_IGNORED_KEY_GROUP_TYPES = ("IE", "INVERSION ENTRY", "INDEX",
                                     "IF", "IF1", "IF2", "IF3", "IF4", "IF5")

# # Defines the approved PowerDesigner → ERwin data type mappings used before the general comparison rules.
# Only listed equivalents are accepted; other types must match exactly or are reported as DATA_TYPE mismatches.

    PD_TO_ERWIN_APPROVED_TYPES = {
        "CHAR": {"CHAR"},
        "VARCHAR": {"VARCHAR"},
        "TEXT": {"LONG_TEXT", "CLOB", "TEXT", "LONGTEXT"},
        "INTEGER": {"INTEGER"},
        "SMALLINT": {"SMALLINT"},
        "BIGINT": {"BIGINT"},
        "DECIMAL": {"DECIMAL"},
        "DATE": {"DATE"},
        "TIME": {"TIME"},
        "TIMESTAMP": {"TIMESTAMP"},
        "BINARY": {"BINARY"},
        "VARBINARY": {"VARBINARY"},
        "BOOLEAN": {"BOOLEAN", "BIT", "BOOL"},
        "XML": {"XML"},
    }

    # Business requirement: a length/precision mismatch on an otherwise
    # type-matching attribute (e.g. DECIMAL(10,2) vs DECIMAL(12,4)) must be
    # visible as a WARNING, not the framework's INFO default. This is the only
    # tier that overrides the empty _Semantic.SEVERITY_OVERRIDES.
    SEVERITY_OVERRIDES = {
        "LENGTH_PRECISION": "WARNING",
    }


# ══════════════════════════════════════════════════════════════════════════════
#  PDM — Physical Data Model
#  Inherits _Shared only: none of the _Semantic entity/relationship vocabulary
#  applies to tables and columns.
#
#  This tier's engine reads its settings with getattr() defaults and uses an
#  EXHAUSTIVE severity table rather than sparse overrides.
# ══════════════════════════════════════════════════════════════════════════════
class PDM(_Shared):

    PD_EXTENSIONS = [".pdm"]

    # The PDM bridge REASSIGNS this at runtime so the pipeline can name the
    # workbook to match its other reports. It must stay a plain writable
    # attribute.
    REPORT_FILENAME = "validation_report.xlsx"

    # ─── VALIDATION TOGGLES ───────────────────────────────────────────────────
    # CHECK_DATA_TYPES is inherited from _Shared.
    CHECK_TABLES = True
    CHECK_COLUMNS = True
    CHECK_NULLABILITY = True
    CHECK_DEFAULT_VALUES = True
    CHECK_PRIMARY_KEYS = True
    CHECK_FOREIGN_KEYS = True
    CHECK_INDEXES = True
    CHECK_VIEWS = True
    CHECK_PROCEDURES = True
    CHECK_TRIGGERS = True
    CHECK_SEQUENCES = True
    CHECK_TABLESPACES = True
    CHECK_PACKAGES = True
    CHECK_COLUMN_ORDER = False   # Column order differences are usually harmless

    # ─── SQL BODY COMPARISON (views, procedures, functions, triggers) ─────────
    # Two SQL bodies count as the same definition at or above this similarity,
    # measured on the NORMALISED text (comments stripped, identifier quoting
    # removed, whitespace collapsed, upper-cased) with difflib.
    #
    # COVERAGE_MATRIX.md and FINAL_AUDIT.md have always named this as the knob
    # to turn ("lower SQL_SIMILARITY_THRESHOLD for literal fidelity"), but it
    # existed in no config file: the 0.90 was hard-coded in data_type_mapper.py,
    # so following that remediation changed nothing. It is now real.
    #
    # Raise it towards 1.0 to demand near-literal fidelity — at 0.90 a single
    # changed literal inside a long body still passes. Lower it to tolerate
    # heavier reformatting by erwin's import.
    SQL_SIMILARITY_THRESHOLD = 0.90

    # ─── STEP 1: PD COMMENTS -> ERWIN NOTES ───────────────────────────────────
    # The PDM flow writes the PD Comment of every table, column, view,
    # procedure / function, trigger, sequence and tablespace into an erwin
    # Note in 2_preprocessed/<model>.xml (same mechanism as the CDM / LDM
    # Phase B). The DOCUMENTATION sheet and the *_DEFINITION extended checks
    # then read those notes as the object's definition.
    PDM_COMMENT_INJECTION_ENABLED = True
    PDM_COMMENT_AUTHOR = "Migration_Bot"

    # Normalize data types before comparing (e.g. INT ≈ INTEGER)
    NORMALIZE_DATA_TYPES = True

# # Defines how ERwin data is interpreted for different export formats; normally handled automatically by the parser.
# This setting maps ERwin's null-option code to "is NOT NULL?" — keep it separate from the LDM setting, which asks "is nullable?"

    ERWIN_ATTR_NULL_OPTION_CODES = {"1": True, "0": False, "2": False}

# # ERwin automatically creates foreign-key indexes for relationships, while PowerDesigner does not export them.
# They are ignored by default to avoid false index differences; set False to compare them.
    ERWIN_IGNORE_FK_INDEXES = True

# # PowerDesigner may use abstract types like "Enum" that ERwin converts into a concrete SQL type such as CHAR(18).
# These types are reported as INFO (DATA_TYPE_ABSTRACT) instead of being treated as critical data-type mismatches.

    PD_ABSTRACT_TYPES = {"ENUM"}

    # PowerDesigner auto-creates a backing index for every primary key,
    # alternate key and foreign key (linked via <c:LinkedObject>). These mirror
    # keys/FKs already validated elsewhere, and erwin does not export them as
    # indexes — comparing them yields hundreds of phantom "index only in
    # PowerDesigner" rows. True skips them; set False to compare them.
    PD_IGNORE_KEY_FK_INDEXES = True

    # ─── FINDING SEVERITY ─────────────────────────────────────────────────────

    FINDING_SEVERITY = {
        "TABLE_MISSING":       "CRITICAL",   # table in PD, absent in erwin
        "TABLE_EXTRA":         "WARNING",    # table in erwin, absent in PD
        "COLUMN_MISSING":      "CRITICAL",   # column in PD, absent in erwin
        "COLUMN_EXTRA":        "WARNING",    # column in erwin, absent in PD
        "DATA_TYPE":           "CRITICAL",   # different base data type
        "DATA_TYPE_LENGTH":    "WARNING",    # same base type, different length/precision
        "DATA_TYPE_ABSTRACT":  "INFO",       # PD abstract type vs concrete erwin type
        "NULLABILITY":         "INFO",       # NULL vs NOT NULL
        "DEFAULT":             "INFO",       # different default value
        "PRIMARY_KEY":         "CRITICAL",   # different PK columns / PK dropped in erwin
        "PRIMARY_KEY_PD_ONLY": "INFO",       # PK only on the PD side
        "FOREIGN_KEY_MISSING": "WARNING",    # FK in PD, absent in erwin
        "FOREIGN_KEY_EXTRA":   "INFO",       # FK in erwin, absent in PD
        "INDEX_MISSING":       "INFO",       # index in PD, absent in erwin
        "INDEX_EXTRA":         "INFO",       # index in erwin, absent in PD
        "VIEW_MISSING":        "WARNING",    # view in PD, absent in erwin
        "VIEW_EXTRA":          "INFO",       # view in erwin, absent in PD
        "VIEW_SQL_MISMATCH":   "WARNING",    # view SQL definition mismatch
        "PROCEDURE_MISSING":   "WARNING",    # procedure in PD, absent in erwin
        "PROCEDURE_EXTRA":     "INFO",       # procedure in erwin, absent in PD
        "PROCEDURE_BODY_MISMATCH": "WARNING", # procedure body mismatch
        "TRIGGER_MISSING":     "WARNING",    # trigger in PD, absent in erwin
        "TRIGGER_EXTRA":       "INFO",       # trigger in erwin, absent in PD
        "TRIGGER_BODY_MISMATCH": "WARNING",  # trigger body mismatch
        "SEQUENCE_MISSING":    "INFO",       # sequence in PD, absent in erwin
        "SEQUENCE_EXTRA":      "INFO",       # sequence in erwin, absent in PD
        "TABLESPACE_MISSING":  "INFO",       # tablespace in PD, absent in erwin
        "TABLESPACE_EXTRA":    "INFO",       # tablespace in erwin, absent in PD
        "PACKAGE_MISSING":     "INFO",       # package in PD, absent in erwin
        "PACKAGE_EXTRA":       "INFO",       # package in erwin, absent in PD
    }

    # Below this the model is flagged "Review? = YES".
    # Deliberately lower than the 95.0 CDM and LDM use: a physical model carries
    # far more comparable objects, so the same absolute defect count scores
    # differently.
    FIDELITY_REVIEW_THRESHOLD = 90.0

    # ─── ROADMAP ENHANCEMENTS (feature-flagged, additive, off by default) ─────
    # Vendor-specific / advanced data type registry (Oracle XMLTYPE/JSON, SQL
    # Server CLR types, PostgreSQL JSONB/arrays/PostGIS, DB2 structured types,
    # generic UDTs) consulted only when the base data_type_mapper classifies a
    # pair as a mismatch, so leaving this False reproduces prior behaviour.
    # See app/validation/pdm_reconcile/pdm_erwin_validator/advanced_datatype_mapper.py.
    ENABLE_ADVANCED_DATATYPE_INTELLIGENCE = False

    # A foreign key whose parent/child table (and join columns) is fully
    # reversed between PowerDesigner and erwin is reported as one reconciled
    # direction change instead of one missing + one extra FK.
    ENABLE_DIRECTION_RECONCILIATION = True


# ══════════════════════════════════════════════════════════════════════════════
#  RUNTIME TIER VIEWS
#
#  Each engine imports one of the three objects below. They flatten a tier's
#  inheritance chain into plain writable attributes, so engine code keeps
#  working unchanged:
#
#      config.CHECK_ENTITIES          attribute read
#      config.as_dict()               the workbook's CONFIG sheet
#      config.resolve_severity(...)   CDM / LDM severity policy
#      config.REPORT_FILENAME = ...   the PDM bridge's runtime rename
# ══════════════════════════════════════════════════════════════════════════════
class _TierConfig:
    """One tier's settings, resolved through its inheritance chain."""

    def __init__(self, tier: str, source: type):
        self._tier = tier
        # reversed(__mro__) applies the most general class first, so a subclass
        # override lands last and wins.
        for klass in reversed(source.__mro__):
            for name, value in vars(klass).items():
                if name.isupper() and not name.startswith("_"):
                    setattr(self, name, value)

    def __repr__(self) -> str:
        return f"<{self._tier} config: {len(self.as_dict())} settings>"

    def as_dict(self) -> dict:
        """
        Every public setting for THIS tier only.

        Written into the report's CONFIG sheet so a reviewer can always tell
        which rules produced a given result. Because each tier view holds only
        its own chain, the LDM workbook shows LDM settings and nothing from CDM
        or PDM.
        """
        return {name: value for name, value in vars(self).items()
                if name.isupper() and not name.startswith("_")}

    def resolve_severity(self, category: str, default: str) -> str:
        """
        Apply SEVERITY_OVERRIDES to a finding category.
        Returns "IGNORE" when the category has been switched off entirely.
        """
        return getattr(self, "SEVERITY_OVERRIDES", {}).get(category, default)


CDM_CONFIG = _TierConfig("CDM", CDM)
LDM_CONFIG = _TierConfig("LDM", LDM)
PDM_CONFIG = _TierConfig("PDM", PDM)

_TIERS = {"CDM": CDM_CONFIG, "LDM": LDM_CONFIG, "PDM": PDM_CONFIG}


def tier(name: str) -> _TierConfig:
    """Look a tier view up by name — 'CDM', 'LDM' or 'PDM'."""
    key = name.upper()
    if key not in _TIERS:
        raise ValueError(f"Unknown tier {name!r}; expected one of {sorted(_TIERS)}")
    return _TIERS[key]

