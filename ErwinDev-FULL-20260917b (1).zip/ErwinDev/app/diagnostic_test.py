"""

Diagnostic script to test erwin COM and model resolution.

Run this on Windows with erwin open.

"""
 
import sys

from pathlib import Path
 
print("=" * 80)

print("ERWIN COM DIAGNOSTIC TEST")

print("=" * 80)
 
# Test 1: Check pywin32

print("\n[1/5] Checking pywin32...")

try:

    import win32com.client

    print("  [OK] pywin32 is installed and importable")

except ImportError as e:

    print(f"  [FAIL] pywin32 import failed: {e}")

    sys.exit(1)
 
# Test 2: Check if erwin COM is available

print("\n[2/5] Checking erwin COM availability...")

try:

    erwin_app = win32com.client.GetObject(None, "erwin.application")

    print(f"  [OK] erwin COM connected: version {erwin_app.Version}")

except Exception as e:

    print(f"  [FAIL] erwin COM failed: {e}")

    print("     Ensure erwin Data Modeler is RUNNING before running this script")

    sys.exit(1)
 
# Test 3: Check model paths

print("\n[3/5] Checking model file resolution...")

erwindev_root = Path.cwd() if Path.cwd().name == "ErwinDev" else Path.cwd().parent

if not erwindev_root.name == "ErwinDev":

    print(f"  [FAIL] Not in ErwinDev folder: {Path.cwd()}")

    sys.exit(1)
 
models_dir = erwindev_root / "app" / "udp_tool" / "input_erwin_models"

if not models_dir.exists():

    print(f"  [FAIL] Models directory not found: {models_dir}")

    sys.exit(1)
 
ldm_models = list((models_dir / "ldm").glob("*.erwin")) if (models_dir / "ldm").exists() else []

print(f"  [OK] Found {len(ldm_models)} LDM .erwin models in {models_dir}/ldm/")

if ldm_models:

    for m in ldm_models[:3]:

        print(f"    - {m.name}")
 
# Test 4: Try to open a model with COM

print("\n[4/5] Testing model opening with erwin COM...")

if ldm_models:

    test_model = ldm_models[0]

    print(f"  Testing with: {test_model.name}")

    try:

        model = erwin_app.OpenModel(str(test_model))

        print(f"  [OK] Model opened successfully")

        # Check model properties

        entity_count = model.Entities.Count

        print(f"    - Entities in model: {entity_count}")

        if entity_count == 0:

            print("    [WARNING] Model has 0 entities - may be empty!")

        model.Close(0)

        print("  [OK] Model closed successfully")

    except Exception as e:

        print(f"  [FAIL] Model open/close failed: {e}")

else:

    print("  [SKIP] No models to test with")
 
# Test 5: Check for normalized folder structure

print("\n[5/5] Checking normalization structure...")

sap_models_dir = erwindev_root / "sappdmodels"

if sap_models_dir.exists():

    for tier in ["cdm", "ldm", "pdm"]:

        tier_dir = sap_models_dir / tier

        if tier_dir.exists():

            normalized = tier_dir / "normalized"

            original_count = len(list(tier_dir.glob("*.pdm")) + list(tier_dir.glob("*.cdm")) + list(tier_dir.glob("*.ldm")))

            normalized_count = len(list(normalized.glob("*"))) if normalized.exists() else 0

            print(f"  {tier}/: {original_count} original, {normalized_count} normalized")

            if normalized_count == 0 and original_count > 0:

                print(f"    ⚠ Models exist but not normalized yet - run pipeline once")
 
print("\n" + "=" * 80)

print("DIAGNOSTIC COMPLETE")

print("=" * 80)

print("\nINTERPRETATION:")

print("  - If [2] fails: erwin COM not available (erwin not running or pywin32 issue)")

print("  - If [4] fails: model open/close broken - check erwin version")

print("  - If model has 0 entities: the .erwin file is empty - re-import from SAP")

print("  - If [5] shows no normalized: normalization hasn't run yet")
 