"""
Conceptual Model Workflow (LDM / CDM)
=======================================
The full per-model pipeline for LDM and CDM when everything is run in ONE
process (``python -m app.main``). The split entry points (run_v1 / run_udp /
run_v3) perform the same steps one stage at a time; both paths share the
helpers used here so they cannot drift apart.

The erwin-side artefacts are OBTAINED, not merely looked for: erwin makes them
through SCAPI when erwin COM is on the host, and when it is not, the hand-off
gate (app/erwin/erwin_handoff.py) says exactly what to save and where. Either
way this module never fabricates an artefact it did not receive:

    sappdmodels/<tier>/<model>.(cdm|ldm)           SAP PD source
    erwinmodels/1_initial/<model>.xml               MANUAL        erwin export of the imported model
      -> Fidelity V1                                AUTOMATED
      -> erwinmodels/2_preprocessed/<model>.xml     AUTOMATED     Step 1: PD Comments -> erwin Notes
    app/udp_tool/input_erwin_models/<model>.erwin   AUTO | MANUAL .ERWIN V1, made from XML V2
      -> erwinmodels/2_preprocessed/<model>.erwin   AUTOMATED     Step 2: UDPs injected (erwin COM)
      -> Fidelity V2 (against the commented XML)    AUTOMATED
    final_xml_models/<tier>/<model>.xml             MANUAL        erwin export of the enriched .erwin
      -> Fidelity V3 + gate + 3_final               AUTOMATED

Note that ``2_preprocessed/`` holds two artefacts and the extension tells them
apart: ``<model>.xml`` is XML V2 (Step 1's output, Step 2's input) and
``<model>.erwin`` is .ERWIN V2 (Step 2's output).
"""

import logging
import os
from pathlib import Path

from app.common.config_helpers import get_setting
from app.erwin import erwin_handoff
from app.orchestration import pipeline_ledger, stage_state
from app.orchestration.concurrency import record_skipped_model
from app.orchestration.model_record import ModelRecord, classify_complexity
from app.orchestration.stage_paths import StagePaths
from app.orchestration.udp_helpers import reconcile, run_udp_phase, udp_stage_override
from app.preprocessing.orchestrator import run_preprocessing
from app.utils.manual_export_wait import validate_erwin_xml, wait_for_manual_export
from app.validation import fidelity_stages
from app.workflows.promotion_routing import route_model

logger = logging.getLogger(__name__)


def _hand_off_editable(path, record=None) -> None:
    """
    Make an artefact a PERSON has to open next actually openable and editable.

    Both manual hand-offs in this flow are files erwin opens by hand —
    2_preprocessed/<model>.xml (saved as .erwin) and 2_preprocessed/<model>.erwin
    (saved as XML V3). The automated erwin paths already call
    windows_files.prepare*; these did not, so on a checkout unpacked from a
    downloaded .zip (Mark-of-the-Web) or living inside OneDrive (cloud
    placeholder / sync hold) erwin opened them READ-ONLY and manual corrections
    could not be saved back.

    Best-effort by design: the artefact is already written, so a failure here is
    logged and noted, never fatal. No-op off Windows.
    """
    try:
        from app.erwin import windows_files
        state = windows_files.make_editable(path)
    except Exception as exc:                                   # noqa: BLE001
        logger.debug("Could not prepare %s for manual editing: %s", path, exc)
        return
    for message in getattr(state, "messages", []) or ():
        logger.info("%s", message)
    if getattr(state, "blocked", False) or getattr(state, "locked", False):
        note = (f"{Path(path).name} may open read-only in erwin: {state.summary()}. "
                f"Close it in any other program, or move the checkout out of "
                f"OneDrive to a short local path such as C:\\erwin.")
        logger.warning("%s", note)
        if record is not None:
            record.notes.append(note)


# ─── shared helpers (also used by run_v1.py / run_v3.py) ──────────────────────

def locate_xml_v1(stages: StagePaths, base_name: str, model_type: str, dirs=None):
    """
    The manual erwin export of the imported model, validated, or None.

    Waits MANUAL_EXPORT_WAIT_SECONDS for the operator when configured. A
    missing or invalid export is recorded as WAITING / FAILED on the model's
    stage state and as a skipped model; it is never substituted.
    """
    expected = stages.xml_v1(base_name)
    wait_seconds = int(get_setting("MANUAL_EXPORT_WAIT_SECONDS", 0))
    poll_interval = float(get_setting("MANUAL_EXPORT_POLL_INTERVAL_SECONDS", 5.0))

    def _on_wait(path, remaining):
        print(f"  ... waiting for manual erwin export of {path.name} ({int(remaining)}s remaining)")

    found = stages.find_xml_v1(base_name)
    if found is None and wait_for_manual_export(expected, wait_seconds, poll_interval, _on_wait):
        found = expected
    if found is None:
        reason = (f"{base_name} ({model_type}): XML V1 (initial erwin export) not found at "
                  f"{stages.describe('xml_v1', base_name)}")
        print(f"  -> {reason}")
        print(f"     {stage_state.NEXT_ACTION[stage_state.STAGE_V1_XML]}")
        record_skipped_model(reason)
        if dirs is not None:
            stage_state.record_stage(dirs, base_name, stage_state.STAGE_V1_XML, stage_state.STATUS_WAITING,
                                     model_type=model_type, artifact=expected, artifact_kind="xml_v1",
                                     message=reason)
        return None

    valid, error = validate_erwin_xml(found)
    if not valid:
        reason = f"{base_name} ({model_type}): export invalid at {found} — {error}"
        print(f"  -> {reason}")
        record_skipped_model(reason)
        if dirs is not None:
            stage_state.record_stage(dirs, base_name, stage_state.STAGE_V1_XML, stage_state.STATUS_FAILED,
                                     model_type=model_type, artifact=found, artifact_kind="xml_v1",
                                     message=reason, next_action="Re-export the model from erwin as XML.")
        return None
    if dirs is not None:
        stage_state.record_stage(dirs, base_name, stage_state.STAGE_V1_XML, stage_state.STATUS_VALIDATED,
                                 model_type=model_type, artifact=found, artifact_kind="xml_v1")
    return found


def measure_v1(record: ModelRecord, model_path, xml_v1, dirs=None):
    """Fidelity V1: SAP PD against the raw erwin export (no comments, no UDPs)."""
    print("\n--- Fidelity V1: SAP PD vs initial erwin XML ---")
    logger.info("V1 - parsing INITIAL erwin XML: %s", xml_v1)
    record.initial_result = reconcile(model_path, xml_v1, record.model_type)
    v1 = fidelity_stages.apply(record.initial_result, fidelity_stages.STAGE_V1, model_type=record.model_type)
    print(f"  -> {v1.summary_line()}")
    record.artefacts["source_model"] = str(model_path)
    record.artefacts["xml_v1"] = str(xml_v1)
    record.artefacts["xml_v1_how"] = "manual"
    if dirs is not None:
        stage_state.record_stage(dirs, record.base_name, stage_state.STAGE_V1_FIDELITY, stage_state.STATUS_READY,
                                 model_type=record.model_type, complexity=classify_complexity(record.initial_result),
                                 message=v1.summary_line())
    return v1


def _mtime(path) -> float:
    """Modification time of a path, or 0.0 when it cannot be read."""
    try:
        return Path(path).stat().st_mtime
    except OSError:
        return 0.0


def inject_comments(record: ModelRecord, model_path, xml_v1, stages: StagePaths, dirs=None):
    """
    Step 1: PD Comments -> erwin Notes, written to 2_preprocessed/<model>.xml.
    An existing, newer commented XML is reused (never overwritten) so re-running
    a stage does not change the artefact the operator already loaded into erwin.
    """
    target = stages.xml_v2(record.base_name)
    # Freshness is judged against the SAP PD SOURCE as well as XML V1. Judging
    # it against XML V1 alone meant editing the .ldm/.cdm did not invalidate a
    # cached XML V2, so the next run silently scored the stale one.
    newest_input = max(Path(xml_v1).stat().st_mtime, _mtime(model_path))
    if target.is_file() and target.stat().st_mtime >= newest_input:
        print(f"  -> Step 1 output already present: {target.name} (kept)")
        how = "existing"
    else:
        try:
            produced = run_preprocessing(model_path, Path(xml_v1), record.base_name,
                                         target.parent, record.model_type)
        except Exception as exc:                               # noqa: BLE001
            # Step 1 produced nothing. Recording this as READY is what let a
            # fabricated XML V2 be scored as though comments had migrated.
            reason = f"Step 1 (comments -> notes) FAILED for {record.base_name}: {exc}"
            print(f"  -> {reason}")
            logger.error(reason)
            record.notes.append(reason)
            if dirs is not None:
                stage_state.record_stage(
                    dirs, record.base_name, stage_state.STAGE_XML_V2,
                    stage_state.STATUS_FAILED, model_type=record.model_type,
                    artifact=None, artifact_kind="xml_v2", parent=str(xml_v1),
                    message=reason,
                    next_action="Fix the cause and re-run run_v1.py; do not "
                                "hand off an .erwin built from XML V1.")
            raise
        target = Path(produced)
        how = "converted"
    _hand_off_editable(target, record)
    record.artefacts["xml_v2"] = str(target)
    record.artefacts["xml_v2_how"] = how
    if dirs is not None:
        stage_state.record_stage(dirs, record.base_name, stage_state.STAGE_XML_V2, stage_state.STATUS_READY,
                                 model_type=record.model_type, artifact=target, artifact_kind="xml_v2",
                                 parent=str(xml_v1))
        # the next thing is a person's job
        erwin_in = stages.erwin_v1(record.base_name)
        status = stage_state.STATUS_VALIDATED if erwin_in.is_file() else stage_state.STATUS_WAITING
        stage_state.record_stage(dirs, record.base_name, stage_state.STAGE_ERWIN_HANDOFF, status,
                                 model_type=record.model_type, artifact=erwin_in if erwin_in.is_file() else None,
                                 artifact_kind="erwin_v1", parent=str(target))
    return target


def validate_erwin_binary(path) -> tuple:
    """
    Sanity check of a hand-off .erwin (a person saved it from erwin): exists,
    has the .erwin extension and is not empty. The binary format is closed, so
    nothing deeper is claimed here — the UDP tool's read-back is the real test.
    """
    p = Path(str(path))
    if not p.is_file():
        return False, "file not found"
    if p.suffix.lower() != ".erwin":
        return False, f"unexpected extension {p.suffix!r} (expected .erwin)"
    if p.stat().st_size == 0:
        return False, "file is empty"
    return True, ""


def _obtain_erwin_v1(record: ModelRecord, stages: StagePaths, dirs):
    """
    Get Step 2's input binary, and record how it was obtained.

    A file ALREADY at the hand-off location is never sent through the gate,
    even when it is empty or unreadable: that is a failed save by the operator
    and it is reported FAILED. Converting over it, or calling it merely
    missing, would hide the one thing they need to know.

    Returns (path or None, how, messages).
    """
    base_name = record.base_name
    found = stages.find_erwin_v1(base_name)
    if found is not None:
        return found, erwin_handoff.HOW_EXISTING, []

    # erwin makes it through SCAPI when COM is on this host; when COM is not,
    # the gate tells the operator exactly what to save and where and waits.
    # Only when BOTH fail is the model recorded WAITING — which is what used to
    # happen unconditionally, leaving run_udp.py with nothing to inject into.
    handoff = erwin_handoff.ensure(
        stages.erwin_v1(base_name),
        stages.find_xml_v2(base_name),
        erwin_handoff.LABEL_ERWIN_V1,
        model_name=base_name,
        recheck=lambda: stages.find_erwin_v1(base_name),
    )
    for line in handoff.messages:
        logger.info("[%s] .ERWIN V1: %s", base_name, line)
    return (handoff.path if handoff.ok else None), handoff.how, handoff.messages


def _record_erwin_v1(record: ModelRecord, stages: StagePaths, dirs,
                     erwin_in, how: str, messages):
    """Validate the hand-off binary and write its stage event. Returns it, or None."""
    base_name, model_type = record.base_name, record.model_type

    if erwin_in is None:
        if dirs is not None:
            # Say WHY it is missing, not just that it is: "erwin COM
            # unavailable" and "no XML V2 to convert from" need different
            # things done about them.
            why = "; ".join(messages[-2:]) if messages else ""
            stage_state.record_stage(
                dirs, base_name, stage_state.STAGE_ERWIN_HANDOFF, stage_state.STATUS_WAITING,
                model_type=model_type, artifact=None, artifact_kind="erwin_v1",
                message=f"no .erwin at {stages.describe('erwin_v1', base_name)}"
                        + (f" — {why}" if why else ""))
        return None

    print(f"  -> .ERWIN V1 ({how}): {erwin_in}")
    valid, error = validate_erwin_binary(erwin_in)
    if not valid:
        reason = f"{base_name} ({model_type}): handed-off .erwin rejected at {erwin_in} — {error}"
        print(f"  -> {reason}")
        if dirs is not None:
            stage_state.record_stage(
                dirs, base_name, stage_state.STAGE_ERWIN_HANDOFF, stage_state.STATUS_FAILED,
                model_type=model_type, artifact=erwin_in, artifact_kind="erwin_v1",
                message=reason, next_action="Save the model again from erwin as .erwin.")
        return None

    record.artefacts["erwin_v1"] = str(erwin_in)
    record.artefacts["erwin_v1_how"] = how
    if dirs is not None:
        stage_state.record_stage(
            dirs, base_name, stage_state.STAGE_ERWIN_HANDOFF, stage_state.STATUS_VALIDATED,
            model_type=model_type, artifact=erwin_in, artifact_kind="erwin_v1",
            parent=record.artefacts.get("xml_v2", ""))
    return erwin_in


def _obtain_erwin_v2(record: ModelRecord, model_path, stages: StagePaths, dirs,
                     erwin_in, erwin_out):
    """
    The injector needs erwin COM. When it was not there, the enriched binary
    can still be produced by a person — so ask, instead of ending the stage at
    EXTRACTED with no output file. There is nothing to CONVERT from here
    (.ERWIN V1 -> .ERWIN V2 is an injection, not a format change), so the gate
    goes straight to the instructions with no source.

    Returns (erwin_out, how) — the path is the one actually found, which may be
    a tolerated spelling rather than the expected path.
    """
    base_name = record.base_name
    handoff = erwin_handoff.ensure(
        erwin_out, None, erwin_handoff.LABEL_ERWIN_V2, model_name=base_name,
        recheck=lambda: stages.find_erwin_v2(base_name),
        report_path=getattr(record.udp_outcome, "migration_report_path", "") or "",
    )
    for line in handoff.messages:
        logger.info("[%s] .ERWIN V2: %s", base_name, line)
    if not handoff.ok:
        return erwin_out, ""

    # Read the model they just saved back, so the UDP verdict is measured
    # evidence rather than an unread file on disk.
    print("  -> re-reading the enriched .erwin that was produced")
    found = Path(handoff.path)
    record.udp_outcome = run_udp_phase(model_path, base_name, record.model_type, dirs,
                                       erwin_in=str(erwin_in), erwin_out=found)
    return found, handoff.how


def _udp_stage_event(record: ModelRecord, erwin_in, erwin_out, how: str):
    """(status, message, next_action) for the UDP stage, and the record's artefacts."""
    outcome = record.udp_outcome

    if erwin_out.is_file() and erwin_in is not None:
        _hand_off_editable(erwin_out, record)
        record.artefacts["erwin_v2"] = str(erwin_out)
        record.artefacts["erwin_v2_how"] = (
            "injected" if getattr(outcome, "injected", False) else (how or "existing"))
        return (stage_state.STATUS_READY,
                f"UDP stage {outcome.stage}: {outcome.summary_line()}", "")

    if erwin_in is None:
        return (stage_state.STATUS_WAITING,
                "UDP injection needs the handed-off .erwin; extraction/mapping reports were produced.",
                stage_state.NEXT_ACTION[stage_state.STAGE_ERWIN_HANDOFF])

    detail = "; ".join(outcome.messages[-2:]) if outcome.messages else outcome.error or "see log"
    return (stage_state.STATUS_FAILED,
            f"UDP stage {outcome.stage}: {outcome.summary_line()} — no enriched .erwin written ({detail})",
            "Run run_udp.py on a Windows host with erwin Data Modeler (COM) installed, "
            "or inject the UDPs in erwin by hand and save as erwinmodels/2_preprocessed/<model>.erwin.")


def run_step2(record: ModelRecord, model_path, stages: StagePaths, dirs=None):
    """
    Step 2 (the UDP tool), with both erwin artefacts obtained rather than
    merely looked for.

    .ERWIN V1 (the input) is converted from XML V2 by erwin's SCAPI when erwin
    COM is on this host; otherwise the hand-off gate says exactly what to save
    and where and waits for a person (app/erwin/erwin_handoff.py). .ERWIN V2
    (the output) goes to 2_preprocessed/<model>.erwin — the input is never
    overwritten — and when the injector could not run, the same gate offers the
    manual route and re-reads whatever the operator produces.

    Extraction and mapping of the SAP extended attributes run regardless, so
    the mapping report exists even while an erwin step is pending.
    """
    base_name, model_type = record.base_name, record.model_type

    erwin_in, how, messages = _obtain_erwin_v1(record, stages, dirs)
    erwin_in = _record_erwin_v1(record, stages, dirs, erwin_in, how, messages)

    erwin_out = stages.erwin_v2(base_name)
    erwin_v2_how = ""
    record.udp_outcome = run_udp_phase(model_path, base_name, model_type, dirs,
                                       erwin_in=str(erwin_in) if erwin_in else "",
                                       erwin_out=erwin_out)

    if erwin_in is not None and not erwin_out.is_file():
        erwin_out, erwin_v2_how = _obtain_erwin_v2(
            record, model_path, stages, dirs, erwin_in, erwin_out)

    status, message, next_action = _udp_stage_event(record, erwin_in, erwin_out, erwin_v2_how)
    outcome = record.udp_outcome

    if dirs is not None:
        stage_state.record_stage(dirs, base_name, stage_state.STAGE_UDP, status, model_type=model_type,
                                 artifact=erwin_out if erwin_out.is_file() else None, artifact_kind="erwin_v2",
                                 parent=str(erwin_in) if erwin_in else "", message=message, next_action=next_action,
                                 extra={"udp_stage": getattr(outcome, "stage", ""),
                                        "udp_pass_rate": getattr(outcome, "pass_rate", None)})
        if status == stage_state.STATUS_READY:
            # the next thing is a person's job again: export the enriched .erwin as XML
            xml_v3 = stages.find_xml_v3(base_name)
            stage_state.record_stage(dirs, base_name, stage_state.STAGE_V3_XML,
                                     stage_state.STATUS_VALIDATED if xml_v3 else stage_state.STATUS_WAITING,
                                     model_type=model_type, artifact=xml_v3, artifact_kind="xml_v3",
                                     parent=str(erwin_out))
    return outcome


def measure_v2(record: ModelRecord, model_path, xml_v2, dirs=None):
    """Fidelity V2: SAP PD against the commented XML; UDP evidence from the UDP tool's read-back."""
    print("\n--- Fidelity V2: SAP PD vs commented erwin XML ---")
    record.v2_result = reconcile(model_path, xml_v2, record.model_type)
    if record.initial_result is not None:
        fidelity_stages.carry_history(record.initial_result, record.v2_result)
    v2 = fidelity_stages.apply(record.v2_result, fidelity_stages.STAGE_V2,
                               udp_override=udp_stage_override(record.v2_result, record.udp_outcome,
                                                               record.base_name, record.model_type,
                                                               dirs=dirs, pd_path=model_path),
                               model_type=record.model_type)
    print(f"  -> {v2.summary_line()}")
    return v2


def _same_model(result) -> bool:
    """
    Did the erwin XML describe THIS model? A V3 export of a different model has
    no entity in common with the SAP source; scoring it would attribute another
    model's fidelity to this one.
    """
    pd_objects = int(getattr(result, "entities_pd", 0) or getattr(result, "tables_pd", 0) or 0)
    matched = int(getattr(result, "entities_matched", 0) or getattr(result, "tables_matched", 0) or 0)
    return pd_objects == 0 or matched > 0


def locate_xml_v3(record: ModelRecord, stages: StagePaths, dirs=None):
    """
    The manual erwin export of the UDP-enriched model, validated, or None.
    Missing by default is a HARD STOP: the V3 verdict gates the erwin Mart
    publish, so scoring another artefact and calling it V3 is worse than
    stopping. FINAL_XML_FALLBACK_TO_PREPROCESSED=true re-enables the dry-run
    fallback (V3 measured against the commented XML), clearly noted.
    """
    base_name, model_type = record.base_name, record.model_type
    found = stages.find_xml_v3(base_name)
    if found is not None:
        valid, error = validate_erwin_xml(found)
        if not valid:
            reason = f"{base_name} ({model_type}): XML V3 invalid at {found} — {error}"
            print(f"  -> {reason}")
            record_skipped_model(reason)
            if dirs is not None:
                stage_state.record_stage(dirs, base_name, stage_state.STAGE_V3_XML, stage_state.STATUS_FAILED,
                                         model_type=model_type, artifact=found, artifact_kind="xml_v3",
                                         message=reason, next_action="Re-export the enriched .erwin as XML.")
            return None
        if dirs is not None:
            stage_state.record_stage(dirs, base_name, stage_state.STAGE_V3_XML, stage_state.STATUS_VALIDATED,
                                     model_type=model_type, artifact=found, artifact_kind="xml_v3",
                                     parent=record.artefacts.get("erwin_v2", ""))
        return found

    reason = (f"{base_name} ({model_type}): XML V3 not found at {stages.describe('xml_v3', base_name)} "
              f"— export erwinmodels/2_preprocessed/{base_name}.erwin from erwin as XML")
    if dirs is not None:
        stage_state.record_stage(dirs, base_name, stage_state.STAGE_V3_XML, stage_state.STATUS_WAITING,
                                 model_type=model_type, artifact=stages.xml_v3(base_name), artifact_kind="xml_v3",
                                 message=reason)
    if get_setting("FINAL_XML_FALLBACK_TO_PREPROCESSED", False):
        logger.info("No separate final erwin XML for %s; V3 measured against 2_preprocessed.", base_name)
        record.notes.append("No final erwin XML export found; V3 measured against 2_preprocessed/"
                            f"{base_name}.xml.")
        return None
    print(f"  -> {reason}")
    record_skipped_model(reason)
    return None


def measure_v3(record: ModelRecord, model_path, xml_v3, dirs=None):
    """
    Fidelity V3: an independent reconciliation of SAP PD against the XML V3
    export, with V1 and V2 carried so the report shows the progression and
    the combined score (see fidelity_stages for the documented formula).
    Returns False when the export does not describe this model.
    """
    print("\n--- Fidelity V3: SAP PD vs XML export of the UDP-enriched model ---")
    logger.info("V3 - parsing XML V3: %s", xml_v3)
    record.result = reconcile(model_path, xml_v3, record.model_type)
    if not _same_model(record.result):
        reason = (f"{record.base_name} ({record.model_type}): XML V3 {os.path.basename(str(xml_v3))} has no "
                  f"entity in common with the SAP PD model — it belongs to a different model; not scored")
        print(f"  -> {reason}")
        record_skipped_model(reason)
        if dirs is not None:
            stage_state.record_stage(dirs, record.base_name, stage_state.STAGE_V3_XML, stage_state.STATUS_FAILED,
                                     model_type=record.model_type, artifact=xml_v3, artifact_kind="xml_v3",
                                     message=reason, next_action="Export the right model from erwin.")
        return False
    record.final_xml = str(xml_v3)
    record.artefacts["xml_v3"] = str(xml_v3)
    record.artefacts.setdefault("xml_v3_how", "existing")
    record.notes.append(f"V3 measured against {os.path.basename(str(xml_v3))}")
    if record.initial_result is not None:
        fidelity_stages.carry_history(record.initial_result, record.result)
    if record.v2_result is not None:
        fidelity_stages.carry_history(record.v2_result, record.result)
    v3 = fidelity_stages.apply(record.result, fidelity_stages.STAGE_V3,
                               udp_override=udp_stage_override(record.result, record.udp_outcome,
                                                               record.base_name, record.model_type,
                                                               dirs=dirs, pd_path=model_path),
                               model_type=record.model_type)
    print(f"  -> {v3.summary_line()}")
    res = record.result
    print(f"  -> Matched: {getattr(res, 'entities_matched', 0)}/{getattr(res, 'entities_pd', 0)} entities, "
          f"{getattr(res, 'attributes_matched', 0)}/{getattr(res, 'attributes_pd', 0)} attributes, "
          f"{getattr(res, 'relationships_matched', 0)}/{getattr(res, 'relationships_pd', 0)} relationships")
    print(f"  -> Discrepancies: {getattr(res, 'critical_count', 0)} critical, "
          f"{getattr(res, 'warning_count', 0)} warnings, {getattr(res, 'info_count', 0)} info")
    if dirs is not None:
        stage_state.record_stage(dirs, record.base_name, stage_state.STAGE_V3_FIDELITY, stage_state.STATUS_READY,
                                 model_type=record.model_type, message=v3.summary_line())
    return True


# ─── the one-process pipeline ─────────────────────────────────────────────────

def process_conceptual_model(model_path, base_name, model_type, dirs, session_context=None):
    """Handle the LDM and CDM routes end to end (used by app/main.py and the batch runner)."""
    stages = StagePaths(dirs, model_type)
    record = ModelRecord(base_name=base_name, model_type=model_type)

    xml_v1 = locate_xml_v1(stages, base_name, model_type, dirs)
    if xml_v1 is None:
        pipeline_ledger.record_skip(dirs, base_name, model_type,
                                    f"XML V1 not found or invalid at {stages.describe('xml_v1', base_name)}",
                                    session_context=session_context)
        return None

    measure_v1(record, model_path, xml_v1, dirs)
    xml_v2 = inject_comments(record, model_path, xml_v1, stages, dirs)

    # Step 2 reads the handed-off .erwin (manual) and writes the enriched one.
    run_step2(record, model_path, stages, dirs)

    measure_v2(record, model_path, xml_v2, dirs)

    xml_v3 = locate_xml_v3(record, stages, dirs)
    if xml_v3 is None:
        if get_setting("FINAL_XML_FALLBACK_TO_PREPROCESSED", False):
            record.result = record.v2_result
            record.artefacts["xml_v3"] = str(xml_v2)
            record.artefacts["xml_v3_how"] = "fallback (commented XML)"
            fidelity_stages.apply(record.result, fidelity_stages.STAGE_V3,
                                  udp_override=udp_stage_override(record.result, record.udp_outcome, base_name,
                                                                  model_type, dirs=dirs, pd_path=model_path),
                                  model_type=model_type)
            route_model(record, xml_v2, dirs, stages=stages)
            return record
        pipeline_ledger.record_skip(dirs, base_name, model_type,
                                    f"XML V3 not found at {stages.describe('xml_v3', base_name)}",
                                    session_context=session_context)
        return None

    if not measure_v3(record, model_path, xml_v3, dirs):
        pipeline_ledger.record_skip(dirs, base_name, model_type,
                                    f"XML V3 {xml_v3} does not describe this model", session_context=session_context)
        return None

    logger.info("Reconciliation Status: %s | V3 Fidelity: %s%%", record.result.status, record.result.fidelity_score)
    route_model(record, xml_v3, dirs, stages=stages,
                erwin_source=stages.find_erwin_v2(base_name))
    return record
