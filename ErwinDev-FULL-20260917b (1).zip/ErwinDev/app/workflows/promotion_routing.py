"""
Promotion Routing
==================
Extracted from app/main.py — applies the promotion gate and sends a
reconciled model to its destination (3_final / manual_review / rejected /
stays in 2_preprocessed).
"""

import logging
import os
import shutil
from pathlib import Path

from app.orchestration.directory_setup import stage_file
from app.orchestration.model_record import (
    DEST_FINAL,
    DEST_MANUAL_REVIEW,
    DEST_PREPROCESSED,
    DEST_REJECTED,
)
from app.validation import promotion_gate

logger = logging.getLogger(__name__)


def _artefacts(record) -> dict:
    """The record's artefact map, created on demand (tests pass bare stand-ins)."""
    store = getattr(record, "artefacts", None)
    if not isinstance(store, dict):
        store = {}
        try:
            record.artefacts = store
        except AttributeError:
            pass
    return store


def route_model(record, promote_source, dirs, stages=None, erwin_source=None):
    """
    Apply the promotion gate and send the model to its destination.

        fidelity >= threshold  PASS -> erwinmodels/3_final/<model>.xml (+ .erwin)
        fidelity <  threshold  FAIL -> stays in erwinmodels/2_preprocessed

    The stage folders are flat.  The artefact promoted is whatever V3 was
    measured against — the final validated XML when there is one, so 3_final
    holds the export that was actually scored — and the .erwin binary next to
    it (preprocessed first, else initial) travels with it.  A model below the
    threshold is left exactly where preprocessing wrote it; only its reports
    are filed for review (see model_reports).
    """
    base_name = record.base_name
    if promotion_gate.apply(record.result):
        target = stage_file(dirs, "final", base_name, ".xml")
        erwin_target = stage_file(dirs, "final", base_name, ".erwin")
        candidates = [erwin_source] if erwin_source else []
        candidates += [stage_file(dirs, "preprocessed", base_name, ".erwin"),
                       stage_file(dirs, "initial", base_name, ".erwin")]
        try:
            os.makedirs(os.path.dirname(str(target)), exist_ok=True)
            if os.path.abspath(str(promote_source)) != os.path.abspath(str(target)):
                shutil.copy2(str(promote_source), str(target))     # copy: the scored input is never moved
            copied = False
            for source in candidates:
                if source and Path(source).is_file():
                    shutil.copy2(str(source), str(erwin_target))
                    _artefacts(record)["erwin_v3"] = str(erwin_target)
                    copied = True
                    break
            if not copied:
                record.notes.append("PASS, but no UDP-enriched .ERWIN V2 was found next to the XML; "
                                    "3_final holds the XML only — run run_udp.py / copy the .erwin by hand.")
        except OSError as exc:
            logger.warning("Could not copy %s to 3_final: %s", promote_source, exc)
        _artefacts(record)["final_xml"] = str(target)
        record.destination = DEST_FINAL
        logger.info("%s passed the gate and was promoted to 3_final.", base_name)
        return

    if promotion_gate.band(record.result) == promotion_gate.BAND_FAIL:
        # Below the threshold: the model stays in 2_preprocessed untouched.
        # Reports are filed under app/reporting/<tier>_reports/<model>/.
        record.destination = (DEST_MANUAL_REVIEW
                              if promotion_gate.bands_mode() == promotion_gate.BANDS_TWO
                              else DEST_REJECTED)
        logger.warning("%s is below the promotion threshold; kept in 2_preprocessed "
                       "(destination=%s)", base_name, record.destination)
        return

    record.destination = DEST_PREPROCESSED
    logger.info("%s held in %s for review", base_name, DEST_PREPROCESSED)
