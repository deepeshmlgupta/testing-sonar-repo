"""
PDM Model Workflow
====================
The PDM route. Fidelity is measured by the isolated PDM validator
(``pdm_flow.run_pdm_flow``); this module wraps it in the SAME operating flow
and hand-off bookkeeping the CDM/LDM route uses, so a PDM model is traceable
stage by stage:

    sappdmodels/pdm/<model>.pdm                     SAP PD source
    erwinmodels/1_initial/<model>.xml               MANUAL   erwin export of the imported model
      -> Fidelity V1                                AUTOMATED
      -> erwinmodels/2_preprocessed/<model>.xml     AUTOMATED Step 1 (comments -> notes) + structural remediation
    app/udp_tool/input_erwin_models/<model>.erwin   MANUAL   .erwin handed to the UDP tool
      -> erwinmodels/2_preprocessed/<model>.erwin   AUTOMATED Step 2: UDPs injected (Windows + erwin COM)
      -> Fidelity V2                                AUTOMATED
    final_xml_models/pdm/<model>.xml                MANUAL   erwin export of the enriched .erwin
      -> Fidelity V3 + gate + 3_final               AUTOMATED

There is no automated erwin bridge: a missing manual artefact is recorded as
WAITING_FOR_MANUAL_INPUT (with the operator's next action) and the model is
left where it is. V3 is measured only against the XML V3 export; without it
the gate is not evaluated (FINAL_XML_FALLBACK_TO_PREPROCESSED=true re-enables
the dry-run gate on the V2 result, clearly noted).
"""

import logging
import os

from app.common.config_helpers import get_setting
from app.config.settings import (
    PDM_FIDELITY_TARGET,
    PDM_KEEP_PREPROCESSED_COPY,
    PDM_PREPROCESS_ENABLED,
)
from app.orchestration import pipeline_ledger, stage_state
from app.orchestration.concurrency import record_skipped_model
from app.orchestration.model_record import (
    DEST_FINAL,
    DEST_MANUAL_REVIEW,
    DEST_PREPROCESSED,
    DEST_REJECTED,
    ModelRecord,
    classify_complexity,
)
from app.orchestration.stage_paths import StagePaths
from app.orchestration.udp_helpers import udp_engine_pass_rate
from app.reporting import report_layout
from app.validation import fidelity_stages
from app.validation.pdm_reconcile.pdm_flow import run_pdm_flow
from app.workflows.conceptual_workflow import locate_xml_v1, run_step2

logger = logging.getLogger(__name__)


def _record_v3_handoff(record, stages, dirs, outcome, xml_v3):
    """Stage-state entries for the XML V3 hand-off and the V3 measurement."""
    if dirs is None:
        return
    base_name = record.base_name
    if outcome.final_xml_validated:
        stage_state.record_stage(dirs, base_name, stage_state.STAGE_V3_XML, stage_state.STATUS_VALIDATED,
                                 model_type="PDM", artifact=xml_v3, artifact_kind="xml_v3",
                                 parent=record.artefacts.get("erwin_v2", ""))
        stage_state.record_stage(dirs, base_name, stage_state.STAGE_V3_FIDELITY, stage_state.STATUS_READY,
                                 model_type="PDM", message=f"V3 fidelity {outcome.final_fidelity:.2f}%")
    elif xml_v3:
        stage_state.record_stage(dirs, base_name, stage_state.STAGE_V3_XML, stage_state.STATUS_FAILED,
                                 model_type="PDM", artifact=xml_v3, artifact_kind="xml_v3",
                                 message="; ".join(m for m in outcome.messages if m.startswith("FAILED")),
                                 next_action="Export the right model from erwin as XML.")
    else:
        stage_state.record_stage(dirs, base_name, stage_state.STAGE_V3_XML, stage_state.STATUS_WAITING,
                                 model_type="PDM", artifact=stages.xml_v3(base_name), artifact_kind="xml_v3",
                                 message=f"no XML V3 at {stages.describe('xml_v3', base_name)}")


def process_pdm_model(model_path, base_name, dirs, session_context=None, run_udp=True):
    """
    Handle the PDM route end to end (used by app/main.py and the batch runner).
    ``run_udp=False`` (run_v3.py) skips Step 2 in this process: the UDP evidence
    is then read from the workbooks run_udp.py already wrote.
    """
    stages = StagePaths(dirs, "PDM")
    record = ModelRecord(base_name=base_name, model_type="PDM")
    fallback = bool(get_setting("FINAL_XML_FALLBACK_TO_PREPROCESSED", False))

    xml_v1 = locate_xml_v1(stages, base_name, "PDM", dirs)
    if xml_v1 is None:
        pipeline_ledger.record_skip(dirs, base_name, "PDM",
                                    f"XML V1 not found or invalid at {stages.describe('xml_v1', base_name)}",
                                    session_context=session_context)
        return None
    record.artefacts["source_model"] = str(model_path)
    record.artefacts["xml_v1"] = str(xml_v1)
    record.artefacts["xml_v1_how"] = "manual"

    # Step 2 first: it reads the handed-off .erwin directly (not V1's result) and
    # run_pdm_flow needs the pass rate in hand before its own V3-last gate runs.
    udp_outcome = run_step2(record, model_path, stages, dirs) if run_udp else None
    if not run_udp:
        erwin_v2 = stages.find_erwin_v2(base_name)
        if erwin_v2 is not None:
            record.artefacts["erwin_v2"] = str(erwin_v2)

    xml_v3 = stages.find_xml_v3(base_name)
    try:
        outcome = run_pdm_flow(
            pdm_path=str(model_path.resolve()),
            initial_erwin=str(stages.find_erwin_v1(base_name) or stages.erwin_v1(base_name)),
            initial_xml=str(xml_v1),
            preprocessed_erwin=str(stages.erwin_v2(base_name)),
            preprocessed_xml=str(stages.xml_v2(base_name)),
            final_erwin=str(stages.erwin_v3(base_name)),
            final_xml=str(stages.folder("erwin_v3") / f"{base_name}.xml"),
            final_validated_xml=str(xml_v3) if xml_v3 else "",
            target_fidelity=PDM_FIDELITY_TARGET,
            preprocess_enabled=PDM_PREPROCESS_ENABLED,
            keep_preprocessed_copy=PDM_KEEP_PREPROCESSED_COPY,
            # result / dirs / pd_path are NOT optional here. Without `result` the
            # workbook_belongs_to_model guard never arms, so a UDP workbook
            # found by filename alone scores this model — the exact failure that
            # gave a Vessel LDM 373 UDP values belonging to a Sanctions model.
            # Without `dirs`/`pd_path` the SHA-256-verified udp_evidence record
            # is skipped entirely and PDM can only ever fall back to that
            # workbook. CDM/LDM passed all three; PDM passed none.
            udp_pass_rate=udp_engine_pass_rate(
                base_name, "PDM", udp_outcome,
                result=getattr(record, "result", None), dirs=dirs,
                pd_path=str(model_path)),
            manual_review_dir=str(report_layout.manual_review_dir("PDM", base_name)),
            manual_export_wait_seconds=int(get_setting("MANUAL_EXPORT_WAIT_SECONDS", 0)),
            manual_export_poll_interval=float(get_setting("MANUAL_EXPORT_POLL_INTERVAL_SECONDS", 5.0)),
            require_final_xml=not fallback,
        )
    except Exception as exc:                                   # noqa: BLE001
        logger.exception("PDM pipeline failed critically for %s: %s", model_path, exc)
        if dirs is not None:
            stage_state.record_stage(dirs, base_name, stage_state.STAGE_V3_FIDELITY, stage_state.STATUS_FAILED,
                                     model_type="PDM", message=f"{type(exc).__name__}: {exc}")
        return None

    if outcome.final_result is None:
        reason = f"{base_name} (PDM): {'; '.join(outcome.messages) or 'no initial result produced'}"
        print(f"  -> {reason}")
        record_skipped_model(reason)
        pipeline_ledger.record_skip(dirs, base_name, "PDM", reason, session_context=session_context)
        return None

    if dirs is not None:
        stage_state.record_stage(dirs, base_name, stage_state.STAGE_V1_FIDELITY, stage_state.STATUS_READY,
                                 model_type="PDM", complexity=classify_complexity(outcome.initial_result),
                                 message=f"V1 fidelity {outcome.initial_fidelity:.2f}%")
        xml_v2 = outcome.artifacts.get("preprocessed_xml") or str(stages.xml_v2(base_name))
        if os.path.isfile(xml_v2):
            stage_state.record_stage(dirs, base_name, stage_state.STAGE_XML_V2, stage_state.STATUS_READY,
                                     model_type="PDM", artifact=xml_v2, artifact_kind="xml_v2", parent=str(xml_v1))
            record.artefacts["xml_v2"] = xml_v2
            record.artefacts["xml_v2_how"] = "converted"
    _record_v3_handoff(record, stages, dirs, outcome, xml_v3)

    if outcome.waiting_for_final_xml:
        reason = (f"{base_name} (PDM): XML V3 not found at {stages.describe('xml_v3', base_name)} "
                  f"— export erwinmodels/2_preprocessed/{base_name}.erwin from erwin as XML")
        print(f"  -> {reason}")
        record_skipped_model(reason)
        pipeline_ledger.record_skip(dirs, base_name, "PDM", reason, session_context=session_context)
        return None
    if xml_v3 and not outcome.final_xml_validated:
        reason = f"{base_name} (PDM): XML V3 {os.path.basename(str(xml_v3))} rejected; not scored"
        print(f"  -> {reason}")
        record_skipped_model(reason)
        pipeline_ledger.record_skip(dirs, base_name, "PDM", reason, session_context=session_context)
        return None

    record.result = outcome.final_result
    record.initial_result = outcome.initial_result
    record.final_xml = str(xml_v3) if outcome.final_xml_validated else ""
    record.destination = pdm_destination(outcome)
    record.notes = list(outcome.messages)
    record.udp_outcome = udp_outcome
    if outcome.final_xml_validated:
        record.artefacts["xml_v3"] = str(xml_v3)
        record.artefacts["xml_v3_how"] = "manual"
    elif fallback:
        record.artefacts["xml_v3_how"] = "fallback (2_preprocessed result)"
        record.notes.append("No final erwin XML export found; gate evaluated on the 2_preprocessed result.")
    for key, art_key in (("final_xml", "final_xml"), ("final_erwin", "erwin_v3")):
        if outcome.artifacts.get(key):
            record.artefacts[art_key] = outcome.artifacts[key]

    for stage_name in fidelity_stages.STAGES:
        value = record.stage(stage_name)
        if value is not None:
            print(f"  -> {stage_name} fidelity {value:.2f}%")
    res = record.result
    if res is not None:
        print(f"  -> Matched: {getattr(res, 'tables_matched', 0)}/{getattr(res, 'tables_pd', 0)} tables, "
              f"{getattr(res, 'columns_matched', 0)}/{getattr(res, 'columns_pd', 0)} columns, "
              f"{getattr(res, 'fk_matched', 0)}/{getattr(res, 'fk_pd', 0)} foreign keys")
        print(f"  -> Discrepancies: {getattr(res, 'critical_count', 0)} critical, "
              f"{getattr(res, 'warning_count', 0)} warnings, {getattr(res, 'info_count', 0)} info")
    return record


def pdm_destination(outcome):
    """Map a PdmFlowOutcome stage onto the destination shown in the summary."""
    if outcome.promoted:
        return DEST_FINAL
    return {DEST_REJECTED: DEST_REJECTED,
            DEST_MANUAL_REVIEW: DEST_MANUAL_REVIEW}.get(outcome.stage,
                                                        DEST_PREPROCESSED)
