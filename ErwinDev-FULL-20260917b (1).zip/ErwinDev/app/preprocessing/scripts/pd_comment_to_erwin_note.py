"""pd_comment_to_erwin_note.py
===========================
Migrate SAP PowerDesigner documentation into erwin Data Modeler, operating
purely on the two XML model files:

    SAP PD <a:Comment>      -->  erwin <Definition>
    SAP PD <a:Description>  -->  erwin Note_List_Array/Note_List
    SAP PD <a:Annotation>   -->  erwin Extended_NotesProps/<Comment>
                                 (shown in the UI as "Note Annotation")

Nothing else is touched.  `Name`, `Physical_Name`, erwin's own props-block
`Comment`, relationships, keys, diagrams, history and every other property are
preserved **byte for byte**.

(The module name is historical — it predates the Comment/Description swap of
2026-09-16 and the two extra targets added on 2026-09-17. It is kept because
``app/preprocessing/orchestrator.py`` shells out to this path by name.)

WHY ALL THREE ARE WRITTEN HERE (2026-09-17)
-------------------------------------------
The 2026-09-16 mapping change assumed erwin's own import would populate
Definition and Extended Notes, leaving this script to write Notes only and the
reconcilers to merely *validate* the other two. A real erwin export of the Real
Estate LDM disproved it: zero <Definition> elements, and an empty
Extended_NotesProps/<Comment> on every entity. Nothing anywhere wrote them, so
all 136 populated PD Comments came back as DEFINITION_LOSS — a validation
failure describing a migration that had never been attempted. A field nobody
writes can only ever be reported lost, so this script writes all three.
WHY THIS SCRIPT DOES A BYTE-LEVEL SPLICE
----------------------------------------
An erwin XML export cannot be safely round-tripped through a DOM writer:

  1. The export carries ~2,187 literal CRLF sequences *inside* <Definition>
     and <Comment> text.  XML line-end normalisation (a hard requirement of
     the XML spec, applied by lxml, ElementTree, expat - everything) silently
     rewrites those to LF.  Re-serialising therefore MODIFIES Definition text,
     which this task explicitly forbids.
  2. erwin writes ~952 empty elements in long form (<Disposition></Disposition>).
     Every DOM writer collapses them to <Disposition/>.
  3. lxml reorders the xmlns declaration on <EMX:Model> ahead of id/name.
A naive parse+write of the supplied 22,576,946-byte export produces
22,550,616 bytes - 26,330 bytes of unrequested change.
So: the XML is *parsed* (with expat, which reports exact byte offsets) only to
LOCATE things, and the output is produced by splicing note fragments into the
original byte stream.  Everything outside the inserted regions is guaranteed
identical, and `verify` proves it.
THE erwin NOTE STRUCTURE (discovered, not assumed)
--------------------------------------------------
Derived by diffing the supplied original export against the export in which
Notes were added by hand in erwin and verified in the tool.  The *only*
property that differs between the two files, across all 781 Entity/Attribute
objects, is `Note_List_Array`.
    <Note_List_Array>
      <Note_List HandleNonPrintableChar="Y" index="0">...record...</Note_List>
    </Note_List_Array>
Placement: immediately after <User_Formatted_Physical_Name>, inside
<EntityProps> / <AttributeProps>.  (Anchor present on 781/781 objects.)

The record is a flat string of 12 fields joined by the six-character ASCII
literal  \\#x1F  - a backslash, then '#x1F'.  There are NO real 0x1F bytes in
the file; `HandleNonPrintableChar="Y"` declares that non-printable characters
are written in this \\#xNN form.

    field[ 0]  note number, 1-based        e.g. "1"
    field[ 1]  created timestamp           "YYYY-MM-DD HH:MM:SS"
    field[ 2]  creator
    field[ 3]  modified timestamp
    field[ 4]  modifier
    field[ 5]  (empty in the verified sample)
    field[ 6]  NOTE TEXT                   <-- the payload
    field[ 7]  flag                        "F"
    field[ 8]  (empty)
    field[ 9]  (empty)
    field[10]  note GUID                   "{XXXXXXXX-....}"
    field[11]  (empty - trailing separator)

Fields 5, 7, 8, 9 are reproduced exactly as erwin wrote them.

ONE ITEM TO CONFIRM IN erwin
-----------------------------
The hand-made sample note text was "asdfghjkl" - no newlines - so the file
gives no direct evidence of how erwin encodes a line break inside a note.
Since `HandleNonPrintableChar="Y"` is exactly the mechanism for non-printable
characters, the default here encodes LF as \\#x0A.  Use --newline-mode to
switch if erwin renders it differently:

    --newline-mode escaped-lf    (default)  LF -> \\#x0A
    --newline-mode escaped-crlf             LF -> \\#x0D\\#x0A
    --newline-mode raw                      literal newline in the record

Migrate a couple of entities first, open them in erwin, confirm the notes read
correctly, then run the full set.

DIRECTORIES
-----------
Three directories are configured in the CONFIGURED DIRECTORIES block below:

    ERWIN_INPUT_DIR   erwin XML export(s)          - input
    MODEL_INPUT_DIR   SAP PowerDesigner .ldm       - input
    OUTPUT_DIR        migrated XML + CSV report    - output

Because of these you can pass a bare filename, or omit the argument when the
directory holds exactly one candidate file.  An absolute path, or any path
containing a directory separator, is honoured as-is and bypasses them.

USAGE
-----
    # 1. show what is actually in the files (no assumptions, no writes)
    python pd_comment_to_erwin_note.py inspect

    # 1b. show the note structure learned from a reference file
    python pd_comment_to_erwin_note.py inspect \\
        --reference SUBSURFACE_AND_WELLS_updated_14_2026.xml

    # 2. migrate  ->  OUTPUT_DIR\\<erwin name>_notes.xml
    python pd_comment_to_erwin_note.py migrate --report

    # 3. prove only Notes changed
    python pd_comment_to_erwin_note.py verify \\
        --out SUBSURFACE_AND_WELLS_notes.xml

Explicit paths still work exactly as before:

    python pd_comment_to_erwin_note.py migrate \\
        --ldm  C:\\models\\SUBSURFACE_AND_WELLS.ldm \\
        --erwin C:\\in\\SUBSURFACE_AND_WELLS.xml \\
        --out  C:\\out\\SUBSURFACE_AND_WELLS_notes.xml \\
        --author PD_MIGRATION --report report.csv

Requires: lxml (for `verify` only).  `inspect` and `migrate` use the standard
library alone.
"""

from __future__ import annotations

import argparse
import csv
import os
import re
import sys
import uuid
import xml.parsers.expat as expat
from collections import Counter, OrderedDict
from datetime import datetime

# ── REPO ROOT ON sys.path ────────────────────────────────────────────────────
# app/preprocessing/orchestrator.py runs this file as a bare subprocess
# (`sys.executable <path> migrate`), with neither the repo root on PYTHONPATH
# nor a package context. Every `from app.…` import therefore raised
# ModuleNotFoundError — silently, because the RTF helper below swallowed it —
# and PowerDesigner's RTF envelopes were written into erwin verbatim
# ("{\rtf1\ansi\ansicpg1252…" showing up in Notes). Putting the root on the
# path makes the shared helpers importable in BOTH run modes.
_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.dirname(os.path.abspath(__file__)))))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

KEY_ERWIN = "erwin"
EXT_XML = ".xml"
PROP_NAME = "Name"
# The three client-confirmed mappings, all injected by this script — see the
# module docstring for why none of them is validation-only.
PROP_COMMENT = "Comment"
PROP_DESCRIPTION = "Description"
PROP_ANNOTATION = "Annotation"

# erwin tags written by this script.
DEFINITION_TAG = "Definition"
EXT_NOTES_PROPS_TAG = "Extended_NotesProps"

# Target identifiers used on report rows and in --only-target.
TARGET_DEFINITION = "definition"
TARGET_NOTE = "note"
TARGET_ANNOTATION = "annotation"
ALL_TARGETS = (TARGET_DEFINITION, TARGET_NOTE, TARGET_ANNOTATION)

#: target -> (PD field it reads, erwin field it writes) — report wording only.
TARGET_FIELDS = {
    TARGET_DEFINITION: ("Comment", "Definition"),
    TARGET_NOTE: ("Description", "Note"),
    TARGET_ANNOTATION: ("Annotation", "Note Annotation"),
}
KEY_KIND = "kind"
KEY_ENTITY = "entity"
KEY_PNAME = "physical_name"
ENC_UTF8 = "utf-8"
KEY_MIGRATE = "migrate"
ERWIN_XML = "erwin XML"


STATUS_KEY = "status"
REASON_KEY = "reason"
STATUS_PASS = "PASS"
STATUS_FAIL = "FAIL"
#: prefix of a per-target outcome that actually changed the erwin file
WRITTEN = "written"
STATUS_SKIPPED = "SKIPPED"
STATUS_UNMATCHED = "UNMATCHED"
KIND_ENTITY = "Entity"
KIND_ATTRIBUTE = "Attribute"
# PDM programmable / storage objects. PD Descriptions on these were never
# carried (the PDM flow used to skip Step 1 altogether); they are written to
# erwin Notes exactly like entity / attribute descriptions.
KIND_VIEW = "View"
KIND_PROCEDURE = "Procedure"          # PD Procedure AND Function (erwin Stored_Procedure / Function)
KIND_TRIGGER = "Trigger"              # owned by a table, matched like an attribute
KIND_SEQUENCE = "Sequence"
KIND_TABLESPACE = "Tablespace"
#: PD Package == erwin Subject Area. Packages carry business documentation in
#: exactly the same Comment/Description/Annotation fields as everything else,
#: and until 2026-09-17 nothing carried it across — the gap only became visible
#: once Definitions started being written at all.
KIND_PACKAGE = "Package"
#: The model object itself. Its Comment is the model-level description the
#: erwin UI shows on the model's own Definition tab; nothing carried it, so
#: every run reported MODEL_DEFINITION "Model comment not carried".
KIND_MODEL = "Model"
SIMPLE_KINDS = (KIND_VIEW, KIND_PROCEDURE, KIND_SEQUENCE, KIND_TABLESPACE,
                KIND_PACKAGE, KIND_MODEL)
ALL_KINDS = (KIND_ENTITY, KIND_ATTRIBUTE, KIND_VIEW, KIND_PROCEDURE, KIND_TRIGGER,
             KIND_SEQUENCE, KIND_TABLESPACE, KIND_PACKAGE, KIND_MODEL)
# --------------------------------------------------------------------------
# erwin note record constants - all verified against the reference export
# --------------------------------------------------------------------------
SEP = r"\#x1F"                     # six literal chars: \ # x 1 F
NOTE_FIELD_COUNT = 12
IDX_NUMBER, IDX_CREATED, IDX_CREATOR = 0, 1, 2
IDX_MODIFIED, IDX_MODIFIER = 3, 4
IDX_TEXT = 6
IDX_FLAG = 7
IDX_GUID = 10

NOTE_FLAG_DEFAULT = "F"            # field[7] as erwin wrote it
ANCHOR_TAG = "User_Formatted_Physical_Name"
NOTE_ARRAY_TAG = "Note_List_Array"
# erwin <XProps> block -> object kind. Tables / columns of a PDM export are
# Entity / Attribute in erwin's XML, so one mapping serves CDM, LDM and PDM.
PROPS_KIND = {
    "EntityProps": KIND_ENTITY,
    "AttributeProps": KIND_ATTRIBUTE,
    "ViewProps": KIND_VIEW,
    "Stored_ProcedureProps": KIND_PROCEDURE,
    "FunctionProps": KIND_PROCEDURE,
    "TriggerProps": KIND_TRIGGER,
    "SequenceProps": KIND_SEQUENCE,
    "TablespaceProps": KIND_TABLESPACE,
    "Subject_AreaProps": KIND_PACKAGE,
    "ModelProps": KIND_MODEL,
}
PROPS_TAGS = tuple(PROPS_KIND)
#: The element that WRAPS each props block — <Entity> around <EntityProps>, and
#: so on. Extended_Notes_Groups is a sibling of the props block inside this
#: wrapper, so the wrapper is what ties an object's Extended Notes back to it.
CONTAINER_TAGS = frozenset(tag[:-len("Props")] for tag in PROPS_KIND)
# PD object tag -> (kind, owner tag or None). Table / Column are the PDM
# spellings of Entity / EntityAttribute.
PD_KIND_TAGS = {
    "Entity": (KIND_ENTITY, None), "Table": (KIND_ENTITY, None),
    "EntityAttribute": (KIND_ATTRIBUTE, "Entity"), "Column": (KIND_ATTRIBUTE, "Table"),
    "View": (KIND_VIEW, None), "Procedure": (KIND_PROCEDURE, None), "Function": (KIND_PROCEDURE, None),
    "Trigger": (KIND_TRIGGER, "Table"), "Sequence": (KIND_SEQUENCE, None), "Tablespace": (KIND_TABLESPACE, None),
    "Package": (KIND_PACKAGE, None), "Model": (KIND_MODEL, None),
}

TS_FMT = "%Y-%m-%d %H:%M:%S"

# SAP PowerDesigner namespaces
PD_ATTR = "attribute"
PD_OBJ = "object"

# --------------------------------------------------------------------------
# CONFIGURED DIRECTORIES
# --------------------------------------------------------------------------
# Edit these three paths to match the machine the script runs on.
#
#   ERWIN_INPUT_DIR : where the erwin XML export(s) live
#   MODEL_INPUT_DIR : where the SAP PowerDesigner .ldm model(s) live
#   OUTPUT_DIR      : where the migrated XML / CSV report are written
#
# With these set you can pass a bare filename - or omit the argument entirely
# when the directory holds exactly one candidate file:
#
#   python pd_comment_to_erwin_note.py migrate
#   python pd_comment_to_erwin_note.py migrate --erwin SUBSURFACE_AND_WELLS.xml
#
# An argument containing a path separator, or an absolute path, is used as
# given and bypasses these directories entirely.
# --------------------------------------------------------------------------

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

ERWIN_INPUT_DIR = os.path.join(BASE_DIR, "Erwin_file")
MODEL_INPUT_DIR = os.path.join(BASE_DIR, "Model_dir")
OUTPUT_DIR = os.path.join(BASE_DIR, "Output_dir")

# suffix appended to the erwin input name when --out is not supplied
DEFAULT_OUTPUT_SUFFIX = "_notes"
DEFAULT_REPORT_NAME = "migration_report.csv"
# --------------------------------------------------------------------------
# small helpers
# --------------------------------------------------------------------------

def localname(tag: str) -> str:
    """Strip {namespace} and any ns: prefix."""
    if not isinstance(tag, str):
        return ""
    return tag.rsplit("}", 1)[-1].split(":")[-1]


def _norm_key(value: str) -> str:
    """
    Case/punctuation-insensitive matching key. SAP PD and erwin frequently
    spell the same object's name/code with different casing, spacing or
    separators ("Business Name" vs "BUSINESS_NAME"); an exact-string match
    alone silently drops the comment for every such object.
    """
    return re.sub(r"[^a-z0-9]", "", (value or "").strip().lower())


def _has_own_path(value: str) -> bool:
    """True when the user gave a path, not just a bare filename."""
    return bool(value) and (os.path.isabs(value) or os.path.dirname(value))


def resolve_input(value, base_dir, extensions, what, flag=None):
    if _has_own_path(value):
        return value
    if value:
        return os.path.join(base_dir, value)
    return _auto_discover_input(base_dir, extensions, what, flag)

def _auto_discover_input(base_dir, extensions, what, flag):
    if not os.path.isdir(base_dir):
        raise SystemExit(
            "ERROR: %s directory does not exist:\n    %s\n"
            "Set it at the top of this script, or pass the file explicitly."
            % (what, base_dir))

    found = sorted(f for f in os.listdir(base_dir)
                   if f.lower().endswith(extensions)
                   and os.path.isfile(os.path.join(base_dir, f)))
    if len(found) == 1:
        return os.path.join(base_dir, found[0])
    if not found:
        raise SystemExit(
            "ERROR: no %s file (%s) found in:\n    %s"
            % (what, "/".join(extensions), base_dir))
    raise SystemExit(
        "ERROR: %d %s files found in:\n    %s\n%s\n"
        "Pass the one you want, e.g. --%s %s"
        % (len(found), what, base_dir,
           "\n".join("      " + f for f in found),
           flag or KEY_ERWIN, found[0]))


def resolve_output(value, default_name):
    """Place an output file in OUTPUT_DIR unless the user gave a path."""
    if _has_own_path(value):
        target = value
    else:
        if not os.path.isdir(OUTPUT_DIR):
            os.makedirs(OUTPUT_DIR, exist_ok=True)
        target = os.path.join(OUTPUT_DIR, value or default_name)
    parent = os.path.dirname(os.path.abspath(target))
    if parent and not os.path.isdir(parent):
        os.makedirs(parent, exist_ok=True)
    return target

def default_output_name(erwin_path: str) -> str:
    stem, ext = os.path.splitext(os.path.basename(erwin_path))
    return "%s%s%s" % (stem, DEFAULT_OUTPUT_SUFFIX, ext or EXT_XML)


def xml_escape_text(s: str) -> str:
    """Escape for XML element content."""
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def encode_note_payload(text: str, newline_mode: str) -> str:
    """
    Turn a SAP PD Description into the field[6] payload.

    HandleNonPrintableChar="Y" means control characters travel as \\#xNN.
    """
    if newline_mode == "escaped-crlf":
        nl = r"\#x0D" + r"\#x0A"
    elif newline_mode == "raw":
        nl = "\n"
    else:                                    # escaped-lf (default)
        nl = r"\#x0A"

    # A literal "\#x" in the source would be re-read by erwin as an escape.
    # Encode the backslash so the text survives intact.
    text = text.replace("\\#x", r"\#x5C" + "#x")

    text = text.replace("\r\n", "\n").replace("\r", "\n")

    out = []
    for ch in text:
        o = ord(ch)
        if ch == "\n":
            out.append(nl)
        elif ch == "\t":
            out.append(r"\#x09")
        elif o < 0x20 or o == 0x7F:
            out.append(r"\#x%02X" % o)
        else:
            out.append(ch)
    return "".join(out)


def build_note_record(text: str, author: str, newline_mode: str,
                      number: int = 1, guid: str | None = None,
                      created: str | None = None,
                      modified: str | None = None) -> str:
    """Assemble the 12-field \\#x1F-delimited erwin note record."""
    now = datetime.now().strftime(TS_FMT)
    fields = [""] * NOTE_FIELD_COUNT
    fields[IDX_NUMBER] = str(number)
    fields[IDX_CREATED] = created or now
    fields[IDX_CREATOR] = author
    fields[IDX_MODIFIED] = modified or now
    fields[IDX_MODIFIER] = author
    fields[IDX_TEXT] = encode_note_payload(text, newline_mode)
    fields[IDX_FLAG] = NOTE_FLAG_DEFAULT
    fields[IDX_GUID] = guid or ("{%s}" % str(uuid.uuid4()).upper())
    return SEP.join(fields)


def build_note_element(record: str, index: int = 0) -> str:
    return ('<Note_List HandleNonPrintableChar="Y" index="%d">%s</Note_List>'
            % (index, xml_escape_text(record)))


def build_note_array(records: list) -> str:
    inner = "".join(build_note_element(r, i) for i, r in enumerate(records))
    return "<%s>%s</%s>" % (NOTE_ARRAY_TAG, inner, NOTE_ARRAY_TAG)
# --------------------------------------------------------------------------
# SAP PowerDesigner .ldm reader
# --------------------------------------------------------------------------

def _strip_rtf(text: str) -> str:
    """
    PowerDesigner stores Comment/Description in a rich-text editor, so a
    one-line description arrives wrapped in a full RTF envelope
    ('{\\rtf1\\ansi...}'). The reconcilers strip it (pd_ldm_parser._strip_rtf)
    before comparing, but this injector did NOT — so an RTF description was
    written into the erwin Note as raw markup, and the Description -> Note
    documentation row then compared stripped PD text against unstripped erwin
    text and reported a MISMATCH for a description that had migrated correctly.

    The shared tokenizer is reused rather than reimplemented: it walks the RTF
    group stack properly, and a second copy here would be free to drift from
    it. It is importable in both run modes now that the repo root is put on
    sys.path at the top of this module.

    If the import still fails, this falls back to a conservative in-file
    extractor and says so on stderr. It no longer returns the text unchanged:
    that "never loses content" fallback was silently shipping raw
    "{\\rtf1\\ansi…}" envelopes into erwin Notes on every pipeline run, because
    the subprocess launch meant the import failed EVERY time.
    """
    if not text or "\\rtf" not in text:
        return text
    try:
        from app.common.rtf_text import strip_rtf as strip
    except Exception:                                          # noqa: BLE001
        if not _RTF_IMPORT_WARNED:
            print("WARNING: app.common.rtf_text unavailable; using the in-file "
                  "RTF fallback. Text is still stripped, but check the run.",
                  file=sys.stderr)
            _RTF_IMPORT_WARNED.append(True)
        strip = _fallback_strip_rtf
    stripped = strip(text)
    # Never let a stripper bug turn a real comment into nothing.
    return stripped if stripped.strip() else text


#: one-shot guard so the fallback warning is printed once per run, not per object
_RTF_IMPORT_WARNED: list = []


def _fallback_strip_rtf(text: str) -> str:
    """
    Last-resort RTF -> plain text, used only when the shared tokenizer cannot
    be imported. Deliberately conservative: imperfect plain text is far better
    than handing erwin a wall of control words.
    """
    for dest in ("fonttbl", "colortbl", "stylesheet", "info", "generator",
                 "listtable", "rsidtbl", "pntxta", "pntxtb"):
        text = re.sub(r"\{\\\*?\\" + dest + r"[^{}]*(?:\{[^{}]*\}[^{}]*)*\}", "", text)
    text = re.sub(r"\{\\\*[^{}]*(?:\{[^{}]*\}[^{}]*)*\}", "", text)
    text = re.sub(r"\\'([0-9a-fA-F]{2})",
                  lambda m: chr(int(m.group(1), 16)), text)
    text = re.sub(r"\\u(-?\d+)\s?\??",
                  lambda m: chr(int(m.group(1)) % 65536), text)
    text = re.sub(r"\\pard\b", "", text)          # paragraph RESET, not a break
    text = re.sub(r"\\(?:par|line)\b", "\n", text)
    text = re.sub(r"\\([a-zA-Z]+)-?\d*\s?", "", text)          # control words
    text = text.replace("\\\\", "\\").replace("\\{", "{").replace("\\}", "}")
    text = re.sub(r"[{}]", "", text)
    text = re.sub(r"[ \t]+\n", "\n", text)
    return re.sub(r"\n{3,}", "\n\n", text).strip()


class DocText(str):
    """
    The three PD documentation fields of one object, carried together.

    Subclasses ``str``, and its string value IS the Description, so every
    existing caller, index and test that treats a PD model's map values as
    "the text that becomes an erwin Note" keeps working untouched. Comment and
    Annotation ride along as attributes for the two mappings added in 2026-09.

    (No ``__slots__``: CPython forbids a non-empty ``__slots__`` on a subclass
    of a variable-length builtin such as ``str``.)
    """

    def __new__(cls, comment="", description="", annotation=""):
        self = super().__new__(cls, description or "")
        self.comment = comment or ""
        self.description = description or ""
        self.annotation = annotation or ""
        return self

    def text_for(self, target: str) -> str:
        """The PD text this object contributes to one erwin target."""
        if target == TARGET_DEFINITION:
            return self.comment
        if target == TARGET_ANNOTATION:
            return self.annotation
        return self.description

    @property
    def has_any(self) -> bool:
        return bool((self.comment + self.description + self.annotation).strip())


def as_doc_text(value) -> DocText:
    """
    Adapt a PD map value to DocText.

    A bare ``str`` is how older callers and tests populate these maps; it is
    read as Description-only, which is exactly the behaviour those callers
    were written against.
    """
    if isinstance(value, DocText):
        return value
    return DocText(description=value or "")


class PDModel:
    """
    Name, Code and the three documentation fields (Comment / Description /
    Annotation) of every documentable object in a PD model.

    CDM / LDM: Entity, EntityAttribute.  PDM: Table, Column (kept in the same
    `entities` / `attributes` maps — erwin calls them Entity / Attribute too),
    plus View, Procedure / Function, Trigger (owned by a table), Sequence and
    Tablespace in `objects[kind]` / `triggers`.
    """

    def __init__(self):
        self.entities = OrderedDict()    # (name, code) -> DocText
        self.attributes = OrderedDict()  # (ent_name, name, code) -> DocText
        self.entity_codes = {}           # code -> [(name, code)]
        self.entity_names = {}           # name.lower() -> [(name, code)]
        self.objects = {k: OrderedDict() for k in SIMPLE_KINDS}   # kind -> (name, code) -> DocText
        self.triggers = OrderedDict()    # (table_name, name, code) -> DocText

    def count(self, kind: str) -> int:
        if kind == KIND_ENTITY:
            return len(self.entities)
        if kind == KIND_ATTRIBUTE:
            return len(self.attributes)
        if kind == KIND_TRIGGER:
            return len(self.triggers)
        return len(self.objects.get(kind, ()))

    @classmethod
    def load(cls, path: str) -> "PDModel":
        try:
            from lxml import etree as ET
            tree = ET.parse(path, ET.XMLParser(huge_tree=True, resolve_entities=False, no_network=True))
        except ImportError:
            from defusedxml.ElementTree import parse as safe_parse
            tree = safe_parse(path)

        m = cls()
        a = "{%s}" % PD_ATTR
        o = "{%s}" % PD_OBJ

        def val(el, name):
            child = el.find(a + name)
            text = child.text if child is not None and child.text else ""
            return _strip_rtf(text)

        def definitions(root, tag):
            # <o:X Ref="oNNN"/> are pointers, not definitions - skip them
            return [el for el in root.iter(o + tag) if el.get("Id") is not None]

        def docs(el):
            """All three PD documentation fields of one element."""
            return DocText(comment=val(el, PROP_COMMENT),
                           description=val(el, PROP_DESCRIPTION),
                           annotation=val(el, PROP_ANNOTATION))

        root = tree.getroot()
        for owner_tag, member_tag in (("Entity", "EntityAttribute"), ("Table", "Column")):
            for ent in definitions(root, owner_tag):
                ename, ecode = val(ent, PROP_NAME), val(ent, "Code")
                m.entities[(ename, ecode)] = docs(ent)
                m.entity_codes.setdefault(ecode, []).append((ename, ecode))
                m.entity_names.setdefault(ename.lower(), []).append((ename, ecode))
                for att in definitions(ent, member_tag):
                    m.attributes[(ename, val(att, PROP_NAME), val(att, "Code"))] = docs(att)
                if owner_tag == "Table":
                    for trg in definitions(ent, "Trigger"):
                        m.triggers[(ename, val(trg, PROP_NAME), val(trg, "Code"))] = docs(trg)

        for tag, (kind, _owner) in PD_KIND_TAGS.items():
            if kind not in SIMPLE_KINDS:
                continue
            for el in definitions(root, tag):
                m.objects[kind][(val(el, PROP_NAME), val(el, "Code"))] = docs(el)
        return m

# --------------------------------------------------------------------------
# erwin XML scanner - expat gives exact byte offsets
# --------------------------------------------------------------------------

class ErwinObject:
    __slots__ = (KEY_KIND, KEY_ENTITY, "name", KEY_PNAME,
                 "anchor_end", "props_close", "note_array_span",
                 "existing_notes", "first_child_start", "name_start",
                 "definition_span", "existing_definition", "ext_comment_span",
                 "existing_annotation")

    def __init__(self):
        self.kind = None
        self.entity = None
        self.name = None
        self.physical_name = None
        self.anchor_end = None       # byte offset just past </User_Formatted_Physical_Name>
        self.props_close = None      # byte offset of </EntityProps> or </AttributeProps>
        self.note_array_span = None  # (start, end) if Note_List_Array already present
        self.existing_notes = 0
        # ── Definition (PD Comment target) ───────────────────────────────────
        #: byte offset of this props block's own <Name> child. Both real erwin
        #: exports that carry Definitions place <Definition> IMMEDIATELY BEFORE
        #: <Name> — in <EntityProps> it is the first child, in <ModelProps> it
        #: follows <Auto_Created_Initially_Id> — so "just before <Name>" is the
        #: anchor that holds for both. first_child_start is the fallback for a
        #: props block with no <Name> at all.
        self.name_start = None
        self.first_child_start = None
        self.definition_span = None    # (start, end) if <Definition> already present
        self.existing_definition = False
        # ── Extended Notes (PD Annotation target) ────────────────────────────
        #: (start, end) of the <Comment> inside this object's
        #: Extended_NotesProps — erwin provisions one per entity and leaves it
        #: empty; that element is the "Note Annotation" the UI shows.
        self.ext_comment_span = None
        self.existing_annotation = False

    @property
    def key(self):
        if self.kind in (KIND_ATTRIBUTE, KIND_TRIGGER):
            return (self.entity, self.name, self.physical_name)
        return (self.name, self.physical_name)

    @property
    def label(self):
        if self.kind in (KIND_ATTRIBUTE, KIND_TRIGGER):
            return "%s '%s.%s'" % (self.kind, self.entity, self.name)
        return "%s '%s'" % (self.kind, self.name)


def _handle_props_text(obj, parent, tag, text):
    if parent not in PROPS_TAGS:
        return

    if tag == PROP_NAME and obj.name is None:
        obj.name = text
    elif tag == "Physical_Name" and obj.physical_name is None:
        obj.physical_name = text


def _handle_anchor(obj, parent, tag, parser):
    if (
        tag == ANCHOR_TAG
        and parent in PROPS_TAGS
        and obj.anchor_end is None
    ):
        obj.anchor_end = (
            parser.CurrentByteIndex + len(f"</{ANCHOR_TAG}>")
        )


def _handle_note_array(obj, tag, state, parser, raw):
    if tag != NOTE_ARRAY_TAG or not state["in_note_array"]:
        return

    idx = parser.CurrentByteIndex
    closing = f"</{NOTE_ARRAY_TAG}>".encode(ENC_UTF8)

    if raw[idx:idx + len(closing)] == closing:
        nla_end = idx + len(closing)
    else:  # self-closing <X/>
        nla_end = raw.index(b">", state["nla_start"]) + 1

    obj.note_array_span = (state["nla_start"], nla_end)
    state["in_note_array"] = False
    state["nla_start"] = None


def _finalize_object(obj, tag, state, parser, objects, containers=None):
    if tag not in PROPS_TAGS:
        return

    obj.props_close = parser.CurrentByteIndex

    if obj.kind == KIND_ENTITY:
        state["cur_entity"] = obj.name
        obj.entity = obj.name

    # Hand the finished object to its wrapper so Extended_Notes_Groups — which
    # erwin writes AFTER </EntityProps>, when no props block is in scope — can
    # still find the object it documents.
    if containers:
        containers[-1]["obj"] = obj

    objects.append(obj)
    state["obj"] = None


def _close_span(tag, start, parser, raw):
    """
    The (start, end) byte span of an element whose start offset is known, while
    in its EndElementHandler. Handles both ``<X>…</X>`` and self-closing ``<X/>``.
    """
    idx = parser.CurrentByteIndex
    closing = f"</{tag}>".encode(ENC_UTF8)
    if raw[idx:idx + len(closing)] == closing:
        return (start, idx + len(closing))
    return (start, raw.index(b">", start) + 1)


def _handle_definition_end(obj, parent, tag, text, state, parser, raw):
    """Record an existing <Definition> sitting inside the props block."""
    if tag != DEFINITION_TAG or parent not in PROPS_TAGS:
        return
    if state.get("def_start") is None:
        return
    obj.definition_span = _close_span(DEFINITION_TAG, state["def_start"], parser, raw)
    obj.existing_definition = bool((text or "").strip())
    state["def_start"] = None


def _handle_ext_comment_end(containers, parent, tag, text, state, parser, raw):
    """
    Record the <Comment> inside Extended_NotesProps — the element the erwin UI
    shows as the object's Note Annotation — against its owning object.

    Only the FIRST Extended Notes group of an object is claimed: erwin numbers
    them Ext_Notes_1, Ext_Notes_2, … and the migrated Annotation belongs in the
    first, not spread across whichever the export happens to end with.
    """
    if tag != PROP_COMMENT or parent != EXT_NOTES_PROPS_TAG:
        return
    start = state.get("ext_comment_start")
    state["ext_comment_start"] = None
    if start is None or not containers:
        return
    owner = containers[-1].get("obj")
    if owner is None or owner.ext_comment_span is not None:
        return
    owner.ext_comment_span = _close_span(PROP_COMMENT, start, parser, raw)
    owner.existing_annotation = bool((text or "").strip())


def _handle_note_list_end(obj, tag, text):
    """
    A pre-existing Note_List whose text field is blank is an empty erwin
    placeholder, not a real note - it must not block writing the SAP PD
    comment under the default --on-existing skip. Only a Note_List that
    actually carries text counts as "already present".
    """
    if tag != "Note_List":
        return
    if decode_note_record(text)["text"].strip():
        obj.existing_notes += 1


def scan_erwin(raw: bytes):
    """Walk the erwin export, returning [ErwinObject] with byte offsets."""
    objects = []
    stack = []
    chars = []
    containers = []          # open <Entity>/<Attribute>/… wrappers, innermost last
    state = {
        "obj": None,
        "cur_entity": None,
        "nla_start": None,
        "in_note_array": False,
        "def_start": None,
        "ext_comment_start": None,
    }

    parser = expat.ParserCreate()
    parser.buffer_text = True

    def start(name, attrs):
        n = localname(name)
        stack.append(n)
        del chars[:]
        parent = stack[-2] if len(stack) >= 2 else None

        if n in CONTAINER_TAGS:
            containers.append({"obj": None})

        if n in PROPS_TAGS:
            o = ErwinObject()
            o.kind = PROPS_KIND[n]
            # Only attributes and triggers belong to the enclosing entity.
            o.entity = state["cur_entity"] if o.kind in (KIND_ATTRIBUTE, KIND_TRIGGER) else None
            state["obj"] = o

        elif n == NOTE_ARRAY_TAG and state["obj"] is not None:
            state["nla_start"] = parser.CurrentByteIndex
            state["in_note_array"] = True

        obj = state["obj"]
        if obj is not None and parent in PROPS_TAGS:
            # erwin places <Definition> immediately before <Name>; remember
            # where <Name> starts so a new Definition lands in that position.
            if obj.first_child_start is None:
                obj.first_child_start = parser.CurrentByteIndex
            if n == PROP_NAME and obj.name_start is None:
                obj.name_start = parser.CurrentByteIndex
            if n == DEFINITION_TAG:
                state["def_start"] = parser.CurrentByteIndex

        if n == PROP_COMMENT and parent == EXT_NOTES_PROPS_TAG:
            state["ext_comment_start"] = parser.CurrentByteIndex

    def chardata(data):
        chars.append(data)

    def end(name):
        n = localname(name)
        text = "".join(chars)
        del chars[:]
        parent = stack[-2] if len(stack) >= 2 else None

        obj = state["obj"]
        if obj is not None:
            _handle_props_text(obj, parent, n, text)
            _handle_anchor(obj, parent, n, parser)
            _handle_definition_end(obj, parent, n, text, state, parser, raw)
            _handle_note_array(obj, n, state, parser, raw)
            _handle_note_list_end(obj, n, text)
            _finalize_object(obj, n, state, parser, objects, containers)

        # Outside the `obj` guard on purpose: Extended_Notes_Groups opens after
        # </EntityProps>, when no props block is in scope any more.
        _handle_ext_comment_end(containers, parent, n, text, state, parser, raw)

        if n in CONTAINER_TAGS and containers:
            containers.pop()

        stack.pop()

    parser.StartElementHandler = start
    parser.EndElementHandler = end
    parser.CharacterDataHandler = chardata
    parser.Parse(raw, True)
    return objects

def decode_note_record(record: str) -> dict:
    """Split a Note_List record into its named fields."""
    f = record.split(SEP)
    while len(f) < NOTE_FIELD_COUNT:
        f.append("")
    return {
        "number": f[IDX_NUMBER], "created": f[IDX_CREATED],
        "creator": f[IDX_CREATOR], "modified": f[IDX_MODIFIED],
        "modifier": f[IDX_MODIFIER], "text": f[IDX_TEXT],
        "flag": f[IDX_FLAG], "guid": f[IDX_GUID],
        "field_count": len(f), "raw_fields": f,
    }

# --------------------------------------------------------------------------
# matching
# --------------------------------------------------------------------------

def match_objects(pd: PDModel, objects):
    matches = {}
    unmatched = []

    simple = {KIND_ENTITY: (pd.entities, _build_simple_indices(pd.entities))}
    for kind in SIMPLE_KINDS:
        simple[kind] = (pd.objects[kind], _build_simple_indices(pd.objects[kind]))
    owned = {KIND_ATTRIBUTE: (pd.attributes, _build_owned_indices(pd.attributes)),
             KIND_TRIGGER: (pd.triggers, _build_owned_indices(pd.triggers))}

    for o in objects:
        if o.kind in owned:
            table, indices = owned[o.kind]
            hit, tier = _match_owned(o, table, indices)
        else:
            table, indices = simple[o.kind]
            hit, tier = _match_simple(o, table, indices)

        if tier is None:
            unmatched.append(o)
        else:
            matches[id(o)] = (as_doc_text(hit), tier)
    return matches, unmatched


def _build_simple_indices(table):
    """(name, code) -> comment  ==>  code / lower-name / normalised indices."""
    by_code, by_name, by_norm = {}, {}, {}
    for (n, c) in table:
        by_code.setdefault(c, []).append((n, c))
        by_name.setdefault(n.strip().lower(), []).append((n, c))
        by_norm.setdefault(_norm_key(c) or _norm_key(n), []).append((n, c))
    return by_code, by_name, by_norm


def _build_owned_indices(table):
    """(owner, name, code) -> comment  ==>  the same three indices scoped by owner."""
    by_code, by_name, by_norm = {}, {}, {}
    for (e, n, c) in table:
        by_code.setdefault((e, c), []).append((e, n, c))
        by_name.setdefault((e, n.strip().lower()), []).append((e, n, c))
        by_norm.setdefault((_norm_key(e), _norm_key(c) or _norm_key(n)), []).append((e, n, c))
    return by_code, by_name, by_norm


def _match_simple(o, table, indices):
    """Tier 1 exact (name, code) · 2 code · 3 name (case-insensitive) · 4 normalised."""
    by_code, by_name, by_norm = indices
    k = (o.name, o.physical_name)
    if k in table:
        return table[k], 1
    cand = by_code.get(o.physical_name, [])
    if len(cand) == 1:
        return table[cand[0]], 2
    cand = by_name.get((o.name or "").strip().lower(), [])
    if len(cand) == 1:
        return table[cand[0]], 3
    cand = by_norm.get(_norm_key(o.physical_name) or _norm_key(o.name), [])
    if len(cand) == 1:
        return table[cand[0]], 4
    return None, None


def _match_owned(o, table, indices):
    """Same tiers as _match_simple, scoped to the owning entity / table."""
    by_code, by_name, by_norm = indices
    k = (o.entity, o.name, o.physical_name)
    if k in table:
        return table[k], 1
    cand = by_code.get((o.entity, o.physical_name), [])
    if len(cand) == 1:
        return table[cand[0]], 2
    cand = by_name.get((o.entity, (o.name or "").strip().lower()), [])
    if len(cand) == 1:
        return table[cand[0]], 3
    cand = by_norm.get((_norm_key(o.entity), _norm_key(o.physical_name) or _norm_key(o.name)), [])
    if len(cand) == 1:
        return table[cand[0]], 4
    return None, None


# Backwards-compatible aliases (older callers / tests).
def _build_entity_indices(pd):
    return _build_simple_indices(pd.entities)


def _build_attribute_indices(pd):
    return _build_owned_indices(pd.attributes)


def _match_entity(o, pd, ent_by_code, ent_by_name, ent_by_norm):
    return _match_simple(o, pd.entities, (ent_by_code, ent_by_name, ent_by_norm))


def _match_attribute(o, pd, att_by_code, att_by_name, att_by_norm):
    return _match_owned(o, pd.attributes, (att_by_code, att_by_name, att_by_norm))


def cmd_inspect(args):
    pd = _inspect_pd_model(args)
    raw, objs = _inspect_erwin_xml(args)
    _inspect_note_structure(args, raw)
    _inspect_match_preview(pd, objs, args)

def _inspect_pd_model(args):
    print("=" * 74)
    print("SAP PowerDesigner LDM :", args.ldm)
    print("=" * 74)
    pd = PDModel.load(args.ldm)
    ec = sum(1 for v in pd.entities.values() if v.strip())
    ac = sum(1 for v in pd.attributes.values() if v.strip())
    print("  entity/table definitions: %d  (with Description: %d)" % (len(pd.entities), ec))
    print("  attribute/column defs   : %d  (with Description: %d)" % (len(pd.attributes), ac))
    for kind in (KIND_VIEW, KIND_PROCEDURE, KIND_SEQUENCE, KIND_TABLESPACE):
        if pd.objects[kind]:
            with_description = sum(1 for v in pd.objects[kind].values() if v.strip())
            print("  %-24s: %d  (with Description: %d)" % (kind.lower() + " definitions", len(pd.objects[kind]), with_description))
    if pd.triggers:
        print("  trigger definitions     : %d  (with Description: %d)"
              % (len(pd.triggers), sum(1 for v in pd.triggers.values() if v.strip())))
    print("  Description is stored as: <a:Description> child of the <o:...> object")
    for (n, c), cm in pd.entities.items():
        if cm.strip():
            print("  sample entity           : Name=%r Code=%r" % (n, c))
            print("     Description[:90]     : %r" % cm[:90])
            break
    return pd

def _inspect_erwin_xml(args):
    raw = open(args.erwin, "rb").read()
    objs = scan_erwin(raw)
    ents = [o for o in objs if o.kind == KIND_ENTITY]
    atts = [o for o in objs if o.kind == KIND_ATTRIBUTE]
    print()
    print("=" * 74)
    print("erwin XML             :", args.erwin)
    print("=" * 74)
    print("  bytes                   : %d" % len(raw))
    print("  Entity objects          : %d" % len(ents))
    print("  Attribute objects       : %d" % len(atts))
    print("  with %-18s: %d / %d" % (ANCHOR_TAG, sum(1 for o in objs if o.anchor_end is not None), len(objs)))
    print("  already carrying %s : %d" % (NOTE_ARRAY_TAG, sum(1 for o in objs if o.note_array_span)))
    print("  existing Note_List recs : %d" % sum(o.existing_notes for o in objs))
    return raw, objs

def _inspect_note_structure(args, raw):
    ref = args.reference or args.erwin
    refraw = open(ref, "rb").read()
    print()
    print("=" * 74)
    print("erwin NOTE STRUCTURE  :", ref)
    print("=" * 74)
    found = re.search(rb"<Note_List\b[^>]*>(.*?)</Note_List>", refraw, re.S)
    if not found:
        print("  no populated <Note_List> in this file (pass --reference <file with verified notes>)")
        return

    rec = found.group(1).decode(ENC_UTF8)
    openttag = refraw[found.start():found.start() + found.group(0).find(b">") + 1]
    print("  element    : %s" % openttag.decode(ENC_UTF8))
    print("  separator  : %r  (literal 6 chars; real 0x1F bytes in file: %d)" % (SEP, refraw.count(b"\x1f")))

    d = decode_note_record(rec)
    print("  fields     : %d" % d["field_count"])
    names = {IDX_NUMBER: "number", IDX_CREATED: "created", IDX_CREATOR: "creator",
             IDX_MODIFIED: "modified", IDX_MODIFIER: "modifier",
             IDX_TEXT: "NOTE TEXT", IDX_FLAG: "flag", IDX_GUID: "guid"}
    for i, v in enumerate(d["raw_fields"]):
        print("     field[%2d] %-10s = %r" % (i, names.get(i, ""), v))

    m = re.search(rb"<Note_List_Array\b", refraw)
    if m:
        before = refraw[max(0, m.start() - 200):m.start()].decode(ENC_UTF8, "replace")
        after = refraw[m.start():m.start() + 200].decode(ENC_UTF8, "replace")
        prev = re.findall(r"</([A-Za-z_]+)>\s*$", before)
        nxt = re.findall(r"<([A-Za-z_]+)[ />]", after[after.find(">"):])
        print("  placement  : after </%s>, before <%s>" % (prev[-1] if prev else "?", nxt[0] if nxt else "?"))

def _inspect_match_preview(pd, objs, args):
    print()
    print("=" * 74)
    print("MATCH PREVIEW")
    print("=" * 74)
    matches, unmatched = match_objects(pd, objs)
    print("  PD objects       : %d" % sum(pd.count(k) for k in ALL_KINDS))
    print("  erwin objects    : %d" % len(objs))
    print("  matched          : %d" % len(matches))
    print("  unmatched erwin  : %d" % len(unmatched))
    if unmatched:
        print("  unmatched sample :")
        for u in unmatched[:5]:
            print("      %-9s Name=%r Code=%r" % (u.kind, u.name, u.physical_name))

def cmd_migrate(args):
    pd = PDModel.load(args.ldm)
    raw = open(args.erwin, "rb").read()
    objects = scan_erwin(raw)
    matches, unmatched = match_objects(pd, objects)

    only = set(args.only.split(",")) if args.only else set(ALL_KINDS)

    edits = []
    rows = []
    stats = Counter()

    for o in objects:
        _process_migrate_object(o, matches, only, args, raw, edits, rows, stats)

    print("=" * 74)
    print("MIGRATION EXECUTION")
    print("=" * 74)
    print("  SAP model               : %s" % args.ldm)
    print("  erwin XML               : %s" % args.erwin)
    print("  objects matched         : %d" % stats["matched"])
    print("  objects skipped         : %d" % stats["skipped"])
    print("  objects unmatched       : %d" % stats["unmatched"])

    skip_reasons = Counter(r[REASON_KEY] for r in rows if r[STATUS_KEY] == STATUS_SKIPPED)
    if skip_reasons:
        print("  skip reasons            :")
        for reason, count in skip_reasons.most_common():
            print("      %-58s %d" % (reason, count))

    total = stats["matched"] + stats["unmatched"]
    if total and stats["unmatched"] / total > 0.5:
        print("  WARNING: over half of erwin objects did not match any SAP PD "
              "object by Name/Code (even case/punctuation-normalised) -- "
              "their comments were NOT migrated. Check whether the two "
              "models actually correspond to the same source.")
    if len(edits) == 0 and any(r["comment_chars"] for r in rows):
        print("  WARNING: SAP PD has populated comments but zero edits were "
              "written to erwin. Every candidate object was either unmatched "
              "or already carried a non-blank Note (see skip reasons above).")

    _write_migrate_output(args, raw, edits)
    if getattr(args, "report", None) and not getattr(args, "csv", None):
        args.csv = args.report
    _write_migrate_csv(args, rows)

def _process_migrate_object(o, matches, only, args, raw, edits, rows, stats):
    row = {KEY_KIND: o.kind, KEY_ENTITY: o.entity or "", "name": o.name or "",
           KEY_PNAME: o.physical_name or "", STATUS_KEY: "",
           "match_tier": "", REASON_KEY: "", "comment_chars": 0,
           TARGET_DEFINITION + "_status": "",
           TARGET_NOTE + "_status": "",
           TARGET_ANNOTATION + "_status": ""}

    if id(o) not in matches:
        row[STATUS_KEY] = STATUS_UNMATCHED
        row[REASON_KEY] = "no PD object with this Name/Code"
        stats["unmatched"] += 1
        rows.append(row)
        return

    docs, tier = matches[id(o)]
    row["match_tier"] = tier
    row["comment_chars"] = len(docs.description)
    stats["matched"] += 1

    if o.kind not in only:
        row[STATUS_KEY] = STATUS_SKIPPED
        row[REASON_KEY] = "object kind excluded by --only"
        stats["skipped"] += 1
        rows.append(row)
        return

    wanted = getattr(args, "targets", None) or ALL_TARGETS
    reasons, written = [], 0
    for target in ALL_TARGETS:
        if target not in wanted:
            outcome = "skipped: target excluded by --only-target"
        else:
            outcome = _apply_target_edit(o, docs, target, args, raw, edits)
        row[target + "_status"] = outcome
        if outcome.startswith(WRITTEN):
            written += 1
        reasons.append("%s %s" % (target, outcome))

    row[REASON_KEY] = "; ".join(reasons)
    if written:
        row[STATUS_KEY] = STATUS_PASS
    else:
        row[STATUS_KEY] = STATUS_SKIPPED
        stats["skipped"] += 1
    rows.append(row)


def _apply_target_edit(o, docs, target, args, raw, edits) -> str:
    """
    Write one of the three PD documentation fields into its erwin home.

    Returns a short outcome string beginning with "written" or "skipped"; the
    caller records it per target so the CSV shows each mapping's fate
    separately rather than collapsing all three into one verdict.
    """
    text = docs.text_for(target)
    pd_field, _erwin_field = TARGET_FIELDS[target]
    if not text.strip():
        return "skipped: PD %s empty" % pd_field
    if target == TARGET_DEFINITION:
        return _edit_definition(o, text, args, raw, edits)
    if target == TARGET_ANNOTATION:
        return _edit_annotation(o, text, args, raw, edits)
    return _edit_note(o, text, args, raw, edits)


def erwin_text(text: str) -> str:
    """
    Normalise line endings to CRLF, the way erwin itself writes them.

    erwin's own exports carry literal CRLF inside <Definition> and <Comment>
    (the byte-splice rationale at the top of this file counts ~2,187 of them),
    and the erwin UI renders a bare LF as no break at all. PowerDesigner stores
    LF, so writing PD text through unchanged collapsed multi-paragraph
    definitions into a single line in the erwin UI — reported by the client as
    "the SAP PD text is in two lines, but erwin receives it as one".
    """
    return (text or "").replace("\r\n", "\n").replace("\r", "\n").replace("\n", "\r\n")


def _replace_element(span, tag, text, raw, edits, what) -> str:
    """Overwrite an existing element with the PD text, or report it unchanged."""
    payload = ("<%s>%s</%s>" % (tag, xml_escape_text(erwin_text(text)),
                                tag)).encode(ENC_UTF8)
    start, end = span
    if raw[start:end] == payload:
        return "unchanged: erwin %s already matches SAP PD" % what
    edits.append((start, end, payload))
    return "written: replaced existing %s" % what


def _edit_definition(o, text, args, raw, edits) -> str:
    """
    PD Comment -> erwin <Definition>, spliced in immediately before <Name>.

    SAP PD is the source of truth here, so an existing erwin Definition is
    REPLACED rather than skipped. ``--on-existing`` governs Notes, where a
    modeller may legitimately have typed something in erwin; a Definition that
    disagrees with PD is a half-finished migration, not authored content. A
    real export carried only the first of three PD paragraphs, and the old
    skip-if-present rule preserved that stump — the report then read
    DEFINITION_PARTIAL at 69.9% similarity. Pass
    ``--keep-existing-definition`` to get the old behaviour back.
    """
    if o.definition_span:
        if o.existing_definition and getattr(args, "keep_existing_definition", False):
            return "skipped: erwin Definition kept (--keep-existing-definition)"
        return _replace_element(o.definition_span, DEFINITION_TAG, text, raw,
                                edits, "Definition")

    start = o.name_start
    if start is None:
        start = o.first_child_start if o.first_child_start is not None else o.props_close
    if start is None:
        return "skipped: no insertion point in erwin object"
    payload = ("<%s>%s</%s>" % (DEFINITION_TAG, xml_escape_text(erwin_text(text)),
                                DEFINITION_TAG)).encode(ENC_UTF8)
    edits.append((start, start, payload))
    return "written: created Definition"


def _edit_annotation(o, text, args, raw, edits) -> str:
    """
    PD Annotation -> the <Comment> inside erwin's Extended_NotesProps.

    erwin provisions one Extended Notes group per entity and leaves its Comment
    empty; that element is what the UI shows as the Note Annotation. Where the
    export provisioned none (erwin does not create them for attributes), this
    reports the fact rather than synthesising a group — a hand-built group needs
    a GUID and Order_Ref wiring that only erwin can allocate safely.

    As with Definition, PD wins over whatever erwin currently holds.
    """
    if o.ext_comment_span is None:
        return "skipped: erwin object has no Extended Notes group to fill"
    return _replace_element(o.ext_comment_span, PROP_COMMENT, text, raw,
                            edits, "Note Annotation")


def _edit_note(o, text, args, raw, edits) -> str:
    """PD Description -> erwin Note_List_Array/Note_List (the Notes tab)."""
    if o.existing_notes and args.on_existing == "skip":
        return "skipped: erwin Note already present (--on-existing skip)"

    if o.existing_notes and args.on_existing == "append":
        start, end = o.note_array_span
        existing = raw[start:end].decode(ENC_UTF8)
        recs = list(re.findall(r"<Note_List\b[^>]*>(.*?)</Note_List>", existing, re.S))
        new = build_note_record(text, args.author, args.newline_mode, number=len(recs) + 1)
        payload = build_note_array([_unescape(r) for r in recs] + [new]).encode(ENC_UTF8)
        edits.append((start, end, payload))
        return "written: appended as note #%d" % (len(recs) + 1)

    rec = build_note_record(text, args.author, args.newline_mode)
    if o.note_array_span:
        start, end = o.note_array_span
        edits.append((start, end, build_note_array([rec]).encode(ENC_UTF8)))
        return ("written: replaced existing Note_List_Array" if o.existing_notes
                else "written: filled empty Note_List_Array")

    start = o.anchor_end if o.anchor_end is not None else o.props_close
    if start is None:
        return "skipped: no insertion anchor found in erwin object"
    edits.append((start, start, build_note_array([rec]).encode(ENC_UTF8)))
    return "written: created new Note_List_Array"

class MigrateResult:
    """Outcome of migrate_file(): counts per status and per object kind."""

    def __init__(self, rows, edits, out_path):
        self.rows = rows
        self.edits = len(edits)
        self.out_path = out_path
        self.matched = sum(1 for r in rows if r[STATUS_KEY] in (STATUS_PASS, STATUS_SKIPPED))
        self.written = sum(1 for r in rows if r[STATUS_KEY] == STATUS_PASS)
        self.skipped = sum(1 for r in rows if r[STATUS_KEY] == STATUS_SKIPPED)
        self.unmatched = sum(1 for r in rows if r[STATUS_KEY] == STATUS_UNMATCHED)
        self.written_by_kind = Counter(r[KEY_KIND] for r in rows if r[STATUS_KEY] == STATUS_PASS)

    def summary(self) -> str:
        kinds = ", ".join(f"{k} {v}" for k, v in sorted(self.written_by_kind.items()))
        return (f"{self.written} note(s) written ({kinds or 'none'}); "
                f"{self.skipped} skipped, {self.unmatched} unmatched")


def migrate_file(pd_path: str, erwin_in: str, erwin_out: str, author: str = "Migration_Bot",
                 only=None, on_existing: str = "skip", newline_mode: str = "escaped-lf",
                 csv_path: str = None, targets=None,
                 keep_existing_definition: bool = False) -> MigrateResult:
    """
    Library entry point used by the pipeline (the PDM flow calls it in-process;
    the CDM/LDM orchestrator still shells out to `migrate`). Writes `erwin_out`
    (may equal `erwin_in`) and returns a MigrateResult; never prints.
    """
    pd = PDModel.load(pd_path)
    with open(erwin_in, "rb") as handle:
        raw = handle.read()
    objects = scan_erwin(raw)
    matches, _unmatched = match_objects(pd, objects)

    class _Args:
        pass
    args = _Args()
    args.author, args.on_existing, args.newline_mode = author, on_existing, newline_mode
    args.targets = set(targets) if targets else set(ALL_TARGETS)
    args.keep_existing_definition = keep_existing_definition
    kinds = set(only) if only else set(ALL_KINDS)

    edits, rows, stats = [], [], Counter()
    for o in objects:
        _process_migrate_object(o, matches, kinds, args, raw, edits, rows, stats)

    edits.sort(key=lambda x: x[0], reverse=True)
    out = bytearray(raw)
    for start, end, payload in edits:
        out[start:end] = payload
    os.makedirs(os.path.dirname(os.path.abspath(erwin_out)) or ".", exist_ok=True)
    with open(erwin_out, "wb") as handle:
        handle.write(out)
    if csv_path:
        args.csv = csv_path
        _write_migrate_csv(args, rows)
    return MigrateResult(rows, edits, erwin_out)


def _write_migrate_output(args, raw, edits):
    edits.sort(key=lambda x: x[0], reverse=True)
    out = bytearray(raw)
    for start, end, payload in edits:
        out[start:end] = payload

    outpath = resolve_output(args.out, "migrated_" + os.path.basename(args.erwin))
    with open(outpath, "wb") as f:
        f.write(out)
    print("  edits applied           : %d" % len(edits))
    print("  output written to       : %s" % outpath)

def _write_migrate_csv(args, rows):
    if getattr(args, "csv", None):
        with open(args.csv, "w", newline="", encoding=ENC_UTF8) as f:
            writer = csv.DictWriter(f, fieldnames=[
                KEY_KIND, KEY_ENTITY, "name", KEY_PNAME, STATUS_KEY,
                "match_tier", REASON_KEY, "comment_chars",
                TARGET_DEFINITION + "_status",
                TARGET_NOTE + "_status",
                TARGET_ANNOTATION + "_status",
            ], extrasaction="ignore")
            writer.writeheader()
            writer.writerows(rows)
        print("  report written to       : %s" % args.csv)

def _unescape(s: str) -> str:
    return (s.replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&"))
# --------------------------------------------------------------------------
# command: verify
# --------------------------------------------------------------------------

NOTE_ARRAY_RE = re.compile(
    rb"<Note_List_Array\b[^>]*/>|<Note_List_Array\b[^>]*>.*?</Note_List_Array>",
    re.S)


def cmd_verify(args):
    a = open(args.erwin, "rb").read()
    b = open(args.out, "rb").read()

    print("=" * 74)
    print("VERIFICATION")
    print("=" * 74)
    ok = True

    ok &= _verify_byte_level(a, b)

    try:
        from lxml import etree
    except ImportError:
        print("  [SKIP] structural check needs lxml (pip install lxml)")
        return 0 if ok else 1

    p = etree.XMLParser(huge_tree=True, resolve_entities=False, no_network=True)
    dict_a = _collect_properties(args.erwin, p, etree)
    dict_b = _collect_properties(args.out, p, etree)

    ok &= _verify_same_keys(dict_a, dict_b)
    ok &= _verify_properties(dict_a, dict_b)
    ok &= _verify_protected_fields(dict_a, dict_b)
    ok &= _verify_payload_sanity(args.out, p, etree)

    print()
    print("  RESULT: %s" % ("PASS - only Notes were changed" if ok else STATUS_FAIL))
    return 0 if ok else 1

def _verify_byte_level(a, b):
    a_stripped = NOTE_ARRAY_RE.sub(b"", a)
    b_stripped = NOTE_ARRAY_RE.sub(b"", b)
    same = a_stripped == b_stripped
    print("  [%s] byte-level: everything outside Note_List_Array is identical" % (STATUS_PASS if same else STATUS_FAIL))
    print("        input  %d bytes -> %d with notes removed" % (len(a), len(a_stripped)))
    print("        output %d bytes -> %d with notes removed" % (len(b), len(b_stripped)))
    if not same:
        n = min(len(a_stripped), len(b_stripped))
        for i in range(n):
            if a_stripped[i] != b_stripped[i]:
                print("        first difference at byte %d" % i)
                print("        IN : %r" % a_stripped[max(0, i - 90):i + 90])
                print("        OUT: %r" % b_stripped[max(0, i - 90):i + 90])
                break
    return same

def _collect_properties(path, p, etree):
    tree = etree.parse(path, p)
    out = {}
    for el in tree.getroot().iter():
        if localname(el.tag) not in (KIND_ENTITY, KIND_ATTRIBUTE):
            continue
        props = None
        for ch in el:
            if localname(ch.tag) in PROPS_TAGS:
                props = ch
                break
        if props is None:
            continue
        d = {}
        for pr in props:
            d.setdefault(localname(pr.tag), []).append(etree.tostring(pr, encoding="unicode"))
        out[(localname(el.tag), el.get("id"))] = d
    return out

def _verify_same_keys(dict_a, dict_b):
    same_keys = set(dict_a) == set(dict_b)
    print("  [%s] same object set: %d objects in / %d out" % (STATUS_PASS if same_keys else STATUS_FAIL, len(dict_a), len(dict_b)))
    return same_keys

def _verify_properties(dict_a, dict_b):
    added, removed, changed = _compute_property_diffs(dict_a, dict_b)
    illegal_add = {k: v for k, v in added.items() if k != NOTE_ARRAY_TAG}
    illegal_chg = {k: v for k, v in changed.items() if k != NOTE_ARRAY_TAG}

    _print_diff_status("properties added", illegal_add, added)
    _print_diff_status("properties removed", removed, removed)
    _print_diff_status("properties changed", illegal_chg, changed)

    return not illegal_add and not removed and not illegal_chg

def _print_diff_status(label, check_dict, full_dict):
    status = STATUS_FAIL if check_dict else STATUS_PASS
    data_str = dict(full_dict) if full_dict else "{}"
    print("  [%s] %s : %s" % (status, label.ljust(18), data_str))

def _compute_property_diffs(dict_a, dict_b):
    added, removed, changed = Counter(), Counter(), Counter()
    for k in set(dict_a) & set(dict_b):
        da, db = dict_a[k], dict_b[k]
        for prop in set(db) - set(da):
            added[prop] += 1
        for prop in set(da) - set(db):
            removed[prop] += 1
        for prop in set(da) & set(db):
            if da[prop] != db[prop]:
                changed[prop] += 1
    return added, removed, changed

def _verify_protected_fields(dict_a, dict_b):
    # NOTE: "Definition" is deliberately NOT protected any more — it is one of
    # the three fields this script now writes (PD Comment -> erwin Definition).
    # PROP_COMMENT stays protected: that is erwin's OWN Comment inside the props
    # block, which this script never touches. The Comment it does write lives in
    # Extended_NotesProps, which is not a props block and never enters this diff.
    protected = (PROP_COMMENT, PROP_NAME, "Physical_Name", "Type",
                 "Long_Id", "Owner_Path", "Logical_Data_Type",
                 "Physical_Data_Type", "Null_Option_Type", "Parent_Domain_Ref")
    bad = []
    for k in set(dict_a) & set(dict_b):
        for prop in protected:
            if dict_a[k].get(prop) != dict_b[k].get(prop):
                bad.append((k, prop))
    print("  [%s] protected fields unchanged (%s)" % (STATUS_PASS if not bad else STATUS_FAIL, ", ".join(protected[:5]) + ", ..."))
    for k, prop in bad[:10]:
        print("        CHANGED %s %s -> %s" % (k, prop, prop))
    return not bad

def _verify_payload_sanity(out_path, p, etree):
    notes = 0
    badrec = 0
    tree = etree.parse(out_path, p)
    for el in tree.getroot().iter():
        if localname(el.tag) != "Note_List":
            continue
        notes += 1
        d = decode_note_record(el.text or "")
        if d["field_count"] != NOTE_FIELD_COUNT:
            badrec += 1
    print("  [%s] note records well-formed: %d notes, %d malformed" % (STATUS_PASS if badrec == 0 else STATUS_FAIL, notes, badrec))
    return badrec == 0

def main(argv=None):
    ap = argparse.ArgumentParser(
        description="Migrate SAP PowerDesigner documentation into erwin: "
                    "Comment -> Definition, Description -> Note, "
                    "Annotation -> Note Annotation (Extended Notes).",
        formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("inspect", help="report the real structures; writes nothing")
    s.add_argument("--ldm", help="PD .ldm (default: the one in MODEL_INPUT_DIR)")
    s.add_argument("--erwin", help="erwin XML (default: the one in ERWIN_INPUT_DIR)")
    s.add_argument("--reference", help="erwin XML that already contains verified Notes")
    s.set_defaults(func=cmd_inspect)

    s = sub.add_parser(KEY_MIGRATE, help="write PD Comment/Description/Annotation "
                                         "into erwin Definition/Note/Note Annotation")
    s.add_argument("--ldm", help="PD .ldm (default: the one in MODEL_INPUT_DIR)")
    s.add_argument("--erwin", help="erwin XML (default: the one in ERWIN_INPUT_DIR)")
    s.add_argument("--out", help="output XML (default: <erwin name>%s.xml in OUTPUT_DIR)"
                                 % DEFAULT_OUTPUT_SUFFIX)
    s.add_argument("--author", default="PD_MIGRATION",
                   help="creator/modifier recorded on each note")
    s.add_argument("--newline-mode", default="escaped-lf",
                   choices=["escaped-lf", "escaped-crlf", "raw"])
    s.add_argument("--on-existing", default="skip",
                   choices=["skip", "replace", "append"],
                   help="what to do when the object already has an erwin Note")
    s.add_argument("--only", help="restrict to a comma-separated subset of: " + ",".join(ALL_KINDS))
    s.add_argument("--keep-existing-definition", action="store_true",
                   dest="keep_existing_definition",
                   help="leave an erwin Definition that already has text alone "
                        "(default: SAP PD wins and overwrites it)")
    s.add_argument("--only-target", nargs="+", dest="targets", choices=ALL_TARGETS,
                   help="restrict to a subset of the three mappings (default: all three)")
    s.add_argument("--report", nargs="?", const=DEFAULT_REPORT_NAME,
                   help="per-object CSV report (written to OUTPUT_DIR)")
    s.set_defaults(func=cmd_migrate)

    s = sub.add_parser("verify", help="prove only Notes differ between two files")
    s.add_argument("--erwin", help="original erwin XML (default: from ERWIN_INPUT_DIR)")
    s.add_argument("--out", help="migrated erwin XML (default: from OUTPUT_DIR)")
    s.set_defaults(func=cmd_verify)

    args = ap.parse_args(argv)

    # ---- resolve paths against the configured directories -----------------
    if args.cmd in ("inspect", KEY_MIGRATE):
        args.ldm = resolve_input(args.ldm, MODEL_INPUT_DIR,
                                 (".ldm",), "LDM model", "ldm")
        args.erwin = resolve_input(args.erwin, ERWIN_INPUT_DIR,
                                   (EXT_XML,), ERWIN_XML, KEY_ERWIN)
        if args.cmd == "inspect" and args.reference:
            args.reference = resolve_input(args.reference, ERWIN_INPUT_DIR,
                                           (EXT_XML,), ERWIN_XML, "reference")
        if args.cmd == KEY_MIGRATE:
            args.out = resolve_output(args.out, default_output_name(args.erwin))
            if args.report:
                args.report = resolve_output(args.report, DEFAULT_REPORT_NAME)
    elif args.cmd == "verify":
        args.erwin = resolve_input(args.erwin, ERWIN_INPUT_DIR,(EXT_XML,), ERWIN_XML, KEY_ERWIN)
        args.out = resolve_input(args.out, OUTPUT_DIR,(EXT_XML,), "migrated XML", "out")
    return args.func(args)

if __name__ == "__main__":
    sys.exit(main())
