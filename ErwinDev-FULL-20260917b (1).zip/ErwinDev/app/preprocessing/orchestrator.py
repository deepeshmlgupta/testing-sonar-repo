"""
Preprocessing orchestration for SAP PowerDesigner migration workflows.

This module coordinates preprocessing activities performed before model
reconciliation and validation. It executes external preprocessing scripts,
captures execution logs, manages intermediate artifacts, and prepares
erwin XML files for downstream validation processes.

The preprocessing stage primarily handles comment migration and XML
enrichment activities while providing fallback mechanisms to ensure
the validation pipeline can continue even if preprocessing fails.
"""
import logging
import os
import subprocess  # nosec B404
import sys
from pathlib import Path

# NOTE: ErwinSession / ErwinExporter were imported here but never used. They
# pull in pywin32, which made this module -- and therefore app/main.py --
# unimportable anywhere except Windows. Removed; no behaviour depended on them.

logger = logging.getLogger(__name__)


class PreprocessingFailed(RuntimeError):
    """
    Step 1 could not produce XML V2.

    A distinct type so the caller can record the stage FAILED rather than
    guessing from a generic exception — and so nothing is tempted to fall back
    to copying XML V1 over XML V2 again.
    """


def run_subprocess(cmd_list):
    """
    Execute a subprocess command and capture its output.

    The command is executed with output capture enabled to prevent
    excessive console logging. Standard output and standard error are
    appended to the preprocessing log file for troubleshooting and
    audit purposes.

    Args:
        cmd_list: List of command-line arguments to execute.

    Raises:
        subprocess.CalledProcessError: Raised when the subprocess
            exits with a non-zero return code.
    """
    log_file = Path(__file__).resolve().parent / "preprocessing.log"
    try:
        # Capture output so it doesn't flood the terminal
        result = subprocess.run(cmd_list, check=True, capture_output=True, text=True)  # nosec B603
        with log_file.open("a", encoding="utf-8") as f:
            f.write(f"\n--- Output of {' '.join(cmd_list)} ---\n")
            f.write(result.stdout)
            if result.stderr:
                f.write(result.stderr)
    except subprocess.CalledProcessError as exc:
        with log_file.open("a", encoding="utf-8") as f:
            f.write(f"\n--- FAILED: {' '.join(cmd_list)} (exit code {exc.returncode}) ---\n")
            if exc.stdout:
                f.write(exc.stdout)
            if exc.stderr:
                f.write(exc.stderr)
        raise

def run_preprocessing(model_path: Path, initial_xml_file: Path, base_name: str, erwin_preprocessed_dir: Path, model_type: str = "LDM"):
    """
    Orchestrates the Comment injection without cluttering main.py.

    `model_type` is informational only -- it is printed so the operator can see
    which model type a given injection belongs to. The underlying script works
    on any SAP PD model that exposes Entity / EntityAttribute with a Comment,
    which covers both LDM and CDM, so no branching is required here.
    """
    print(f"\n--- Phase B: Preprocessing (Comments) for {base_name} [{model_type}] ---")

    file_path_str = str(model_path.resolve())
    scripts_dir = Path(__file__).parent / "scripts"

    # 1. Inject Comments into XML (Stage 1)
    print("  -> Phase B: Injecting Comments directly into XML...")
    # 2_preprocessed is a flat folder: <model>.xml sits directly in it.
    preprocessed_xml_file = Path(erwin_preprocessed_dir) / f"{base_name}.xml"
    os.makedirs(erwin_preprocessed_dir, exist_ok=True)
    try:
        run_subprocess([
            sys.executable, str(scripts_dir / "pd_comment_to_erwin_note.py"), "migrate",
            "--ldm", file_path_str,
            "--erwin", str(initial_xml_file.resolve()),
            "--out", str(preprocessed_xml_file.resolve()),
            "--author", "Migration_Bot"
        ])
    except Exception as e:
        # DO NOT fabricate XML V2. The old fallback copied XML V1 over it, and
        # the caller then recorded the stage as READY — so a byte-for-byte copy
        # of the uninjected export was scored as "comments migrated", producing
        # a real documentation-fidelity number from a file in which nothing had
        # been injected. Worse, shutil.copy2 preserves mtime, so the freshness
        # guard in conceptual_workflow.inject_comments kept the fabricated file
        # on every subsequent run: the defect became permanent and silent.
        #
        # Raising is the honest outcome. The caller records the stage FAILED
        # with this reason, and the model is not scored on an artefact that
        # does not exist.
        print(f"  -> ERROR: Comment injection FAILED for {base_name}: {e}")
        logger.error("Comment injection failed for %s: %s", base_name, e)
        try:
            if preprocessed_xml_file.exists():
                # A partial file from the failed run is worse than none: it
                # would be found by the next run's freshness guard.
                preprocessed_xml_file.unlink()
        except OSError as cleanup_error:                       # noqa: BLE001
            logger.warning("Could not remove the partial XML V2 for %s: %s",
                           base_name, cleanup_error)
        raise PreprocessingFailed(
            f"comment injection failed for {base_name}: {e}") from e
    print(f"  -> Preprocessing complete. Updated XML saved to: 2_preprocessed/{base_name}.xml")
    return preprocessed_xml_file
