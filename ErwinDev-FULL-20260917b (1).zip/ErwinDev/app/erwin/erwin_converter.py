"""
erwin Converter (pipeline side)
================================
Produces the two erwin-made artefacts of the migration flow without a person
having to open erwin between pipeline steps:

    XML V2    -> .ERWIN V1   (Step 1 output -> Step 2 input)
    .ERWIN V2 -> XML V3      (Step 2 output -> Step 3 input)

``ensure_artifact`` is the only entry point the workflows use. Given the
artefact's expected path and its source, it:

  1. returns immediately if the artefact already exists (e.g. a person made
     it, or a previous run did);
  2. otherwise, when erwin COM automation is available on this host
     (Windows + pywin32 + erwin Data Modeler) and ERWIN_CONVERT_ENABLED,
     runs app/udp_tool/erwin_convert.py as a subprocess;
  3. otherwise — or when the converter says the erwin UI must be visible —
     waits for a manual conversion for MANUAL_EXPORT_WAIT_SECONDS.

Never raises. Every outcome is described on the returned ConversionOutcome so
the workflow can record it as a stage note or a skip reason.
"""

from __future__ import annotations

import logging
import subprocess  # nosec B404
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, List, Optional

from app.common.config_helpers import get_setting
from app.erwin import windows_files
from app.utils.manual_export_wait import validate_erwin_xml, wait_for_manual_export

logger = logging.getLogger(__name__)

CONVERT_SCRIPT = Path(__file__).resolve().parent.parent / "udp_tool" / "erwin_convert.py"

HOW_EXISTING = "existing"
HOW_CONVERTED = "converted"      # produced by erwin through SCAPI in this run
HOW_MANUAL = "manual"            # appeared on disk while we waited
HOW_MISSING = "missing"

_EXIT_NEEDS_VISIBLE_UI = 2
#: erwin was never launched: a file or folder blocked the conversion up front.
_EXIT_BLOCKED = 4


@dataclass
class ConversionOutcome:
    path: Path
    ok: bool = False
    how: str = HOW_MISSING
    messages: List[str] = field(default_factory=list)

    def summary(self) -> str:
        return f"{self.path.name}: {self.how}" + (
            f" — {self.messages[-1]}" if self.messages and not self.ok else "")


def com_available() -> bool:
    """pywin32 importable on this interpreter (a proxy for 'erwin COM can be tried')."""
    try:
        import importlib
        importlib.import_module("win32com.client")
        return True
    except ImportError:
        return False


def run_convert(src: Path, dst: Path, timeout_seconds: int) -> int:
    """
    Run erwin_convert.py; returns its exit code (1 on launch failure / timeout).

    Both ends are prepared first (read-only attribute cleared, OneDrive
    placeholder downloaded, Mark-of-the-Web stripped, output folder proven
    writable). erwin reports a read-only file as "File exists and read only."
    and a read-only TARGET as a failure to delete, which the old code reported
    as a file lock — so the preparation happens here, where the real cause can
    still be named, rather than being guessed at from erwin's message.
    """
    states = windows_files.prepare_conversion(src, dst)
    for state in states:
        for line in state.messages:
            logger.info("erwin_convert: %s", line)
    blocked = windows_files.blocking_reason(states)
    if blocked:
        logger.warning("erwin conversion cannot start: %s", blocked)
        return _EXIT_BLOCKED

    try:
        proc = subprocess.run(                                 # nosec B603
            [sys.executable, str(CONVERT_SCRIPT), "--in", str(src), "--out", str(dst)],
            capture_output=True, text=True, timeout=max(30, int(timeout_seconds)))
    except subprocess.TimeoutExpired:
        logger.warning("erwin conversion of %s timed out after %ss", src.name, timeout_seconds)
        return 1
    except OSError as exc:
        logger.warning("Could not launch erwin_convert.py: %s", exc)
        return 1
    for stream in (proc.stdout, proc.stderr):
        for line in (stream or "").splitlines():
            if line.strip():
                logger.info("erwin_convert: %s", line.rstrip())
    return proc.returncode


def _valid(path: Path) -> bool:
    if not path.is_file() or path.stat().st_size == 0:
        return False
    if path.suffix.lower() == ".xml":
        ok, _ = validate_erwin_xml(path)
        return ok
    return True


def ensure_artifact(dst: Path, src: Optional[Path], label: str,
                    on_wait: Optional[Callable[[Path, float], None]] = None) -> ConversionOutcome:
    """
    Make sure ``dst`` exists, converting it from ``src`` through erwin when
    possible and otherwise waiting for a person to produce it.
    """
    outcome = ConversionOutcome(path=Path(dst))

    if _valid(outcome.path):
        outcome.ok, outcome.how = True, HOW_EXISTING
        outcome.messages.append(f"{label} already present at {dst}")
        return outcome

    wait_seconds = int(get_setting("MANUAL_EXPORT_WAIT_SECONDS", 0))
    poll = float(get_setting("MANUAL_EXPORT_POLL_INTERVAL_SECONDS", 5.0))

    if src is not None and Path(src).is_file() and bool(get_setting("ERWIN_CONVERT_ENABLED", True)):
        if com_available():
            code = run_convert(Path(src), outcome.path,
                               int(get_setting("ERWIN_CONVERT_TIMEOUT_SECONDS", 900)))
            if code == 0 and _valid(outcome.path):
                outcome.ok, outcome.how = True, HOW_CONVERTED
                outcome.messages.append(f"{label} produced by erwin (SCAPI) from {Path(src).name}")
                return outcome
            if code == _EXIT_BLOCKED:
                outcome.messages.append(
                    f"{label} blocked before erwin was launched — "
                    f"{windows_files.blocking_reason(windows_files.prepare_conversion(src, outcome.path)) or 'see log'}")
            elif code == _EXIT_NEEDS_VISIBLE_UI:
                outcome.messages.append(
                    f"erwin must be open on the desktop to convert {Path(src).name}; "
                    f"waiting for a manual conversion instead")
            else:
                outcome.messages.append(
                    f"erwin conversion of {Path(src).name} failed (exit {code}); "
                    f"waiting for a manual conversion instead")
        else:
            outcome.messages.append(
                "erwin COM automation unavailable on this host (pywin32 / erwin not installed); "
                f"{label} must be produced in erwin by hand")
    elif src is None or not Path(src).is_file():
        outcome.messages.append(f"no source available to convert into {label}")
    else:
        outcome.messages.append("ERWIN_CONVERT_ENABLED is off; manual conversion expected")

    if wait_for_manual_export(outcome.path, wait_seconds, poll, on_wait) and _valid(outcome.path):
        outcome.ok, outcome.how = True, HOW_MANUAL
        outcome.messages.append(f"{label} found at {dst}")
        return outcome

    outcome.messages.append(f"{label} not found at {dst}")
    return outcome


__all__ = ["ConversionOutcome", "ensure_artifact", "run_convert", "com_available",
           "HOW_EXISTING", "HOW_CONVERTED", "HOW_MANUAL", "HOW_MISSING"]
