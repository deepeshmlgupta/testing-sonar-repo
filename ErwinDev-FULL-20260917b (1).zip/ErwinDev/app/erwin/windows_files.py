"""
Windows file preparation for erwin
==================================
erwin Data Modeler refuses to open or overwrite a file whose Windows read-only
attribute is set — it reports "File exists and read only." rather than opening
it read/write — and a model delivered through a zip, a OneDrive sync or a
corporate file share arrives read-only more often than not.

The pipeline already tried to handle this, in two copies of a helper that was
wrong in four ways:

1. ``os.access(path, os.W_OK)`` was used to DECIDE whether to clear the
   attribute. On Windows that call does not consult NTFS ACLs at all, so a file
   the user cannot actually write reads as writable and the ``chmod`` never
   runs. The reliable test is the FILE_ATTRIBUTE_READONLY bit on
   ``os.stat().st_file_attributes``.
2. Only the SOURCE was cleared. The destination was not — so converting a
   second time, or writing over a ``.erwin`` restored from OneDrive, failed at
   ``os.remove()`` / ``Path.unlink()``.
3. The destination FOLDER was never checked, so a read-only output directory
   failed later and further away, inside erwin.
4. The resulting error said the file was "currently open or locked", which is
   usually untrue and sends the operator looking for a process to close when
   the real fix is one attribute bit.

On top of that, two Windows-specific conditions look like a permissions
problem but are not:

* **OneDrive Files On-Demand.** A cloud-only placeholder has
  FILE_ATTRIBUTE_OFFLINE / RECALL_ON_OPEN / RECALL_ON_DATA_ACCESS set. Opening
  it triggers a download, which erwin can time out on. Reading one byte forces
  the hydration up front, where it can be waited for and reported.
* **Mark of the Web.** A file extracted from a downloaded zip carries a
  ``Zone.Identifier`` alternate data stream that marks it as from the internet.

Everything here is a no-op on Linux and macOS, so the module imports and runs
on the build host; only the Windows attribute bits are Windows-specific.
Nothing raises — a file that cannot be prepared is reported and the caller
decides.
"""

from __future__ import annotations

import logging
import os
import stat
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

logger = logging.getLogger(__name__)

IS_WINDOWS = sys.platform.startswith("win")

# Windows file attributes. Defined here rather than taken from `stat` because
# the FILE_ATTRIBUTE_* names only exist on Windows builds of Python.
FILE_ATTRIBUTE_READONLY = 0x0001
FILE_ATTRIBUTE_HIDDEN = 0x0002
FILE_ATTRIBUTE_SYSTEM = 0x0004
FILE_ATTRIBUTE_OFFLINE = 0x1000
FILE_ATTRIBUTE_RECALL_ON_OPEN = 0x00040000
FILE_ATTRIBUTE_RECALL_ON_DATA_ACCESS = 0x00400000

_CLOUD_PLACEHOLDER = (FILE_ATTRIBUTE_OFFLINE
                      | FILE_ATTRIBUTE_RECALL_ON_OPEN
                      | FILE_ATTRIBUTE_RECALL_ON_DATA_ACCESS)

_ZONE_IDENTIFIER = ":Zone.Identifier"


@dataclass
class FileState:
    """What is actually wrong with one path, in terms the operator can act on."""

    path: Path
    exists: bool = False
    read_only: bool = False
    cloud_only: bool = False
    locked: bool = False
    marked_from_internet: bool = False
    cleared: bool = False
    hydrated: bool = False
    messages: List[str] = field(default_factory=list)

    @property
    def blocked(self) -> bool:
        """Still un-writable after everything this module can do."""
        return self.locked or (self.read_only and not self.cleared)

    def summary(self) -> str:
        if not self.exists:
            return f"{self.path} does not exist"
        if self.locked:
            return (f"{self.path} is locked by another process — it is open in erwin, "
                    f"Explorer's preview pane, or a sync client. Close it and retry.")
        if self.read_only and not self.cleared:
            return (f"{self.path} is read-only and the attribute could not be cleared "
                    f"(the file is probably not yours, or the share denies write).")
        bits = []
        if self.cleared:
            bits.append("read-only attribute cleared")
        if self.hydrated:
            bits.append("downloaded from OneDrive")
        if self.marked_from_internet:
            bits.append("Mark-of-the-Web removed")
        return f"{self.path}: " + (", ".join(bits) if bits else "ready")


def _attributes(path: Path) -> int:
    """Windows file attribute bits, or 0 where the platform has none."""
    try:
        return int(getattr(os.stat(path), "st_file_attributes", 0) or 0)
    except OSError:
        return 0


def is_read_only(path: Path) -> bool:
    """
    True when the file cannot be written.

    On Windows this is the FILE_ATTRIBUTE_READONLY bit, which is the thing
    erwin actually objects to. Elsewhere it falls back to the POSIX mode.
    """
    path = Path(path)
    if not path.exists():
        return False
    if IS_WINDOWS:
        return bool(_attributes(path) & FILE_ATTRIBUTE_READONLY)
    return not os.access(path, os.W_OK)


def is_cloud_only(path: Path) -> bool:
    """True for a OneDrive Files On-Demand placeholder that is not downloaded."""
    return IS_WINDOWS and bool(_attributes(Path(path)) & _CLOUD_PLACEHOLDER)


def clear_read_only(path: Path) -> bool:
    """
    Clear the read-only attribute. Returns True when the file is writable
    afterwards. Never raises.
    """
    path = Path(path)
    if not path.exists():
        return False
    if not is_read_only(path):
        return True
    try:
        # S_IWRITE alone is what clears FILE_ATTRIBUTE_READONLY on Windows;
        # the S_IREAD is kept so the mode stays sane on POSIX.
        os.chmod(path, stat.S_IWRITE | stat.S_IREAD)
    except OSError as exc:
        logger.warning("Could not clear the read-only attribute on %s: %s", path, exc)
        return False
    return not is_read_only(path)


def hydrate(path: Path) -> bool:
    """
    Force a OneDrive placeholder to download by reading one byte, so the
    download happens here — where it can be reported — rather than inside
    erwin, which times out without saying why. Returns True when the file is
    local afterwards.
    """
    path = Path(path)
    try:
        with open(path, "rb") as handle:
            handle.read(1)
    except OSError as exc:
        logger.warning("Could not download %s from OneDrive: %s", path, exc)
        return False
    return not is_cloud_only(path)


def strip_mark_of_the_web(path: Path) -> bool:
    """
    Remove the Zone.Identifier alternate data stream a file picks up when it
    comes out of a downloaded zip. Returns True when a mark was removed.
    """
    if not IS_WINDOWS:
        return False
    stream = f"{path}{_ZONE_IDENTIFIER}"
    if not os.path.exists(stream):
        return False
    try:
        os.remove(stream)
        return True
    except OSError as exc:
        logger.debug("Could not remove the Mark-of-the-Web on %s: %s", path, exc)
        return False


def is_locked(path: Path) -> bool:
    """
    True when something else holds the file open for writing.

    Checked by actually opening it read/write, because that is the only test
    that distinguishes "another process has it" from "the attribute is set" —
    and the two need completely different things done about them.
    """
    path = Path(path)
    if not path.exists():
        return False
    try:
        with open(path, "r+b"):
            return False
    except PermissionError:
        return True
    except OSError:
        return False


def prepare(path, *, must_exist: bool = True) -> FileState:
    """
    Make one file ready for erwin: downloaded, writable, unmarked.
    Never raises; the returned state says what is still wrong.
    """
    path = Path(path)
    state = FileState(path=path, exists=path.exists())
    if not state.exists:
        if must_exist:
            state.messages.append(f"{path} does not exist")
        return state

    if is_cloud_only(path):
        state.cloud_only = True
        state.hydrated = hydrate(path)
        state.messages.append(
            f"{path.name} was a OneDrive placeholder; "
            + ("downloaded" if state.hydrated else "the download did not complete"))

    if strip_mark_of_the_web(path):
        state.marked_from_internet = True
        state.messages.append(f"{path.name} was marked as coming from the internet; mark removed")

    if is_read_only(path):
        state.read_only = True
        state.cleared = clear_read_only(path)
        state.messages.append(
            f"{path.name} was read-only; "
            + ("cleared" if state.cleared else "the attribute could NOT be cleared"))

    if not state.blocked and is_locked(path):
        state.locked = True
        state.messages.append(f"{path.name} is open in another process")

    return state


def prepare_target(path) -> FileState:
    """
    Make a destination writable: clear the attribute on an existing file so it
    can be replaced, and make sure the folder itself accepts a new file.

    This is the case the old helper missed entirely — it only ever prepared the
    source, so a second conversion over an existing read-only .erwin failed at
    the delete with a message blaming a file lock.
    """
    path = Path(path)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        state = FileState(path=path)
        state.messages.append(f"cannot create the output folder {path.parent}: {exc}")
        return state

    state = prepare(path, must_exist=False) if path.exists() else FileState(path=path)

    probe = path.parent / f".erwin_write_test_{os.getpid()}"
    try:
        probe.write_bytes(b"")
        probe.unlink()
    except OSError as exc:
        state.messages.append(
            f"the output folder {path.parent} is not writable ({exc}). "
            f"Choose a folder outside the read-only share, or fix its permissions.")
        state.locked = True
    return state


def prepare_conversion(source, target) -> List[FileState]:
    """Prepare both ends of an erwin conversion. Returns [source state, target state]."""
    return [prepare(source), prepare_target(target)]


def blocking_reason(states) -> Optional[str]:
    """The first reason a conversion cannot proceed, or None."""
    for state in states or ():
        if state.blocked or (not state.exists and state.messages):
            return state.summary()
    return None


def make_editable(path) -> FileState:
    """
    Make an artefact the pipeline just produced OPENABLE AND EDITABLE by a
    person — clear the read-only attribute, strip Mark-of-the-Web, and pull a
    OneDrive placeholder down to local disk.

    ``prepare`` / ``prepare_target`` / ``prepare_conversion`` above cover the
    AUTOMATED erwin paths (erwin_converter, udp_bridge, erwin_load). They do
    nothing for the files a person opens BY HAND, which is every manual
    hand-off in the flow:

        2_preprocessed/<model>.xml     opened in erwin, saved as .erwin
        2_preprocessed/<model>.erwin   opened in erwin, saved as XML V3

    Those were written and left exactly as the filesystem made them. On a
    checkout that came out of a downloaded .zip every file carries
    Mark-of-the-Web, and inside OneDrive a synced file can be a cloud
    placeholder or still be held by the sync client — so erwin opened them
    read-only and manual corrections could not be saved back.

    Never raises and never blocks a run: this is a convenience applied to an
    artefact that has already been written successfully. Returns the FileState
    so a caller can log what was (or could not be) cleared. A no-op off Windows.
    """
    path = Path(path)
    state = FileState(path=path)
    if not IS_WINDOWS:
        return state
    try:
        if not path.is_file():
            return state
        state = prepare(path, must_exist=False)
    except OSError as exc:                                     # noqa: BLE001
        state.messages.append(f"could not prepare {path.name} for manual editing: {exc}")
    return state


__all__ = ["FileState", "IS_WINDOWS", "is_read_only", "is_cloud_only", "is_locked",
           "clear_read_only", "hydrate", "strip_mark_of_the_web",
           "prepare", "prepare_target", "prepare_conversion", "blocking_reason",
           "make_editable"]
