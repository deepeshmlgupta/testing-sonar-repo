"""
erwin Hand-off Gate
===================
The one place that answers "this erwin artefact does not exist yet — now what?"

Step 2 of the migration flow needs two things erwin itself must make:

    .ERWIN V1   app/udp_tool/input_erwin_models/<model>.erwin
                the binary the UDP tool injects into, saved from XML V2
    .ERWIN V2   erwinmodels/2_preprocessed/<model>.erwin
                the UDP-enriched binary Step 2 produces

Both are produced by erwin Data Modeler through COM, which exists only on a
Windows host with erwin installed. Before this module, a host without COM made
``run_udp.py`` stop at EXTRACTED with a one-line note and no output file, which
read as "the run worked" when nothing had been migrated.

The gate replaces that with an explicit three-way outcome, in order:

  1. AUTOMATIC   erwin COM is here and ERWIN_CONVERT_ENABLED is on: drive erwin
                 through SCAPI (app/erwin/erwin_converter.py) and carry on.
  2. INTERACTIVE erwin COM is NOT here and a person is at the terminal: print
                 exactly what to make and where, write the same instructions
                 next to the target as ``<model>.<artefact>.HOWTO.txt``, and
                 WAIT at a prompt until they say it is done (re-checking disk
                 each time, so the tier sub-folder and short-name spellings are
                 honoured too).
  3. UNATTENDED  erwin COM is NOT here and nobody is watching (a scheduled run,
                 a worker thread, a redirected stdin): poll for
                 MANUAL_EXPORT_WAIT_SECONDS, then record a WAITING stage with
                 the instructions in the message. Never blocks a batch.

Never raises, and never fabricates an artefact: the only way a file appears is
erwin making it or a person making it.
"""

from __future__ import annotations

import logging
import sys
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

from app.common.config_helpers import get_setting
from app.erwin import erwin_converter, windows_files

logger = logging.getLogger(__name__)

HOW_EXISTING = "existing"
HOW_CONVERTED = "converted"      # erwin made it through SCAPI in this run
HOW_MANUAL = "manual"            # a person made it while the gate waited
HOW_MISSING = "missing"

#: The two artefacts this gate produces. Named once so a caller cannot ask for
#: ".ERWIN V1 " or ".Erwin V1" and silently fall through to the generic
#: instructions with no steps in them.
LABEL_ERWIN_V1 = ".ERWIN V1"
LABEL_ERWIN_V2 = ".ERWIN V2"

#: Suffix of the per-model instruction file written beside a missing artefact.
HOWTO_SUFFIX = ".HOWTO.txt"

#: erwin_convert.py's "open erwin on the desktop and retry" exit code.
_EXIT_NEEDS_VISIBLE_UI = 2
#: a file or folder blocked the conversion before erwin was launched.
_EXIT_BLOCKED = 4

_PROMPT_SENTINELS = ("s", "skip", "n", "no")


@dataclass
class HandoffOutcome:
    """What happened to one requested artefact."""

    path: Path
    label: str
    ok: bool = False
    how: str = HOW_MISSING
    instructions: str = ""
    messages: List[str] = field(default_factory=list)

    @property
    def automated(self) -> bool:
        return self.how == HOW_CONVERTED

    def summary(self) -> str:
        if self.ok:
            return f"{self.label} {self.how} at {self.path}"
        return f"{self.label} not available at {self.path}"


# ═════════════════════════════════════════════════════════════════════════════
#  Is anyone actually there?
# ═════════════════════════════════════════════════════════════════════════════

def interactive_allowed() -> bool:
    """
    True when it is safe to stop and ask a person.

    Three conditions, all required. A prompt in a worker thread would interleave
    with three other prompts on one terminal; a prompt in a scheduled or piped
    run would hang forever holding the batch open.
    """
    if not bool(get_setting("ERWIN_MANUAL_PROMPT_ENABLED", True)):
        return False
    if threading.current_thread() is not threading.main_thread():
        return False
    try:
        return bool(sys.stdin) and sys.stdin.isatty() and sys.stdout.isatty()
    except (AttributeError, ValueError):            # closed / replaced stream
        return False


# ═════════════════════════════════════════════════════════════════════════════
#  What to tell the operator
# ═════════════════════════════════════════════════════════════════════════════

def _instructions_erwin_v1(source: Optional[Path], target: Path, model: str) -> str:
    src = str(source) if source else "erwinmodels/2_preprocessed/<model>.xml (run run_v1.py first)"
    return (
        f"MANUAL STEP — produce .ERWIN V1 for {model}\n"
        f"\n"
        f"  1. Open erwin Data Modeler.\n"
        f"  2. File > Open, and open this XML:\n"
        f"       {src}\n"
        f"     (It is the Step 1 output: your erwin export with the SAP PD\n"
        f"      comments already injected as erwin Notes.)\n"
        f"  3. File > Save As, type 'erwin file (*.erwin)', and save it as:\n"
        f"       {target}\n"
        f"  4. Come back here and confirm.\n"
        f"\n"
        f"Why by hand: erwin's COM automation (pywin32 + erwin Data Modeler) is\n"
        f"not available on this host, so the pipeline cannot open erwin itself.\n"
        f"Run run_udp.py on the Windows workstation that has erwin installed and\n"
        f"this step is done for you — no setting to change, it is on by default.\n"
    )


def _instructions_erwin_v2(source: Optional[Path], target: Path, model: str,
                           report: str = "") -> str:
    src = str(source) if source else "app/udp_tool/input_erwin_models/<model>.erwin"
    extra = (f"  * Every UDP to apply is listed in the migration workbook:\n"
             f"       {report}\n") if report else ""
    return (
        f"MANUAL STEP — produce .ERWIN V2 (UDP-enriched) for {model}\n"
        f"\n"
        f"  1. On a Windows host with erwin Data Modeler installed, run:\n"
        f"       python -m app.run_udp\n"
        f"     That injects the UDPs through erwin COM and writes the file for you.\n"
        f"\n"
        f"  OR, to do it in erwin by hand:\n"
        f"  1. Open {src} in erwin Data Modeler.\n"
        f"  2. Apply the SAP extended attributes as erwin UDPs.\n"
        f"{extra}"
        f"  3. File > Save As:\n"
        f"       {target}\n"
        f"  4. Come back here and confirm.\n"
        f"\n"
        f"Why by hand: erwin's COM automation is not available on this host, so\n"
        f"the UDP injector (app/udp_tool/erwin_load.py) cannot run.\n"
    )


_INSTRUCTIONS = {
    LABEL_ERWIN_V1: _instructions_erwin_v1,
    LABEL_ERWIN_V2: _instructions_erwin_v2,
}


def write_howto(target: Path, label: str, text: str) -> Optional[Path]:
    """
    Drop the instructions next to where the artefact belongs, so an operator
    who finds the folder before they find the console still knows what to do.
    Never raises: a read-only folder must not fail the run.
    """
    slug = label.strip().lstrip(".").replace(" ", "_").lower()
    path = Path(target).with_suffix(f".{slug}{HOWTO_SUFFIX}")
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
        return path
    except OSError as exc:
        logger.debug("Could not write %s: %s", path, exc)
        return None


# ═════════════════════════════════════════════════════════════════════════════
#  The gate
# ═════════════════════════════════════════════════════════════════════════════

def _resolve(target: Path, recheck) -> Optional[Path]:
    """Where the artefact actually is now — ``recheck`` first, then the exact path."""
    if recheck is not None:
        try:
            found = recheck()
        except Exception as exc:                               # noqa: BLE001
            logger.debug("Re-check for %s failed: %s", target, exc)
            found = None
        if found is not None and Path(found).is_file() and Path(found).stat().st_size:
            return Path(found)
    path = Path(target)
    return path if path.is_file() and path.stat().st_size else None


def _ask(outcome: HandoffOutcome, target: Path, recheck) -> bool:
    """
    Stop and ask. Returns True once the artefact exists.

    The operator may answer as many times as they like: each answer re-checks
    disk, so a typo'd filename or a save to the wrong folder is recoverable
    without losing the run. 's' skips this model and the batch continues.
    """
    attempts = max(1, int(get_setting("ERWIN_MANUAL_PROMPT_ATTEMPTS", 10)))
    question = (f"\n  Press ENTER when {outcome.label} for this model has been saved, "
                f"or type 's' to skip it: ")
    for attempt in range(attempts):
        try:
            answer = input(question).strip().lower()           # nosec B322
        except (EOFError, KeyboardInterrupt):
            print("\n  -> input closed; treating as skip.")
            outcome.messages.append("Operator input unavailable; manual hand-off skipped.")
            return False
        if answer in _PROMPT_SENTINELS:
            outcome.messages.append(f"Operator skipped the manual {outcome.label} hand-off.")
            print(f"  -> skipped: {outcome.label} was not produced.")
            return False
        found = _resolve(target, recheck)
        if found is not None:
            outcome.path = found
            return True
        remaining = attempts - attempt - 1
        print(f"  -> still not found at {target}"
              + (f" ({remaining} more attempt{'s' if remaining != 1 else ''})" if remaining else ""))
    outcome.messages.append(
        f"{outcome.label} was still missing after {attempts} prompts.")
    return False


def _try_automatic(outcome: HandoffOutcome, target: Path, source, recheck) -> bool:
    """
    Have erwin make the artefact through SCAPI. Returns True when it exists.

    ``erwin_converter.run_convert`` is called directly rather than
    ``ensure_artifact`` so that the manual fallback belongs to THIS module
    only: ensure_artifact runs its own MANUAL_EXPORT_WAIT_SECONDS poll, and
    going through it would make an operator wait out that timeout twice before
    being asked anything.
    """
    if source is None or not source.is_file():
        outcome.messages.append(
            f"no source available to convert into {outcome.label}"
            + ("; run run_v1.py first, or save the .erwin by hand"
               if outcome.label == LABEL_ERWIN_V1 else ""))
        return False
    if not bool(get_setting("ERWIN_CONVERT_ENABLED", True)):
        outcome.messages.append("ERWIN_CONVERT_ENABLED is off; manual conversion expected")
        return False
    if not erwin_converter.com_available():
        outcome.messages.append(
            "erwin COM automation unavailable on this host (pywin32 / erwin Data Modeler "
            f"not installed); {outcome.label} must be produced in erwin")
        return False

    code = erwin_converter.run_convert(
        source, target, int(get_setting("ERWIN_CONVERT_TIMEOUT_SECONDS", 900)))
    found = _resolve(target, recheck)
    if code == 0 and found is not None:
        outcome.path, outcome.ok, outcome.how = found, True, HOW_CONVERTED
        outcome.messages.append(f"{outcome.label} produced by erwin (SCAPI) from {source.name}")
        return True
    if code == _EXIT_BLOCKED:
        outcome.messages.append(
            f"conversion blocked before erwin started: "
            f"{windows_files.blocking_reason(windows_files.prepare_conversion(source, target)) or 'see log'}")
    elif code == _EXIT_NEEDS_VISIBLE_UI:
        outcome.messages.append(
            f"erwin must be open on the desktop to convert {source.name}")
    else:
        outcome.messages.append(
            f"erwin conversion of {source.name} failed (exit {code})")
    return False


def _instructions_for(label: str, source, target: Path, model_name: str,
                      report_path: str) -> str:
    builder = _INSTRUCTIONS.get(label)
    if builder is _instructions_erwin_v2:
        return builder(source, target, model_name, report_path)
    if builder is not None:
        return builder(source, target, model_name)
    return f"MANUAL STEP — produce {label} at {target}\n"


def _announce(outcome: HandoffOutcome, target: Path, text: str) -> None:
    """Print the instructions and leave a copy beside where the artefact belongs."""
    outcome.instructions = text
    howto = write_howto(target, outcome.label, text)
    if howto is not None:
        outcome.messages.append(f"Instructions written to {howto}")

    print("\n" + "=" * 72)
    print(text.rstrip())
    if howto is not None:
        print(f"\n  (These instructions are also saved at {howto})")
    print("=" * 72)


def _wait_unattended(outcome: HandoffOutcome, target: Path, recheck) -> bool:
    """Nobody to ask: poll for the bounded window, then give up cleanly."""
    wait_seconds = int(get_setting("MANUAL_EXPORT_WAIT_SECONDS", 0))
    if wait_seconds <= 0:
        outcome.messages.append(
            "Not an interactive session and MANUAL_EXPORT_WAIT_SECONDS is 0; "
            f"{outcome.label} must be produced before the next run.")
        return False

    print(f"  ... not interactive; polling for {outcome.label} for up to {wait_seconds}s")
    from app.utils.manual_export_wait import wait_for_manual_export
    poll = float(get_setting("MANUAL_EXPORT_POLL_INTERVAL_SECONDS", 5.0))
    wait_for_manual_export(target, wait_seconds, poll)
    found = _resolve(target, recheck)
    if found is None:
        return False
    outcome.path, outcome.ok, outcome.how = found, True, HOW_MANUAL
    outcome.messages.append(f"{outcome.label} appeared at {found} while waiting")
    return True


def ensure(target, source, label: str, model_name: str = "",
           recheck=None, report_path: str = "") -> HandoffOutcome:
    """
    Make sure ``target`` exists, by erwin automation or by asking a person.

    ``source``     what erwin would convert FROM (may be None / missing).
    ``label``      ".ERWIN V1" or ".ERWIN V2" — selects the instructions.
    ``recheck``    optional zero-argument callable returning the artefact's
                   real location, used instead of ``target`` on every re-check.
                   Step 2 passes ``stages.find_erwin_v1`` so a file saved into
                   the tier sub-folder or under the short model name is found.
    ``report_path`` the UDP migration workbook, quoted in the .ERWIN V2 text.
    """
    target = Path(target)
    outcome = HandoffOutcome(path=target, label=label)

    found = _resolve(target, recheck)
    if found is not None:
        outcome.path, outcome.ok, outcome.how = found, True, HOW_EXISTING
        outcome.messages.append(f"{label} already present at {found}")
        return outcome

    # ── 1. automatic, when erwin is on this host ──────────────────────────────
    source_path = Path(source) if source else None
    if _try_automatic(outcome, target, source_path, recheck):
        return outcome

    # The file may have landed meanwhile — possibly under one of the tolerated
    # spellings (tier sub-folder, short model name) the converter cannot see.
    found = _resolve(target, recheck)
    if found is not None:
        outcome.path, outcome.ok, outcome.how = found, True, HOW_MANUAL
        return outcome

    # ── 2. / 3. ask, or say clearly what is needed and carry on ───────────────
    _announce(outcome, target,
              _instructions_for(label, source_path, target,
                                model_name or target.stem, report_path))

    if interactive_allowed():
        if _ask(outcome, target, recheck):
            outcome.ok, outcome.how = True, HOW_MANUAL
            outcome.messages.append(f"{label} produced by the operator at {outcome.path}")
            print(f"  -> found {outcome.label}: {outcome.path}")
        return outcome

    if _wait_unattended(outcome, target, recheck):
        return outcome

    outcome.messages.append(f"{label} not available at {target}")
    return outcome


def com_available() -> bool:
    """erwin COM automation reachable from this interpreter."""
    return erwin_converter.com_available()


__all__ = ["HandoffOutcome", "ensure", "com_available", "interactive_allowed",
           "write_howto", "HOWTO_SUFFIX", "LABEL_ERWIN_V1", "LABEL_ERWIN_V2",
           "HOW_EXISTING", "HOW_CONVERTED", "HOW_MANUAL", "HOW_MISSING"]
