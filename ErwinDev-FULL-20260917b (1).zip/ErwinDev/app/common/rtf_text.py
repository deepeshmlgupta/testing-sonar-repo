"""
Shared PowerDesigner rich-text normalisation
============================================

ONE RTF-to-text implementation for the whole framework.

Why this module exists
----------------------
There used to be three independent RTF strippers — a proper tokenizer in the
LDM parser, a regex chain in the CDM parser, and a three-line regex in the PDM
documentation engine — and they produced DIFFERENT plain text for the same
bytes. That mattered because the two sides of a single comparison were
normalised by different code:

* The Phase-B injector writes the SAP PD Comment into erwin's Notes using the
  LDM tokenizer. The CDM comparator then stripped the SAP PD side with the
  regex chain and compared it against that erwin Note. For any comment holding
  a Word smart quote the SAP side produced ``\x93quoted\x94`` (the regex chain
  read ``\'93`` as a Unicode CODE POINT) while the erwin side produced
  ``“quoted”`` (the tokenizer decodes it as cp1252, which is what
  ``\ansicpg1252`` declares). Identical text, reported as a MISMATCH.
* The regex chain also DELETED content: ``\\`` was not recognised as an
  escaped backslash, so the next backslash started a control-word match that
  ate the following word — ``C:\\Users\\x`` lost both ``Users`` and ``x``.
* The PDM stripper left the font table and generator string in the compared
  text and replaced every ``\'xx`` with a space, so EVERY RTF-wrapped PDM
  comment reported MISMATCH however perfectly it had migrated.

None of those were migration defects. They were normalisation defects
manufacturing false positives, and they are exactly what "never treat
source-quality problems as migration failures" forbids.

The implementation below is the tokenizer that was already verified against
the real SAP PD models; CDM and PDM now delegate to it, so all three tiers
answer the same question the same way. It is deliberately conservative: on
malformed input it returns the RAW text rather than risk discarding a real
definition, and an empty result from a well-formed envelope is reported as
empty because that is what an untouched rich-text field genuinely contains.
"""

import logging
import re
from typing import Optional

logger = logging.getLogger(__name__)


# Destinations whose content is not visible body text and must be skipped
# entirely: font/color/style tables, document metadata, embedded binary
# objects (pictures), bookmarks, and field CODES (the URL/formula half of a
# hyperlink or cross-reference -- as opposed to \fldrslt, the field's
# visible RESULT text, which is deliberately NOT in this set and stays).
_RTF_SKIP_DESTINATIONS = {
    "fonttbl", "colortbl", "stylesheet", "info", "generator",
    "pict", "object", "objdata", "objclass", "result",
    "footnote", "header", "headerf", "headerl", "headerr",
    "footer", "footerf", "footerl", "footerr",
    "xe", "tc", "bkmkstart", "bkmkend",
    "listtable", "listoverridetable", "revtbl", "rsidtbl",
    "themedata", "colorschememapping", "datastore", "fldinst",
    "shp", "shpinst", "sp", "do", "dptxbxtext", "nonshppict",
}

# Longest first so no keyword shadows a longer one, then alphabetically.
# The second sort key is not cosmetic: the input is a SET, and sorting a set
# by length alone leaves equal-length keywords in hash-randomised order, so
# the compiled pattern differed between interpreter runs. The OUTPUT was
# stable (equal-length distinct literals are mutually exclusive at a fixed
# start position), but a pattern that is not reproducible build-to-build is
# not something an auditor can verify, so the order is pinned here.
_RTF_KNOWN_KEYWORDS = sorted(
    {"par", "line", "tab", "u"} | _RTF_SKIP_DESTINATIONS,
    key=lambda keyword: (-len(keyword), keyword),
)
# Recognised keyword, optionally followed by a signed numeric parameter and
# at most one delimiting space -- matched only when NOT immediately followed
# by another lowercase letter, so "\parSecond" (a missing delimiter some
# non-conformant generators produce) is never misread as the single unknown
# control word "parSecond", which would otherwise silently swallow "Second"
# along with it. Real conformant generators always delimit control words,
# but this guards the case where one doesn't.
_RTF_KNOWN_CONTROL_WORD = re.compile(
    r"\\(" + "|".join(_RTF_KNOWN_KEYWORDS) + r")(-?\d+)?( )?(?![a-z])"
)
_RTF_GENERIC_CONTROL_WORD = re.compile(r"\\([a-zA-Z]+)(-?\d+)?([ ])?")


class _RtfState:
    """Mutable cursor/output state for the RTF tokenizer walk."""
    __slots__ = ("text", "n", "i", "out", "skip_stack")

    def __init__(self, text: str):
        self.text = text
        self.n = len(text)
        self.i = 0
        self.out: list = []
        self.skip_stack: list = [False]   # top-level body is never skipped

    @property
    def skipping(self) -> bool:
        return any(self.skip_stack)

    def emit(self, value: str) -> None:
        if not self.skipping:
            self.out.append(value)


def _rtf_handle_escaped_literal(state: _RtfState, nxt: str) -> None:
    """\\{  \\}  \\\\  -> literal brace/backslash."""
    state.emit(nxt)
    state.i += 2


def _rtf_handle_hex_escape(state: _RtfState) -> None:
    """\\'e9 -> decode one byte via cp1252 (RTF's default ANSI code page)."""
    hex_pair = state.text[state.i + 2:state.i + 4]
    state.i += 4
    if state.skipping:
        return
    try:
        state.out.append(bytes([int(hex_pair, 16)]).decode("cp1252", "ignore"))
    except ValueError:
        pass


def _rtf_handle_unicode(state: _RtfState, param: Optional[str]) -> None:
    """\\uN<fallback>: emit code point N, discard the one ANSI fallback char."""
    try:
        codepoint = int(param)
        if codepoint < 0:
            codepoint += 65536
        state.emit(chr(codepoint))
    except (ValueError, OverflowError):
        pass
    if state.i < state.n and state.text[state.i] not in "\\{}":
        state.i += 1


def _rtf_handle_control_word(state: _RtfState) -> bool:
    """
    Consume a control word at the cursor. Returns True when one was handled.
    """
    match = (_RTF_KNOWN_CONTROL_WORD.match(state.text, state.i)
             or _RTF_GENERIC_CONTROL_WORD.match(state.text, state.i))
    if not match:
        return False

    keyword = match.group(1)
    param = match.group(2)
    state.i = match.end()

    if keyword == "u" and param is not None:
        _rtf_handle_unicode(state, param)
    elif keyword in ("par", "line"):
        state.emit("\n")
    elif keyword == "tab":
        state.emit("\t")
    elif keyword in _RTF_SKIP_DESTINATIONS:
        state.skip_stack[-1] = True
    # Every other control word (\rtf1, \ansi, \f0, \fs20, \pard, ...) is
    # formatting noise: consumed, nothing emitted, nothing skipped.
    return True


def _rtf_handle_backslash(state: _RtfState) -> None:
    """Dispatch the token following a backslash at the cursor."""
    nxt = state.text[state.i + 1] if state.i + 1 < state.n else ""

    if nxt in ("{", "}", "\\"):
        _rtf_handle_escaped_literal(state, nxt)
        return

    if nxt == "'" and state.i + 3 < state.n:
        _rtf_handle_hex_escape(state)
        return

    # Extended-destination marker: skip an unrecognised destination group,
    # the safe default per the RTF spec so unknown destinations fail closed.
    if nxt == "*":
        state.skip_stack[-1] = True
        state.i += 2
        return

    if _rtf_handle_control_word(state):
        return

    # Lone backslash that matched no known pattern -- drop it.
    state.i += 1


def _rtf_tokenize(state: _RtfState) -> None:
    """Walk the RTF string once, filling state.out with visible text."""
    while state.i < state.n:
        ch = state.text[state.i]

        if ch == "{":
            state.skip_stack.append(False)
            state.i += 1
        elif ch == "}":
            if len(state.skip_stack) > 1:
                state.skip_stack.pop()
            state.i += 1
        elif ch == "\\":
            _rtf_handle_backslash(state)
        else:
            state.emit(ch)
            state.i += 1


def strip_rtf(text: str) -> str:
    """
    PowerDesigner's Comment/Description/Definition field is a rich-text
    editor internally -- even a one-line definition is stored wrapped in a
    full RTF envelope: '{\\rtf1\\ansi\\ansicpg1252\\deflang1033{\\fonttbl...}
    {\\colortbl...} ... actual text ... }'. Confirmed by inspecting
    BLM_Real_Estate_Lease_Administration.ldm directly.

    Left unstripped, this markup (a) makes the report's SAP PD Value column
    unreadable, and (b) artificially deflates DEFINITION similarity scores.

    This is a proper minimal RTF-to-text tokenizer, not a regex chain: it
    walks the string once, tracking group ("{"/"}") nesting on an explicit
    stack, and marks a group as "skip" (its text is not emitted) only when
    its own control word names a non-visible destination (font table, color
    table, embedded picture, bookmark, field CODE, ...) or is introduced by
    the RTF "\\*" extended-destination marker.  Tracking the stack directly
    -- rather than a one-level-deep regex, as an earlier version of this
    function did -- means a destination group nested two or more levels deep
    (list formatting, embedded objects, and field codes routinely nest this
    deep in real Word/PowerDesigner-authored RTF) can no longer cause the
    visible sentence sitting next to it to be swallowed along with it. That
    exact failure mode was found in production: a real definition collapsed
    to an empty string, which silently suppressed a DEFINITION_LOSS finding
    instead of surfacing the definition text. See FINDINGS.md for the case
    that exposed it and the mutation-style regression test that now guards
    against it recurring silently.
    """
    if not text or "{\\rtf" not in text[:12]:
        return text.strip() if text else ""

    original_len = len(text)
    state = _RtfState(text)
    _rtf_tokenize(state)

    result = "".join(state.out)
    result = re.sub(r"[ \t]+", " ", result)
    result = re.sub(r"\n\s*\n+", "\n", result)
    result = result.strip()

    # Safety net -- but note WHICH signal it keys on, because the obvious
    # choice is wrong. An empty result is NOT by itself evidence of failure:
    # a PowerDesigner description field that was opened and saved without
    # any text typed into it still stores a complete ~230-character RTF
    # envelope with no body text, and reducing that to "" is exactly right.
    # Confirmed in production on BLM_Real_Estate_Lease_Administration's
    # PYMNT_TYP attribute, whose empty-but-wrapped comment produced a false
    # DEFINITION_LOSS finding before this stripping existed. An earlier
    # version of this guard keyed on input LENGTH (">40 chars and empty ->
    # assume failure"), which mistook that legitimate case for a failure and
    # would have re-emitted the raw RTF and the false finding along with it.
    #
    # The signal that actually separates the two is brace balance: every
    # group the tokenizer opened should have been closed by the end of a
    # well-formed document. Unclosed groups mean the input was truncated or
    # malformed, so text may have been trapped inside a never-closed skip
    # destination -- that is the case worth warning about and falling back
    # for. Balanced braces with an empty result means the document genuinely
    # had no body text, and "" is the correct answer.
    unbalanced = len(state.skip_stack) > 1

    if unbalanced:
        logger.warning(
            "strip_rtf() found %d unclosed RTF group(s) in a %d-character "
            "comment (malformed or truncated RTF). Falling back to the raw "
            "value so a real definition cannot be silently discarded; the "
            "report will show raw RTF for this object. Please report the "
            "source text so the tokenizer can be extended to cover it.",
            len(state.skip_stack) - 1, original_len,
        )
        return text.strip()

    if not result:
        # Legitimately empty rich-text field: log at DEBUG only, since this
        # is normal and expected, not a defect.
        logger.debug(
            "strip_rtf(): %d-character RTF envelope contained no body text "
            "(empty description field) -- returning empty string.",
            original_len,
        )

    return result
