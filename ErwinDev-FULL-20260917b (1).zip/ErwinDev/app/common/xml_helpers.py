"""
XML Helpers
===========
The namespace-stripping and child/descendant lookups every erwin / SAP PD
parser needs. Five modules used to carry their own copies; this is the one
implementation, and ``local_name`` is memoised because a 3 MB erwin export
calls it a few million times (it was the single hottest Python function in a
profiled run — ~12 % of a model's reconciliation time).
"""

from __future__ import annotations

import functools
from typing import Any, List, Optional


@functools.lru_cache(maxsize=4096)
def _strip_namespace(tag: str) -> str:
    return tag.rsplit("}", 1)[-1] if "}" in tag else tag


def local_name(tag: Any) -> str:
    """'{uri}Entity' -> 'Entity'; non-string tags (comments, PIs) -> ''."""
    return _strip_namespace(tag) if isinstance(tag, str) else ""


def namespace(tag: Any) -> str:
    """'{uri}Entity' -> 'uri'; '' when the tag carries no namespace."""
    return tag[1:].split("}", 1)[0] if isinstance(tag, str) and tag.startswith("{") else ""


def children(elem, name: str) -> List[Any]:
    """Direct children whose local name is ``name``."""
    return [child for child in elem if local_name(child.tag) == name]


def first_child(elem, *names: str) -> Optional[Any]:
    """The first direct child matching any of ``names``, tried in order."""
    if elem is None:
        return None
    for name in names:
        for child in elem:
            if local_name(child.tag) == name:
                return child
    return None


def descendants(elem, name: str) -> List[Any]:
    """Every element at any depth (including ``elem``) whose local name is ``name``."""
    return [node for node in elem.iter() if local_name(node.tag) == name]


__all__ = ["local_name", "namespace", "children", "first_child", "descendants"]
