"""
Configuration Helpers
======================
Tier-config resolution shared by the orchestration, validation, workflow and
reporting layers. No business logic here, only lookups.

Import-light on purpose: this module depends only on ``app.config`` so any
module in the tree (including ``validation/fidelity_stages`` and the
reporting layer) can use it without an import cycle.
"""

import logging
import os
from pathlib import Path

from app.config import settings

logger = logging.getLogger(__name__)


def get_setting(name: str, default):
    """A ``settings`` value, or ``default`` when unset."""
    return getattr(settings, name, default)


def cfg(config, name: str, default=None):
    """A tier-config value, or ``default`` when the config is None or lacks it."""
    return getattr(config, name, default) if config is not None else default


def tier_config(model_type: str, supplied=None):
    """
    The tier config object for CDM / LDM / PDM, or None when there is none.
    ``supplied`` (an explicit config) is returned as is, so callers can write
    ``tier_config(model_type, request.config)`` without a branch.
    """
    if supplied is not None:
        return supplied
    try:
        from app.config.validation_config import tier
        return tier(model_type)
    except (ImportError, ValueError) as exc:                   # noqa: BLE001
        logger.debug("No tier config for %s: %s", model_type, exc)
        return None


def excluded_sheets(model_type):
    """Sheets the consolidated V3 report must not carry."""
    from app.reporting import v3_report  # local: avoids a reporting<->common cycle
    return tuple(cfg(tier_config(model_type), "V3_REPORT_EXCLUDE_SHEETS", v3_report.DEFAULT_EXCLUDE_SHEETS))


def udp_reports_dir(model_type: str) -> Path:
    """The udp_tool's own report folder for one tier."""
    raw = cfg(tier_config(model_type), "UDP_TOOL_REPORT_DIR", "")
    if not raw:
        base = os.path.join(settings.BASE_DIR, "app", "udp_tool", "output_excel_reports")
    elif not os.path.isabs(str(raw)):
        base = os.path.join(settings.BASE_DIR, str(raw))
    else:
        base = str(raw)
    return Path(base) / str(model_type).lower()


__all__ = ["get_setting", "cfg", "tier_config", "excluded_sheets", "udp_reports_dir"]
