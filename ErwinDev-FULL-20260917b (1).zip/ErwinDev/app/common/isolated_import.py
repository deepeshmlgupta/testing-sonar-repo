"""
Isolated Import
===============
Load a self-contained tool folder (one whose modules import each other by bare
top-level name — ``import comparator``, ``from pd_parser import ...``) without
letting those names collide with anything the pipeline has already imported.

Two such tools live in this repository: the UDP tool (``app/udp_tool``) and the
PDM validator (``app/validation/pdm_reconcile/pdm_erwin_validator``). Each used
to carry its own copy of this logic with its own lock. That was a race: both
copies rewrite ``sys.path`` and ``sys.modules`` for the duration of the import
window, and with ``MAX_WORKERS > 1`` an LDM worker loading the UDP tool could
run at the same moment as a PDM worker loading the validator. Whichever
finished first restored ``sys.path`` to *its* saved copy, erasing the other's
insertion mid-import — an ``ImportError`` that appeared only under load.

There is now ONE process-wide re-entrant lock for every isolated import window.
It is never held while calling back into pipeline code (only the tool's own
modules are imported under it), so it cannot participate in a lock cycle.
"""

from __future__ import annotations

import importlib
import logging
import os
import sys
import threading
from typing import Any, Dict, Iterable, Optional

logger = logging.getLogger(__name__)

# One lock for every isolated import in the process. RLock so a tool module
# that (indirectly) triggers another isolated load on the same thread cannot
# deadlock against itself.
IMPORT_LOCK = threading.RLock()


def module_belongs_to(module: Any, folder: str) -> bool:
    """True when ``module`` was imported from ``folder`` (or below it)."""
    path = getattr(module, "__file__", None) or ""
    try:
        return os.path.commonpath([os.path.abspath(path), folder]) == folder
    except (ValueError, TypeError):
        return False


def _import_owned(owned_names: Iterable[str], before: set, folder: str) -> Dict[str, Any]:
    """Import each owned module plus any folder-local submodule it dragged in."""
    modules = {name: importlib.import_module(name) for name in owned_names}
    for name in set(sys.modules) - before:
        module = sys.modules.get(name)
        if module is not None and module_belongs_to(module, folder):
            modules.setdefault(name, module)
    return modules


def _publish_aliases(owned_names: Iterable[str], alias_prefix: str, folder: str) -> set:
    """
    Re-register the loaded modules under ``<alias_prefix>.<name>`` so the
    bridge keeps a live, non-colliding reference, and return the alias names.
    Collected first, registered afterwards: writing into ``sys.modules`` while
    iterating it raises "dictionary changed size during iteration".
    """
    owned = set(owned_names)
    aliases = {
        f"{alias_prefix}.{name}": module
        for name, module in sys.modules.items()
        if name in owned and module is not None and module_belongs_to(module, folder)
    }
    sys.modules.update(aliases)
    return set(aliases)


def _restore(shadowed: Dict[str, Any], before: set, aliases: set, folder: str) -> None:
    """Undo every change to ``sys.modules`` except the aliases deliberately kept."""
    for name, previous in shadowed.items():
        if previous is not None:
            sys.modules[name] = previous
        else:
            sys.modules.pop(name, None)
    for name in set(sys.modules) - before - aliases:
        module = sys.modules.get(name)
        if module is not None and module_belongs_to(module, folder):
            sys.modules.pop(name, None)


def load_isolated(folder: str, owned_names: Iterable[str], alias_prefix: str,
                  label: str = "tool") -> Dict[str, Any]:
    """
    Import ``owned_names`` from ``folder`` inside an isolated window and return
    them as ``{name: module}``. ``sys.path`` and the non-alias part of
    ``sys.modules`` are exactly as before on return, success or failure.
    """
    folder = os.path.abspath(folder)
    owned = tuple(owned_names)
    if not os.path.isdir(folder):
        raise ImportError(f"{label} folder not found: {folder}")

    with IMPORT_LOCK:
        saved_path = list(sys.path)
        shadowed = {name: sys.modules.pop(name, None) for name in owned}
        before = set(sys.modules)
        sys.path.insert(0, folder)
        try:
            modules = _import_owned(owned, before, folder)
        finally:
            aliases = _publish_aliases(owned, alias_prefix, folder)
            _restore(shadowed, before, aliases, folder)
            sys.path[:] = saved_path

    logger.info("Loaded %s from %s", label, folder)
    return modules


class IsolatedLoader:
    """
    Load-once holder for one tool folder.

        _loader = IsolatedLoader(TOOL_DIR, OWNED, "udp_tool", label="UDP tool")
        modules = _loader.load()

    Thread-safe: the first caller performs the import under IMPORT_LOCK, later
    callers get the cached dict. ``reset()`` exists for tests.
    """

    def __init__(self, folder: str, owned_names: Iterable[str], alias_prefix: str,
                 label: str = "tool"):
        self.folder = folder
        self.owned_names = tuple(owned_names)
        self.alias_prefix = alias_prefix
        self.label = label
        self._modules: Optional[Dict[str, Any]] = None

    def load(self) -> Dict[str, Any]:
        with IMPORT_LOCK:
            if self._modules is None:
                self._modules = load_isolated(self.folder, self.owned_names,
                                              self.alias_prefix, self.label)
            return self._modules

    def loaded(self) -> bool:
        return self._modules is not None

    def reset(self) -> None:
        with IMPORT_LOCK:
            self._modules = None


__all__ = ["IMPORT_LOCK", "IsolatedLoader", "load_isolated", "module_belongs_to"]
