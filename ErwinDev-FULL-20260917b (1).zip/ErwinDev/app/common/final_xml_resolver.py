"""
Final Validated XML Resolver
=============================
Extracted from app/main.py — locates the FINAL, manually validated erwin XML
export for a model, tolerant of both flat and per-tier subfolder layouts.
"""

from pathlib import Path
from typing import List

from app.common.config_helpers import get_setting
from app.reporting import report_layout


def final_xml_roots() -> List[Path]:
    """
    The Final XML Models folder and its immediate sub-folders.

    Both layouts work without configuration:
        <FINAL_XML_DIR>/<model>.xml
        <FINAL_XML_DIR>/{cdm,ldm,pdm,...}/<model>.xml
    """
    roots: List[Path] = []
    # The XML V3 stage folder of the six-artefact layout comes first: it is
    # where the pipeline's own .ERWIN V2 -> XML V3 conversion writes.
    try:
        from app.orchestration.stage_paths import stage_folders
        erwin_out = Path(str(get_setting("OUTPUT_DIR", "erwinmodels")))
        roots.append(stage_folders(erwin_out)["xml_v3"])
    except Exception:                                          # noqa: BLE001
        pass
    # Then the legacy hand-populated folder, flat or per tier.
    base = Path(str(get_setting("FINAL_XML_DIR", "final_xml_models")))
    roots.append(base)
    if base.is_dir():
        roots.extend(sorted(child for child in base.iterdir() if child.is_dir()))
    return roots


def find_final_xml(base_name: str, model_type: str) -> str:
    """
    This model's final, manually validated erwin XML, or "" when there is none.

    Resolved by name against FINAL_XML_DIR using the same tolerant matcher the
    UDP workbooks use (exact stem, then punctuation/case-insensitive, then a
    unique prefix), with an optional FINAL_XML_MAP for estates whose exports
    are not named after the source model.
    """
    extensions = tuple(get_setting("FINAL_XML_EXTENSIONS", (".xml",)))
    name_map = str(get_setting("FINAL_XML_MAP", "") or "")
    roots = final_xml_roots()

    # An exact <model><ext> in any root is the common case and the cheapest.
    for root in roots:
        for extension in extensions:
            candidate = root / f"{base_name}{extension}"
            if candidate.is_file():
                return str(candidate)

    # Otherwise fall back to the tolerant resolver (suffix "" = the stem itself).
    found = report_layout.resolve_workbook(base_name, roots, ("",), name_map)
    if found:
        return found

    # resolve_workbook only globs *.xlsx; repeat the same matching for the
    # configured extensions so a mapped or loosely named .xml is still found.
    mapped = report_layout.load_name_map(name_map).get(
        report_layout.norm_key(base_name), "")
    wanted = report_layout.norm_key(mapped or base_name)
    for root in roots:
        if not root.is_dir():
            continue
        for path in sorted(root.iterdir()):
            if (path.is_file() and path.suffix.lower() in extensions
                    and report_layout.norm_key(path.stem) == wanted):
                return str(path)
    return ""

