"""
SAP PowerDesigner -> erwin Migration Pipeline
=============================================
One-process entry point. Runs the whole operating flow for every model found
under the SAP PD models folder — the same steps run_v1.py / run_udp.py /
run_v3.py perform one stage at a time — and produces three reports per model
plus one Pass/Fail summary for the run.

    V1  SAP PD  vs  erwinmodels/1_initial/<m>.xml      MANUAL erwin export of the imported model
        Step 1  ->  erwinmodels/2_preprocessed/<m>.xml PD comments written as erwin notes
        Step 2  ->  erwinmodels/2_preprocessed/<m>.erwin UDPs injected into the MANUALLY handed-off
                    app/udp_tool/input_erwin_models/<m>.erwin (Windows + erwin COM)
    V2  SAP PD  vs  2_preprocessed/<m>.xml (+ UDP read-back)
    V3  SAP PD  vs  final_xml_models/<tier>/<m>.xml     MANUAL erwin export of the enriched .erwin
        gate >= threshold -> erwinmodels/3_final/<m>.xml + .erwin; else the model stays in 2_preprocessed

There is no automated erwin bridge: a model whose manual artefact is missing
is recorded WAITING_FOR_MANUAL_INPUT (batch_summary/stage_state/<m>.json) and
skipped — use the split scripts to run stage by stage between the hand-offs.

THE V3 FRAMEWORK'S TWO INPUTS
-----------------------------
V3 needs exactly two paths, both in app/config/settings.py and both
environment-overridable:

    settings.SAMPLES_DIR      sappdmodels/{cdm,ldm,pdm}   .cdm / .ldm / .pdm
    settings.FINAL_XML_DIR    the Final XML Models folder (populated by hand)

Nothing about a model is hard-coded: names, tiers, folders, report filenames
and UDP workbook names are all resolved at runtime, so a 100+ model estate runs
without per-model configuration.

SCALE
-----
Each model's three reports are written as soon as that model finishes and its
heavy objects (findings, parsed models, documentation rows, UDP detail) are
released immediately afterwards. Only a lightweight summary row survives, so
memory stays flat across a long batch instead of growing with it.

"""

import logging
import os
import sys

# Ensure the root of the project is in the PYTHONPATH
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.common.config_helpers import get_setting
from app.config.settings import LOG_LEVEL
from app.orchestration import concurrency
from app.orchestration.batch_runner import run_batch
from app.orchestration.directory_setup import find_models, setup_directories
from app.orchestration.run_context import start_run
from app.reporting.summary_report import generate_summary_report

logging.basicConfig(
    level=getattr(logging, str(LOG_LEVEL).upper(), logging.WARNING),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


def main(argv=None):
    print("\nStarting SAP PowerDesigner to erwin Migration Pipeline...")
    concurrency.clear_skipped_models()

    # Command line -> settings overrides -> run identity (shared or per-session roots).
    run = start_run("python -m app.main",
                    "SAP PowerDesigner -> erwin migration: V1 / UDP / V2 / V3 for every model.", argv)

    dirs = setup_directories(run)
    models = find_models(dirs, mirror=True)

    if not models:
        logger.warning("No models found under %s", get_setting("SAMPLES_DIR", ""))
        print(f"No models found under {get_setting('SAMPLES_DIR', '')}.")
        return

    print(f"Found {len(models)} model(s) to process.")
    print(f"Final validated erwin XML folder: {get_setting('FINAL_XML_DIR', '')}")

    release = bool(get_setting("RELEASE_RESULTS_AFTER_REPORTING", True))
    max_workers = int(get_setting("MAX_WORKERS", 4))

    summary_rows = run_batch(models, dirs, release, max_workers, session_context=run.session_context)

    if summary_rows:
        generate_summary_report(summary_rows, dirs["summary"])

    skipped_models = concurrency.get_skipped_models()
    if skipped_models:
        print(f"\n{'=' * 60}\n{len(skipped_models)} model(s) skipped — pre-flight rejection or "
              f"awaiting manual erwin export:\n{'=' * 60}")
        for reason in skipped_models:
            print(f"  - {reason}")

    if run.isolated:
        print(f"\nSession outputs: {run.roots['session']}")
    print("\nPipeline execution completed.\n")


if __name__ == "__main__":  # pragma: no cover
    main()
