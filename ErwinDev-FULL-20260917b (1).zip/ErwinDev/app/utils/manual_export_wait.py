"""
Manual erwin export gate: bounded wait for a hand-produced XML export, plus a
well-formedness check so a corrupt/partial export fails fast with a clear
message instead of surfacing as a generic parser crash later in the pipeline.
"""

import time
import xml.etree.ElementTree as ET  # nosec B405
from pathlib import Path
from typing import Callable, Optional, Tuple

from defusedxml.ElementTree import parse as safe_parse


def wait_for_manual_export(xml_path: Path, timeout_seconds: int = 0,
                           poll_interval: float = 5.0,
                           on_wait: Optional[Callable[[Path, float], None]] = None) -> bool:
    """
    Wait for a manually produced erwin XML export to appear on disk.

    ``timeout_seconds`` <= 0 preserves the original one-shot behaviour: check
    once and return immediately. A positive value polls every
    ``poll_interval`` seconds until the file appears or the timeout elapses,
    calling ``on_wait(xml_path, seconds_remaining)`` before each sleep so the
    caller can print progress.
    """
    if timeout_seconds <= 0:
        return xml_path.exists()

    deadline = time.monotonic() + timeout_seconds
    while True:
        if xml_path.exists():
            return True
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return False
        if on_wait is not None:
            on_wait(xml_path, remaining)
        time.sleep(min(poll_interval, remaining))


def validate_erwin_xml(xml_path: Path) -> Tuple[bool, str]:
    """
    Confirm an exported XML file is well-formed. Never raises.

    Returns (True, "") when the file parses cleanly, or (False, reason) for a
    truncated/corrupt export so the caller can report it explicitly rather
    than letting a downstream parser fail with an unrelated-looking error.
    """
    try:
        safe_parse(str(xml_path))
        return True, ""
    except ET.ParseError as exc:
        return False, str(exc)
    except OSError as exc:
        return False, str(exc)
