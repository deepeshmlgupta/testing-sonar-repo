"""
Session and user isolation management for multi-user safety.

This module provides:
- Session ID generation (UUID + timestamp)
- User identification (Windows/Unix username)
- Per-session directory isolation
- File locking for concurrent access safety
- Audit log segregation
"""

import contextlib
import logging
import os
import re
import sys
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Tuple

logger = logging.getLogger(__name__)


def _lock_poll_interval() -> float:
    """Seconds between non-blocking lock retries (settings-overridable).

    Was a bare 0.05 at both retry sites; the value is now declared once in
    settings.FILE_LOCK_POLL_INTERVAL_SECONDS with the same default.
    """
    try:
        from app.config import settings
        return float(getattr(settings, "FILE_LOCK_POLL_INTERVAL_SECONDS", 0.05))
    except Exception:                                          # noqa: BLE001
        return 0.05


def get_current_user() -> str:
    """
    Get the current user's login name across Windows/Unix.
    Falls back to environment variables if not available.
    """
    try:
        import getpass
        user = getpass.getuser()
        if user:
            return user.strip()
    except Exception:
        pass

    # Fallback to environment variables
    for var in ('USERNAME', 'USER', 'LOGNAME'):
        user = os.environ.get(var)
        if user:
            return user.strip()

    return "unknown_user"


_UNSAFE = re.compile(r"[^A-Za-z0-9._-]+")


def _safe_component(text: str) -> str:
    """A user / session id as a single safe path component (``DOMAIN\\user`` -> ``DOMAIN_user``)."""
    cleaned = _UNSAFE.sub("_", str(text or "").strip()).strip("._")
    return cleaned or "unknown"


def generate_session_id() -> str:
    """
    Generate a unique session ID combining UUID and timestamp.
    Format: <timestamp>_<short_uuid>
    Example: 20250912_143022_a1b2c3d4
    """
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    short_uuid = str(uuid.uuid4())[:8]
    return f"{timestamp}_{short_uuid}"


def get_session_context(user: str = "", session_id: str = "") -> Tuple[str, str, str]:
    """
    Get the current session context.

    ``user`` / ``session_id`` override detection; when empty, the
    ``FORCE_USERNAME`` / ``FORCE_SESSION_ID`` settings are honoured, then the
    OS user and a fresh timestamp+uuid id. A forced session id is what lets
    ``run_v1`` / ``run_udp`` / ``run_v3`` (three processes) share one session
    folder, and what a scheduler uses to give each job a predictable path.

    Returns:
        (user, session_id, session_dir_suffix)
    """
    try:
        from app.config import settings
        user = user or str(getattr(settings, "FORCE_USERNAME", "") or "")
        session_id = session_id or str(getattr(settings, "FORCE_SESSION_ID", "") or "")
    except ImportError:                                         # pragma: no cover
        pass
    user = _safe_component(user or get_current_user())
    session_id = _safe_component(session_id or generate_session_id())
    # session_dir_suffix used in path construction: "user_session_id"
    session_suffix = f"{user}_{session_id}"

    return user, session_id, session_suffix


class SessionContext:
    """
    Holds session information for the current run.

    Usage:
        ctx = SessionContext()
        print(ctx.user)
        print(ctx.session_id)
        print(ctx.session_output_dir)
    """

    def __init__(self, base_output_dir: str, auto_create: bool = True,
                 user: str = "", session_id: str = ""):
        """
        Initialize session context.

        Args:
            base_output_dir: Base directory for all outputs
            auto_create: Auto-create session-scoped directories
            user / session_id: explicit identity (CLI flags); otherwise the
                FORCE_* settings, then auto-detection.
        """
        self.user, self.session_id, self.session_suffix = get_session_context(user, session_id)
        self.base_output_dir = Path(base_output_dir)
        self.session_output_dir = self.base_output_dir / self.session_suffix

        logger.info(f"Session initialized: user={self.user}, session_id={self.session_id}")

        if auto_create:
            self.session_output_dir.mkdir(parents=True, exist_ok=True)
            logger.info(f"Session output directory: {self.session_output_dir}")

    def get_scoped_path(self, subdir: str) -> Path:
        """
        Get a user-scoped subdirectory within the session.

        Args:
            subdir: Subdirectory name (e.g., 'reports', 'json', 'xml')

        Returns:
            Path object for the scoped directory
        """
        path = self.session_output_dir / subdir
        path.mkdir(parents=True, exist_ok=True)
        return path

    def create_session_log_file(self, base_path: str, filename: str) -> Path:
        """
        Create a session-scoped log file path.

        Args:
            base_path: Base directory (e.g., 'audit')
            filename: Log filename (e.g., 'timings.jsonl')

        Returns:
            Path object: base_path/user_session_id/filename
        """
        log_dir = Path(base_path) / self.session_suffix
        log_dir.mkdir(parents=True, exist_ok=True)
        return log_dir / filename

    def __repr__(self) -> str:
        return f"SessionContext(user={self.user}, session_id={self.session_id})"


@contextlib.contextmanager
def file_lock(file_path: Path, timeout: float = 30.0):
    """
    Context manager for cross-platform file locking.

    Usage:
        with file_lock(Path('output.txt')):
            # Safe concurrent access
            with open(output_path, 'a') as f:
                f.write("data")

    Args:
        file_path: Path to file to lock
        timeout: Timeout in seconds (not enforced on all platforms)

    Yields:
        Path to the locked file
    """
    lock_file = Path(str(file_path) + '.lock')

    # NOTE: these helpers are plain generator functions, so they must be
    # driven with ``yield from``. The previous ``yield _posix_file_lock(...)``
    # yielded the un-started generator object itself: the helper's body never
    # ran, no lock was ever taken, and callers received a generator instead
    # of the path. Every "safe concurrent write" was in fact unlocked.
    if sys.platform == 'win32':
        yield from _win32_file_lock(file_path, lock_file, timeout)
    else:
        yield from _posix_file_lock(file_path, lock_file, timeout)


def _acquire_with_timeout(try_lock, timeout: float, lock_file: Path) -> bool:
    """
    Retry a non-blocking lock attempt until it succeeds or ``timeout`` elapses.
    A single non-blocking attempt (the previous behaviour) meant two writers
    arriving together both "proceeded without lock", which is exactly the
    case the lock exists for.
    """
    deadline = time.monotonic() + max(0.0, float(timeout))
    while True:
        try:
            try_lock()
            return True
        except (OSError, IOError):
            if time.monotonic() >= deadline:
                logger.warning(f"Could not acquire lock on {lock_file} within {timeout}s; proceeding without lock")
                return False
            time.sleep(_lock_poll_interval())


def _win32_file_lock(file_path: Path, lock_file: Path, timeout: float):
    """Windows file locking using msvcrt."""
    try:
        import msvcrt
    except ImportError:
        logger.warning("msvcrt not available; proceeding without lock")
        yield file_path
        return

    lock_file.touch(exist_ok=True)
    with open(lock_file, 'a') as lf:
        locked = _acquire_with_timeout(
            lambda: msvcrt.locking(lf.fileno(), msvcrt.LK_NBLCK, 1), timeout, lock_file)
        if locked:
            logger.debug(f"File lock acquired: {lock_file}")
        try:
            yield file_path
        finally:
            if locked:
                try:
                    msvcrt.locking(lf.fileno(), msvcrt.LK_UNLCK, 1)
                except OSError:
                    pass
                logger.debug(f"File lock released: {lock_file}")


def _posix_file_lock(file_path: Path, lock_file: Path, timeout: float):
    """POSIX file locking using fcntl."""
    try:
        import fcntl
    except ImportError:
        logger.warning("fcntl not available; proceeding without lock")
        yield file_path
        return

    lock_file.touch(exist_ok=True)
    with open(lock_file, 'a') as lf:
        locked = _acquire_with_timeout(
            lambda: fcntl.flock(lf.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB), timeout, lock_file)
        if locked:
            logger.debug(f"File lock acquired: {lock_file}")
        try:
            yield file_path
        finally:
            if locked:
                try:
                    fcntl.flock(lf.fileno(), fcntl.LOCK_UN)
                except OSError:
                    pass
                logger.debug(f"File lock released: {lock_file}")


def lock_is_held(file_path: Path, timeout: float = 0.0) -> bool:
    """
    True when the advisory lock on ``file_path`` cannot be taken within
    ``timeout`` seconds, i.e. another live process holds it. Nothing is left
    locked on return. Used by the batch pre-flight to warn about a concurrent
    run before workers start.
    """
    lock_file = Path(str(file_path) + '.lock')
    try:
        lock_file.parent.mkdir(parents=True, exist_ok=True)
        lock_file.touch(exist_ok=True)
        with open(lock_file, 'a') as lf:
            if sys.platform == 'win32':
                import msvcrt
                try_lock = lambda: msvcrt.locking(lf.fileno(), msvcrt.LK_NBLCK, 1)   # noqa: E731
                unlock = lambda: msvcrt.locking(lf.fileno(), msvcrt.LK_UNLCK, 1)     # noqa: E731
            else:
                import fcntl
                try_lock = lambda: fcntl.flock(lf.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)  # noqa: E731
                unlock = lambda: fcntl.flock(lf.fileno(), fcntl.LOCK_UN)                    # noqa: E731
            deadline = time.monotonic() + max(0.0, float(timeout))
            while True:
                try:
                    try_lock()
                    unlock()
                    return False
                except OSError:
                    if time.monotonic() >= deadline:
                        return True
                    time.sleep(_lock_poll_interval())
    except (ImportError, OSError):
        return False


def write_json_atomically(file_path: Path, data: dict, use_lock: bool = True) -> None:
    """
    Write JSON data atomically using write-then-rename pattern.

    Args:
        file_path: Target file path
        data: Dictionary to serialize as JSON
        use_lock: Use file locking for safety
    """
    import json

    file_path = Path(file_path)
    file_path.parent.mkdir(parents=True, exist_ok=True)

    # Write to temp file first
    temp_path = file_path.with_suffix(file_path.suffix + '.tmp')

    try:
        with open(temp_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)

        # Atomic rename
        if use_lock:
            with file_lock(file_path):
                temp_path.replace(file_path)
        else:
            temp_path.replace(file_path)
    except Exception as e:
        logger.error(f"Failed to write JSON atomically to {file_path}: {e}")
        if temp_path.exists():
            temp_path.unlink()
        raise


def append_jsonl_line_safely(file_path: Path, data: dict) -> None:
    """
    Append a single JSON line atomically with file locking.
    Safe for concurrent writes by multiple processes.

    Args:
        file_path: Target JSONL file path
        data: Dictionary to append as a JSON line
    """
    import json

    file_path = Path(file_path)
    file_path.parent.mkdir(parents=True, exist_ok=True)

    with file_lock(file_path):
        with open(file_path, 'a', encoding='utf-8') as f:
            json.dump(data, f)
            f.write('\n')
            f.flush()
            os.fsync(f.fileno())  # Force flush to disk

    logger.debug(f"Appended JSONL line to {file_path}")
