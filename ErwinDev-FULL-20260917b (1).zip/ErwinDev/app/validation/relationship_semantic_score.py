"""
Relationship Semantic Scoring (Workstream 5)
==============================================
Classifies each matched relationship pair by three semantic axes —
identifying/non-identifying, weak-entity (existence) dependency, and
mandatory/optional participation at each end — and blends per-model
agreement into one "Relationship Semantic Fidelity %".

Tier-agnostic: operates on any duck-typed relationship pair exposing
``identifying`` and ``end1``/``end2`` with ``mandatory``/``dependent``
attributes (both the CDM and LDM ``Relationship``/``RelationshipEnd``
dataclasses satisfy this without any import here).
"""

from dataclasses import dataclass, field
from typing import Any, Iterable, List, Optional, Tuple


@dataclass
class RelationshipSemanticFinding:
    label:                str
    identifying_match:    bool
    weak_entity_match:    bool
    participation_match:  bool
    semantic_score_pct:   float  # 0 / 33.33 / 66.67 / 100 — axes agreeing / 3


@dataclass
class RelationshipSemanticOutcome:
    findings:     List[RelationshipSemanticFinding] = field(default_factory=list)
    fidelity_pct: Optional[float] = None


def _end_participation(end: Any) -> Tuple[bool, bool]:
    return (bool(getattr(end, "mandatory", False)), bool(getattr(end, "dependent", False)))


def _entity_key(end: Any) -> str:
    """Case/punctuation-insensitive key of the entity an end points at."""
    import re
    return re.sub(r"[^a-z0-9]", "", str(getattr(end, "entity", "") or "").lower())


def aligned_erwin_ends(pd_rel: Any, erwin_rel: Any) -> Tuple[Any, Any]:
    """
    erwin's two ends re-ordered so that they line up with ``pd_rel.end1`` and
    ``pd_rel.end2`` by ENTITY, not by position.

    PowerDesigner lists Entity1/Entity2 in whatever order the modeller drew
    them, while erwin always lists the parent end first.  For a typical
    "child (0,n) -> parent (1,1)" relationship the two tools therefore store
    the ends in opposite order, and a positional comparison reports a
    participation mismatch on a relationship that migrated perfectly.  When
    the entities cannot be matched (or the relationship is self-referencing)
    the positional order is kept.
    """
    pd1, pd2 = _entity_key(pd_rel.end1), _entity_key(pd_rel.end2)
    er1, er2 = _entity_key(erwin_rel.end1), _entity_key(erwin_rel.end2)
    if pd1 and pd2 and pd1 != pd2 and er1 != er2:
        if pd1 == er2 and pd2 == er1:
            return erwin_rel.end2, erwin_rel.end1
        if pd1 == er1 and pd2 == er2:
            return erwin_rel.end1, erwin_rel.end2
    # Unknown or recursive: fall back to whichever orientation agrees best.
    straight = (_end_participation(erwin_rel.end1), _end_participation(erwin_rel.end2))
    swapped = (_end_participation(erwin_rel.end2), _end_participation(erwin_rel.end1))
    pd_part = (_end_participation(pd_rel.end1), _end_participation(pd_rel.end2))
    if pd_part == swapped and pd_part != straight:
        return erwin_rel.end2, erwin_rel.end1
    return erwin_rel.end1, erwin_rel.end2


def classify_pair(pd_rel: Any, erwin_rel: Any) -> RelationshipSemanticFinding:
    """Score one matched (pd, erwin) relationship pair across the three axes."""
    label = getattr(pd_rel, "name", "") or getattr(pd_rel, "code", "") or "relationship"

    identifying_match = (bool(getattr(pd_rel, "identifying", False)) ==
                         bool(getattr(erwin_rel, "identifying", False)))

    erwin_end1, erwin_end2 = aligned_erwin_ends(pd_rel, erwin_rel)

    pd_dependent = (bool(getattr(pd_rel.end1, "dependent", False)) or
                    bool(getattr(pd_rel.end2, "dependent", False)))
    erwin_dependent = (bool(getattr(erwin_end1, "dependent", False)) or
                       bool(getattr(erwin_end2, "dependent", False)))
    weak_entity_match = pd_dependent == erwin_dependent

    pd_participation = (_end_participation(pd_rel.end1), _end_participation(pd_rel.end2))
    erwin_participation = (_end_participation(erwin_end1), _end_participation(erwin_end2))
    participation_match = pd_participation == erwin_participation

    agree = sum((identifying_match, weak_entity_match, participation_match))
    score = round(100.0 * agree / 3, 2)

    return RelationshipSemanticFinding(
        label=label, identifying_match=identifying_match,
        weak_entity_match=weak_entity_match, participation_match=participation_match,
        semantic_score_pct=score,
    )


def score_relationships(pairs: Iterable[Tuple[Any, Any]]) -> RelationshipSemanticOutcome:
    """
    Score every matched relationship pair and blend the model-level fidelity.

    ``pairs`` is an iterable of (pd_rel, erwin_rel) tuples — typically the
    already name/endpoint-matched pairs a comparator's own matching already
    produced, so no additional matching pass is needed here.
    """
    outcome = RelationshipSemanticOutcome()
    outcome.findings = [classify_pair(pd_rel, erwin_rel) for pd_rel, erwin_rel in pairs]
    if outcome.findings:
        outcome.fidelity_pct = round(
            sum(f.semantic_score_pct for f in outcome.findings) / len(outcome.findings), 2)
    return outcome
