"""
Business Rule Expression Parser (Workstream 2)
================================================
Turns a PowerDesigner / erwin business-rule expression string into a Python
``ast`` tree so two syntactically different but semantically equivalent
expressions ("Amount > 0" vs "0 < Amount") can be compared structurally
instead of as raw text.

Safety
------
The expression is only ever passed to ``ast.parse()`` — never to ``eval()``
or ``exec()`` — so nothing here executes user-authored code. Parsing failures
(business rules are prose, not always valid expressions) are swallowed and
reported as ``None``, letting the caller fall back to the existing raw-text
comparison unchanged.
"""

import ast
import re
from typing import Optional

# Node types this module understands. Anything else (list/dict literals,
# attribute access, subscripting, lambdas, comprehensions, …) is rejected so a
# malformed or unexpectedly rich expression falls back to text comparison
# rather than being partially/incorrectly normalized.
_ALLOWED_NODES = (
    ast.Expression, ast.BoolOp, ast.BinOp, ast.UnaryOp, ast.Compare,
    ast.Call, ast.Name, ast.Load, ast.Constant,
    ast.And, ast.Or, ast.Not, ast.UAdd, ast.USub,
    ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Mod, ast.Pow, ast.FloorDiv,
    ast.Eq, ast.NotEq, ast.Lt, ast.LtE, ast.Gt, ast.GtE,
)

# The "simple functions" Workstream 2 asks for — anything else (including
# names that merely look like functions, e.g. __import__) is rejected.
_ALLOWED_CALL_NAMES = {"abs", "min", "max", "round", "sum", "len"}

# A bare "=" (not already part of ==, !=, <=, >=) is PowerDesigner/SQL
# equality syntax, not valid Python — rewritten to "==" before parsing.
_BARE_EQUALS_RE = re.compile(r"(?<![=!<>])=(?!=)")
_LOGICAL_WORDS_RE = re.compile(r"\bAND\b|\bOR\b|\bNOT\b", re.IGNORECASE)
_LOGICAL_WORD_MAP = {"and": "and", "or": "or", "not": "not"}


def _preprocess(text: str) -> str:
    """Rewrite common business-rule syntax into a parseable Python expression."""
    expr = (text or "").strip().rstrip(";")
    expr = _BARE_EQUALS_RE.sub("==", expr)
    expr = _LOGICAL_WORDS_RE.sub(lambda m: _LOGICAL_WORD_MAP[m.group(0).lower()], expr)
    return expr


def _validate(node: ast.AST) -> bool:
    """Every node in the tree must be in the allowed whitelist."""
    for child in ast.walk(node):
        if not isinstance(child, _ALLOWED_NODES):
            return False
        if isinstance(child, ast.Call):
            if not isinstance(child.func, ast.Name) or child.func.id not in _ALLOWED_CALL_NAMES:
                return False
    return True


def parse_expression(text: str) -> Optional[ast.Expression]:
    """
    Parse a business rule expression into an AST, or ``None`` when the text is
    not a supported expression (free prose, unsupported syntax, empty).
    """
    expr = _preprocess(text)
    if not expr:
        return None
    try:
        tree = ast.parse(expr, mode="eval")
    except (SyntaxError, ValueError):
        return None
    if not _validate(tree):
        return None
    return tree
