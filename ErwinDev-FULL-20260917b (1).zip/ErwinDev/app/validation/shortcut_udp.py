"""
Shortcuts -> erwin UDPs
=======================
Carries PowerDesigner Shortcuts into erwin as User-Defined Properties, so the
one class of SAP PD content that had no erwin representation at all stops being
silently dropped.

Why UDPs, and not a shortcut object
-----------------------------------
erwin has no shortcut object. Until now the framework's honest response was a
census: count the shortcuts, emit a VERIFIED finding per shortcut saying erwin
has no equivalent, and weight the component 0.0 so no invented number entered
the score. That was correct but terminal — the information never arrived in
erwin, and ``sow_classify`` recorded it as ``facts_lost``.

A UDP is the representation erwin does have, and the pipeline already injects
UDPs through ``app/udp_tool/erwin_load.py``. So this module produces extra rows
for the SAME two artefacts that engine already consumes — ``udp_schema.json``
(the definitions) and ``property_manifest.json`` (the values) — and the
existing injector, read-back and comparison workbooks handle them unchanged.
Nothing in ``app/udp_tool`` is modified.

What is actually in these models
--------------------------------
Measured on the two real LDMs rather than assumed:

* ``c:ExternalObjects`` — the "List of Shortcuts" a modeller creates — is
  ABSENT from both. The reconcile parsers only read that collection, which is
  why ``shortcuts_pd`` is 0 for both models.
* What the files DO carry is the glossary: 18 and 164 ``o:Shortcut``
  definitions under ``c:TermObjects`` / ``c:SessionShortcuts``, almost all of
  target class Term ("Site"/ST, "Property"/PRPRTY, "Is"/IS).
* And, crucially, the BINDINGS: ``c:RelatedNameTerms`` / ``c:RelatedCodeTerms``
  on individual objects, pointing at those terms by ``Ref``. In real_estate
  that is 102 of 105 entities (797 term references) and 39 attributes.

The bindings are the migratable fact: "entity Property Structure's name is
built from the glossary terms Property and Structure". That is what a naming
standard is, and it is what this module writes into erwin.

What lands where
----------------
    per entity   PD_NameTerms        the glossary terms forming its NAME
                 PD_CodeTerms        the glossary terms forming its CODE
                 PD_Shortcut_Target  external shortcut: the owning model
                 PD_Shortcut_Type    external shortcut: Model | Category | Term
                 PD_Shortcut_Package / PD_Shortcut_Stereotype
    model root   PD_Shortcut_Count   how many shortcut definitions there were
                 PD_Shortcut_Terms   the glossary census, truncated to fit

Bindings owned by objects the injector cannot reach (attributes,
relationships, inheritances, diagrams) are counted into the model-root census
rather than dropped quietly: ``erwin_load`` applies values to Entities and to
the model root, and nothing else.

Never raises. A model this cannot read produces an empty census and the UDP
phase carries on exactly as it did before.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

from defusedxml.ElementTree import parse as safe_parse

logger = logging.getLogger(__name__)

# ─── PowerDesigner target classes (the GUIDs are stable across releases) ──────
TARGET_CLASSES = {
    "186C8AC3-D3DC-11D3-881C-00508B03C75C": "Model",
    "CD2F5C71-2CA9-4B74-9BBA-50786D1D88EF": "Category",
    "EBE946CF-7218-4FAC-B85E-4AB922930494": "Term",
}

#: Collections holding shortcut DEFINITIONS (elements with an Id).
#: ExternalObjects is the modeller's "List of Shortcuts"; the other two are the
#: glossary, which is where the content actually is in the real models.
DEFAULT_SHORTCUT_COLLECTIONS = ("ExternalObjects", "TermObjects", "SessionShortcuts")

#: Collections holding shortcut REFERENCES (elements with a Ref), i.e. the
#: per-object glossary bindings.
DEFAULT_BINDING_COLLECTIONS = ("RelatedNameTerms", "RelatedCodeTerms")

#: Owners the erwin injector can actually apply a value to.
INJECTABLE_OWNERS = ("Entity",)

#: UDP names. Changing one changes what erwin holds, so they are named here
#: once and referenced everywhere else.
UDP_NAME_TERMS = "PD_NameTerms"
UDP_CODE_TERMS = "PD_CodeTerms"
UDP_SHORTCUT_COUNT = "PD_Shortcut_Count"
UDP_SHORTCUT_TERMS = "PD_Shortcut_Terms"
UDP_SHORTCUT_TARGET = "PD_Shortcut_Target"
UDP_SHORTCUT_TYPE = "PD_Shortcut_Type"
UDP_SHORTCUT_PACKAGE = "PD_Shortcut_Package"
UDP_SHORTCUT_STEREOTYPE = "PD_Shortcut_Stereotype"

#: erwin refuses a UDP value longer than this; the text ones are truncated to
#: fit with an explicit ellipsis rather than being silently cut by erwin.
DEFAULT_MAX_VALUE_LENGTH = 1024

_TERM_SEPARATOR = ", "
_TRUNCATION_MARK = " …(truncated)"


def _local(tag: Any) -> str:
    """Local name of an element tag; '' for comments and processing instructions."""
    return tag.split("}")[-1] if isinstance(tag, str) else ""


def _attr(elem, name: str) -> str:
    """Text of the ``<a:Name>`` child of an element, or ''."""
    for child in elem:
        if _local(child.tag) == name:
            return (child.text or "").strip()
    return ""


@dataclass
class Shortcut:
    """One PowerDesigner shortcut definition."""

    oid: str = ""
    object_id: str = ""
    name: str = ""
    code: str = ""
    target_type: str = "Object"
    target_model: str = ""
    target_package: str = ""
    target_stereotype: str = ""
    collection: str = ""

    @property
    def label(self) -> str:
        return f"{self.name}({self.code})" if self.code and self.code != self.name else self.name

    @property
    def is_external_reference(self) -> bool:
        """A modeller-made reference to another model, not a glossary term."""
        return self.collection == "ExternalObjects"


@dataclass
class Binding:
    """One object's glossary bindings."""

    owner_type: str = ""
    owner_name: str = ""
    owner_code: str = ""
    owner_oid: str = ""
    name_terms: List[str] = field(default_factory=list)
    code_terms: List[str] = field(default_factory=list)

    @property
    def injectable(self) -> bool:
        return self.owner_type in INJECTABLE_OWNERS and bool(self.owner_name)


@dataclass
class ShortcutCensus:
    """Everything this module found in one SAP PD model."""

    model_name: str = ""
    shortcuts: List[Shortcut] = field(default_factory=list)
    bindings: List[Binding] = field(default_factory=list)
    error: str = ""

    @property
    def external_references(self) -> List[Shortcut]:
        return [s for s in self.shortcuts if s.is_external_reference]

    @property
    def glossary_terms(self) -> List[Shortcut]:
        return [s for s in self.shortcuts if not s.is_external_reference]

    @property
    def injectable_bindings(self) -> List[Binding]:
        return [b for b in self.bindings if b.injectable]

    @property
    def unreachable_bindings(self) -> List[Binding]:
        """Bindings on objects erwin's injector cannot address."""
        return [b for b in self.bindings if not b.injectable]

    def summary_line(self) -> str:
        if self.error:
            return f"shortcut census failed: {self.error}"
        return (f"{len(self.shortcuts)} shortcut definition(s) "
                f"({len(self.external_references)} external, {len(self.glossary_terms)} glossary term(s)); "
                f"{len(self.injectable_bindings)} entity binding(s), "
                f"{len(self.unreachable_bindings)} on objects erwin cannot hold a UDP for")


# ═════════════════════════════════════════════════════════════════════════════
#  Extraction
# ═════════════════════════════════════════════════════════════════════════════

def _collect_definitions(root, collections: Sequence[str]) -> Tuple[Dict[str, Shortcut], List[Shortcut]]:
    """Every ``<o:Shortcut Id=...>`` in the wanted collections, by element id."""
    wanted = set(collections or ())
    by_oid: Dict[str, Shortcut] = {}
    found: List[Shortcut] = []
    for parent in root.iter():
        collection = _local(getattr(parent, "tag", ""))
        if collection not in wanted:
            continue
        for elem in parent:
            if _local(elem.tag) != "Shortcut":
                continue
            oid = elem.get("Id") or ""
            if not oid:                      # a Ref pointer, not a definition
                continue
            shortcut = Shortcut(
                oid=oid,
                object_id=_attr(elem, "ObjectID"),
                name=_attr(elem, "Name"),
                code=_attr(elem, "Code") or _attr(elem, "Name"),
                target_type=TARGET_CLASSES.get(_attr(elem, "TargetClassID"), "Object"),
                target_model=_attr(elem, "TargetModelURL"),
                target_package=_attr(elem, "TargetPackagePath"),
                target_stereotype=_attr(elem, "TargetStereotype"),
                collection=collection,
            )
            by_oid[oid] = shortcut
            found.append(shortcut)
    return by_oid, found


def _terms_in(collection, by_oid: Dict[str, Shortcut], use_code: bool) -> List[str]:
    """Resolve one ``<c:Related*Terms>`` collection's Refs to term labels, in order."""
    terms: List[str] = []
    for ref in collection:
        if _local(ref.tag) != "Shortcut":
            continue
        shortcut = by_oid.get(ref.get("Ref") or ref.get("Id") or "")
        if shortcut is None:
            continue
        value = shortcut.code if use_code else shortcut.name
        if value and value not in terms:
            terms.append(value)
    return terms


def _binding_for(owner, by_oid: Dict[str, Shortcut],
                 wanted: set) -> Optional[Binding]:
    """One object's glossary binding, or None when it has none."""
    owner_type = _local(getattr(owner, "tag", ""))
    if not owner_type:
        return None
    name_terms: List[str] = []
    code_terms: List[str] = []
    for child in owner:
        collection = _local(child.tag)
        if collection not in wanted:
            continue
        use_code = collection != "RelatedNameTerms"
        target = code_terms if use_code else name_terms
        target.extend(term for term in _terms_in(child, by_oid, use_code)
                      if term not in target)
    if not name_terms and not code_terms:
        return None
    return Binding(
        owner_type=owner_type,
        owner_name=_attr(owner, "Name"),
        owner_code=_attr(owner, "Code"),
        owner_oid=_attr(owner, "ObjectID") or (owner.get("Id") or ""),
        name_terms=name_terms,
        code_terms=code_terms,
    )


def _collect_bindings(root, by_oid: Dict[str, Shortcut],
                      collections: Sequence[str]) -> List[Binding]:
    """Per-object ``RelatedNameTerms`` / ``RelatedCodeTerms`` resolved to term labels."""
    wanted = set(collections or ())
    bindings = (_binding_for(owner, by_oid, wanted) for owner in root.iter())
    return [binding for binding in bindings if binding is not None]


def extract(pd_path, model_name: str = "", config=None) -> ShortcutCensus:
    """
    Census one SAP PD model's shortcuts and glossary bindings. Never raises.
    """
    census = ShortcutCensus(model_name=model_name or Path(str(pd_path)).stem)
    definitions = _cfg(config, "SHORTCUT_COLLECTIONS", DEFAULT_SHORTCUT_COLLECTIONS)
    bindings = _cfg(config, "SHORTCUT_BINDING_COLLECTIONS", DEFAULT_BINDING_COLLECTIONS)
    try:
        root = safe_parse(str(pd_path)).getroot()
    except Exception as exc:                                   # noqa: BLE001
        census.error = f"{type(exc).__name__}: {exc}"
        logger.warning("Shortcut census could not read %s: %s", pd_path, exc)
        return census

    try:
        by_oid, census.shortcuts = _collect_definitions(root, definitions)
        census.bindings = _collect_bindings(root, by_oid, bindings)
    except Exception as exc:                                   # noqa: BLE001
        census.error = f"{type(exc).__name__}: {exc}"
        logger.warning("Shortcut census failed for %s: %s", pd_path, exc)
    return census


# ═════════════════════════════════════════════════════════════════════════════
#  UDP schema + manifest rows
# ═════════════════════════════════════════════════════════════════════════════

def _cfg(config, name: str, default):
    return getattr(config, name, default) if config is not None else default


def _fit(value: str, limit: int) -> str:
    """Truncate to what erwin will accept, visibly."""
    text = str(value or "")
    if len(text) <= limit:
        return text
    return text[:max(0, limit - len(_TRUNCATION_MARK))].rstrip(" ,") + _TRUNCATION_MARK


def _schema_row(udp: str, purpose: str, length: int) -> Dict[str, Any]:
    """A definition in the exact shape app/udp_tool/erwin_prepare.py emits."""
    return {
        "udp": udp,
        "type": "Text",
        "length": length,
        "value_list": None,
        "source_path": "",
        "coverage": "",
        "distinct_observed": "",
        "list_source": "",
        "purpose": purpose,
    }


def schema_rows(census: ShortcutCensus, config=None) -> List[Dict[str, Any]]:
    """The UDP definitions the census needs, or [] when there is nothing to carry."""
    if not census.shortcuts and not census.bindings:
        return []
    limit = int(_cfg(config, "SHORTCUT_UDP_MAX_LENGTH", DEFAULT_MAX_VALUE_LENGTH))
    rows = []
    if census.injectable_bindings:
        rows.append(_schema_row(
            UDP_NAME_TERMS,
            "PowerDesigner glossary terms that make up this object's NAME "
            "(c:RelatedNameTerms). erwin has no glossary, so the binding is "
            "carried as text.", limit))
        rows.append(_schema_row(
            UDP_CODE_TERMS,
            "PowerDesigner glossary terms that make up this object's CODE "
            "(c:RelatedCodeTerms).", limit))
    if census.external_references:
        rows.append(_schema_row(UDP_SHORTCUT_TARGET,
                                "Model that owns the object this PowerDesigner shortcut points at.", 200))
        rows.append(_schema_row(UDP_SHORTCUT_TYPE,
                                "Target class of the PowerDesigner shortcut: Model, Category, Term or Object.", 40))
        rows.append(_schema_row(UDP_SHORTCUT_PACKAGE,
                                "Package path of the shortcut's target inside its owning model.", 200))
        rows.append(_schema_row(UDP_SHORTCUT_STEREOTYPE,
                                "Stereotype of the shortcut's target (e.g. IsEntity).", 60))
    rows.append(_schema_row(UDP_SHORTCUT_COUNT,
                            "How many PowerDesigner Shortcut definitions the source model carried. "
                            "Provenance: erwin has no shortcut object, so this records what existed.", 20))
    rows.append(_schema_row(UDP_SHORTCUT_TERMS,
                            "The PowerDesigner glossary terms the source model bound to, as name(code).", limit))
    return rows


def manifest_rows(census: ShortcutCensus, config=None) -> List[Dict[str, Any]]:
    """
    The UDP values, in the exact row shape ``erwin_load.py`` applies:
    ``entity_name`` names the erwin Entity to write to, and an EMPTY
    ``entity_name`` means the model root.
    """
    if not census.shortcuts and not census.bindings:
        return []
    limit = int(_cfg(config, "SHORTCUT_UDP_MAX_LENGTH", DEFAULT_MAX_VALUE_LENGTH))
    rows: List[Dict[str, Any]] = []

    def row(entity_name: str, entity_code: str, oid: str, udp: str, value: str):
        rows.append({
            "pd_object_id": oid,
            "entity_name": entity_name,
            "entity_code": entity_code,
            "udp": udp,
            "value": value,
            "source_path": "",
        })

    # Per-entity glossary bindings — the migratable fact.
    for binding in census.injectable_bindings:
        if binding.name_terms:
            row(binding.owner_name, binding.owner_code, binding.owner_oid,
                UDP_NAME_TERMS, _fit(_TERM_SEPARATOR.join(binding.name_terms), limit))
        if binding.code_terms:
            row(binding.owner_name, binding.owner_code, binding.owner_oid,
                UDP_CODE_TERMS, _fit(_TERM_SEPARATOR.join(binding.code_terms), limit))

    # External shortcuts, on the entity erwin's import will have named after them.
    for shortcut in census.external_references:
        if not shortcut.name:
            continue
        row(shortcut.name, shortcut.code, shortcut.object_id,
            UDP_SHORTCUT_TARGET, _fit(shortcut.target_model, 200))
        row(shortcut.name, shortcut.code, shortcut.object_id,
            UDP_SHORTCUT_TYPE, shortcut.target_type)
        if shortcut.target_package:
            row(shortcut.name, shortcut.code, shortcut.object_id,
                UDP_SHORTCUT_PACKAGE, _fit(shortcut.target_package, 200))
        if shortcut.target_stereotype:
            row(shortcut.name, shortcut.code, shortcut.object_id,
                UDP_SHORTCUT_STEREOTYPE, _fit(shortcut.target_stereotype, 60))

    # Model-root provenance. This always lands, so a model whose bindings are
    # all on unreachable objects still records that they existed.
    row("", "", "", UDP_SHORTCUT_COUNT, str(len(census.shortcuts)))
    terms = _TERM_SEPARATOR.join(sorted({s.label for s in census.glossary_terms if s.name}))
    if terms:
        row("", "", "", UDP_SHORTCUT_TERMS, _fit(terms, limit))
    return rows


def build(pd_path, model_name: str = "", config=None
          ) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], ShortcutCensus]:
    """
    Census a model and return (schema rows, manifest rows, census).
    The single entry point ``udp_bridge.build_mapping`` uses.
    """
    census = extract(pd_path, model_name, config)
    if census.error:
        return [], [], census
    return schema_rows(census, config), manifest_rows(census, config), census


__all__ = [
    "Shortcut", "Binding", "ShortcutCensus",
    "extract", "schema_rows", "manifest_rows", "build",
    "TARGET_CLASSES", "DEFAULT_SHORTCUT_COLLECTIONS", "DEFAULT_BINDING_COLLECTIONS",
    "INJECTABLE_OWNERS", "DEFAULT_MAX_VALUE_LENGTH",
    "UDP_NAME_TERMS", "UDP_CODE_TERMS", "UDP_SHORTCUT_COUNT", "UDP_SHORTCUT_TERMS",
    "UDP_SHORTCUT_TARGET", "UDP_SHORTCUT_TYPE", "UDP_SHORTCUT_PACKAGE",
    "UDP_SHORTCUT_STEREOTYPE",
]
