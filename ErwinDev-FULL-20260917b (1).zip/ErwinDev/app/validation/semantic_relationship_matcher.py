"""Direction-invariant relationship matching shared by CDM and LDM."""

from dataclasses import dataclass, field
from typing import Any, Callable, List, Sequence, Tuple


@dataclass
class SemanticMatchOutcome:
    pairs: List[Tuple[Any, Any, str]] = field(default_factory=list)
    unmatched_left: List[Any] = field(default_factory=list)
    unmatched_right: List[Any] = field(default_factory=list)


def _text(value: Any) -> str:
    return " ".join(str(value or "").casefold().replace("_", " ").replace("-", " ").split())


def _role_text(value: Any) -> str:
    """Normalize harmless role-phrase wording without ignoring role meaning."""
    tokens = _text(value).split()
    while tokens and tokens[0] in {"a", "an", "the"}:
        tokens.pop(0)
    if tokens[:1] == ["is"]:
        tokens = tokens[1:]
    return " ".join(tokens)


def _entity_pair(rel: Any, entity_key: Callable[[Any], str]) -> Tuple[str, str]:
    ends = (getattr(rel, "end1", None), getattr(rel, "end2", None))
    values = sorted(entity_key(getattr(end, "entity", "")) for end in ends)
    return tuple(values)  # type: ignore[return-value]


def _name(rel: Any) -> str:
    return _text(getattr(rel, "code", "") or getattr(rel, "name", ""))


def _role_signature(rel: Any, entity_key: Callable[[Any], str]) -> Tuple[Tuple[str, str], ...]:
    values = []
    for end_name in ("end1", "end2"):
        end = getattr(rel, end_name)
        values.append((entity_key(getattr(end, "entity", "")), _role_text(getattr(end, "role", ""))))
    return tuple(sorted(values))


def match_relationships(left: Sequence[Any], right: Sequence[Any], *,
                        entity_key: Callable[[Any], str],
                        endpoint_key: Callable[[Any], str],
                        full_key: Callable[[Any], str]) -> SemanticMatchOutcome:
    """Match by participating entities, then cardinality and stable metadata."""
    del endpoint_key  # endpoint identity is represented by the semantic group below
    left_groups = {}
    right_groups = {}
    for item in left:
        left_groups.setdefault(_entity_pair(item, entity_key), []).append(item)
    for item in right:
        right_groups.setdefault(_entity_pair(item, entity_key), []).append(item)

    outcome = SemanticMatchOutcome()
    for pair in sorted(set(left_groups) | set(right_groups)):
        left_items = list(left_groups.get(pair, []))
        right_items = list(right_groups.get(pair, []))
        while left_items and right_items:
            best = None
            for left_item in left_items:
                for right_item in right_items:
                    score = (
                        4 * (full_key(left_item) == full_key(right_item))
                        + 2 * (_role_signature(left_item, entity_key) ==
                               _role_signature(right_item, entity_key))
                        + 1 * (_name(left_item) == _name(right_item) and bool(_name(left_item)))
                    )
                    candidate = (score, _name(left_item), _name(right_item),
                                 id(left_item), id(right_item), left_item, right_item)
                    if best is None or candidate[:5] > best[:5]:
                        best = candidate
            assert best is not None
            _, left_name, right_name, _, _, left_item, right_item = best
            basis = "semantic endpoints"
            if full_key(left_item) == full_key(right_item):
                basis = "semantic endpoints + cardinality"
            elif left_name and left_name == right_name:
                basis = "semantic endpoints + name"
            outcome.pairs.append((left_item, right_item, basis))
            left_items.remove(left_item)
            right_items.remove(right_item)
        outcome.unmatched_left.extend(left_items)
        outcome.unmatched_right.extend(right_items)
    return outcome
