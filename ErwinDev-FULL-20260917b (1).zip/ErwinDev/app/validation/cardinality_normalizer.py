"""
Cardinality Normalization Engine (Task 3)
===========================================
Tier-agnostic canonical forms for a single relationship end's cardinality,
independent of which tool's notation it arrived in:

    ONE_TO_ONE     exactly one       "1"      "1..1"   "1,1"
    ZERO_OR_ONE    at most one       "0,1"    "0..1"
    ONE_TO_MANY    one or more       "1,n"    "1..*"   "1,N"
    ZERO_TO_MANY   zero or more      "0,n"    "0..*"   "*"

Standalone by design (Task 3 asks for a dedicated module): it does not import
either tier's ``cardinality.py`` so it has no coupling to CDM/LDM internals,
and a comparator can feed it either a raw source string or an already
tier-normalised "0,1"-style string.
"""

import re
from dataclasses import dataclass

ONE_TO_ONE = "ONE_TO_ONE"
ZERO_OR_ONE = "ZERO_OR_ONE"
ONE_TO_MANY = "ONE_TO_MANY"
ZERO_TO_MANY = "ZERO_TO_MANY"

UNKNOWN = ""

# Tier-normalised short forms and the raw variants named in the task, folded
# onto one canonical label each.
_ALIASES = {
    "1": ONE_TO_ONE, "1..1": ONE_TO_ONE, "1,1": ONE_TO_ONE, "1.1": ONE_TO_ONE,
    "exactly one": ONE_TO_ONE, "exactlyone": ONE_TO_ONE,

    "0,1": ZERO_OR_ONE, "0..1": ZERO_OR_ONE, "0.1": ZERO_OR_ONE,
    "zero or one": ZERO_OR_ONE, "zeroorone": ZERO_OR_ONE,

    "1,n": ONE_TO_MANY, "1..*": ONE_TO_MANY, "1,*": ONE_TO_MANY, "1..n": ONE_TO_MANY,
    "one or more": ONE_TO_MANY, "oneormore": ONE_TO_MANY,

    "0,n": ZERO_TO_MANY, "0..*": ZERO_TO_MANY, "0,*": ZERO_TO_MANY, "0..n": ZERO_TO_MANY,
    "*": ZERO_TO_MANY, "many": ZERO_TO_MANY,
    "zero or more": ZERO_TO_MANY, "zeroormore": ZERO_TO_MANY,
    "zero, one or more": ZERO_TO_MANY, "zeroonemore": ZERO_TO_MANY,
}

_UNBOUNDED_WORDS = {"more", "many", "n", "m"}
_OPTIONAL_WORDS = {"zero", "optional", "most"}
_CARDINALITY_WORDS = _UNBOUNDED_WORDS | _OPTIONAL_WORDS | {"one", "exactly", "mandatory", "or"}


def _compact(token: str) -> str:
    compact = re.sub(r"[\s()\[\]]", "", token)
    return compact.replace("..", ",")


def _phrase_label(token: str) -> str:
    words = set(re.findall(r"[a-z]+", token))
    if not words & _CARDINALITY_WORDS:
        return UNKNOWN
    unbounded = bool(words & _UNBOUNDED_WORDS) or "*" in token
    optional = bool(words & _OPTIONAL_WORDS)
    if optional:
        return ZERO_TO_MANY if unbounded else ZERO_OR_ONE
    return ONE_TO_MANY if unbounded else ONE_TO_ONE


def _numeric_label(compact: str) -> str:
    parts = compact.split(",")
    if len(parts) != 2 or not re.search(r"[\d*]", compact):
        return UNKNOWN
    low, high = parts
    low_one = low in ("1", "one")
    high_many = high in ("n", "m", "*", "many", "more")
    if low_one:
        return ONE_TO_MANY if high_many else ONE_TO_ONE
    return ZERO_TO_MANY if high_many else ZERO_OR_ONE


def normalize(raw: str) -> str:
    """Fold any supported cardinality spelling onto one of the four canonical labels."""
    token = (raw or "").strip().lower()
    if not token:
        return UNKNOWN
    if token in _ALIASES:
        return _ALIASES[token]

    compact = _compact(token)
    if compact in _ALIASES:
        return _ALIASES[compact]

    phrase = _phrase_label(token)
    if phrase:
        return phrase

    return _numeric_label(compact)


@dataclass
class CardinalityComparison:
    source_cardinality: str
    target_cardinality: str
    normalized_source: str
    normalized_target: str
    semantic_match: bool


def compare(source_raw: str, target_raw: str) -> CardinalityComparison:
    """Build the Source/Target/Normalized/Semantic Match report row for one end."""
    normalized_source = normalize(source_raw)
    normalized_target = normalize(target_raw)
    semantic_match = bool(normalized_source) and normalized_source == normalized_target
    return CardinalityComparison(
        source_cardinality=source_raw or "", target_cardinality=target_raw or "",
        normalized_source=normalized_source, normalized_target=normalized_target,
        semantic_match=semantic_match,
    )
