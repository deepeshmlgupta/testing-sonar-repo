"""
Extended property checks — the properties the core CDM / LDM / PDM engines
do not compare, read straight from the two XML files.

The core engines parse both models into their own object graphs and compare
the structural properties (names, types, keys, relationships, inheritance,
definitions). The client's object × property inventory asks for more:
attribute defaults, domain bindings, domain check parameters, identifier
names and member order, referential-integrity rules, package contents and
hierarchy, diagrams, table owners and tablespaces, identity columns, check
constraints, trigger events, sequence parameters, DBMS target, and the
"catalogue" objects the PDM engine never parsed (domains, business rules,
defaults, data formats).

Rather than growing four parsers and three comparators in lock-step, this
module re-reads BOTH files with a small generic indexer and runs one function
per property. It is deliberately additive:

  * every finding is INFO — it appears in the FINDINGS sheet and nudges the
    score by the INFO weight, never by itself fails a model;
  * a check runs only when the erwin export carries the vocabulary at all
    (`_carries`) — an export that never writes <Owner> cannot lose an owner,
    so thin exports are not flooded; when PD has the objects and erwin has
    none of the element type, ONE model-level "not carried" finding is
    emitted instead of one per object;
  * each check is switchable through config.EXTENDED_PROPERTY_CHECKS and the
    whole module through config.CHECK_EXTENDED_PROPERTIES;
  * nothing here can break a run: `apply()` catches and logs, then returns.

erwin tag names used by the PDM checks that were NOT observed in the real
sample export (which is an LDM) are listed in `UNVERIFIED_ERWIN_TAGS` so the
report can say so.
"""

from __future__ import annotations

import logging
import re
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Callable, Dict, Iterable, List, Optional, Sequence, Set, Tuple

from defusedxml import ElementTree as ET

from app.common import xml_helpers

logger = logging.getLogger(__name__)

# Tag names this module reads on the erwin side that the real vessel export
# did not contain. Their spelling follows erwin's XML property naming; a
# mismatch simply means the check never fires (the `_carries` guard).
#: Severity for a check that could not run because the erwin element name it
#: needs was not present. It is NOT a defect in the migration and never scores;
#: it is an admission that the framework did not look, which a production
#: report has to state rather than leave to be inferred from a clean sheet.
SEVERITY_EXTERNAL_VERIFICATION = "EXTERNAL_VERIFICATION_REQUIRED"

#: Which checks each unverified tag gates, so the report can say what did not
#: run rather than only which word was missing.
UNVERIFIED_TAG_CHECKS = {
    "Default_Value": "attribute / column / domain default values",
    "Domain_Name": "domain bindings", "Domain_Ref": "domain bindings",
    "Domain": "domain objects",
    "Key_Group_Member_Order": "identifier and key member ORDER",
    "Key_Group_Sort_Order": "index sort order",
    "Owner": "table owners", "Tablespace_Ref": "table tablespaces",
    "Identity": "identity / auto-increment columns",
    "Valid_Value_Rule_Ref": "column check constraints",
    "Min_Value": "domain check parameters", "Max_Value": "domain check parameters",
    "Start_Value": "sequence parameters", "Increment_Value": "sequence parameters",
    "Rule_Type": "business rule types", "Expression": "business rule expressions",
    "Stored_Display": "diagrams", "Subject_Area": "subject areas / packages",
    "Parent_Subject_Area": "package hierarchy", "Entity_Ref": "package contents",
    "Trigger_Fire_On_Insert": "trigger events", "Trigger_Fire_On_Update": "trigger events",
    "Trigger_Fire_On_Delete": "trigger events",
    "View_Attribute": "view columns", "Default": "default objects",
    "Validation_Rule": "validation rules", "Target_Server": "the database target",
}

UNVERIFIED_ERWIN_TAGS = (
    "Default_Value", "Domain_Name", "Domain_Ref", "Key_Group_Member_Order", "Key_Group_Sort_Order",
    "Owner", "Tablespace_Ref", "Identity", "Valid_Value_Rule_Ref", "Min_Value", "Max_Value",
    "Start_Value", "Increment_Value", "Rule_Type", "Expression", "Stored_Display", "Subject_Area",
    "Parent_Subject_Area", "Entity_Ref", "Trigger_Fire_On_Insert", "Trigger_Fire_On_Update",
    "Trigger_Fire_On_Delete", "View_Attribute", "Default", "Validation_Rule", "Target_Server",
)

_PD_NS = {"a": "attribute", "c": "collection", "o": "object"}


# ─── GENERIC INDEXES ─────────────────────────────────────────────────────────

_local = xml_helpers.local_name          # shared, memoised: app/common/xml_helpers
_ns = xml_helpers.namespace


def _norm(value: Optional[str]) -> str:
    """Whitespace-collapsed, quote-stripped, upper-cased comparison form."""
    text = re.sub(r"\s+", " ", (value or "").strip())
    if len(text) >= 2 and text[0] == text[-1] and text[0] in "'\"":
        text = text[1:-1]
    return text.upper()


def _key(value: Optional[str]) -> str:
    return _norm(value)


@dataclass
class PdObject:
    id: str
    tag: str
    attrs: Dict[str, str] = field(default_factory=dict)
    colls: Dict[str, List[str]] = field(default_factory=dict)
    parent: Optional[str] = None
    coll_in_parent: str = ""

    @property
    def name(self) -> str:
        return self.attrs.get("Name", "")

    @property
    def code(self) -> str:
        return self.attrs.get("Code", "") or self.name

    def refs(self, coll: str) -> List[str]:
        return self.colls.get(coll, [])


class PdDoc:
    """Every `o:*` object in a PowerDesigner XML, indexed by Id."""

    def __init__(self, path: str):
        self.objects: Dict[str, PdObject] = {}
        self.by_tag: Dict[str, List[str]] = defaultdict(list)
        root = ET.parse(path).getroot()
        self.model: Optional[PdObject] = None
        self._walk(root, None, "")
        models = self.by_tag.get("Model", [])
        if models:
            self.model = self.objects[models[0]]

    def _walk(self, elem, parent: Optional[str], coll: str) -> None:
        for child in elem:
            ns, local = _ns(child.tag), _local(child.tag)
            if ns == "object" and child.get("Id"):
                obj = PdObject(child.get("Id"), local, parent=parent, coll_in_parent=coll)
                self.objects[obj.id] = obj
                self.by_tag[local].append(obj.id)
                for prop in child:
                    pns, plocal = _ns(prop.tag), _local(prop.tag)
                    if pns == "attribute":
                        obj.attrs[plocal] = (prop.text or "").strip()
                    elif pns == "collection":
                        obj.colls[plocal] = [c.get("Id") or c.get("Ref") for c in prop
                                             if _ns(c.tag) == "object" and (c.get("Id") or c.get("Ref"))]
                        self._walk(prop, obj.id, plocal)
            else:
                self._walk(child, parent, coll)

    def get(self, oid: Optional[str]) -> Optional[PdObject]:
        return self.objects.get(oid or "")

    def all(self, *tags: str) -> List[PdObject]:
        return [self.objects[i] for t in tags for i in self.by_tag.get(t, [])]

    def first_ref(self, obj: PdObject, coll: str) -> Optional[PdObject]:
        refs = obj.refs(coll)
        return self.get(refs[0]) if refs else None

    def owner_of(self, obj: PdObject, tag: str) -> Optional[PdObject]:
        cur = self.get(obj.parent)
        while cur is not None and cur.tag != tag:
            cur = self.get(cur.parent)
        return cur


@dataclass
class ErObject:
    id: str
    tag: str
    name: str
    props: Dict[str, str] = field(default_factory=dict)
    multi: Dict[str, List[str]] = field(default_factory=dict)
    children: List[str] = field(default_factory=list)
    parent: Optional[str] = None
    ref_descendants: List[str] = field(default_factory=list)

    @property
    def physical(self) -> str:
        return self.props.get("Physical_Name", "") or self.props.get("Name", "") or self.name

    @property
    def logical(self) -> str:
        return self.props.get("Name", "") or self.name


class ErDoc:
    """Every element with an `id` attribute in an erwin XML export."""

    def __init__(self, path: str):
        self.objects: Dict[str, ErObject] = {}
        self.by_tag: Dict[str, List[str]] = defaultdict(list)
        self.tags: Set[str] = set()
        #: Every tag any check asked about, and those it did not find.
        #: Used to turn a silent non-firing check into a visible one.
        self.asked: Set[str] = set()
        self.missing: Set[str] = set()
        self.model_props: Dict[str, str] = {}
        root = ET.parse(path).getroot()
        for el in root.iter():
            self.tags.add(_local(el.tag))
        for el in root.iter():
            if _local(el.tag) == "Model" and el.get("id"):
                for props in el:
                    if _local(props.tag).endswith("Props"):
                        for p in props:
                            self.model_props.setdefault(_local(p.tag), (p.text or "").strip())
                self.model_name = el.get("name", "")
                self._walk(el, None)
                break

    def _walk(self, elem, parent: Optional[str]) -> None:
        for child in elem:
            self._visit(child, parent)

    def _visit(self, child, parent: Optional[str]) -> None:
        local = _local(child.tag)
        if not child.get("id") or local == "Model":
            self._walk(child, parent)
            return
        obj = ErObject(child.get("id"), local, child.get("name", ""), parent=parent)
        self.objects[obj.id] = obj
        self.by_tag[local].append(obj.id)
        if parent and parent in self.objects:
            self.objects[parent].children.append(obj.id)
        for sub in child:
            if _local(sub.tag) == local + "Props":
                for p in sub:
                    plocal = _local(p.tag)
                    text = (p.text or "").strip()
                    obj.props.setdefault(plocal, text)
                    obj.multi.setdefault(plocal, []).append(text)
                    if plocal.endswith("_Ref"):
                        obj.ref_descendants.append(text)
                self._walk(sub, obj.id)          # objects nested inside a Props block
            else:
                self._visit(sub, obj.id)         # child objects (Attribute, Key_Group, View_Attribute ...)

    def carries(self, *tags: str) -> bool:
        """
        Does the erwin export use any of these element names?

        Every query is RECORDED. The guard exists so a thin export is not
        flooded with findings it cannot answer — an export that never writes
        <Owner> cannot have lost an owner. But the same guard makes a
        MISSPELLED tag indistinguishable from an absent one: the check simply
        never fires, silently, and the report looks clean because nothing was
        checked. For the tags in UNVERIFIED_ERWIN_TAGS — spellings never
        confirmed against a real erwin export — that is a production hazard,
        so the misses are collected here and reported by
        `unverified_tag_findings()` at EXTERNAL_VERIFICATION_REQUIRED.
        """
        found = False
        for tag in tags:
            self.asked.add(tag)
            if tag in self.tags:
                found = True
        if not found:
            self.missing.update(tags)
        return found

    def get(self, oid: Optional[str]) -> Optional[ErObject]:
        return self.objects.get(oid or "")

    def all(self, *tags: str) -> List[ErObject]:
        return [self.objects[i] for t in tags for i in self.by_tag.get(t, [])]

    def children_of(self, obj: ErObject, tag: str) -> List[ErObject]:
        return [self.objects[c] for c in obj.children if self.objects[c].tag == tag]

    def owner_of(self, obj: ErObject, tag: str) -> Optional[ErObject]:
        cur = self.get(obj.parent)
        while cur is not None and cur.tag != tag:
            cur = self.get(cur.parent)
        return cur

    def refs_under(self, obj: ErObject) -> List[str]:
        """Every *_Ref value on `obj` and on all objects nested under it."""
        out = list(obj.ref_descendants)
        for child in obj.children:
            out.extend(self.refs_under(self.objects[child]))
        return out

    def by_name(self, tag: str) -> Dict[str, ErObject]:
        """Objects of `tag` keyed by BOTH logical and physical name."""
        out: Dict[str, ErObject] = {}
        for obj in self.all(tag):
            for k in (obj.logical, obj.physical, obj.name):
                if k:
                    out.setdefault(_key(k), obj)
        return out


# ─── FINDINGS ────────────────────────────────────────────────────────────────

@dataclass
class ExtFinding:
    category: str
    object_type: str
    object_name: str
    message: str
    member: str = ""
    pd_value: str = ""
    erwin_value: str = ""
    severity: str = "INFO"
    remediation: str = "Set the property on the erwin object; re-export XML V3."


class Ctx:
    def __init__(self, pd: PdDoc, er: ErDoc, config, model_type: str):
        self.pd, self.er, self.config, self.model_type = pd, er, config, model_type
        self.findings: List[ExtFinding] = []
        self._er_entities = er.by_name("Entity")

    def enabled(self, check: str) -> bool:
        toggles = getattr(self.config, "EXTENDED_PROPERTY_CHECKS", {}) or {}
        return bool(toggles.get(check, True))

    def add(self, category: str, object_type: str, object_name: str, message: str, **kw) -> None:
        self.findings.append(ExtFinding(category, object_type, object_name, message, **kw))

    def not_carried(self, category: str, object_type: str, what: str, count: int) -> None:
        self.add(f"{category}_NOT_CARRIED", object_type, "(model)",
                 f"SAP PD defines {count} {what}; the erwin export carries none of the "
                 f"corresponding elements, so they cannot be compared object by object.",
                 pd_value=str(count), erwin_value="0",
                 remediation=f"Create the {what} in erwin (or confirm they are intentionally dropped).")

    # entity / table matching -------------------------------------------------
    def er_entity(self, pd_entity: PdObject) -> Optional[ErObject]:
        return self._er_entities.get(_key(pd_entity.code)) or self._er_entities.get(_key(pd_entity.name))

    def er_attribute(self, er_entity: ErObject, pd_attr: PdObject) -> Optional[ErObject]:
        for a in self.er.children_of(er_entity, "Attribute"):
            if _key(a.physical) == _key(pd_attr.code) or _key(a.logical) == _key(pd_attr.name):
                return a
        return None

    def er_entity_name(self, oid: str) -> str:
        obj = self.er.get(oid)
        return obj.physical if obj else ""


# ─── SHARED HELPERS ──────────────────────────────────────────────────────────

def _first(props: Dict[str, str], *names: str) -> str:
    for n in names:
        if props.get(n):
            return props[n]
    return ""


def _pd_entity_like(pd: PdDoc, model_type: str) -> List[PdObject]:
    return pd.all("Table") if model_type == "pdm" else pd.all("Entity")


def _pd_attr_like(pd: PdDoc, entity: PdObject) -> List[PdObject]:
    return [o for o in (pd.get(i) for i in entity.refs("Attributes") + entity.refs("Columns")) if o is not None]


def _domain_name_of(pd: PdDoc, obj: PdObject) -> str:
    dom = pd.first_ref(obj, "Domain")
    return dom.name if dom else ""


def _domain_code_of(pd: PdDoc, obj: PdObject) -> str:
    dom = pd.first_ref(obj, "Domain")
    return dom.code if dom else ""


def _er_domain_name(ctx: Ctx, attr: ErObject) -> str:
    name = attr.props.get("Domain_Name", "")
    if not name and attr.props.get("Domain_Ref"):
        dom = ctx.er.get(attr.props["Domain_Ref"])
        name = dom.logical if dom else ""
    return name


def _pd_label(entity: PdObject, member: Optional[PdObject] = None) -> str:
    return entity.name if member is None else f"{entity.name}.{member.name}"


_TRUE = {"1", "TRUE", "YES", "Y", "T"}


def _bool(value: str) -> Optional[bool]:
    v = _norm(value)
    if not v:
        return None
    return v in _TRUE


# ─── CHECKS: ATTRIBUTES / COLUMNS (CDM, LDM, PDM) ────────────────────────────

def check_attribute_default(ctx: Ctx) -> None:
    """PD DefaultValue on an attribute/column vs erwin Default_Value (CDM/LDM; PDM core already scores DEFAULT)."""
    if ctx.model_type == "pdm" or not ctx.enabled("ATTRIBUTE_DEFAULT"):
        return
    pd_with = [(e, a) for e in _pd_entity_like(ctx.pd, ctx.model_type) for a in _pd_attr_like(ctx.pd, e)
               if a.attrs.get("DefaultValue")]
    if not pd_with:
        return
    if not ctx.er.carries("Default_Value"):
        ctx.not_carried("ATTRIBUTE_DEFAULT", "ATTRIBUTE", "attribute default values", len(pd_with))
        return
    for entity, attr in pd_with:
        er_e = ctx.er_entity(entity)
        er_a = ctx.er_attribute(er_e, attr) if er_e else None
        if er_a is None:
            continue
        pd_v, er_v = attr.attrs["DefaultValue"], er_a.props.get("Default_Value", "")
        if _norm(pd_v) != _norm(er_v):
            ctx.add("ATTRIBUTE_DEFAULT", "ATTRIBUTE", _pd_label(entity, attr),
                    "Default value differs" if er_v else "Default value not carried to erwin",
                    member=attr.name, pd_value=pd_v, erwin_value=er_v or "(none)")


def check_attribute_domain(ctx: Ctx) -> None:
    """PD attribute/column → Domain reference vs erwin Domain_Name / Domain_Ref."""
    check = "COLUMN_DOMAIN" if ctx.model_type == "pdm" else "ATTRIBUTE_DOMAIN"
    if not ctx.enabled(check):
        return
    otype = "COLUMN" if ctx.model_type == "pdm" else "ATTRIBUTE"
    bound = [(e, a) for e in _pd_entity_like(ctx.pd, ctx.model_type) for a in _pd_attr_like(ctx.pd, e)
             if a.refs("Domain")]
    if not bound:
        return
    if not ctx.er.carries("Domain_Name", "Domain_Ref"):
        ctx.not_carried(check, otype, "domain bindings", len(bound))
        return
    for entity, attr in bound:
        er_e = ctx.er_entity(entity)
        er_a = ctx.er_attribute(er_e, attr) if er_e else None
        if er_a is None:
            continue
        pd_dom, pd_code = _domain_name_of(ctx.pd, attr), _domain_code_of(ctx.pd, attr)
        er_dom = _er_domain_name(ctx, er_a)
        if _key(er_dom) not in {_key(pd_dom), _key(pd_code)}:
            ctx.add(check, otype, _pd_label(entity, attr),
                    "Domain binding differs" if er_dom else "Domain binding not carried to erwin",
                    member=attr.name, pd_value=pd_dom, erwin_value=er_dom or "(unbound)")


def check_column_identity(ctx: Ctx) -> None:
    if ctx.model_type != "pdm" or not ctx.enabled("COLUMN_IDENTITY"):
        return
    ident = [(t, c) for t in ctx.pd.all("Table") for c in _pd_attr_like(ctx.pd, t) if _bool(c.attrs.get("Identity", ""))]
    if not ident:
        return
    if not ctx.er.carries("Identity"):
        ctx.not_carried("COLUMN_IDENTITY", "COLUMN", "identity columns", len(ident))
        return
    for table, col in ident:
        er_t = ctx.er_entity(table)
        er_c = ctx.er_attribute(er_t, col) if er_t else None
        if er_c is not None and not _bool(er_c.props.get("Identity", "")):
            ctx.add("COLUMN_IDENTITY", "COLUMN", _pd_label(table, col), "Identity flag lost",
                    member=col.name, pd_value="identity", erwin_value=er_c.props.get("Identity", "") or "(not identity)")


_PD_CHECK_TAGS = ("LowValue", "HighValue", "ListOfValues", "Format", "ConstraintName", "ClientExpression", "ServerExpression")
_ER_CHECK_TAGS = ("Valid_Value_Rule_Ref", "Min_Value", "Max_Value", "Minimum_Value", "Maximum_Value",
                  "Valid_Value_Ref", "Validation_Rule_Ref", "Check_Constraint")


def _has_check(attrs: Dict[str, str]) -> bool:
    return any(attrs.get(t) for t in _PD_CHECK_TAGS)


def _er_has_check(props: Dict[str, str]) -> bool:
    return any(props.get(t) for t in _ER_CHECK_TAGS)


def check_column_check_constraint(ctx: Ctx) -> None:
    if ctx.model_type != "pdm" or not ctx.enabled("COLUMN_CHECK_CONSTRAINT"):
        return
    with_check = [(t, c) for t in ctx.pd.all("Table") for c in _pd_attr_like(ctx.pd, t) if _has_check(c.attrs)]
    if not with_check:
        return
    if not ctx.er.carries(*_ER_CHECK_TAGS):
        ctx.not_carried("COLUMN_CHECK_CONSTRAINT", "COLUMN", "column check constraints", len(with_check))
        return
    for table, col in with_check:
        er_t = ctx.er_entity(table)
        er_c = ctx.er_attribute(er_t, col) if er_t else None
        if er_c is not None and not _er_has_check(er_c.props):
            params = "; ".join(f"{t}={col.attrs[t]}" for t in _PD_CHECK_TAGS if col.attrs.get(t))
            ctx.add("COLUMN_CHECK_CONSTRAINT", "COLUMN", _pd_label(table, col),
                    "Check constraint / validation parameters not carried to erwin",
                    member=col.name, pd_value=params, erwin_value="(none)")


def check_logical_names(ctx: Ctx) -> None:
    """PDM: PD Table/Column Name (logical) vs erwin Name, matched on Code ↔ Physical_Name."""
    if ctx.model_type != "pdm":
        return
    for check, otype, per_column in (("TABLE_LOGICAL_NAME", "TABLE", False), ("COLUMN_LOGICAL_NAME", "COLUMN", True)):
        if not ctx.enabled(check):
            continue
        pairs: List[Tuple[str, str, str, str]] = []      # label, member, pd_name, erwin_name
        pd_distinct = er_distinct = False                 # does either side carry a Name that is not just the code?
        for table in ctx.pd.all("Table"):
            er_t = ctx.er_entity(table)
            if er_t is None:
                continue
            items = [(col, ctx.er_attribute(er_t, col)) for col in _pd_attr_like(ctx.pd, table)] if per_column else [(table, er_t)]
            for pd_obj, er_obj in items:
                if er_obj is None:
                    continue
                pd_distinct |= _key(pd_obj.name) != _key(pd_obj.code)
                er_distinct |= _key(er_obj.logical) != _key(er_obj.physical)
                label = _pd_label(table, pd_obj) if per_column else table.name
                pairs.append((label, pd_obj.name if per_column else "", pd_obj.name, er_obj.logical))
        if pd_distinct and not er_distinct:
            ctx.not_carried(check, otype, f"{otype.lower()} logical names distinct from their codes", sum(1 for _ in pairs))
            continue
        for label, member, pd_name, er_name in pairs:
            if pd_name and er_name and _key(pd_name) != _key(er_name):
                ctx.add(check, otype, label, "Logical name differs", member=member, pd_value=pd_name, erwin_value=er_name)


def _pd_owner(pd: PdDoc, table: PdObject) -> str:
    if table.attrs.get("Owner"):
        return table.attrs["Owner"]
    user = pd.first_ref(table, "Owner")
    return (user.code or user.name) if user else ""


def check_table_owner(ctx: Ctx) -> None:
    if ctx.model_type != "pdm" or not ctx.enabled("TABLE_OWNER"):
        return
    owned = [(t, _pd_owner(ctx.pd, t)) for t in ctx.pd.all("Table")]
    owned = [(t, o) for t, o in owned if o]
    if not owned:
        return
    if not ctx.er.carries("Owner"):
        ctx.not_carried("TABLE_OWNER", "TABLE", "table owners / schemas", len(owned))
        return
    for table, owner in owned:
        er_t = ctx.er_entity(table)
        if er_t is None:
            continue
        er_owner = er_t.props.get("Owner", "")
        if _key(owner) != _key(er_owner):
            ctx.add("TABLE_OWNER", "TABLE", table.name, "Owner / schema differs", pd_value=owner, erwin_value=er_owner or "(none)")


def check_table_tablespace(ctx: Ctx) -> None:
    if ctx.model_type != "pdm" or not ctx.enabled("TABLE_TABLESPACE"):
        return
    assigned = [(t, ctx.pd.first_ref(t, "Tablespace")) for t in ctx.pd.all("Table")]
    assigned = [(t, ts) for t, ts in assigned if ts is not None]
    if not assigned:
        return
    if not ctx.er.carries("Tablespace_Ref"):
        ctx.not_carried("TABLE_TABLESPACE", "TABLE", "table → tablespace assignments", len(assigned))
        return
    for table, ts in assigned:
        er_t = ctx.er_entity(table)
        if er_t is None:
            continue
        er_ts = ctx.er.get(er_t.props.get("Tablespace_Ref"))
        er_name = er_ts.physical if er_ts else ""
        if _key(er_name) not in {_key(ts.code), _key(ts.name)}:
            ctx.add("TABLE_TABLESPACE", "TABLE", table.name, "Tablespace assignment differs",
                    pd_value=ts.code, erwin_value=er_name or "(none)")


# ─── CHECKS: KEYS / IDENTIFIERS / INDEXES ────────────────────────────────────

def _pd_key_members(pd: PdDoc, key: PdObject) -> List[str]:
    coll = "Identifier.Attributes" if key.tag == "Identifier" else "Key.Columns"
    return [pd.get(i).code for i in key.refs(coll) if pd.get(i) is not None]


def _er_key_members(er: ErDoc, kg: ErObject, ordered: bool = True) -> List[str]:
    members = []
    for i, m in enumerate(er.children_of(kg, "Key_Group_Member")):
        attr = er.get(m.props.get("Attribute_Ref"))
        order = m.props.get("Key_Group_Member_Order")
        members.append((int(order) if (order or "").isdigit() else i, attr.physical if attr else ""))
    if ordered:
        members.sort(key=lambda t: t[0])
    return [name for _, name in members]


def _er_key_groups(ctx: Ctx, er_entity: ErObject) -> List[ErObject]:
    return ctx.er.children_of(er_entity, "Key_Group")


def _names_match(pd_obj: PdObject, er_obj: ErObject) -> bool:
    return _key(pd_obj.name) == _key(er_obj.logical) or _key(pd_obj.code) == _key(er_obj.physical) \
        or _key(pd_obj.code) == _key(er_obj.logical) or _key(pd_obj.name) == _key(er_obj.physical)


def check_identifier_names_and_order(ctx: Ctx) -> None:
    pdm = ctx.model_type == "pdm"
    name_check = "KEY_NAME" if pdm else "IDENTIFIER_NAME"
    order_check = None if pdm else "IDENTIFIER_MEMBER_ORDER"
    if not (ctx.enabled(name_check) or (order_check and ctx.enabled(order_check))):
        return
    otype = "KEY" if pdm else "IDENTIFIER"
    for entity in _pd_entity_like(ctx.pd, ctx.model_type):
        er_e = ctx.er_entity(entity)
        if er_e is None:
            continue
        pd_keys = [o for o in (ctx.pd.get(i) for i in entity.refs("Identifiers") + entity.refs("Keys")) if o]
        er_kgs = [k for k in _er_key_groups(ctx, er_e) if k.props.get("Key_Group_Type") in ("PK", "AK")]
        for pd_key in pd_keys:
            pd_members = _pd_key_members(ctx.pd, pd_key)
            match = next((k for k in er_kgs if set(map(_key, _er_key_members(ctx.er, k))) == set(map(_key, pd_members))), None)
            if match is None:
                continue
            if ctx.enabled(name_check) and not _names_match(pd_key, match):
                ctx.add(name_check, otype, _pd_label(entity, pd_key), "Key / identifier name differs",
                        member=pd_key.code, pd_value=f"{pd_key.name} / {pd_key.code}",
                        erwin_value=f"{match.logical} / {match.physical}")
            if order_check and ctx.enabled(order_check) and len(pd_members) > 1 and ctx.er.carries("Key_Group_Member_Order"):
                er_members = _er_key_members(ctx.er, match)
                if list(map(_key, er_members)) != list(map(_key, pd_members)):
                    ctx.add(order_check, otype, _pd_label(entity, pd_key), "Identifier member order differs",
                            member=pd_key.code, pd_value=", ".join(pd_members), erwin_value=", ".join(er_members))


def check_indexes(ctx: Ctx) -> None:
    if ctx.model_type != "pdm" or not (ctx.enabled("INDEX_NAME") or ctx.enabled("INDEX_SORT_ORDER")):
        return
    for table in ctx.pd.all("Table"):
        er_t = ctx.er_entity(table)
        if er_t is None:
            continue
        er_kgs = [k for k in _er_key_groups(ctx, er_t) if k.props.get("Key_Group_Type") in ("IE", "AK", "IF")]
        for idx in (ctx.pd.get(i) for i in table.refs("Indexes")):
            if idx is None:
                continue
            cols: List[Tuple[str, bool]] = []
            for ic in (ctx.pd.get(i) for i in idx.refs("IndexColumns")):
                if ic is None:
                    continue
                col = ctx.pd.first_ref(ic, "Column")
                asc = _bool(ic.attrs.get("Ascending", "1"))
                cols.append((col.code if col else "", asc is not False))
            member_set = {_key(c) for c, _ in cols}
            match = next((k for k in er_kgs if set(map(_key, _er_key_members(ctx.er, k))) == member_set), None)
            if match is None:
                continue
            if ctx.enabled("INDEX_NAME") and not _names_match(idx, match):
                ctx.add("INDEX_NAME", "INDEX", _pd_label(table, idx), "Index name differs", member=idx.code,
                        pd_value=f"{idx.name} / {idx.code}", erwin_value=f"{match.logical} / {match.physical}")
            if ctx.enabled("INDEX_SORT_ORDER") and ctx.er.carries("Key_Group_Sort_Order"):
                er_sort = {}
                for m in ctx.er.children_of(match, "Key_Group_Member"):
                    attr = ctx.er.get(m.props.get("Attribute_Ref"))
                    if attr:
                        er_sort[_key(attr.physical)] = not _norm(m.props.get("Key_Group_Sort_Order", "ASC")).startswith("DESC")
                for code, asc in cols:
                    if _key(code) in er_sort and er_sort[_key(code)] != asc:
                        ctx.add("INDEX_SORT_ORDER", "INDEX", _pd_label(table, idx), "Index column sort order differs",
                                member=code, pd_value="ASC" if asc else "DESC", erwin_value="ASC" if er_sort[_key(code)] else "DESC")


# ─── CHECKS: RELATIONSHIPS / REFERENCES ──────────────────────────────────────

def _pd_relationships(pd: PdDoc) -> List[PdObject]:
    return pd.all("Relationship", "Reference")


def _pd_rel_ends(pd: PdDoc, rel: PdObject) -> Tuple[Optional[PdObject], Optional[PdObject]]:
    if rel.tag == "Reference":
        return pd.first_ref(rel, "ParentTable"), pd.first_ref(rel, "ChildTable")
    return pd.first_ref(rel, "Object1"), pd.first_ref(rel, "Object2")


def _er_relationships(ctx: Ctx) -> List[ErObject]:
    return ctx.er.all("Relationship")


def _match_relationship(ctx: Ctx, rel: PdObject, er_rels: Sequence[ErObject]) -> Optional[ErObject]:
    by_name = [r for r in er_rels if _names_match(rel, r)]
    if len(by_name) == 1:
        return by_name[0]
    e1, e2 = _pd_rel_ends(ctx.pd, rel)
    ends = {_key(e.code) for e in (e1, e2) if e} | {_key(e.name) for e in (e1, e2) if e}
    by_ends = [r for r in er_rels
               if {_key(ctx.er_entity_name(r.props.get("Parent_Entity_Ref", ""))),
                   _key(ctx.er_entity_name(r.props.get("Child_Entity_Ref", "")))} <= ends]
    if by_name:
        both = [r for r in by_name if r in by_ends]
        return both[0] if both else by_name[0]
    return by_ends[0] if len(by_ends) == 1 else None


def _er_rel_kind(rel: ErObject) -> str:
    rtype, nullopt = rel.props.get("Type", ""), rel.props.get("Null_Option_Type", "")
    if rtype == "9":
        return "Subtype"
    if rtype == "2":
        return "Identifying"
    return "Nonidentifying_Not_Null" if nullopt == "101" else "Nonidentifying"


def _er_ri_rule(ctx: Ctx, rel: ErObject, action: str) -> Tuple[str, str]:
    """(code, origin) — the relationship's own Parent_<Action>_Rule, else the model default for its kind."""
    tag = f"Parent_{action}_Rule"
    if rel.props.get(tag):
        return rel.props[tag], "relationship"
    default = ctx.er.model_props.get(f"{tag}_{_er_rel_kind(rel)}", "")
    return default, "model default"


def check_relationship_ri_rules(ctx: Ctx) -> None:
    if not ctx.enabled("RELATIONSHIP_RI_RULE"):
        return
    pd_codes = getattr(ctx.config, "PD_RI_RULE_CODES", {}) or {}
    er_codes = getattr(ctx.config, "ERWIN_RI_RULE_CODES", {}) or {}
    otype = "REFERENCE" if ctx.model_type == "pdm" else "RELATIONSHIP"
    category = "REFERENCE_RI_RULE" if ctx.model_type == "pdm" else "RELATIONSHIP_RI_RULE"
    rels = [(r, r.attrs.get("UpdateConstraint", ""), r.attrs.get("DeleteConstraint", "")) for r in _pd_relationships(ctx.pd)]
    rels = [(r, u, d) for r, u, d in rels if u or d]
    if not rels:
        return
    if not any(t.startswith(("Parent_Update_Rule", "Parent_Delete_Rule")) for t in ctx.er.tags):
        ctx.not_carried(category, otype, "referential-integrity rules", len(rels))
        return
    er_rels = _er_relationships(ctx)
    for rel, upd, dele in rels:
        er_rel = _match_relationship(ctx, rel, er_rels)
        if er_rel is None:
            continue
        for action, pd_code in (("Update", upd), ("Delete", dele)):
            if not pd_code:
                continue
            er_code, origin = _er_ri_rule(ctx, er_rel, action)
            pd_action = pd_codes.get(str(pd_code))
            er_action = (er_codes.get(action.lower(), {}) or {}).get(str(er_code))
            if not er_code:
                ctx.add(category, otype, rel.name, f"{action} rule not carried to erwin",
                        member=action.lower(), pd_value=f"{pd_code} ({pd_action or 'unmapped'})", erwin_value="(none)")
            elif pd_action is None or er_action is None:
                ctx.add(f"{category}_UNMAPPED", otype, rel.name,
                        f"{action} rule code not in PD_RI_RULE_CODES / ERWIN_RI_RULE_CODES — extend the map to compare",
                        member=action.lower(), pd_value=str(pd_code), erwin_value=f"{er_code} ({origin})",
                        remediation="Add the code to app/config/validation_config.py RI maps.")
            elif pd_action != er_action:
                ctx.add(category, otype, rel.name, f"{action} rule differs",
                        member=action.lower(), pd_value=f"{pd_action} ({pd_code})", erwin_value=f"{er_action} ({er_code}, {origin})")


def check_reference_name_and_cardinality(ctx: Ctx) -> None:
    if ctx.model_type != "pdm" or not (ctx.enabled("REFERENCE_NAME") or ctx.enabled("REFERENCE_CARDINALITY")):
        return
    er_rels = _er_relationships(ctx)
    card_codes = getattr(ctx.config, "ERWIN_CARDINALITY_CODES", {}) or {"-3": "0,n", "-2": "1,n", "-1": "0,1"}
    for ref in ctx.pd.all("Reference"):
        er_rel = _match_relationship(ctx, ref, er_rels)
        if er_rel is None:
            continue
        if ctx.enabled("REFERENCE_NAME") and not _names_match(ref, er_rel):
            ctx.add("REFERENCE_NAME", "REFERENCE", ref.name, "Reference / constraint name differs",
                    pd_value=f"{ref.name} / {ref.code}", erwin_value=f"{er_rel.logical} / {er_rel.physical}")
        pd_card = ref.attrs.get("Cardinality", "")
        if ctx.enabled("REFERENCE_CARDINALITY") and pd_card and er_rel.props.get("Cardinality"):
            er_card = card_codes.get(er_rel.props["Cardinality"], er_rel.props["Cardinality"])
            if _card(pd_card) != _card(er_card):
                ctx.add("REFERENCE_CARDINALITY", "REFERENCE", ref.name, "Child cardinality differs",
                        pd_value=pd_card, erwin_value=f"{er_card} ({er_rel.props['Cardinality']})")
        pd_mand = ref.attrs.get("ParentMandatory", "")
        if ctx.enabled("REFERENCE_CARDINALITY") and pd_mand and er_rel.props.get("Null_Option_Type") in ("100", "101"):
            er_mand = er_rel.props["Null_Option_Type"] == "101"
            if _bool(pd_mand) != er_mand:
                ctx.add("REFERENCE_CARDINALITY", "REFERENCE", ref.name, "Parent optionality differs",
                        pd_value="mandatory" if _bool(pd_mand) else "optional", erwin_value="mandatory" if er_mand else "optional")


def _card(text: str) -> Tuple[str, str]:
    t = _norm(text).replace("..", ",").replace("*", "N")
    parts = [p.strip() for p in t.split(",")]
    return (parts[0], parts[-1]) if parts else ("", "")


# ─── CHECKS: DOMAINS / RULES / DEFAULTS / FORMATS (catalogue objects) ────────

def _pd_domains(pd: PdDoc) -> List[PdObject]:
    return pd.all("Domain", "PhysicalDomain")


def check_domains(ctx: Ctx) -> None:
    pdm = ctx.model_type == "pdm"
    domains = _pd_domains(ctx.pd)
    if not domains:
        return
    if pdm:
        if not ctx.enabled("DOMAIN_OBJECT"):
            return
        if not ctx.er.carries("Domain"):
            ctx.not_carried("DOMAIN_OBJECT", "DOMAIN", "domains", len(domains))
            return
    er_domains = ctx.er.by_name("Domain")
    for dom in domains:
        er_dom = er_domains.get(_key(dom.code)) or er_domains.get(_key(dom.name))
        if er_dom is None:
            if pdm:
                ctx.add("DOMAIN_OBJECT", "DOMAIN", dom.name, "Domain missing in erwin", pd_value=dom.code, erwin_value="(missing)")
            continue
        if pdm and ctx.enabled("DOMAIN_OBJECT"):
            pd_type = _norm(dom.attrs.get("DataType", "")).replace(" ", "")
            er_type = _norm(_first(er_dom.props, "Physical_Datatype", "Physical_Data_Type", "Logical_Datatype", "Logical_Data_Type")).replace(" ", "")
            if pd_type and er_type and pd_type != er_type:
                ctx.add("DOMAIN_OBJECT", "DOMAIN", dom.name, "Domain data type differs", pd_value=dom.attrs.get("DataType", ""), erwin_value=er_type)
        if (not pdm) and ctx.enabled("DOMAIN_NAME") and _key(dom.name) != _key(er_dom.logical) and _key(dom.code) == _key(er_dom.physical):
            ctx.add("DOMAIN_NAME", "DOMAIN", dom.name, "Domain name differs (code carried)", pd_value=dom.name, erwin_value=er_dom.logical)
        if (not pdm) and ctx.enabled("DOMAIN_LENGTH") and dom.attrs.get("Length") and er_dom.props.get("Length") \
                and _norm(dom.attrs["Length"]) != _norm(er_dom.props["Length"]):
            ctx.add("DOMAIN_LENGTH", "DOMAIN", dom.name, "Domain length differs", pd_value=dom.attrs["Length"], erwin_value=er_dom.props["Length"])
        default_check = "DOMAIN_OBJECT" if pdm else "DOMAIN_DEFAULT"
        if ctx.enabled(default_check) and dom.attrs.get("DefaultValue") and ctx.er.carries("Default_Value") \
                and _norm(dom.attrs["DefaultValue"]) != _norm(er_dom.props.get("Default_Value", "")):
            ctx.add(default_check if pdm else "DOMAIN_DEFAULT", "DOMAIN", dom.name, "Domain default value differs",
                    pd_value=dom.attrs["DefaultValue"], erwin_value=er_dom.props.get("Default_Value", "") or "(none)")
        if (not pdm) and ctx.enabled("DOMAIN_CHECK_PARAMS") and _has_check(dom.attrs) and ctx.er.carries(*_ER_CHECK_TAGS):
            if not _er_has_check(er_dom.props):
                params = "; ".join(f"{t}={dom.attrs[t]}" for t in _PD_CHECK_TAGS if dom.attrs.get(t))
                ctx.add("DOMAIN_CHECK_PARAMS", "DOMAIN", dom.name, "Domain check parameters not carried to erwin",
                        pd_value=params, erwin_value="(none)")
            else:
                for pd_tag, er_tags in (("LowValue", ("Min_Value", "Minimum_Value")), ("HighValue", ("Max_Value", "Maximum_Value"))):
                    er_v = _first(er_dom.props, *er_tags)
                    if dom.attrs.get(pd_tag) and er_v and _norm(dom.attrs[pd_tag]) != _norm(er_v):
                        ctx.add("DOMAIN_CHECK_PARAMS", "DOMAIN", dom.name, f"Domain {pd_tag} differs", member=pd_tag,
                                pd_value=dom.attrs[pd_tag], erwin_value=er_v)


def check_business_rules(ctx: Ctx) -> None:
    rules = ctx.pd.all("BusinessRule")
    if not rules:
        return
    pdm = ctx.model_type == "pdm"
    check = "BUSINESS_RULE_OBJECT" if pdm else "BUSINESS_RULE_TYPE"
    if not ctx.enabled(check):
        return
    if not ctx.er.carries("Validation_Rule"):
        if pdm:
            ctx.not_carried("BUSINESS_RULE_OBJECT", "BUSINESS_RULE", "business rules", len(rules))
        return
    er_rules = ctx.er.by_name("Validation_Rule")
    for rule in rules:
        er_rule = er_rules.get(_key(rule.code)) or er_rules.get(_key(rule.name))
        if er_rule is None:
            if pdm:
                ctx.add("BUSINESS_RULE_OBJECT", "BUSINESS_RULE", rule.name, "Business rule missing in erwin", pd_value=rule.code, erwin_value="(missing)")
            continue
        if pdm:
            pd_expr = rule.attrs.get("ServerExpression") or rule.attrs.get("ClientExpression") or ""
            er_expr = er_rule.props.get("Expression", "")
            if pd_expr and _norm(pd_expr) != _norm(er_expr):
                ctx.add("BUSINESS_RULE_OBJECT", "BUSINESS_RULE", rule.name, "Business rule expression differs", pd_value=pd_expr, erwin_value=er_expr or "(none)")
        elif rule.attrs.get("RuleType") and ctx.er.carries("Rule_Type"):
            if _norm(rule.attrs["RuleType"]) != _norm(er_rule.props.get("Rule_Type", "")):
                ctx.add("BUSINESS_RULE_TYPE", "BUSINESS_RULE", rule.name, "Business rule type differs",
                        pd_value=rule.attrs["RuleType"], erwin_value=er_rule.props.get("Rule_Type", "") or "(none)")


def check_defaults(ctx: Ctx) -> None:
    if ctx.model_type != "pdm" or not ctx.enabled("DEFAULT_OBJECT"):
        return
    defaults = ctx.pd.all("Default")
    if not defaults:
        return
    if not ctx.er.carries("Default"):
        ctx.not_carried("DEFAULT_OBJECT", "DEFAULT", "default objects", len(defaults))
        return
    er_defaults = ctx.er.by_name("Default")
    for d in defaults:
        er_d = er_defaults.get(_key(d.code)) or er_defaults.get(_key(d.name))
        if er_d is None:
            ctx.add("DEFAULT_OBJECT", "DEFAULT", d.name, "Default object missing in erwin", pd_value=d.code, erwin_value="(missing)")
        elif d.attrs.get("Value") and _norm(d.attrs["Value"]) != _norm(_first(er_d.props, "Default_Value", "Value")):
            ctx.add("DEFAULT_OBJECT", "DEFAULT", d.name, "Default value differs", pd_value=d.attrs["Value"],
                    erwin_value=_first(er_d.props, "Default_Value", "Value") or "(none)")


def check_data_formats(ctx: Ctx) -> None:
    """erwin has no Data Format object: report the PD ones as a census (VERIFIED, unscored)."""
    if ctx.model_type != "pdm" or not ctx.enabled("DATA_FORMAT"):
        return
    formats = ctx.pd.all("DataFormat")
    if not formats:
        return
    users = defaultdict(list)
    for table in ctx.pd.all("Table"):
        for col in _pd_attr_like(ctx.pd, table):
            fmt = ctx.pd.first_ref(col, "DataFormat")
            if fmt is not None:
                users[fmt.id].append(_pd_label(table, col))
    for fmt in formats:
        ctx.add("DATA_FORMAT_NOT_REPRESENTABLE", "DATA_FORMAT", fmt.name,
                "erwin Data Modeler has no Data Format object; the format is not migrated (display-only metadata in PD)",
                pd_value=fmt.attrs.get("Expression", fmt.code), erwin_value="(no equivalent)",
                severity="VERIFIED", member=", ".join(users.get(fmt.id, [])),
                remediation="If the format must survive, record it as a UDP or in the column definition.")


def check_database_target(ctx: Ctx) -> None:
    if ctx.model_type != "pdm" or not ctx.enabled("DATABASE_TARGET"):
        return
    dbms = ctx.pd.model and ctx.pd.first_ref(ctx.pd.model, "DBMS")
    if dbms is None:
        return
    if not ctx.er.carries("Target_Server"):
        return
    target = ctx.er.model_props.get("Target_Server", "")
    version = ctx.er.model_props.get("Target_Server_Version", "")
    pd_name = f"{dbms.name} ({dbms.code})"
    if not target:
        ctx.add("DATABASE_TARGET", "MODEL", "(model)", "Target database not set in erwin", pd_value=pd_name, erwin_value="(empty)")
        return
    tokens = [t for t in re.split(r"[^A-Z0-9]+", _norm(target)) if len(t) > 1]
    if not any(t in _norm(dbms.name) or t in _norm(dbms.code) for t in tokens):
        ctx.add("DATABASE_TARGET", "MODEL", "(model)", "Target database differs", pd_value=pd_name,
                erwin_value=f"{target} {version}".strip())


# ─── CHECKS: PROGRAMMABLE OBJECTS ────────────────────────────────────────────

def check_view_columns(ctx: Ctx) -> None:
    if ctx.model_type != "pdm" or not ctx.enabled("VIEW_COLUMNS"):
        return
    views = [v for v in ctx.pd.all("View") if v.refs("Columns")]
    if not views or not ctx.er.carries("View_Attribute"):
        return
    er_views = ctx.er.by_name("View")
    for view in views:
        er_v = er_views.get(_key(view.code)) or er_views.get(_key(view.name))
        if er_v is None:
            continue
        pd_cols = [ctx.pd.get(i).code for i in view.refs("Columns") if ctx.pd.get(i)]
        er_cols = [a.physical for a in ctx.er.children_of(er_v, "View_Attribute")]
        if set(map(_key, pd_cols)) != set(map(_key, er_cols)):
            ctx.add("VIEW_COLUMNS", "VIEW", view.name, "View column list differs", pd_value=", ".join(pd_cols), erwin_value=", ".join(er_cols) or "(none)")


_EVENT_TAGS = {"INSERT": "Trigger_Fire_On_Insert", "UPDATE": "Trigger_Fire_On_Update", "DELETE": "Trigger_Fire_On_Delete"}


def check_triggers(ctx: Ctx) -> None:
    if ctx.model_type != "pdm" or not (ctx.enabled("TRIGGER_EVENT") or ctx.enabled("TRIGGER_TABLE")):
        return
    triggers = ctx.pd.all("Trigger")
    if not triggers:
        return
    er_triggers = ctx.er.by_name("Trigger")
    for trg in triggers:
        er_t = er_triggers.get(_key(trg.code)) or er_triggers.get(_key(trg.name))
        if er_t is None:
            continue
        table = ctx.pd.owner_of(trg, "Table")
        er_table = ctx.er.owner_of(er_t, "Entity")
        if ctx.enabled("TRIGGER_TABLE") and table is not None and er_table is not None \
                and _key(er_table.physical) not in {_key(table.code), _key(table.name)}:
            ctx.add("TRIGGER_TABLE", "TRIGGER", trg.code, "Trigger attached to a different table", pd_value=table.code, erwin_value=er_table.physical)
        event = _norm(trg.attrs.get("TriggerEvent", "") or trg.attrs.get("Event", ""))
        if ctx.enabled("TRIGGER_EVENT") and event and ctx.er.carries(*_EVENT_TAGS.values()):
            pd_events = {e for e in _EVENT_TAGS if e in event}
            er_events = {e for e, tag in _EVENT_TAGS.items() if _bool(er_t.props.get(tag, ""))}
            if pd_events != er_events:
                ctx.add("TRIGGER_EVENT", "TRIGGER", trg.code, "Trigger event differs",
                        pd_value=", ".join(sorted(pd_events)), erwin_value=", ".join(sorted(er_events)) or "(none)")


_PROGRAMMABLE = (("View", "View", "VIEW"), ("Procedure", "Stored_Procedure", "PROCEDURE"), ("Function", "Function", "PROCEDURE"),
                 ("Trigger", "Trigger", "TRIGGER"), ("Sequence", "Sequence", "SEQUENCE"), ("Tablespace", "Tablespace", "TABLESPACE"))


def check_programmable_definitions(ctx: Ctx) -> None:
    """PDM: PD Comment on views / procedures / functions / triggers / sequences / tablespaces vs erwin Definition."""
    if ctx.model_type != "pdm" or not ctx.enabled("OBJECT_DEFINITION") or not ctx.er.carries("Definition"):
        return
    for pd_tag, er_tag, otype in _PROGRAMMABLE:
        er_objs = ctx.er.by_name(er_tag)
        for obj in ctx.pd.all(pd_tag):
            comment = obj.attrs.get("Comment", "")
            if not comment:
                continue
            er_o = er_objs.get(_key(obj.code)) or er_objs.get(_key(obj.name))
            if er_o is None:
                continue
            er_def = er_o.props.get("Definition", "")
            if _norm(comment) != _norm(er_def):
                ctx.add(f"{otype}_DEFINITION", otype, obj.code,
                        "Definition differs" if er_def else "Comment not carried to erwin Definition",
                        pd_value=comment, erwin_value=er_def or "(none)",
                        remediation="Step 1 (comment injection) covers entities and attributes; set this one in erwin.")


_SEQ_PARAMS = (("StartValue", ("Start_Value", "Start_With")), ("IncrementValue", ("Increment_Value", "Increment_By")),
               ("MinValue", ("Min_Value", "Minimum_Value")), ("MaxValue", ("Max_Value", "Maximum_Value")))


def check_sequences(ctx: Ctx) -> None:
    if ctx.model_type != "pdm" or not ctx.enabled("SEQUENCE_PARAMS"):
        return
    seqs = ctx.pd.all("Sequence")
    if not seqs:
        return
    er_seqs = ctx.er.by_name("Sequence")
    for seq in seqs:
        er_s = er_seqs.get(_key(seq.code)) or er_seqs.get(_key(seq.name))
        if er_s is None:
            continue
        for pd_tag, er_tags in _SEQ_PARAMS:
            pd_v = seq.attrs.get(pd_tag, "")
            if not pd_v or not ctx.er.carries(*er_tags):
                continue
            er_v = _first(er_s.props, *er_tags)
            if _norm(pd_v) != _norm(er_v):
                ctx.add("SEQUENCE_PARAMS", "SEQUENCE", seq.code, f"Sequence {pd_tag} differs", member=pd_tag,
                        pd_value=pd_v, erwin_value=er_v or "(none)")


# ─── CHECKS: INHERITANCE / PACKAGES / DIAGRAMS / MODEL ───────────────────────

def check_inheritance_name(ctx: Ctx) -> None:
    if ctx.model_type == "pdm" or not ctx.enabled("INHERITANCE_NAME"):
        return
    for inh in ctx.pd.all("Inheritance"):
        parent = ctx.pd.first_ref(inh, "ParentEntity")
        if parent is None:
            continue
        er_parent = ctx.er_entity(parent)
        if er_parent is None:
            continue
        cands = [s for s in ctx.er.all("Subtype_Relationship") if s.props.get("Parent_Entity_Ref") == er_parent.id]
        if len(cands) == 1 and not _names_match(inh, cands[0]):
            ctx.add("INHERITANCE_NAME", "INHERITANCE", inh.name, "Inheritance name differs", pd_value=inh.name, erwin_value=cands[0].logical)


def _pd_packages(pd: PdDoc) -> List[PdObject]:
    return pd.all("Package")


def _pd_package_contents(pd: PdDoc, pkg: PdObject) -> List[str]:
    return [pd.get(i).code for i in pkg.refs("Entities") + pkg.refs("Tables") if pd.get(i)]


def check_packages(ctx: Ctx) -> None:
    packages = _pd_packages(ctx.pd)
    if not packages or not ctx.er.carries("Subject_Area"):
        return
    er_areas = ctx.er.by_name("Subject_Area")
    any_parent = ctx.er.carries("Parent_Subject_Area")
    any_contents = any(a.multi.get("Entity_Ref") for a in ctx.er.all("Subject_Area"))
    for pkg in packages:
        er_a = er_areas.get(_key(pkg.code)) or er_areas.get(_key(pkg.name))
        if er_a is None:
            continue
        if ctx.enabled("PACKAGE_DEFINITION") and pkg.attrs.get("Comment") and ctx.er.carries("Definition") \
                and _norm(pkg.attrs["Comment"]) != _norm(er_a.props.get("Definition", "")):
            ctx.add("PACKAGE_DEFINITION", "PACKAGE", pkg.name, "Package definition differs",
                    pd_value=pkg.attrs["Comment"], erwin_value=er_a.props.get("Definition", "") or "(none)")
        parent = ctx.pd.owner_of(pkg, "Package")
        if ctx.enabled("PACKAGE_HIERARCHY") and parent is not None and any_parent and not er_a.props.get("Parent_Subject_Area"):
            ctx.add("PACKAGE_HIERARCHY", "PACKAGE", pkg.name, "Package moved to the root (parent lost)", pd_value=parent.name, erwin_value="(root)")
        if ctx.enabled("PACKAGE_CONTENTS") and any_contents:
            pd_contents = _pd_package_contents(ctx.pd, pkg)
            er_contents = [ctx.er_entity_name(ref) for ref in er_a.multi.get("Entity_Ref", []) if ref]
            if pd_contents and set(map(_key, pd_contents)) != set(map(_key, er_contents)):
                ctx.add("PACKAGE_CONTENTS", "PACKAGE", pkg.name, "Package contents differ",
                        pd_value=", ".join(pd_contents), erwin_value=", ".join(er_contents) or "(none)")


def _pd_diagrams(pd: PdDoc) -> List[PdObject]:
    return pd.all("ConceptualDiagram", "LogicalDiagram", "PhysicalDiagram")


def _pd_symbol_objects(pd: PdDoc, diagram: PdObject) -> List[str]:
    names = []
    for sym in (pd.get(i) for i in diagram.refs("Symbols")):
        if sym is None:
            continue
        obj = pd.first_ref(sym, "Object")
        if obj is not None and obj.tag in ("Entity", "Table"):
            names.append(obj.code)
    return names


def check_diagrams(ctx: Ctx) -> None:
    if not ctx.enabled("DIAGRAM"):
        return
    diagrams = _pd_diagrams(ctx.pd)
    if not diagrams or not ctx.er.carries("Stored_Display"):
        return
    displays = ctx.er.by_name("Stored_Display")
    any_refs = any(ctx.er.refs_under(d) for d in ctx.er.all("Stored_Display"))
    for dg in diagrams:
        er_d = displays.get(_key(dg.name)) or displays.get(_key(dg.code))
        if er_d is None:
            ctx.add("DIAGRAM_MISSING", "DIAGRAM", dg.name, "Diagram has no erwin stored display with this name",
                    pd_value=dg.name, erwin_value=", ".join(sorted({d.logical for d in ctx.er.all('Stored_Display')})) or "(none)")
            continue
        if any_refs:
            pd_objs = _pd_symbol_objects(ctx.pd, dg)
            er_objs = [ctx.er_entity_name(r) for r in ctx.er.refs_under(er_d) if ctx.er.get(r) and ctx.er.get(r).tag == "Entity"]
            if pd_objs and set(map(_key, pd_objs)) != set(map(_key, er_objs)):
                ctx.add("DIAGRAM_SYMBOLS", "DIAGRAM", dg.name, "Objects shown on the diagram differ",
                        pd_value=", ".join(pd_objs), erwin_value=", ".join(er_objs) or "(none)")


def check_model_definition(ctx: Ctx) -> None:
    if not ctx.enabled("MODEL_DEFINITION") or ctx.pd.model is None:
        return
    comment = ctx.pd.model.attrs.get("Comment", "")
    if not comment or not ctx.er.carries("Definition"):
        return
    er_def = ctx.er.model_props.get("Definition", "")
    if _norm(comment) != _norm(er_def):
        ctx.add("MODEL_DEFINITION", "MODEL", "(model)", "Model definition / comment differs" if er_def else "Model comment not carried",
                pd_value=comment, erwin_value=er_def or "(none)")


CHECKS: Tuple[Callable[[Ctx], None], ...] = (
    check_attribute_default, check_attribute_domain, check_column_identity, check_column_check_constraint,
    check_logical_names, check_table_owner, check_table_tablespace,
    check_identifier_names_and_order, check_indexes,
    check_relationship_ri_rules, check_reference_name_and_cardinality,
    check_domains, check_business_rules, check_defaults, check_data_formats, check_database_target,
    check_view_columns, check_triggers, check_sequences, check_programmable_definitions,
    check_inheritance_name, check_packages, check_diagrams, check_model_definition,
)


# ─── ENTRY POINTS ────────────────────────────────────────────────────────────

def unverified_tag_findings(er: "ErDoc") -> List[ExtFinding]:
    """
    One finding per UNVERIFIED erwin element name a check looked for and did
    not find.

    This is the fix for the framework's quietest failure mode. `carries()`
    exists so a thin export is not flooded with findings it cannot answer, but
    it makes two very different situations look identical:

        the export genuinely has no such property   -> nothing to compare, fine
        the framework has the property name WRONG   -> nothing was compared at
                                                       all, and the report says
                                                       so nowhere

    The spellings in UNVERIFIED_ERWIN_TAGS were derived from erwin's property
    naming and have never been seen in a real export, so for those the second
    case is live. Reporting them at EXTERNAL_VERIFICATION_REQUIRED — visible,
    never scored — means a clean sheet can no longer be produced by a typo.

    Grouped by the CHECK each tag gates, so one missing vocabulary produces one
    row naming what did not run, not one row per word.
    """
    unverified = {tag for tag in er.missing if tag in set(UNVERIFIED_ERWIN_TAGS)}
    if not unverified:
        return []

    by_check: Dict[str, Set[str]] = defaultdict(set)
    for tag in unverified:
        by_check[UNVERIFIED_TAG_CHECKS.get(tag, "an extended property check")].add(tag)

    findings = []
    for what, tags in sorted(by_check.items()):
        names = ", ".join(f"<{tag}>" for tag in sorted(tags))
        findings.append(ExtFinding(
            category="ERWIN_TAG_UNVERIFIED",
            object_type="MODEL", object_name="(model)",
            severity=SEVERITY_EXTERNAL_VERIFICATION,
            message=(f"{what} were NOT checked: this export contains none of {names}, "
                     f"and those element names have never been confirmed against a "
                     f"real erwin export. Either erwin does not write them for this "
                     f"model, or the framework has the name wrong — from this model "
                     f"alone the two are indistinguishable, so the check is recorded "
                     f"as not performed rather than as passed."),
            pd_value="(not compared)", erwin_value="(element name absent)",
            remediation=(f"EXTERNAL_VERIFICATION_REQUIRED: open one erwin export that "
                         f"definitely contains {what} and confirm the element name. If "
                         f"it differs, correct it in app/validation/extended_properties.py "
                         f"and remove it from UNVERIFIED_ERWIN_TAGS."),
        ))
    return findings


def run(pd_path: str, erwin_path: str, model_type: str, config) -> List[ExtFinding]:
    """Run every enabled check and return the findings (no result object needed)."""
    ctx = Ctx(PdDoc(pd_path), ErDoc(erwin_path), config, model_type.lower())
    for check in CHECKS:
        try:
            check(ctx)
        except Exception as exc:                                     # noqa: BLE001
            logger.warning("extended property check %s failed: %s", check.__name__, exc)
    # Must run AFTER every check, because it reports what those checks asked for.
    if getattr(config, "REPORT_UNVERIFIED_ERWIN_TAGS", True):
        ctx.findings.extend(unverified_tag_findings(ctx.er))
    return ctx.findings


def _pdm_emit(result, finding: ExtFinding) -> None:
    from app.validation.pdm_reconcile.pdm_erwin_validator.comparator import Finding
    object_type = finding.object_type
    table = finding.object_name if object_type in ("TABLE", "COLUMN", "KEY", "INDEX", "TRIGGER") else ""
    if "." in table and object_type in ("COLUMN", "KEY", "INDEX"):
        table = table.split(".", 1)[0]
    if finding.severity == "INFO":
        result.emit(finding.category, category=finding.category, object_type=object_type, table=table,
                    column=finding.member if object_type == "COLUMN" else (finding.object_name if object_type != "TABLE" else ""),
                    message=finding.message, pd_value=finding.pd_value, erwin_value=finding.erwin_value)
    else:
        result.add(Finding(category=finding.category, severity=finding.severity, object_type=object_type, table=table,
                           column=finding.member, message=finding.message, pd_value=finding.pd_value, erwin_value=finding.erwin_value))


def apply(result, model_type: str, config, pd_path: Optional[str] = None, erwin_path: Optional[str] = None) -> int:
    """
    Run the checks for `model_type` ("cdm" | "ldm" | "pdm") and record the
    findings on `result`. Returns the number of findings added. Never raises.
    Must be called BEFORE the result's status / score are computed.
    """
    if not getattr(config, "CHECK_EXTENDED_PROPERTIES", True):
        return 0
    pd_path = pd_path or getattr(result, "pd_file", "")
    erwin_path = erwin_path or getattr(result, "erwin_file", "")
    if not (pd_path and erwin_path):
        return 0
    try:
        findings = run(pd_path, erwin_path, model_type, config)
    except Exception as exc:                                         # noqa: BLE001
        logger.warning("extended property checks skipped for %s: %s", pd_path, exc)
        return 0
    added = 0
    for f in findings:
        try:
            if model_type.lower() == "pdm":
                _pdm_emit(result, f)
            else:
                result.emit(f.category, severity=f.severity, object_type=f.object_type, object_name=f.object_name,
                            member=f.member, message=f.message, pd_value=f.pd_value, erwin_value=f.erwin_value,
                            remediation=f.remediation)
            added += 1
        except Exception as exc:                                     # noqa: BLE001
            logger.warning("could not record extended finding %s: %s", f.category, exc)
    return added


def categories() -> Iterable[str]:
    """Every finding category this module can emit (for the coverage matrix and CONFIG sheet)."""
    return sorted({
        "ATTRIBUTE_DEFAULT", "ATTRIBUTE_DOMAIN", "COLUMN_DOMAIN", "COLUMN_IDENTITY", "COLUMN_CHECK_CONSTRAINT",
        "TABLE_LOGICAL_NAME", "COLUMN_LOGICAL_NAME", "TABLE_OWNER", "TABLE_TABLESPACE",
        "IDENTIFIER_NAME", "IDENTIFIER_MEMBER_ORDER", "KEY_NAME", "INDEX_NAME", "INDEX_SORT_ORDER",
        "RELATIONSHIP_RI_RULE", "REFERENCE_RI_RULE", "RELATIONSHIP_RI_RULE_UNMAPPED", "REFERENCE_RI_RULE_UNMAPPED",
        "REFERENCE_NAME", "REFERENCE_CARDINALITY",
        "DOMAIN_NAME", "DOMAIN_LENGTH", "DOMAIN_DEFAULT", "DOMAIN_CHECK_PARAMS", "DOMAIN_OBJECT",
        "BUSINESS_RULE_TYPE", "BUSINESS_RULE_OBJECT", "DEFAULT_OBJECT", "DATA_FORMAT_NOT_REPRESENTABLE", "DATABASE_TARGET",
        "VIEW_COLUMNS", "TRIGGER_EVENT", "TRIGGER_TABLE", "SEQUENCE_PARAMS",
        "VIEW_DEFINITION", "PROCEDURE_DEFINITION", "TRIGGER_DEFINITION", "SEQUENCE_DEFINITION", "TABLESPACE_DEFINITION",
        "INHERITANCE_NAME", "PACKAGE_DEFINITION", "PACKAGE_HIERARCHY", "PACKAGE_CONTENTS",
        "DIAGRAM_MISSING", "DIAGRAM_SYMBOLS", "MODEL_DEFINITION",
    })
