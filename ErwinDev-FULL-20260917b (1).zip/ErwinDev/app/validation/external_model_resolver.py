"""
External Model Resolver (Workstream 3)
========================================
Best-effort file lookup for an external shortcut's target model, so deep
shortcut validation can locate the referenced PowerDesigner model and its
erwin XML export when they happen to be part of the same migration estate.

Never raises: an unresolved target returns ``None`` so the caller can emit a
WARNING rather than fail the shortcut outright — the referenced model may
simply not be part of this batch.
"""

from pathlib import Path
from typing import Iterable, Optional, Sequence

_DEFAULT_PD_EXTENSIONS = (".ldm", ".cdm")


def _norm(name: str) -> str:
    return "".join(ch for ch in (name or "").strip().casefold() if ch.isalnum())


def resolve_external_model(target_model: str, search_dirs: Iterable[str],
                           extensions: Sequence[str] = _DEFAULT_PD_EXTENSIONS) -> Optional[str]:
    """
    Locate the PowerDesigner file for a shortcut's target model by name.

    Matching is tolerant of case/punctuation (same style as the report
    workbook resolver): the file's stem is compared to ``target_model`` with
    both sides reduced to lowercase alphanumerics only.
    """
    wanted = _norm(target_model)
    if not wanted:
        return None

    for directory in search_dirs:
        root = Path(directory)
        if not root.is_dir():
            continue
        for ext in extensions:
            for candidate in root.rglob(f"*{ext}"):
                if _norm(candidate.stem) == wanted:
                    return str(candidate)
    return None


def resolve_external_erwin_xml(target_model: str, search_dirs: Iterable[str]) -> Optional[str]:
    """Locate the erwin XML export that corresponds to the same target model."""
    wanted = _norm(target_model)
    if not wanted:
        return None

    for directory in search_dirs:
        root = Path(directory)
        if not root.is_dir():
            continue
        for candidate in root.rglob("*.xml"):
            if _norm(candidate.stem) == wanted:
                return str(candidate)
    return None
