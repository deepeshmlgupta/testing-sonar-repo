"""
Validation Comparator
---------------------
Compares a parsed PowerDesigner PDM model against a parsed ERwin model and
produces a structured list of differences (Findings) plus reconciliation counts
at three levels — tables, columns and foreign keys — and an overall fidelity
score, mirroring the CDM validator's report.

Each Finding has:
  category   : TABLE | COLUMN | DATA_TYPE | NULLABILITY | DEFAULT |
               PRIMARY_KEY | FOREIGN_KEY | INDEX
  severity   : CRITICAL | WARNING | INFO   (driven by config.FINDING_SEVERITY)
  table      : physical table name (or empty for model-level issues)
  column     : physical column name (or empty)
  message    : human-readable description of the difference
  pd_value   : value from PowerDesigner
  erwin_value: value from ERwin

Severity is looked up per finding *key* in config.FINDING_SEVERITY, so the whole
policy (what is CRITICAL vs WARNING vs INFO vs IGNORE) lives in config.py and can
be tuned without touching this module.
"""

import logging
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional

try:
    from .advanced_datatype_mapper import classify as classify_vendor_type
    from .advanced_datatype_mapper import datatype_fidelity_pct
    from .data_type_mapper import classify_type_match, compare_sql, normalize
except ImportError:
    from advanced_datatype_mapper import classify as classify_vendor_type
    from advanced_datatype_mapper import datatype_fidelity_pct
    from data_type_mapper import classify_type_match, compare_sql, normalize

# The PDM tier's settings live in app/config/validation_config.py. This module
# used to do a bare ``import config`` against a local config.py that no longer
# exists in this folder, which made the whole PDM engine unimportable (and the
# PDM route in app/main.py die with "No module named 'config'" before it ever
# validated anything). Import the central tier view, exactly as erwin_parser.py
# already does, and keep a local-file fallback for anyone running this folder
# standalone.
try:
    from app.config.validation_config import PDM_CONFIG as config
except Exception:                       # pragma: no cover - standalone use
    try:
        import config  # type: ignore
    except Exception:
        config = None

# UDP integration. Guarded because this validator is also run standalone from
# its own folder (pdm_erwin_validator/main.py), where app.* is not importable.
try:
    from app.validation import udp_fidelity
except Exception:                       # pragma: no cover - standalone use
    udp_fidelity = None

logger = logging.getLogger(__name__)

NONE_VALUE = "(none)"


# ─── SEVERITY POLICY ──────────────────────────────────────────────────────────

#: Visible in the report, never weighted into fidelity: a condition identical
#: in BOTH models, which the migration neither caused nor could fix.
SEVERITY_SOURCE_PRE_EXISTING = "SOURCE_PRE_EXISTING"

_DEFAULT_SEVERITY = {
    "TABLE_MISSING": "CRITICAL", "TABLE_EXTRA": "WARNING",
    "COLUMN_MISSING": "CRITICAL", "COLUMN_EXTRA": "WARNING",
    "TABLE_DUPLICATE": "CRITICAL", "COLUMN_DUPLICATE": "WARNING",
    "FOREIGN_KEY_DUPLICATE": "INFO",
    "DATA_TYPE": "CRITICAL", "DATA_TYPE_LENGTH": "WARNING",
    "DATA_TYPE_ABSTRACT": "INFO",
    "DATA_TYPE_VENDOR_EXACT": "VERIFIED",
    "DATA_TYPE_VENDOR_COMPATIBLE": "INFO",
    "DATA_TYPE_VENDOR_CONVERTIBLE": "WARNING",
    "TYPE_EXACT_MATCH": "VERIFIED", "TYPE_CANONICAL_MATCH": "VERIFIED",
    "TYPE_SEMANTIC_MATCH": "VERIFIED", "TYPE_MISMATCH": "CRITICAL",
    "NULLABILITY": "INFO", "DEFAULT": "INFO",
    "PRIMARY_KEY": "CRITICAL", "PRIMARY_KEY_PD_ONLY": "INFO",
    "PRIMARY_KEY_ABSENT_BOTH": "SOURCE_PRE_EXISTING",
    "FOREIGN_KEY_MISSING": "WARNING", "FOREIGN_KEY_EXTRA": "INFO",
    "FOREIGN_KEY_DIRECTION_RECONCILED": "INFO",
    "INDEX_MISSING": "INFO", "INDEX_EXTRA": "INFO",
    "VIEW_MISSING": "WARNING", "VIEW_EXTRA": "INFO",
    "VIEW_SQL_MISMATCH": "WARNING", "VIEW_VERIFIED": "VERIFIED",
    "PROCEDURE_MISSING": "WARNING", "PROCEDURE_EXTRA": "INFO",
    "PROCEDURE_BODY_MISMATCH": "WARNING", "PROCEDURE_VERIFIED": "VERIFIED",
    "TRIGGER_MISSING": "WARNING", "TRIGGER_EXTRA": "INFO",
    "TRIGGER_BODY_MISMATCH": "WARNING", "TRIGGER_VERIFIED": "VERIFIED",
    "SEQUENCE_MISSING": "INFO", "SEQUENCE_EXTRA": "INFO", "SEQUENCE_VERIFIED": "VERIFIED",
    "TABLESPACE_MISSING": "INFO", "TABLESPACE_EXTRA": "INFO", "TABLESPACE_VERIFIED": "VERIFIED",
    "PACKAGE_MISSING": "INFO", "PACKAGE_EXTRA": "INFO", "PACKAGE_VERIFIED": "VERIFIED",
    # Census keys — matched objects reported as context (never scored).
    "TABLE_VERIFIED": "VERIFIED", "COLUMN_VERIFIED": "VERIFIED",
    "KEY_VERIFIED": "VERIFIED", "INDEX_VERIFIED": "VERIFIED",
    "INDEX_MIRROR": "VERIFIED", "REFERENCE_VERIFIED": "VERIFIED",
}


def _sev(key: str) -> str:
    """Effective severity for a finding key (config override, else default)."""
    policy = getattr(config, "FINDING_SEVERITY", None) or _DEFAULT_SEVERITY
    return policy.get(key, _DEFAULT_SEVERITY.get(key, "INFO"))


# Which PowerDesigner list a finding belongs to — the FINDINGS sheet's
# "Object Type" column, so every PD list (Tables, Columns, Keys, Indexes,
# References) can be filtered in one click.
_OBJECT_TYPE_BY_CATEGORY = {
    "TABLE": "TABLE",
    "COLUMN": "COLUMN", "DATA_TYPE": "COLUMN",
    "NULLABILITY": "COLUMN", "DEFAULT": "COLUMN",
    "PRIMARY_KEY": "KEY",
    "FOREIGN_KEY": "REFERENCE",
    "INDEX": "INDEX",
    "VIEW": "VIEW",
    "PROCEDURE": "PROCEDURE",
    "TRIGGER": "TRIGGER",
    "SEQUENCE": "SEQUENCE",
    "TABLESPACE": "TABLESPACE",
    "PACKAGE": "PACKAGE",
    "PARSE_ERROR": "MODEL",
}


# ─── FINDING + RESULT ─────────────────────────────────────────────────────────

@dataclass
class Finding:
    category:    str
    severity:    str          # CRITICAL | WARNING | INFO
    object_type: str = ""     # TABLE | COLUMN | KEY | INDEX | REFERENCE
    table:       str = ""
    column:      str = ""
    message:     str = ""
    pd_value:    str = ""
    erwin_value: str = ""

    def as_dict(self) -> Dict[str, str]:
        return asdict(self)


@dataclass
class ValidationResult:
    pd_file:     str
    erwin_file:  str
    pd_model:    str = ""
    erwin_model: str = ""
    status:      str = "PASS"      # PASS | WARN | FAIL | ERROR
    findings:    List[Finding] = field(default_factory=list)

    # Table-level counters.
    # tables_pd / tables_erwin are RAW object counts — what PowerDesigner's
    # "List of Tables" and erwin's entity list show. Objects that collide on
    # physical name are counted here and reported separately, so
    #     tables_pd == tables_matched + tables_missing_in_erwin + tables_duplicate_pd
    # always holds and the workbook can never disagree with the source tool.
    tables_pd:      int = 0
    tables_erwin:   int = 0
    tables_matched: int = 0
    tables_missing_in_erwin: int = 0
    tables_extra_in_erwin:   int = 0
    tables_duplicate_pd:     int = 0
    tables_duplicate_erwin:  int = 0

    # Column-level counters (same reconciliation identity as above).
    columns_pd:      int = 0
    columns_erwin:   int = 0
    columns_matched: int = 0
    columns_missing_in_erwin: int = 0
    columns_extra_in_erwin:   int = 0
    columns_duplicate_pd:     int = 0
    columns_duplicate_erwin:  int = 0

    # Key / index census counters (for the SUMMARY sheet)
    keys_pd:       int = 0
    keys_erwin:    int = 0
    indexes_pd:    int = 0
    indexes_erwin: int = 0

    # Foreign-key-level counters
    fk_pd:      int = 0
    fk_erwin:   int = 0
    fk_matched: int = 0
    fk_missing_in_erwin: int = 0
    fk_extra_in_erwin:   int = 0
    fk_duplicate_pd:     int = 0
    fk_duplicate_erwin:  int = 0

    # Extended PDM objects
    views_pd:            int = 0
    views_erwin:         int = 0
    views_matched:       int = 0
    procedures_pd:       int = 0
    procedures_erwin:    int = 0
    procedures_matched:  int = 0
    triggers_pd:         int = 0
    triggers_erwin:      int = 0
    triggers_matched:    int = 0

    # Roadmap enhancements (Workstream 4)
    relationships_direction_reconciled: int = 0
    # Roadmap enhancements (Workstream 7 — Optional: None = not measured this run)
    datatype_fidelity_pct: Optional[float] = None
    datatype_classifications: List[Any] = field(default_factory=list)

    # Finding counters
    critical_count: int = 0
    warning_count:  int = 0
    info_count:     int = 0

    # Scoring.
    # fidelity_score is rounded to 2dp for display. fidelity_score_raw is NOT —
    # the promotion gate must read the raw value, because on a model with a few
    # thousand comparable objects a real defect shrinks below the rounding step
    # (1 INFO over 1000 objects = 99.995% -> displays and compares as 100.00%)
    # and a defective model would be promoted on a cosmetic number.
    fidelity_score:     float = 100.0
    fidelity_score_raw: float = 100.0
    needs_review:       bool = False

    # ── Mutators ──────────────────────────────────────────────────────────────
    def add(self, finding: Optional[Finding]) -> None:
        if finding is None or finding.severity == "IGNORE":
            return
        self.findings.append(finding)
        if finding.severity == "CRITICAL":
            self.critical_count += 1
        elif finding.severity == "WARNING":
            self.warning_count += 1
        elif finding.severity == "INFO":
            self.info_count += 1
        # Any other severity ("VERIFIED") is context-only: reported in the
        # workbook, never counted into fidelity or PASS/WARN/FAIL.

    def emit(self, key: str, *, category: str, **kwargs) -> None:
        """Create a finding at the severity configured for `key` and record it."""
        severity = _sev(key)
        if severity == "IGNORE":
            return
        kwargs.setdefault("object_type",
                          _OBJECT_TYPE_BY_CATEGORY.get(category, category))
        self.add(Finding(category=category, severity=severity, **kwargs))

    # ── Scoring ─────────────────────────────────────────────────────────────
    def compute_score(self) -> None:
        if self.status == "ERROR":
            self.fidelity_score = 0.0
            self.fidelity_score_raw = 0.0
            self.needs_review = True
            return
        comparable = max(1, self.tables_pd + self.columns_pd + self.fk_pd)
        weights = getattr(config, "FIDELITY_WEIGHTS",
                          {"CRITICAL": 1.0, "WARNING": 0.35, "INFO": 0.05})
        penalty = (self.critical_count * weights.get("CRITICAL", 1.0) +
                   self.warning_count  * weights.get("WARNING", 0.35) +
                   self.info_count     * weights.get("INFO", 0.05))
        cap = getattr(config, "FIDELITY_MAX_PENALTY_PER_OBJECT", 1.0)
        penalty = min(penalty, comparable * cap)
        self.fidelity_score_raw = max(0.0, 100.0 * (1.0 - penalty / comparable))
        self.fidelity_score = round(self.fidelity_score_raw, 2)
        threshold = getattr(config, "FIDELITY_REVIEW_THRESHOLD", 90.0)
        self.needs_review = self.fidelity_score < threshold

    # ── Count self-check ──────────────────────────────────────────────────────
    def reconciliation_errors(self) -> List[str]:
        """
        Where the reported totals fail to add up.

        Every count in the workbook must satisfy an identity against the raw
        object counts of the two source models. When one of these breaks, the
        report is claiming something arithmetically impossible (e.g. "476 erwin
        columns, 473 matched, 0 extra") and must not be trusted — so the
        breakage is surfaced instead of being left for a reader to spot.
        """
        checks = [
            ("Tables (SAP PD)", self.tables_pd,
             self.tables_matched + self.tables_missing_in_erwin
             + self.tables_duplicate_pd),
            ("Tables (erwin)", self.tables_erwin,
             self.tables_matched + self.tables_extra_in_erwin
             + self.tables_duplicate_erwin),
            ("Columns (SAP PD)", self.columns_pd,
             self.columns_matched + self.columns_missing_in_erwin
             + self.columns_duplicate_pd),
            ("Columns (erwin)", self.columns_erwin,
             self.columns_matched + self.columns_extra_in_erwin
             + self.columns_duplicate_erwin),
            ("FKs (SAP PD)", self.fk_pd,
             self.fk_matched + self.fk_missing_in_erwin),
            ("FKs (erwin)", self.fk_erwin,
             self.fk_matched + self.fk_extra_in_erwin),
        ]
        return [f"{label}: reported {total}, parts sum to {parts}"
                for label, total, parts in checks if total != parts]

    def counts_reconcile(self) -> bool:
        return not self.reconciliation_errors()

    def compute_status(self) -> None:
        if self.status == "ERROR":
            return
        if self.critical_count > 0:
            self.status = "FAIL"
        elif self.warning_count > 0:
            self.status = "WARN"
        else:
            self.status = "PASS"


# ─── NAME NORMALISATION ─────────────────────────────────────────────────────────

def _key(name: str) -> str:
    if getattr(config, "CASE_INSENSITIVE", True):
        return (name or "").strip().upper()
    return (name or "").strip()


def _base_and_len(dtype: str):
    """('VARCHAR(100)') -> ('VARCHAR', '100').  Uses the normaliser first."""
    norm = normalize(dtype)
    if "(" in norm and norm.endswith(")"):
        base, rest = norm.split("(", 1)
        return base.strip(), rest[:-1].strip()
    return norm, ""


# ─── COLUMN COMPARISON ──────────────────────────────────────────────────────────

def _duplicate_codes(columns: List[Dict]) -> Dict[str, int]:
    """{code: how many objects carry it} for codes carried by more than one."""
    counts: Dict[str, int] = {}
    for column in columns:
        code = _key(column.get("code", ""))
        counts[code] = counts.get(code, 0) + 1
    return {code: n for code, n in counts.items() if n > 1}


def _emit_duplicate_columns(result: ValidationResult, tbl_code: str,
                            pd_cols: List[Dict], erwin_cols: List[Dict]):
    pd_dupes = _duplicate_codes(pd_cols)
    erwin_dupes = _duplicate_codes(erwin_cols)

    for code, count in sorted(pd_dupes.items()):
        result.emit("COLUMN_DUPLICATE", category="COLUMN", table=tbl_code,
                    column=code,
                    message=f"Column '{code}' is defined {count} times in "
                            f"PowerDesigner table '{tbl_code}'",
                    pd_value=f"{count} objects share this physical name",
                    erwin_value=str(erwin_dupes.get(code, 1)))

    for code, count in sorted(erwin_dupes.items()):
        result.emit("COLUMN_DUPLICATE", category="COLUMN", table=tbl_code,
                    column=code,
                    message=f"Column '{code}' is defined {count} times in the "
                            f"ERwin entity '{tbl_code}' (usually one migrated "
                            f"attribute per duplicate relationship; the "
                            f"generated DDL would be invalid)",
                    pd_value=str(pd_dupes.get(code, 1)),
                    erwin_value=f"{count} objects share this physical name")

    return (len(pd_cols) - len({_key(c["code"]) for c in pd_cols}),
            len(erwin_cols) - len({_key(c["code"]) for c in erwin_cols}))


def _compare_column_data_type(result: ValidationResult, tbl_code: str, col_key: str,
                              pd_c: Dict, erwin_c: Dict) -> None:
    if not getattr(config, "CHECK_DATA_TYPES", True):
        return

    pd_dt = pd_c.get("data_type", "")
    erwin_dt = erwin_c.get("data_type", "")
    if not pd_dt or not erwin_dt:
        return

    match_cat, is_match = classify_type_match(pd_dt, erwin_dt)
    if is_match:
        if match_cat != "TYPE_EXACT_MATCH":
            result.emit(match_cat, category="DATA_TYPE", table=tbl_code, column=col_key,
                        message=f"Data type semantic equivalence ({match_cat}) on column '{col_key}'",
                        pd_value=pd_dt, erwin_value=erwin_dt)
        return

    if getattr(config, "ENABLE_ADVANCED_DATATYPE_INTELLIGENCE", False):
        vendor = classify_vendor_type(pd_dt, erwin_dt)
        result.datatype_classifications.append(vendor)
        if vendor.category != "UNSUPPORTED":
            key = f"DATA_TYPE_VENDOR_{vendor.category}"
            result.emit(key, category="DATA_TYPE", table=tbl_code, column=col_key,
                        message=f"Vendor-specific data type match ({vendor.category}, "
                                f"{vendor.vendor}) on column '{col_key}'",
                        pd_value=pd_dt, erwin_value=erwin_dt)
            return

    pd_base, _ = _base_and_len(pd_dt)
    ew_base, _ = _base_and_len(erwin_dt)
    abstract = {t.upper() for t in getattr(config, "PD_ABSTRACT_TYPES", {"ENUM"})}

    if pd_base.upper() in abstract:
        key = "DATA_TYPE_ABSTRACT"
        label = f"PD abstract type '{pd_dt}' realised in ERwin"
    elif pd_base == ew_base:
        key = "DATA_TYPE_LENGTH"
        label = "Data type length mismatch"
    else:
        key = "DATA_TYPE"
        label = "Data type mismatch"

    result.emit(key, category="DATA_TYPE", table=tbl_code, column=col_key,
                message=f"{label} on column '{col_key}'",
                pd_value=f"{pd_dt} → {normalize(pd_dt)}",
                erwin_value=f"{erwin_dt} → {normalize(erwin_dt)}")


def _compare_column_nullability(result: ValidationResult, tbl_code: str, col_key: str,
                                pd_c: Dict, erwin_c: Dict) -> None:
    if not getattr(config, "CHECK_NULLABILITY", True):
        return
    if pd_c.get("not_null") == erwin_c.get("not_null"):
        return

    result.emit("NULLABILITY", category="NULLABILITY", table=tbl_code,
                column=col_key,
                message=f"Nullability mismatch on column '{col_key}'",
                pd_value="NOT NULL" if pd_c.get("not_null") else "NULL",
                erwin_value="NOT NULL" if erwin_c.get("not_null") else "NULL")


def _compare_column_default(result: ValidationResult, tbl_code: str, col_key: str,
                            pd_c: Dict, erwin_c: Dict) -> None:
    if not getattr(config, "CHECK_DEFAULT_VALUES", True):
        return

    pd_def = (pd_c.get("default") or "").strip()
    erwin_def = (erwin_c.get("default") or "").strip()
    if _key(pd_def) == _key(erwin_def):
        return

    result.emit("DEFAULT", category="DEFAULT", table=tbl_code, column=col_key,
                message=f"Default value mismatch on column '{col_key}'",
                pd_value=pd_def or NONE_VALUE,
                erwin_value=erwin_def or NONE_VALUE)


def _compare_matched_column(result: ValidationResult, tbl_code: str, col_key: str,
                            pd_c: Dict, erwin_c: Dict) -> None:
    before = len(result.findings)
    _compare_column_data_type(result, tbl_code, col_key, pd_c, erwin_c)
    _compare_column_nullability(result, tbl_code, col_key, pd_c, erwin_c)
    _compare_column_default(result, tbl_code, col_key, pd_c, erwin_c)

    if len(result.findings) != before:
        return

    result.emit("COLUMN_VERIFIED", category="COLUMN", table=tbl_code,
                column=col_key,
                message=f"Column '{col_key}' migrated intact — present in "
                        f"ERwin with matching type, nullability and default",
                pd_value=pd_c.get("data_type", "") or "(untyped)",
                erwin_value=erwin_c.get("data_type", "") or "(untyped)")


def _compare_columns(result: ValidationResult, tbl_code: str,
                     pd_cols: List[Dict], erwin_cols: List[Dict]):
    pd_map = {_key(c["code"]): c for c in pd_cols}
    erwin_map = {_key(c["code"]): c for c in erwin_cols}
    pd_names, erwin_names = set(pd_map), set(erwin_map)

    matched = pd_names & erwin_names
    missing = pd_names - erwin_names
    extra = erwin_names - pd_names
    duplicate_pd, duplicate_erwin = _emit_duplicate_columns(
        result, tbl_code, pd_cols, erwin_cols)

    for col in sorted(missing):
        result.emit("COLUMN_MISSING", category="COLUMN", table=tbl_code, column=col,
                    message=f"Column '{col}' exists in PowerDesigner but NOT in ERwin",
                    pd_value=col, erwin_value="—")

    for col in sorted(extra):
        result.emit("COLUMN_EXTRA", category="COLUMN", table=tbl_code, column=col,
                    message=f"Column '{col}' exists in ERwin but NOT in PowerDesigner",
                    pd_value="—", erwin_value=col)

    for col_key in sorted(matched):
        _compare_matched_column(result, tbl_code, col_key,
                                pd_map[col_key], erwin_map[col_key])

    return (len(matched), len(missing), len(extra),
            duplicate_pd, duplicate_erwin)


# ─── PRIMARY KEY ─────────────────────────────────────────────────────────────────

def _pk_columns(tbl: Dict) -> Optional[List[str]]:
    for key in tbl.get("keys", []):
        if key.get("is_pk"):
            return [_key(c) for c in key.get("columns", [])]
    return None


def _compare_primary_keys(result, tbl_code, pd_tbl, erwin_tbl):
    pd_pk, erwin_pk = _pk_columns(pd_tbl), _pk_columns(erwin_tbl)
    if pd_pk is None and erwin_pk is None:
        
        result.emit("PRIMARY_KEY_ABSENT_BOTH", category="PRIMARY_KEY", table=tbl_code,
            message="No Primary Key in PowerDesigner or ERwin — pre-existing "
                    "in PowerDesigner, faithfully preserved by the migration",
            pd_value=NONE_VALUE, erwin_value=NONE_VALUE)
        return
    if pd_pk is None:
        result.emit("PRIMARY_KEY_PD_ONLY", category="PRIMARY_KEY", table=tbl_code,
                    message="No Primary Key in PowerDesigner; ERwin has one",
                    pd_value=NONE_VALUE, erwin_value=str(sorted(erwin_pk)))
        return
    if erwin_pk is None or not erwin_pk:
        # erwin sometimes does not serialise PK members for fully-migrated keys;
        # only flag if PD genuinely has PK columns and ERwin genuinely has none.
        result.emit("PRIMARY_KEY", category="PRIMARY_KEY", table=tbl_code,
                    message="Primary Key exists in PowerDesigner but NOT in ERwin",
                    pd_value=str(sorted(pd_pk)), erwin_value=NONE_VALUE)
        return
    if set(pd_pk) != set(erwin_pk):
        result.emit("PRIMARY_KEY", category="PRIMARY_KEY", table=tbl_code,
                    message="Primary Key column mismatch",
                    pd_value=str(sorted(pd_pk)), erwin_value=str(sorted(erwin_pk)))
    else:
        pk_name = next((k.get("name") or k.get("code", "")
                        for k in pd_tbl.get("keys", []) if k.get("is_pk")), "")
        result.emit("KEY_VERIFIED", category="PRIMARY_KEY", table=tbl_code,
                    column=", ".join(sorted(pd_pk)),
                    message=f"Primary key '{pk_name or 'PK'}' migrated intact — "
                            f"same column set in both models",
                    pd_value=str(sorted(pd_pk)), erwin_value=str(sorted(erwin_pk)))


# ─── FOREIGN KEYS ──────────────────────────────────────────────────────────────

def _fk_signature(ref: Dict) -> str:
    parent = _key(ref.get("parent_table", ""))
    child  = _key(ref.get("child_table", ""))
    joins  = tuple(sorted(
        (_key(j.get("parent_col", "")), _key(j.get("child_col", "")))
        for j in ref.get("join_columns", [])))
    return f"{parent}→{child}:{joins}"


def _group_references_by_signature(refs: List[Dict]) -> Dict[str, List[Dict]]:
    grouped: Dict[str, List[Dict]] = {}
    for reference in refs:
        grouped.setdefault(_fk_signature(reference), []).append(reference)
    return grouped


def _emit_matched_references(result: ValidationResult, sig: str,
                             references: List[Dict]) -> None:
    for reference in references:
        result.emit(
            "REFERENCE_VERIFIED", category="FOREIGN_KEY",
            table=f"{reference.get('parent_table', '?')}→{reference.get('child_table', '?')}",
            column=reference.get("name") or reference.get("code", ""),
            message=f"Reference '{reference.get('name') or reference.get('code', '?')}' "
                    f"migrated intact — same parent/child and join columns",
            pd_value=sig, erwin_value=sig)


def _emit_missing_references(result: ValidationResult, sig: str,
                             references: List[Dict]) -> None:
    for reference in references:
        result.emit(
            "FOREIGN_KEY_MISSING", category="FOREIGN_KEY",
            table=f"{reference.get('parent_table','?')}→{reference.get('child_table','?')}",
            column=reference.get("name") or reference.get("code", ""),
            message=f"FK '{reference.get('name','?')}' exists in PowerDesigner but NOT in ERwin",
            pd_value=sig, erwin_value="—")


def _emit_extra_references(result: ValidationResult, sig: str,
                           references: List[Dict]) -> None:
    for reference in references:
        result.emit(
            "FOREIGN_KEY_EXTRA", category="FOREIGN_KEY",
            table=f"{reference.get('parent_table','?')}→{reference.get('child_table','?')}",
            column=reference.get("name") or reference.get("code", ""),
            message=f"FK '{reference.get('name','?')}' exists in ERwin but NOT in PowerDesigner",
            pd_value="—", erwin_value=sig)


def _emit_duplicate_reference(result: ValidationResult, sig: str,
                              pd_side: List[Dict], erwin_side: List[Dict]) -> None:
    if len(pd_side) <= 1:
        return

    names = ", ".join(r.get("name") or r.get("code", "?") for r in pd_side)
    result.emit(
        "FOREIGN_KEY_DUPLICATE", category="FOREIGN_KEY",
        table=f"{pd_side[0].get('parent_table','?')}→{pd_side[0].get('child_table','?')}",
        column=names,
        message=f"{len(pd_side)} PowerDesigner references share one "
                f"parent/child/join signature ({names}); erwin migrates "
                f"the join column once per reference",
        pd_value=sig, erwin_value=str(len(erwin_side)))


def _fk_signature_reversed(ref: Dict) -> str:
    """The signature this FK would have if its parent/child were swapped."""
    parent = _key(ref.get("child_table", ""))
    child = _key(ref.get("parent_table", ""))
    joins = tuple(sorted(
        (_key(j.get("child_col", "")), _key(j.get("parent_col", "")))
        for j in ref.get("join_columns", [])))
    return f"{parent}→{child}:{joins}"


def _reconcile_reversed_foreign_keys(result: ValidationResult, pd_refs: List[Dict],
                                     erwin_refs: List[Dict]):
    """
    Workstream 4 for PDM: a reference whose parent/child table (and join
    column pairing) is fully reversed between PowerDesigner and erwin is
    reported once as a direction reconciliation instead of one MISSING plus
    one EXTRA foreign key. Returns (remaining_pd, remaining_erwin, reconciled_count).
    """
    reconciled_erwin_ids = set()
    remaining_pd: List[Dict] = []
    reconciled_count = 0

    for pd_ref in pd_refs:
        reversed_sig = _fk_signature_reversed(pd_ref)
        match = next((e for e in erwin_refs
                     if id(e) not in reconciled_erwin_ids and _fk_signature(e) == reversed_sig),
                    None)
        if match is None:
            remaining_pd.append(pd_ref)
            continue
        reconciled_erwin_ids.add(id(match))
        reconciled_count += 1
        result.relationships_direction_reconciled += 1
        result.emit(
            "FOREIGN_KEY_DIRECTION_RECONCILED", category="FOREIGN_KEY",
            table=f"{pd_ref.get('parent_table','?')}→{pd_ref.get('child_table','?')}",
            column=pd_ref.get("name") or pd_ref.get("code", ""),
            message="Foreign key parent/child direction is reversed between "
                    "PowerDesigner and erwin, but the same tables and join "
                    "columns are still connected — the migration is intact.",
            pd_value=_fk_signature(pd_ref), erwin_value=_fk_signature(match),
        )

    remaining_erwin = [e for e in erwin_refs if id(e) not in reconciled_erwin_ids]
    return remaining_pd, remaining_erwin, reconciled_count


def _compare_foreign_keys(result, pd_refs, erwin_refs):
    original_pd_count = len(pd_refs)
    original_erwin_count = len(erwin_refs)
    reconciled_count = 0

    if getattr(config, "ENABLE_DIRECTION_RECONCILIATION", False):
        pd_refs, erwin_refs, reconciled_count = _reconcile_reversed_foreign_keys(
            result, pd_refs, erwin_refs)

    pd_by_sig = _group_references_by_signature(pd_refs)
    erwin_by_sig = _group_references_by_signature(erwin_refs)
    matched = missing = extra = 0

    for sig in sorted(set(pd_by_sig) | set(erwin_by_sig)):
        pd_side = pd_by_sig.get(sig, [])
        erwin_side = erwin_by_sig.get(sig, [])
        pair_count = min(len(pd_side), len(erwin_side))
        matched += pair_count
        missing += len(pd_side) - pair_count
        extra += len(erwin_side) - pair_count

        _emit_matched_references(result, sig, pd_side[:pair_count])
        _emit_missing_references(result, sig, pd_side[pair_count:])
        _emit_extra_references(result, sig, erwin_side[pair_count:])
        _emit_duplicate_reference(result, sig, pd_side, erwin_side)

    result.fk_pd = original_pd_count
    result.fk_erwin = original_erwin_count
    result.fk_matched = matched + reconciled_count
    result.fk_missing_in_erwin = missing
    result.fk_extra_in_erwin = extra
    result.fk_duplicate_pd = len(pd_refs) - len(pd_by_sig)
    result.fk_duplicate_erwin = len(erwin_refs) - len(erwin_by_sig)


# ─── INDEXES ─────────────────────────────────────────────────────────────────

def _index_signature(idx: Dict) -> str:
    cols = tuple(sorted(_key(c) for c in idx.get("columns", [])))
    return f"{'U' if idx.get('is_unique') else 'I'}:{cols}"


def _compare_indexes(result, tbl_code, pd_tbl, erwin_tbl):
    def non_pk_keys(tbl):
        return [k for k in tbl.get("keys", []) if not k.get("is_pk")]

    skip_mirror = getattr(config, "PD_IGNORE_KEY_FK_INDEXES", True)
    if skip_mirror:
        # PD's "List of Indexes" counts these too; ERwin represents them as
        # the key/FK itself, so they are accounted for rather than compared.
        for idx in pd_tbl.get("indexes", []):
            if idx.get("mirror"):
                result.emit(
                    "INDEX_MIRROR", category="INDEX", table=tbl_code,
                    column=idx.get("name") or idx.get("code", ""),
                    message=f"Index '{idx.get('name') or idx.get('code', '?')}' "
                            f"mirrors a key/FK — ERwin carries it as the key "
                            f"itself, not as an index object; accounted for",
                    pd_value=_index_signature(idx),
                    erwin_value="(represented as the key/FK)")
    pd_index_objs = [i for i in pd_tbl.get("indexes", [])
                     if not (skip_mirror and i.get("mirror"))]
    pd_idxs = {_index_signature(i): i
               for i in pd_index_objs + non_pk_keys(pd_tbl)}
    erwin_idxs = {_index_signature(i): i
                  for i in erwin_tbl.get("indexes", []) + non_pk_keys(erwin_tbl)
                  if i.get("kg_type", "IE") != "PK"}

    for sig in sorted(set(pd_idxs) & set(erwin_idxs)):
        idx = pd_idxs[sig]
        result.emit("INDEX_VERIFIED", category="INDEX", table=tbl_code,
                    column=idx.get("name") or idx.get("code", ""),
                    message=f"Index '{idx.get('name') or idx.get('code', '?')}' "
                            f"migrated intact — same columns and uniqueness",
                    pd_value=sig, erwin_value=sig)
    for sig in set(pd_idxs) - set(erwin_idxs):
        idx = pd_idxs[sig]
        result.emit("INDEX_MISSING", category="INDEX", table=tbl_code,
                    message=f"Index '{idx.get('name','?')}' in PowerDesigner missing from ERwin",
                    pd_value=sig, erwin_value="—")
    for sig in set(erwin_idxs) - set(pd_idxs):
        idx = erwin_idxs[sig]
        result.emit("INDEX_EXTRA", category="INDEX", table=tbl_code,
                    message=f"Index '{idx.get('name','?')}' in ERwin not in PowerDesigner",
                    pd_value="—", erwin_value=sig)


# ─── PUBLIC API ───────────────────────────────────────────────────────────────

def _parse_error_result(result: ValidationResult, model: Dict[str, Any],
                        source_label: str) -> bool:
    if "error" not in model:
        return False
    result.status = "ERROR"
    result.add(Finding("PARSE_ERROR", "CRITICAL",
                       message=f"{source_label} parse error: {model['error']}"))
    result.compute_score()
    return True


def _report_duplicate_tables(result: ValidationResult, pd_model: Dict[str, Any],
                             erwin_model: Dict[str, Any]) -> None:
    pd_dupe_tables = pd_model.get("duplicate_tables", {}) or {}
    erwin_dupe_tables = erwin_model.get("duplicate_tables", {}) or {}
    result.tables_duplicate_pd = sum(n - 1 for n in pd_dupe_tables.values())
    result.tables_duplicate_erwin = sum(n - 1 for n in erwin_dupe_tables.values())

    for code, count in sorted(pd_dupe_tables.items()):
        result.emit("TABLE_DUPLICATE", category="TABLE", table=code,
                    message=f"{count} PowerDesigner tables share the physical "
                            f"name '{code}'; only the first was compared",
                    pd_value=f"{count} tables", erwin_value="1 compared")

    for code, count in sorted(erwin_dupe_tables.items()):
        result.emit("TABLE_DUPLICATE", category="TABLE", table=code,
                    message=f"{count} ERwin entities share the physical name "
                            f"'{code}'; only the first was compared",
                    pd_value="1 compared", erwin_value=f"{count} entities")


def _set_model_counts(result: ValidationResult, pd_keys: Dict[str, Dict],
                      erwin_keys: Dict[str, Dict]) -> None:
    pd_names, erwin_names = set(pd_keys), set(erwin_keys)
    result.tables_pd = len(pd_keys) + result.tables_duplicate_pd
    result.tables_erwin = len(erwin_keys) + result.tables_duplicate_erwin
    result.tables_matched = len(pd_names & erwin_names)
    result.columns_pd = sum(len(t.get("columns", [])) for t in pd_keys.values())
    result.columns_erwin = sum(len(t.get("columns", [])) for t in erwin_keys.values())
    result.keys_pd = sum(len(t.get("keys", [])) for t in pd_keys.values())
    result.keys_erwin = sum(len(t.get("keys", [])) for t in erwin_keys.values())
    result.indexes_pd = sum(len(t.get("indexes", [])) for t in pd_keys.values())
    result.indexes_erwin = sum(len(t.get("indexes", [])) for t in erwin_keys.values())


def _compare_table_presence(result: ValidationResult, pd_keys: Dict[str, Dict],
                            erwin_keys: Dict[str, Dict]) -> None:
    if not getattr(config, "CHECK_TABLES", True):
        return

    pd_names, erwin_names = set(pd_keys), set(erwin_keys)
    for tbl in sorted(pd_names - erwin_names):
        result.tables_missing_in_erwin += 1
        result.emit("TABLE_MISSING", category="TABLE", table=tbl,
                    message=f"Table '{tbl}' in PowerDesigner is MISSING from ERwin",
                    pd_value=tbl, erwin_value="—")
        result.columns_missing_in_erwin += len(pd_keys[tbl].get("columns", []))

    for tbl in sorted(erwin_names - pd_names):
        result.tables_extra_in_erwin += 1
        result.emit("TABLE_EXTRA", category="TABLE", table=tbl,
                    message=f"Table '{tbl}' in ERwin does NOT exist in PowerDesigner",
                    pd_value="—", erwin_value=tbl)
        result.columns_extra_in_erwin += len(erwin_keys[tbl].get("columns", []))


def _compare_matched_table(result: ValidationResult, tbl_key: str,
                           pd_tbl: Dict, erwin_tbl: Dict) -> None:
    if getattr(config, "CHECK_TABLES", True):
        result.emit("TABLE_VERIFIED", category="TABLE", table=tbl_key,
                    message=f"Table '{tbl_key}' migrated — present in both models",
                    pd_value=f"{len(pd_tbl.get('columns', []))} column(s)",
                    erwin_value=f"{len(erwin_tbl.get('columns', []))} column(s)")

    if getattr(config, "CHECK_COLUMNS", True):
        matched, missing, extra, dup_pd, dup_er = _compare_columns(
            result, tbl_key, pd_tbl.get("columns", []), erwin_tbl.get("columns", []))
        result.columns_matched += matched
        result.columns_missing_in_erwin += missing
        result.columns_extra_in_erwin += extra
        result.columns_duplicate_pd += dup_pd
        result.columns_duplicate_erwin += dup_er

    if getattr(config, "CHECK_PRIMARY_KEYS", True):
        _compare_primary_keys(result, tbl_key, pd_tbl, erwin_tbl)
    if getattr(config, "CHECK_INDEXES", True):
        _compare_indexes(result, tbl_key, pd_tbl, erwin_tbl)


def _compare_all_matched_tables(result: ValidationResult, pd_keys: Dict[str, Dict],
                                erwin_keys: Dict[str, Dict]) -> None:
    for tbl_key in sorted(set(pd_keys) & set(erwin_keys)):
        _compare_matched_table(result, tbl_key, pd_keys[tbl_key], erwin_keys[tbl_key])


def _compare_views(result: ValidationResult, pd_model: Dict[str, Any], erwin_model: Dict[str, Any]) -> None:
    if not getattr(config, "CHECK_VIEWS", True):
        return
    pd_views = pd_model.get("views", {}) or {}
    erwin_views = erwin_model.get("views", {}) or {}
    result.views_pd = len(pd_views)
    result.views_erwin = len(erwin_views)

    pd_keys = {_key(k): v for k, v in pd_views.items()}
    erwin_keys = {_key(k): v for k, v in erwin_views.items()}

    matched = set(pd_keys) & set(erwin_keys)
    result.views_matched = len(matched)

    for v in sorted(set(pd_keys) - set(erwin_keys)):
        result.emit("VIEW_MISSING", category="VIEW", table=v,
                    message=f"View '{v}' in PowerDesigner is MISSING from ERwin",
                    pd_value=v, erwin_value="—")
    for v in sorted(set(erwin_keys) - set(pd_keys)):
        result.emit("VIEW_EXTRA", category="VIEW", table=v,
                    message=f"View '{v}' in ERwin does NOT exist in PowerDesigner",
                    pd_value="—", erwin_value=v)
    for v in sorted(matched):
        sql_pd = pd_keys[v].get("sql", "")
        sql_erwin = erwin_keys[v].get("sql", "")
        if sql_pd or sql_erwin:
            status, sim, msg = compare_sql(sql_pd, sql_erwin)
            if status == "SQL_MISMATCH":
                result.emit("VIEW_SQL_MISMATCH", category="VIEW", table=v,
                            message=f"View '{v}' SQL definition differs ({sim:.1%} similarity)",
                            pd_value=sql_pd[:100] if sql_pd else NONE_VALUE,
                            erwin_value=sql_erwin[:100] if sql_erwin else NONE_VALUE)
            else:
                result.emit("VIEW_VERIFIED", category="VIEW", table=v,
                            message=f"View '{v}' definition verified ({status})",
                            pd_value=v, erwin_value=v)
        else:
            # Presence matched, but NEITHER side carries SQL. The view migrated;
            # its definition was not measured. Saying "migrated intact" here
            # claimed a fidelity nobody established.
            result.emit("VIEW_VERIFIED", category="VIEW", table=v,
                        message=f"View '{v}' present on both sides; no SQL definition on "
                                f"either side, so the definition was not compared",
                        pd_value=v, erwin_value=v)


def _compare_procedures_and_functions(result: ValidationResult, pd_model: Dict[str, Any], erwin_model: Dict[str, Any]) -> None:
    if not getattr(config, "CHECK_PROCEDURES", True):
        return
    pd_procs = {**pd_model.get("procedures", {}), **pd_model.get("functions", {})}
    erwin_procs = {**erwin_model.get("procedures", {}), **erwin_model.get("functions", {})}
    result.procedures_pd = len(pd_procs)
    result.procedures_erwin = len(erwin_procs)

    pd_keys = {_key(k): v for k, v in pd_procs.items()}
    erwin_keys = {_key(k): v for k, v in erwin_procs.items()}

    matched = set(pd_keys) & set(erwin_keys)
    result.procedures_matched = len(matched)

    for p in sorted(set(pd_keys) - set(erwin_keys)):
        result.emit("PROCEDURE_MISSING", category="PROCEDURE", table=p,
                    message=f"Stored Procedure/Function '{p}' in PowerDesigner is MISSING from ERwin",
                    pd_value=p, erwin_value="—")
    for p in sorted(set(erwin_keys) - set(pd_keys)):
        result.emit("PROCEDURE_EXTRA", category="PROCEDURE", table=p,
                    message=f"Stored Procedure/Function '{p}' in ERwin does NOT exist in PowerDesigner",
                    pd_value="—", erwin_value=p)
    for p in sorted(matched):
        body_pd = pd_keys[p].get("body", "")
        body_erwin = erwin_keys[p].get("body", "")
        if body_pd or body_erwin:
            status, sim, msg = compare_sql(body_pd, body_erwin)
            if status == "SQL_MISMATCH":
                result.emit("PROCEDURE_BODY_MISMATCH", category="PROCEDURE", table=p,
                            message=f"Procedure '{p}' SQL body differs ({sim:.1%} similarity)",
                            pd_value=body_pd[:100] if body_pd else NONE_VALUE,
                            erwin_value=body_erwin[:100] if body_erwin else NONE_VALUE)
            else:
                result.emit("PROCEDURE_VERIFIED", category="PROCEDURE", table=p,
                            message=f"Procedure '{p}' body verified ({status})",
                            pd_value=p, erwin_value=p)
        else:
            # Presence matched with no body on either side — nothing measured.
            result.emit("PROCEDURE_VERIFIED", category="PROCEDURE", table=p,
                        message=f"Procedure '{p}' present on both sides; no SQL body on "
                                f"either side, so the body was not compared",
                        pd_value=p, erwin_value=p)


def _compare_triggers(result: ValidationResult, pd_model: Dict[str, Any], erwin_model: Dict[str, Any]) -> None:
    if not getattr(config, "CHECK_TRIGGERS", True):
        return
    pd_trigs = pd_model.get("triggers", {}) or {}
    erwin_trigs = erwin_model.get("triggers", {}) or {}
    result.triggers_pd = len(pd_trigs)
    result.triggers_erwin = len(erwin_trigs)

    pd_keys = {_key(k): v for k, v in pd_trigs.items()}
    erwin_keys = {_key(k): v for k, v in erwin_trigs.items()}

    matched = set(pd_keys) & set(erwin_keys)
    result.triggers_matched = len(matched)

    for t in sorted(set(pd_keys) - set(erwin_keys)):
        result.emit("TRIGGER_MISSING", category="TRIGGER", table=t,
                    message=f"Trigger '{t}' in PowerDesigner is MISSING from ERwin",
                    pd_value=t, erwin_value="—")
    for t in sorted(set(erwin_keys) - set(pd_keys)):
        result.emit("TRIGGER_EXTRA", category="TRIGGER", table=t,
                    message=f"Trigger '{t}' in ERwin does NOT exist in PowerDesigner",
                    pd_value="—", erwin_value=t)
    for t in sorted(matched):
        body_pd = pd_keys[t].get("body", "")
        body_erwin = erwin_keys[t].get("body", "")
        if body_pd or body_erwin:
            status, sim, msg = compare_sql(body_pd, body_erwin)
            if status == "SQL_MISMATCH":
                result.emit("TRIGGER_BODY_MISMATCH", category="TRIGGER", table=t,
                            message=f"Trigger '{t}' SQL body differs ({sim:.1%} similarity)",
                            pd_value=body_pd[:100] if body_pd else NONE_VALUE,
                            erwin_value=body_erwin[:100] if body_erwin else NONE_VALUE)
            else:
                result.emit("TRIGGER_VERIFIED", category="TRIGGER", table=t,
                            message=f"Trigger '{t}' body verified ({status})",
                            pd_value=t, erwin_value=t)
        else:
            # Presence matched with no body on either side — nothing measured.
            result.emit("TRIGGER_VERIFIED", category="TRIGGER", table=t,
                        message=f"Trigger '{t}' present on both sides; no SQL body on "
                                f"either side, so the body was not compared",
                        pd_value=t, erwin_value=t)


def _compare_sequences(result: ValidationResult, pd_model: Dict[str, Any], erwin_model: Dict[str, Any]) -> None:
    if not getattr(config, "CHECK_SEQUENCES", True):
        return
    pd_seqs = pd_model.get("sequences", {}) or {}
    erwin_seqs = erwin_model.get("sequences", {}) or {}
    pd_keys = {_key(k): v for k, v in pd_seqs.items()}
    erwin_keys = {_key(k): v for k, v in erwin_seqs.items()}
    for s in sorted(set(pd_keys) & set(erwin_keys)):
        result.emit("SEQUENCE_VERIFIED", category="SEQUENCE", table=s,
                    message=f"Sequence '{s}' migrated intact", pd_value=s, erwin_value=s)
    for s in sorted(set(pd_keys) - set(erwin_keys)):
        result.emit("SEQUENCE_MISSING", category="SEQUENCE", table=s,
                    message=f"Sequence '{s}' in PowerDesigner is missing from ERwin", pd_value=s, erwin_value="—")
    for s in sorted(set(erwin_keys) - set(pd_keys)):
        result.emit("SEQUENCE_EXTRA", category="SEQUENCE", table=s,
                    message=f"Sequence '{s}' exists in ERwin only", pd_value="—", erwin_value=s)


def _compare_tablespaces(result: ValidationResult, pd_model: Dict[str, Any], erwin_model: Dict[str, Any]) -> None:
    if not getattr(config, "CHECK_TABLESPACES", True):
        return
    pd_ts = pd_model.get("tablespaces", {}) or {}
    erwin_ts = erwin_model.get("tablespaces", {}) or {}
    pd_keys = {_key(k): v for k, v in pd_ts.items()}
    erwin_keys = {_key(k): v for k, v in erwin_ts.items()}
    for ts in sorted(set(pd_keys) & set(erwin_keys)):
        result.emit("TABLESPACE_VERIFIED", category="TABLESPACE", table=ts,
                    message=f"Tablespace '{ts}' migrated intact", pd_value=ts, erwin_value=ts)
    for ts in sorted(set(pd_keys) - set(erwin_keys)):
        result.emit("TABLESPACE_MISSING", category="TABLESPACE", table=ts,
                    message=f"Tablespace '{ts}' in PowerDesigner is missing from ERwin", pd_value=ts, erwin_value="—")
    for ts in sorted(set(erwin_keys) - set(pd_keys)):
        result.emit("TABLESPACE_EXTRA", category="TABLESPACE", table=ts,
                    message=f"Tablespace '{ts}' exists in ERwin only", pd_value="—", erwin_value=ts)


def _compare_packages(result: ValidationResult, pd_model: Dict[str, Any], erwin_model: Dict[str, Any]) -> None:
    if not getattr(config, "CHECK_PACKAGES", True):
        return
    pd_pkgs = pd_model.get("packages", {}) or {}
    erwin_pkgs = erwin_model.get("packages", {}) or {}
    pd_keys = {_key(k): v for k, v in pd_pkgs.items()}
    erwin_keys = {_key(k): v for k, v in erwin_pkgs.items()}
    for pkg in sorted(set(pd_keys) & set(erwin_keys)):
        result.emit("PACKAGE_VERIFIED", category="PACKAGE", table=pkg,
                    message=f"Package '{pkg}' migrated intact", pd_value=pkg, erwin_value=pkg)
    for pkg in sorted(set(pd_keys) - set(erwin_keys)):
        result.emit("PACKAGE_MISSING", category="PACKAGE", table=pkg,
                    message=f"Package '{pkg}' in PowerDesigner is missing from ERwin", pd_value=pkg, erwin_value="—")
    for pkg in sorted(set(erwin_keys) - set(pd_keys)):
        result.emit("PACKAGE_EXTRA", category="PACKAGE", table=pkg,
                    message=f"Package '{pkg}' exists in ERwin only", pd_value="—", erwin_value=pkg)


def compare(pd_model: Dict[str, Any], erwin_model: Dict[str, Any]) -> ValidationResult:
    result = ValidationResult(
        pd_file=pd_model.get("source_file", ""),
        erwin_file=erwin_model.get("source_file", ""),
        pd_model=pd_model.get("model_name", ""),
        erwin_model=erwin_model.get("model_name", ""),
    )

    if _parse_error_result(result, pd_model, "PD"):
        return result
    if _parse_error_result(result, erwin_model, "ERwin"):
        return result

    pd_tables = pd_model.get("tables", {})
    erwin_tables = erwin_model.get("tables", {})
    pd_keys = {_key(k): v for k, v in pd_tables.items()}
    erwin_keys = {_key(k): v for k, v in erwin_tables.items()}

    _report_duplicate_tables(result, pd_model, erwin_model)
    _set_model_counts(result, pd_keys, erwin_keys)
    _compare_table_presence(result, pd_keys, erwin_keys)
    _compare_all_matched_tables(result, pd_keys, erwin_keys)

    if getattr(config, "CHECK_FOREIGN_KEYS", True):
        _compare_foreign_keys(result, pd_model.get("references", []),
                              erwin_model.get("references", []))

    _compare_views(result, pd_model, erwin_model)
    _compare_procedures_and_functions(result, pd_model, erwin_model)
    _compare_triggers(result, pd_model, erwin_model)
    _compare_sequences(result, pd_model, erwin_model)
    _compare_tablespaces(result, pd_model, erwin_model)
    _compare_packages(result, pd_model, erwin_model)

    if result.datatype_classifications:
        result.datatype_fidelity_pct = datatype_fidelity_pct(result.datatype_classifications)

    # Extended property checks (owner, tablespace, identity, check constraints,
    # RI rules, index/key/reference names, view columns, trigger events,
    # sequence parameters, domains/rules/defaults/DBMS target ...): additive
    # INFO findings read straight from the two XML files, before scoring.
    if config is not None:
        try:
            from app.validation import extended_properties
            extended_properties.apply(result, "pdm", config)
        except Exception as exc:                       # pragma: no cover - standalone use
            logger.warning("extended property checks unavailable: %s", exc)

    result.compute_status()
    result.compute_score()

    # ─── UDP FIDELITY ─────────────────────────────────────────────────────────
    # Added by the UDP integration. Scores SAP PD Extended Attributes against
    # the UDPs the erwin export carries and blends the result into the fidelity
    # score, preserving the reconciliation number on
    # result.structural_fidelity_score. Runs AFTER the score is computed, so it
    # cannot influence a single finding, and it never raises.
    if udp_fidelity is not None:
        udp_fidelity.apply(result, "PDM")
    return result
