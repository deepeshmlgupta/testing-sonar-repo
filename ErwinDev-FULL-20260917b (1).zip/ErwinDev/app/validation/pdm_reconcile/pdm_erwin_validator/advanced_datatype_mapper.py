"""
Advanced / Vendor-Specific Data Type Intelligence (Workstream 7)
==================================================================
Extends ``data_type_mapper.py``'s family/canonical comparison with an
explicit registry of vendor-specific and advanced data types (Oracle
XMLTYPE/JSON, SQL Server CLR types, PostgreSQL JSONB/arrays/PostGIS, DB2
structured types, generic UDTs, …) that a length/precision-based normalizer
cannot classify on its own.

Consulted only as a FALLBACK, after the base mapper's own
``classify_type_match`` has already failed to find a match — this module
never overrides an already-successful classification.
"""

import os
from dataclasses import dataclass
from typing import Dict, List, Optional

_REGISTRY_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              "datatype_registry.yaml")

# Fallback registry used when PyYAML is unavailable, or the YAML file is
# missing/unreadable, so this module degrades gracefully rather than failing
# the whole comparator import.
_FALLBACK_REGISTRY: Dict[str, List[dict]] = {
    "oracle": [
        {"pd": ["XMLTYPE"], "erwin": ["XMLTYPE", "XML"], "classification": "EXACT"},
        {"pd": ["JSON"], "erwin": ["JSON", "BLOB", "CLOB"], "classification": "COMPATIBLE"},
        {"pd": ["SDO_GEOMETRY"], "erwin": ["SDO_GEOMETRY"], "classification": "EXACT"},
        {"pd": ["UROWID", "ROWID"], "erwin": ["UROWID", "ROWID", "VARCHAR2"], "classification": "CONVERTIBLE"},
    ],
    "sqlserver": [
        {"pd": ["HIERARCHYID"], "erwin": ["HIERARCHYID", "VARBINARY"], "classification": "COMPATIBLE"},
        {"pd": ["SQL_VARIANT"], "erwin": ["SQL_VARIANT"], "classification": "EXACT"},
        {"pd": ["GEOGRAPHY"], "erwin": ["GEOGRAPHY"], "classification": "EXACT"},
        {"pd": ["GEOMETRY"], "erwin": ["GEOMETRY"], "classification": "EXACT"},
        {"pd": ["ROWVERSION", "TIMESTAMP"], "erwin": ["ROWVERSION", "BINARY"], "classification": "COMPATIBLE"},
    ],
    "postgresql": [
        {"pd": ["JSONB"], "erwin": ["JSONB", "JSON"], "classification": "COMPATIBLE"},
        {"pd": ["ARRAY", "INTEGER[]", "TEXT[]", "VARCHAR[]"], "erwin": ["ARRAY", "TEXT"], "classification": "CONVERTIBLE"},
        {"pd": ["GEOMETRY", "GEOGRAPHY"], "erwin": ["GEOMETRY", "GEOGRAPHY", "BYTEA"], "classification": "COMPATIBLE"},
        {"pd": ["HSTORE"], "erwin": ["HSTORE", "JSONB"], "classification": "CONVERTIBLE"},
    ],
    "db2": [
        {"pd": ["STRUCTURED TYPE", "STRUCTURED_TYPE"], "erwin": ["STRUCTURED TYPE", "VARCHAR"], "classification": "CONVERTIBLE"},
        {"pd": ["DECFLOAT"], "erwin": ["DECFLOAT", "DECIMAL"], "classification": "COMPATIBLE"},
    ],
    "generic": [
        {"pd": ["UDT", "USER DEFINED TYPE", "USER_DEFINED_TYPE"], "erwin": ["UDT", "USER DEFINED TYPE"], "classification": "EXACT"},
    ],
}

_WEIGHTS = {"EXACT": 1.0, "COMPATIBLE": 0.75, "CONVERTIBLE": 0.5, "UNSUPPORTED": 0.0}


def _load_registry() -> Dict[str, List[dict]]:
    try:
        import yaml  # optional dependency
    except ImportError:
        return _FALLBACK_REGISTRY
    try:
        with open(_REGISTRY_PATH, "r", encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}
        vendor_types = data.get("vendor_types")
        return vendor_types if vendor_types else _FALLBACK_REGISTRY
    except (OSError, ValueError):
        return _FALLBACK_REGISTRY


_REGISTRY = _load_registry()


def _base_type(raw: str) -> str:
    """Strip length/precision, e.g. 'VARCHAR2(4000)' -> 'VARCHAR2'."""
    text = (raw or "").strip().upper()
    paren = text.find("(")
    return text[:paren].strip() if paren != -1 else text


@dataclass
class DatatypeClassification:
    category:      str = "UNSUPPORTED"   # EXACT | COMPATIBLE | CONVERTIBLE | UNSUPPORTED
    vendor:        str = ""
    matched_rule:  str = ""
    fidelity_weight: float = 0.0


def classify(pd_type: str, erwin_type: str) -> DatatypeClassification:
    """
    Classify a PD/erwin data type pair against the vendor-specific registry.

    Returns ``UNSUPPORTED`` (weight 0.0) when neither side's base type is a
    recognised vendor-specific/advanced type — the caller should then keep
    whatever the base ``data_type_mapper`` already decided.
    """
    pd_base = _base_type(pd_type)
    erwin_base = _base_type(erwin_type)
    if not pd_base:
        return DatatypeClassification()

    for vendor, rules in _REGISTRY.items():
        for rule in rules:
            pd_candidates = {c.upper() for c in rule.get("pd", [])}
            if pd_base not in pd_candidates:
                continue
            erwin_candidates = {c.upper() for c in rule.get("erwin", [])}
            if erwin_base in erwin_candidates or pd_base == erwin_base:
                category = rule.get("classification", "UNSUPPORTED")
                return DatatypeClassification(
                    category=category, vendor=vendor,
                    matched_rule=f"{pd_base} -> {erwin_base}",
                    fidelity_weight=_WEIGHTS.get(category, 0.0),
                )
            # PD side recognised as vendor-specific but erwin side isn't the
            # documented equivalent: still UNSUPPORTED, but distinguishable
            # from "not a vendor type at all" via the matched_rule text.
            return DatatypeClassification(
                category="UNSUPPORTED", vendor=vendor,
                matched_rule=f"{pd_base} has no equivalent for '{erwin_base}'",
                fidelity_weight=0.0,
            )

    return DatatypeClassification()


def datatype_fidelity_pct(classifications: List[DatatypeClassification]) -> Optional[float]:
    """
    Aggregate 'Datatype Fidelity %' across a batch of classifications.

    Returns ``None`` when the list is empty, so a model with nothing to
    classify is reported as "not measured" rather than a misleading 0%/100%.
    """
    if not classifications:
        return None
    total_weight = sum(c.fidelity_weight for c in classifications)
    return round(100.0 * total_weight / len(classifications), 2)
