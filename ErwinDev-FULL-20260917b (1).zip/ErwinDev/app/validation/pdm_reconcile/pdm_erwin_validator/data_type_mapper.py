"""
Data Type Normalization
-----------------------
Both PowerDesigner and ERwin may store the same logical type with slightly
different strings.  This module normalises both sides to a canonical form
before comparison so trivial differences (INT vs INTEGER, VARCHAR vs
VARCHAR2) don't produce false failures.
"""

import re

# ─── CANONICAL TYPE MAP ───────────────────────────────────────────────────────
# Each key maps to the canonical name.  Aliases of the same type share one key.
_TYPE_ALIASES = {
    # Integer variants
    "int":          "INTEGER",
    "integer":      "INTEGER",
    "int4":         "INTEGER",
    "int8":         "BIGINT",
    "bigint":       "BIGINT",
    "smallint":     "SMALLINT",
    "int2":         "SMALLINT",
    "tinyint":      "TINYINT",
    "byteint":      "TINYINT",

    # Numeric / Decimal
    "number":       "NUMERIC",
    "numeric":      "NUMERIC",
    "decimal":      "NUMERIC",
    "dec":          "NUMERIC",
    "float":        "FLOAT",
    "float4":       "FLOAT",
    "float8":       "DOUBLE",
    "double":       "DOUBLE",
    "double precision": "DOUBLE",
    "real":         "FLOAT",
    "money":        "MONEY",
    "smallmoney":   "MONEY",

    # Boolean
    "boolean":      "BOOLEAN",
    "bool":         "BOOLEAN",
    "bit":          "BOOLEAN",

    # Character
    "char":         "CHAR",
    "character":    "CHAR",
    "characters":   "CHAR",
    "nchar":        "NCHAR",
    "varchar":      "VARCHAR",
    "varchar2":     "VARCHAR",
    "character varying": "VARCHAR",
    "variable character": "VARCHAR",
    "variable characters": "VARCHAR",
    "nvarchar":     "NVARCHAR",
    "nvarchar2":    "NVARCHAR",
    "national character varying": "NVARCHAR",
    "text":         "TEXT",
    "ntext":        "NTEXT",
    "longtext":     "TEXT",
    "clob":         "CLOB",
    "nclob":        "NCLOB",
    "long":         "CLOB",
    "long characters": "CLOB",

    # Binary
    "binary":       "BINARY",
    "varbinary":    "VARBINARY",
    "raw":          "VARBINARY",
    "long raw":     "BLOB",
    "blob":         "BLOB",
    "image":        "BLOB",

    # Date / Time
    "date":         "DATE",
    "time":         "TIME",
    "datetime":     "DATETIME",
    "datetime2":    "DATETIME",
    "timestamp":    "TIMESTAMP",
    "smalldatetime":"DATETIME",

    # Other
    "uniqueidentifier": "UUID",
    "guid":         "UUID",
    "uuid":         "UUID",
    "xml":          "XML",
    "json":         "JSON",
    "jsonb":        "JSON",
}


def _split_type_and_precision(dtype: str):
    """
    Split 'VARCHAR(100)' → ('varchar', '100')
    Split 'NUMERIC(18,4)' → ('numeric', '18,4')
    Split 'INTEGER'       → ('integer', '')
    """
    dtype = dtype.strip()
    m = re.match(r"^([a-zA-Z]\w*(?:[ \t]+\w+)*)\s*(?:\(([^)]*)\))?$", dtype)
    if m:
        base = m.group(1).strip().lower()
        prec = (m.group(2) or "").strip()
        return base, prec
    return dtype.lower(), ""


def normalize(dtype: str) -> str:
    """
    Return a normalised data type string for comparison.
    Examples
    --------
    normalize("VARCHAR2(100)")  → "VARCHAR(100)"
    normalize("NUMBER(18,4)")   → "NUMERIC(18,4)"
    normalize("INT")            → "INTEGER"
    normalize("FLOAT(24)")      → "FLOAT(24)"
    """
    if not dtype:
        return ""

    base, prec = _split_type_and_precision(dtype)
    canonical = _TYPE_ALIASES.get(base, base.upper())

    if prec:
        return f"{canonical}({prec})"
    return canonical


def _semantic_numeric_equivalent(base1: str, prec1: str, base2: str, prec2: str) -> bool:
    """Check if NUMBER(18,0)/NUMERIC(18,0) matches BIGINT/INTEGER."""
    if base1 in ("NUMERIC", "NUMBER", "DECIMAL"):
        dim_parts = [p.strip() for p in prec1.split(",") if p.strip()]
        length = int(dim_parts[0]) if dim_parts and dim_parts[0].isdigit() else 0
        scale = int(dim_parts[1]) if len(dim_parts) > 1 and dim_parts[1].isdigit() else 0
        if scale == 0 and length > 0:
            if length in (18, 19, 20) and base2 in ("BIGINT", "INTEGER"):
                return True
            if length in (5, 6, 7, 8, 9, 10, 11) and base2 in ("INTEGER", "BIGINT"):
                return True
            if length in (3, 4) and base2 in ("SMALLINT", "INTEGER"):
                return True
            if length in (1, 2) and base2 in ("TINYINT", "SMALLINT", "INTEGER"):
                return True
    return False


def classify_type_match(dtype_pd: str, dtype_erwin: str) -> tuple:
    """
    Classify the match status between two physical data types:
    Returns (category, is_match)
      - TYPE_EXACT_MATCH: identical raw or direct normalized match
      - TYPE_CANONICAL_MATCH: canonical alias match
      - TYPE_SEMANTIC_MATCH: semantic equivalence (NUMBER(18,0) == BIGINT)
      - TYPE_MISMATCH: incompatible types
    """
    pd_clean = (dtype_pd or "").strip()
    erwin_clean = (dtype_erwin or "").strip()

    if not pd_clean and not erwin_clean:
        return "TYPE_EXACT_MATCH", True
    if not pd_clean or not erwin_clean:
        return "TYPE_MISMATCH", False

    if pd_clean.lower() == erwin_clean.lower():
        return "TYPE_EXACT_MATCH", True

    norm_pd = normalize(dtype_pd)
    norm_erwin = normalize(dtype_erwin)

    if norm_pd == norm_erwin:
        return "TYPE_CANONICAL_MATCH", True

    b1, p1 = _split_type_and_precision(dtype_pd)
    b2, p2 = _split_type_and_precision(dtype_erwin)
    c1 = _TYPE_ALIASES.get(b1, b1.upper())
    c2 = _TYPE_ALIASES.get(b2, b2.upper())

    if _semantic_numeric_equivalent(c1, p1, c2, p2) or _semantic_numeric_equivalent(c2, p2, c1, p1):
        return "TYPE_SEMANTIC_MATCH", True

    return "TYPE_MISMATCH", False


def types_match(dtype_pd: str, dtype_erwin: str) -> bool:
    """Return True if the two data type strings are equivalent after normalisation."""
    _, is_match = classify_type_match(dtype_pd, dtype_erwin)
    return is_match


# ─── SQL FIDELITY & SEMANTIC NORMALIZATION ────────────────────────────────────

def normalize_sql(sql: str) -> str:
    """
    Normalize SQL text for semantic comparison:
    - Strips line/block comments
    - Collapses whitespace
    - Normalizes quotes/brackets around identifiers
    - Converts keywords/text to case-normalized format
    """
    if not sql:
        return ""
    text = str(sql)
    # Remove single line comments
    text = re.sub(r"--.*?$", "", text, flags=re.MULTILINE)
    # Remove block comments
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.DOTALL)
    # Remove schema bracket/backtick quoting: [dbo].[table] -> dbo.table
    text = re.sub(r"[\[\]`\"]", "", text)
    # Collapse all whitespace and newlines to single space
    text = re.sub(r"\s+", " ", text).strip().upper()
    return text


#: Similarity at or above which two normalised SQL bodies are treated as the
#: same definition. COVERAGE_MATRIX.md and FINAL_AUDIT.md both name
#: SQL_SIMILARITY_THRESHOLD as the knob to turn for literal fidelity, but it
#: existed in no config file and the 0.90 was hard-coded here, so the
#: documented remediation did nothing. It is now read from the PDM tier config
#: (app/config/validation_config.py) with this as the fallback.
DEFAULT_SQL_SIMILARITY_THRESHOLD = 0.90

#: Returned when NEITHER side carries any SQL. This is not a match: there is
#: nothing to compare, and reporting it as a 100% match is the same inflation
#: as scoring an unreadable erwin read-back as a measured 0% — a number
#: invented where a measurement is missing. The similarity is None, never 1.0,
#: so a caller cannot average it into a fidelity figure by accident.
SQL_NOT_COMPARED = "SQL_NOT_COMPARED"


def sql_similarity_threshold() -> float:
    """The configured match threshold, clamped to a sane range."""
    try:
        from app.config.validation_config import PDM_CONFIG
        value = float(getattr(PDM_CONFIG, "SQL_SIMILARITY_THRESHOLD",
                              DEFAULT_SQL_SIMILARITY_THRESHOLD))
    except (ImportError, TypeError, ValueError):
        return DEFAULT_SQL_SIMILARITY_THRESHOLD
    return min(1.0, max(0.0, value))


def compare_sql(sql_pd: str, sql_erwin: str) -> tuple:
    """
    Compare two SQL queries/definitions.

    Returns (status, similarity, message), where similarity is a float 0..1 —
    or None for SQL_NOT_COMPARED, which means no SQL existed on either side.

      - SQL_EXACT_MATCH       identical, or identical after normalisation
      - SQL_NORMALIZED_MATCH  equivalent at or above the configured threshold
      - SQL_MISMATCH          differs, or present on one side only
      - SQL_NOT_COMPARED      absent from both sides — nothing was measured
    """
    raw_pd = (sql_pd or "").strip()
    raw_erwin = (sql_erwin or "").strip()

    if not raw_pd and not raw_erwin:
        return (SQL_NOT_COMPARED, None,
                "no SQL definition on either side — nothing to compare")
    if not raw_pd or not raw_erwin:
        side = "ERwin" if raw_pd else "PowerDesigner"
        return "SQL_MISMATCH", 0.0, f"SQL definition missing on the {side} side"

    if raw_pd == raw_erwin:
        return "SQL_EXACT_MATCH", 1.0, "SQL definition identical"

    norm_pd = normalize_sql(raw_pd)
    norm_erwin = normalize_sql(raw_erwin)

    if norm_pd == norm_erwin:
        return "SQL_NORMALIZED_MATCH", 1.0, "SQL definition matches after formatting/whitespace normalization"

    import difflib
    threshold = sql_similarity_threshold()
    sim = difflib.SequenceMatcher(None, norm_pd, norm_erwin).ratio()
    if sim >= threshold:
        return "SQL_NORMALIZED_MATCH", sim, (
            f"SQL definition highly equivalent ({sim:.1%} similarity, "
            f"threshold {threshold:.0%})")
    return "SQL_MISMATCH", sim, (
        f"SQL definition differs ({sim:.1%} similarity, threshold {threshold:.0%})")
