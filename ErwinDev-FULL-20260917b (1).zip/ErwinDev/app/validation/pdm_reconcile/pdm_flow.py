"""
PDM Reconciliation Flow
=======================
The PDM half of Phase D, kept in its own module so it can be exercised without
starting erwin (the COM automation in ``app/erwin`` only runs on Windows).

The flow implements the promotion gate:

    1_initial ──validate (V1)──▶ complete? ──yes─┐
                             │                    │
                             no                   │
                             ▼                    │
                        preprocess  (remediation)  │
                             │                    │
                             ▼                    │
                      2_preprocessed ──validate (V2)──▶ [merge] ◀┘
                                                         │
                                                         ▼
                                        final validated XML present?
                                          ──validate (V3, authoritative)──▶
                                                         │
                                          complete? ──yes──▶ 3_final
                                                         │
                                                         no
                                                         ▼
                                            manual_review / 2_preprocessed

V3 always runs LAST, after any remediation — the same ordering CDM/LDM use
(V1 -> UDP -> V2 -> V3) — so promotion is never decided ahead of migration.
A model is only ever promoted on a *measured* fidelity — the validation pass
reads whatever XML it is measuring back off disk rather than trusting what
preprocessing believes it changed.
"""

import logging
import os
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

# Stage folder names are aliases of the canonical ones in stage_paths (which in
# turn read settings), so a renamed stage folder cannot drift between the PDM
# flow and the rest of the pipeline.
from app.orchestration.stage_paths import FINAL_DIRNAME as STAGE_FINAL
from app.orchestration.stage_paths import INITIAL_DIRNAME as STAGE_INITIAL
from app.orchestration.stage_paths import PREPROCESSED_DIRNAME as STAGE_PREPROCESSED
from app.preprocessing import pdm_preprocessor
from app.utils.manual_export_wait import validate_erwin_xml, wait_for_manual_export

# Migration framework additions: staged V1/V2/V3 scoring and the shared
# >=90% PASS / <90% FAIL routing.
from app.validation import fidelity_stages, promotion_gate
from app.validation.pdm_reconcile import pdm_validator_bridge as bridge

logger = logging.getLogger(__name__)

STAGE_MANUAL_REVIEW = "manual_review"  # <model>/manual_review_report


@dataclass
class PdmFlowOutcome:
    """Everything the pipeline needs to know about one PDM model."""
    model_name: str
    pdm_path: str = ""
    initial_result: Any = None
    final_result: Any = None
    preprocess_report: Optional[pdm_preprocessor.PreprocessReport] = None
    preprocessed: bool = False
    comment_injection: Any = None          # MigrateResult from Step 1, when it ran
    final_xml_validated: bool = False      # V3 was measured against a validated XML V3 export
    waiting_for_final_xml: bool = False    # require_final_xml and no XML V3 export yet: gate not evaluated
    promoted: bool = False
    stage: str = STAGE_INITIAL
    artifacts: Dict[str, str] = field(default_factory=dict)
    messages: List[str] = field(default_factory=list)

    @property
    def initial_fidelity(self) -> float:
        return getattr(self.initial_result, "fidelity_score", 0.0)

    @property
    def final_fidelity(self) -> float:
        return getattr(self.final_result, "fidelity_score", 0.0)

    @property
    def status(self) -> str:
        return getattr(self.final_result, "status", "ERROR")


def _move(source: str, target: str) -> str:
    """Move a file, replacing any previous copy at the destination."""
    os.makedirs(os.path.dirname(os.path.abspath(target)), exist_ok=True)
    if os.path.abspath(source) == os.path.abspath(target):
        return target
    if os.path.exists(target):
        os.remove(target)
    shutil.move(source, target)
    return target


def _copy(source: str, target: str) -> str:
    os.makedirs(os.path.dirname(os.path.abspath(target)), exist_ok=True)
    shutil.copy2(source, target)
    return target


def _stamp(outcome: "PdmFlowOutcome", pd_model=None, erwin_xml: str = "") -> "PdmFlowOutcome":
    """
    Carry the flow's own context onto the result object the report reads.

    The validator's ValidationResult knows nothing about staging or promotion —
    those are this module's concepts — so the report would otherwise have no way
    to show WHY a 99% model was not promoted. The parsed models ride along too,
    so the report's matrix sheets cost no second parse.
    """
    result = outcome.final_result
    if result is None:
        return outcome
    result.stage = outcome.stage
    result.promoted = outcome.promoted
    result.flow_notes = " | ".join(outcome.messages)

    # The workbook is built from the FINAL result only, so everything the raw
    # erwin import actually lost — the columns preprocessing then put back —
    # used to be invisible: a model that imported with seven dropped columns
    # and two emptied primary keys produced a report showing none of that.
    # Carry the as-imported result and the remediation log through so the
    # report can show what the migration did before it was repaired.
    result.initial_result = outcome.initial_result
    result.preprocess_report = outcome.preprocess_report
    if pd_model is not None:
        # The erwin side is whichever XML produced this result.
        try:
            erwin_model = bridge.parse_erwin(erwin_xml) if erwin_xml else None
        except Exception:                                      # noqa: BLE001
            erwin_model = None
        result.source_models = {"pd": pd_model, "erwin": erwin_model}
    return outcome


def _gate_failures(result, target_fidelity: float) -> List[str]:
    """
    Every reason this model must NOT be promoted automatically. Empty = promote.

    The gate used to be one line: ``fidelity_score >= target``. Three things
    were wrong with it, and each of them promotes a defective model:

    1. ``fidelity_score`` is rounded to 2 decimal places. The penalty for one
       defect is divided by the number of comparable objects, so on a large
       physical model the defect vanishes into the rounding: one INFO finding
       across 1000 objects scores 99.995% and displays — and compared — as
       100.00%. At 20 000 objects even a CRITICAL finding rounds to 100.00%.
       The raw score is used here instead.
    2. Nothing looked at the findings. A model could carry CRITICAL findings
       (a dropped table, a lost primary key) and still pass on the number
       alone. The LDM/CDM route in app/main.py has always required
       ``status == "PASS" and critical_count == 0``; the PDM route did not.
    3. Nothing checked that the report's own arithmetic held. If the counts do
       not reconcile the fidelity score is computed over a denominator that
       does not describe the model, so the number means nothing.

    A model with WARNING findings and no CRITICAL ones is deliberately NOT
    auto-promoted: warnings are the human-sign-off path through
    app/promote_model.py, which re-validates before it copies anything.
    """
    if result is None:
        return ["no validation result"]
    if getattr(result, "status", "") == "ERROR":
        return ["validation ended in ERROR"]

    failures: List[str] = []

    # Whether findings block promotion outright is now a setting, so the
    # ">= PROMOTION_FIDELITY_THRESHOLD means PASS" rule holds for PDM exactly as
    # it does for CDM and LDM. Set PROMOTION_BLOCK_ON_CRITICAL /
    # PROMOTION_BLOCK_ON_WARNING to True in app/config/settings.py to restore
    # the previous behaviour, where any finding held the model back.
    critical = int(getattr(result, "critical_count", 0) or 0)
    if critical and promotion_gate.blocks_on_critical():
        failures.append(f"{critical} CRITICAL finding(s)")

    warning = int(getattr(result, "warning_count", 0) or 0)
    if warning and promotion_gate.blocks_on_warning():
        failures.append(f"{warning} WARNING finding(s) awaiting human sign-off")

    raw = float(getattr(result, "fidelity_score_raw",
                        getattr(result, "fidelity_score", 0.0)))
    if raw < float(target_fidelity):
        failures.append(f"measured fidelity {raw:.4f}% is below the "
                        f"{float(target_fidelity):.2f}% target")

    # A component dropped for want of evidence renormalises the remaining
    # weights, so a PDM whose .erwin was never handed off scored exactly like
    # one that migrated perfectly and was promoted on the number alone. Same
    # rule and same implementation as the CDM/LDM gate.
    if promotion_gate._setting("PROMOTION_BLOCK_ON_UNVERIFIED",
                               promotion_gate.DEFAULT_BLOCK_ON_UNVERIFIED):
        failures.extend(promotion_gate.unverified_failures(result))

    errors = getattr(result, "reconciliation_errors", None)
    if callable(errors):
        broken = errors()
        if broken:
            failures.append("reported counts do not reconcile (" +
                            "; ".join(broken) + ")")

    return failures


def _is_complete(result, target_fidelity: float) -> bool:
    """True only when nothing blocks automatic promotion."""
    return not _gate_failures(result, target_fidelity)


def _missing_input(pdm_path: str, initial_xml: str,
                   wait_seconds: int = 0, poll_interval: float = 5.0) -> str:
    """
    Why the flow cannot start, or "" when both inputs are present and the
    erwin export is well-formed.

    ``wait_seconds`` <= 0 preserves the original one-shot check. A positive
    value polls for the manually produced export before giving up, so an
    operator can start the batch and export while it runs.
    """
    if not os.path.exists(pdm_path):
        return f"PowerDesigner model not found: {pdm_path}"

    def _on_wait(path, remaining):
        logger.info("  ... waiting for manual erwin export of %s (%ds remaining)",
                    path, int(remaining))

    if not wait_for_manual_export(Path(initial_xml), wait_seconds, poll_interval, _on_wait):
        return (f"erwin XML export not found: {initial_xml}. "
                "Phase B must produce the XML before reconciliation can run.")

    valid, error = validate_erwin_xml(Path(initial_xml))
    if not valid:
        return f"erwin XML export invalid, please re-export: {initial_xml} ({error})"

    return ""


def _log_pass(pass_number: int, result) -> None:
    logger.info("  pass %d → status=%s fidelity=%.2f%% (critical=%d warning=%d info=%d)",
                pass_number, result.status, result.fidelity_score,
                result.critical_count,
                result.warning_count,
                result.info_count)


def _validate_initial(outcome: "PdmFlowOutcome", pdm_path: str, initial_xml: str,
                      initial_erwin: str, model_name: str):
    """Pass 1: validate the raw import; returns the parsed PD model."""
    logger.info("PDM validation (pass 1): %s", model_name)
    pd_model = bridge.parse_pdm(pdm_path)
    outcome.initial_result = bridge.validate_pair(pdm_path, initial_xml)
    # V1: the raw erwin export, before any remediation or enrichment.
    fidelity_stages.apply(outcome.initial_result, fidelity_stages.STAGE_V1,
                          model_type="PDM")
    outcome.final_result = outcome.initial_result
    outcome.artifacts["initial_xml"] = initial_xml
    if os.path.exists(initial_erwin):
        outcome.artifacts["initial_erwin"] = initial_erwin

    _log_pass(1, outcome.initial_result)
    return pd_model


def validate_initial_only(pdm_path: str, initial_xml: str, initial_erwin: str,
                          manual_export_wait_seconds: int = 0,
                          manual_export_poll_interval: float = 5.0) -> PdmFlowOutcome:
    """
    V1 only: validate the raw import and stop, for a V1-only pipeline run.

    Used when V1, the UDP phase and V3 are run as separate scripts with
    manual steps in between; ``run_pdm_flow`` remains the all-in-one entry
    point for a single-pass run.
    """
    model_name = os.path.splitext(os.path.basename(pdm_path))[0]
    outcome = PdmFlowOutcome(model_name=model_name, pdm_path=pdm_path)

    missing = _missing_input(pdm_path, initial_xml,
                             manual_export_wait_seconds, manual_export_poll_interval)
    if missing:
        outcome.messages.append(missing)
        logger.error(outcome.messages[-1])
        return outcome

    pd_model = _validate_initial(outcome, pdm_path, initial_xml, initial_erwin, model_name)
    return _stamp(outcome, pd_model, initial_xml)



def _promote_from_initial(outcome: "PdmFlowOutcome", initial_xml: str, initial_erwin: str,
                          final_xml: str, final_erwin: str) -> None:
    """Already perfect: promote straight from 1_initial."""
    logger.info("  fidelity target met on import; promoting to %s", STAGE_FINAL)
    outcome.artifacts["final_xml"] = _copy(initial_xml, final_xml)
    if os.path.exists(initial_erwin):
        outcome.artifacts["final_erwin"] = _copy(initial_erwin, final_erwin)
    outcome.promoted = True
    outcome.stage = STAGE_FINAL
    outcome.messages.append(
        f"Fidelity {outcome.initial_result.fidelity_score:.2f}% on import; "
        f"promoted to {STAGE_FINAL} without preprocessing.")


def _run_preprocessing(outcome: "PdmFlowOutcome", pd_model, model_name: str,
                       initial_xml: str, initial_erwin: str,
                       preprocessed_xml: str, preprocessed_erwin: str,
                       target_fidelity: float):
    """Preprocess into 2_preprocessed; returns the preprocessing report."""
    logger.info("  fidelity %.2f%% below target %.2f%%; applying preprocessing",
                outcome.initial_result.fidelity_score, target_fidelity)
    report = pdm_preprocessor.preprocess_model(
        pd_model=pd_model,
        result=outcome.initial_result,
        source_xml=initial_xml,
        target_xml=preprocessed_xml,
        source_erwin=initial_erwin,
        target_erwin=preprocessed_erwin,
        validator_config=bridge.get_config(),
        model_name=model_name,
    )
    outcome.preprocess_report = report
    outcome.preprocessed = True
    outcome.stage = STAGE_PREPROCESSED
    outcome.artifacts["preprocessed_xml"] = preprocessed_xml
    if os.path.exists(preprocessed_erwin):
        outcome.artifacts["preprocessed_erwin"] = preprocessed_erwin
    logger.info("  preprocessing → %s", report.summary())
    return report


def _inject_comments(outcome: "PdmFlowOutcome", pdm_path: str, initial_xml: str,
                     preprocessed_xml: str):
    """
    Step 1 for a PDM: write the PD Comments of tables, columns, views,
    procedures / functions, triggers, sequences and tablespaces into erwin
    Notes, exactly as the CDM / LDM orchestrator does for entities and
    attributes. The result lands in 2_preprocessed/<model>.xml; structural
    remediation (when the gate needs it) then works on that file so the notes
    survive. Returns the MigrateResult, or None when disabled / nothing to do.
    """
    if not getattr(bridge.get_config(), "PDM_COMMENT_INJECTION_ENABLED", True):
        return None
    try:
        from app.preprocessing.scripts.pd_comment_to_erwin_note import migrate_file
        result = migrate_file(pdm_path, initial_xml, preprocessed_xml,
                              author=str(getattr(bridge.get_config(), "PDM_COMMENT_AUTHOR", "Migration_Bot")))
    except Exception as exc:                                       # noqa: BLE001
        logger.warning("  comment injection skipped for %s: %s", outcome.model_name, exc)
        outcome.messages.append(f"Comment injection skipped: {exc}")
        return None
    outcome.comment_injection = result
    outcome.artifacts["preprocessed_xml"] = preprocessed_xml
    outcome.messages.append(f"Comments -> erwin Notes: {result.summary()}.")
    logger.info("  %s", outcome.messages[-1])
    return result


def _revalidate_after_comments(outcome: "PdmFlowOutcome", pdm_path: str, preprocessed_xml: str,
                               model_name: str, udp_pass_rate: Optional[float]) -> None:
    """V2 when only comments were injected (no structural remediation needed)."""
    logger.info("PDM validation (pass 2, comments only): %s", model_name)
    outcome.final_result = bridge.validate_pair(pdm_path, preprocessed_xml)
    fidelity_stages.carry_history(outcome.initial_result, outcome.final_result)
    for stage in (fidelity_stages.STAGE_V2, fidelity_stages.STAGE_V3):
        fidelity_stages.apply(outcome.final_result, stage,
                              udp_override=_udp_stage_override(outcome.final_result, udp_pass_rate),
                              model_type="PDM")
    _log_pass(2, outcome.final_result)
    outcome.stage = STAGE_PREPROCESSED


def _erwin_xml_carries_udps(result) -> bool:
    """
    Does the erwin XML this result was measured against carry THE MIGRATED
    UDPs? Shared by V2 and V3 so both stages apply the same rule: prefer the
    XML's own measured match rate when it genuinely carries the migration,
    otherwise fall back to the UDP engine's read-back evidence. Without this
    shared rule V2 and V3 can disagree even when the migration is identical.

    "Carries UDPs" means UDPs that CORRESPOND TO THE SAP PD ones — at least one
    matched value, or a UDP dictionary. Accepting any non-zero value count was
    a defect: an export holding values that all classify as "extra in erwin"
    (0 matched, 0 definitions) was enough to overrule a verified read-back and
    score the component 0%. See app/orchestration/udp_helpers for the LDM/CDM
    copy of this rule and the real_estate case that exposed it.
    """
    fidelity = getattr(result, "udp_fidelity", None)
    if fidelity is None:
        return False
    matched = int(getattr(fidelity, "udp_matched", 0) or 0)
    definitions = int(getattr(fidelity, "udp_definitions_erwin", 0) or 0)
    if matched or definitions:
        return True
    values = int(getattr(fidelity, "udp_values_erwin", 0) or 0)
    if values:
        logger.warning(
            "The erwin export holds %d UDP value(s) that match no SAP PD UDP "
            "(0 matched, 0 definitions); using the engine read-back instead.", values)
    return False


def _udp_stage_override(result, udp_pass_rate: Optional[float]) -> Optional[float]:
    return None if _erwin_xml_carries_udps(result) else udp_pass_rate


def _revalidate(outcome: "PdmFlowOutcome", pdm_path: str, preprocessed_xml: str,
                model_name: str, report,
                udp_pass_rate: Optional[float] = None) -> None:
    """Pass 2: re-validate what was actually written."""
    logger.info("PDM validation (pass 2): %s", model_name)
    outcome.final_result = bridge.validate_pair(pdm_path, preprocessed_xml)
    # Pass 2 is a fresh result: carry V1 across or the progression sheet loses it.
    fidelity_stages.carry_history(outcome.initial_result, outcome.final_result)
    # V2: after structural remediation, still against the XML export.
    fidelity_stages.apply(outcome.final_result, fidelity_stages.STAGE_V2,
                          udp_override=_udp_stage_override(outcome.final_result, udp_pass_rate),
                          model_type="PDM")
    # V3 is stamped here only as a fallback. When a final validated erwin XML
    # exists, _validate_final() re-reconciles against it and overwrites this,
    # so the gate tests the migration as actually delivered.
    fidelity_stages.apply(outcome.final_result, fidelity_stages.STAGE_V3,
                          udp_override=_udp_stage_override(outcome.final_result, udp_pass_rate),
                          model_type="PDM")
    _log_pass(2, outcome.final_result)

    gain = outcome.final_result.fidelity_score - outcome.initial_result.fidelity_score
    outcome.messages.append(
        f"Preprocessing applied ({report.summary()}); fidelity "
        f"{outcome.initial_result.fidelity_score:.2f}% → "
        f"{outcome.final_result.fidelity_score:.2f}% ({gain:+.2f}).")


def _validate_final(outcome: "PdmFlowOutcome", pdm_path: str,
                    final_validated_xml: str, model_name: str,
                    udp_pass_rate: Optional[float] = None) -> bool:
    """
    Pass 3: reconcile against the FINAL, manually validated erwin XML.

    This is the V3 measurement. The validated export carries the UDPs, comments
    and other constructs the raw import and the remediation pass were missing,
    so the whole reconciliation is re-run against it rather than the earlier
    result being re-scored. Returns False when no validated export exists, in
    which case the caller keeps the V2 result as before.
    """
    if not final_validated_xml or not os.path.exists(final_validated_xml):
        return False

    logger.info("PDM validation (pass 3, final validated XML): %s", model_name)
    previous = outcome.final_result
    result = bridge.validate_pair(pdm_path, final_validated_xml)
    if getattr(result, "status", "") == "ERROR":
        logger.warning("  final validated XML could not be validated; keeping pass 2.")
        outcome.messages.append(
            f"FAILED: XML V3 {os.path.basename(final_validated_xml)} could not be validated; V3 not measured.")
        return False
    if int(getattr(result, "tables_pd", 0) or 0) > 0 and int(getattr(result, "tables_matched", 0) or 0) == 0:
        # Not this model: an export of another model has no table in common
        # with the SAP source. Scoring it would attribute a stranger's fidelity
        # to this model, so it is refused rather than measured.
        outcome.messages.append(
            f"FAILED: XML V3 {os.path.basename(final_validated_xml)} has no table in common with the SAP PD "
            f"model — it belongs to a different model; V3 not measured.")
        logger.error("  %s", outcome.messages[-1])
        return False

    fidelity_stages.carry_history(outcome.initial_result, result)
    fidelity_stages.carry_history(previous, result)
    # The validated XML is the authority on UDPs. Only when it carries none is
    # the UDP engine's read-back used as the remaining evidence.
    override = _udp_stage_override(result, udp_pass_rate)

    fidelity_stages.apply(result, fidelity_stages.STAGE_V3,
                          udp_override=override, model_type="PDM")
    outcome.final_result = result
    outcome.final_xml_validated = True
    outcome.artifacts["final_validated_xml"] = final_validated_xml
    _log_pass(3, result)
    outcome.messages.append(
        f"V3 measured against the final validated erwin XML "
        f"({os.path.basename(final_validated_xml)}); fidelity "
        f"{result.fidelity_score:.2f}%.")
    return True


def _warn_if_binary_stale(outcome: "PdmFlowOutcome", report) -> None:
    """
    The XML that was validated is the one being promoted. The .erwin
    binary next to it is only a byte copy of the pre-remediation file
    unless erwin's COM API was available to regenerate it — so say so
    rather than letting a "promoted" model ship a binary that still
    lacks the restored columns.
    """
    if getattr(report, "erwin_binary_stale", False):
        outcome.messages.append(
            "WARNING: the promoted .erwin binary was carried forward "
            "unchanged and does NOT contain the remediation — only the "
            "XML does. Regenerate it on a Windows host with erwin Data "
            "Modeler before treating the binary as the final artefact.")
        logger.warning("  %s", outcome.messages[-1])


def _promote_after_preprocessing(outcome: "PdmFlowOutcome", report,
                                 preprocessed_xml: str, preprocessed_erwin: str,
                                 final_xml: str, final_erwin: str,
                                 keep_preprocessed_copy: bool) -> None:
    logger.info("  fidelity target met after preprocessing; promoting to %s",
                STAGE_FINAL)
    transfer = _copy if keep_preprocessed_copy else _move
    outcome.artifacts["final_xml"] = transfer(preprocessed_xml, final_xml)
    if os.path.exists(preprocessed_erwin):
        outcome.artifacts["final_erwin"] = transfer(preprocessed_erwin,
                                                    final_erwin)
    if not keep_preprocessed_copy:
        outcome.artifacts.pop("preprocessed_xml", None)
        outcome.artifacts.pop("preprocessed_erwin", None)
    outcome.promoted = True
    outcome.stage = STAGE_FINAL
    outcome.messages.append(f"Promoted to {STAGE_FINAL}.")
    _warn_if_binary_stale(outcome, report)


def _hold_for_review(outcome: "PdmFlowOutcome", target_fidelity: float,
                     preprocessed_xml: str = "", preprocessed_erwin: str = "",
                     manual_review_dir: str = "") -> None:
    """
    The model did not reach the promotion threshold.

    Two-band mode (the default) moves it and its .erwin binary into that
    model's own manual_review_report folder. Three-band mode keeps the previous
    behaviour and leaves it in 2_preprocessed for review.
    """
    blockers = _gate_failures(outcome.final_result, target_fidelity)

    if promotion_gate.bands_mode() == promotion_gate.BANDS_TWO:
        # Below the threshold the model files STAY in 2_preprocessed; only the
        # report/log are filed in the model's manual_review_report folder
        # (done by the report layer).  Nothing is moved here.
        outcome.stage = STAGE_MANUAL_REVIEW
        outcome.messages.append(
            f"FAIL — fidelity below the {target_fidelity:.2f}% threshold; "
            f"model left in {STAGE_PREPROCESSED} for review. "
            f"Blocked by: {'; '.join(blockers)}.")
        logger.warning("  %s", outcome.messages[-1])
        return

    outcome.messages.append(
        f"NOT promoted — held in {STAGE_PREPROCESSED} for review. "
        f"Blocked by: {'; '.join(blockers)}.")
    logger.info("  %s", outcome.messages[-1])


def run_pdm_flow(pdm_path: str,
                 initial_erwin: str,
                 initial_xml: str,
                 preprocessed_erwin: str,
                 preprocessed_xml: str,
                 final_erwin: str,
                 final_xml: str,
                 target_fidelity: float = 100.0,
                 preprocess_enabled: bool = True,
                 keep_preprocessed_copy: bool = False,
                 udp_pass_rate: Optional[float] = None,
                 manual_review_dir: str = "",
                 final_validated_xml: str = "",
                 manual_export_wait_seconds: int = 0,
                 manual_export_poll_interval: float = 5.0,
                 require_final_xml: bool = False) -> PdmFlowOutcome:
    """
    Validate one PDM model, remediate it if it falls short, and promote it only
    when it measures at the fidelity target.

    All path arguments are full file paths; parent folders are created on demand.

    ``require_final_xml=True`` is the operating flow: V3 is measured ONLY against
    the manual XML export of the UDP-enriched .erwin (``final_validated_xml``).
    Without that export the gate is not evaluated — nothing is promoted or moved,
    the V2 result stands as the latest measurement and the outcome says the model
    is WAITING_FOR_MANUAL_INPUT. With the default ``False`` (dry run / legacy
    single-pass) the V2 result is gated when no export exists.
    """
    model_name = os.path.splitext(os.path.basename(pdm_path))[0]
    outcome = PdmFlowOutcome(model_name=model_name, pdm_path=pdm_path)

    # ── Guard: we need both the source model and the erwin XML export ──────────
    missing = _missing_input(pdm_path, initial_xml,
                             manual_export_wait_seconds, manual_export_poll_interval)
    if missing:
        outcome.messages.append(missing)
        logger.error(outcome.messages[-1])
        return outcome

    # ── Pass 1: validate the raw import ───────────────────────────────────────
    pd_model = _validate_initial(outcome, pdm_path, initial_xml,
                                 initial_erwin, model_name)

    # ── Migrations (remediation + Pass 2) run BEFORE V3 ───────────────────────
    # V3 is the final, authoritative measurement and must reflect what actually
    # migrated, not short-circuit ahead of it — the same ordering CDM/LDM use
    # (V1 -> UDP -> V2 -> V3). Skipping preprocessing here is only ever because
    # V1 already measured complete, i.e. there is nothing left to remediate.
    preprocessed = False
    best_xml = initial_xml

    # ── Step 1: PD Comments -> erwin Notes (tables, columns, views, procedures,
    # triggers, sequences, tablespaces). Independent of the gate: a model that
    # is structurally complete still needs its documentation carried.
    injection = _inject_comments(outcome, pdm_path, initial_xml, preprocessed_xml) if preprocess_enabled else None
    remediation_source = preprocessed_xml if injection else initial_xml

    if _is_complete(outcome.initial_result, target_fidelity):
        outcome.messages.append(
            f"Fidelity {outcome.initial_result.fidelity_score:.2f}% on import; "
            "no remediation needed.")
        if injection and injection.written:
            _revalidate_after_comments(outcome, pdm_path, preprocessed_xml, model_name, udp_pass_rate)
            preprocessed = True
            best_xml = preprocessed_xml
    elif not preprocess_enabled:
        outcome.messages.append(
            f"Preprocessing is disabled. Blocked by: "
            f"{'; '.join(_gate_failures(outcome.initial_result, target_fidelity))}.")
        logger.warning("  %s", outcome.messages[-1])
    else:
        report = _run_preprocessing(outcome, pd_model, model_name,
                                    remediation_source, initial_erwin,
                                    preprocessed_xml, preprocessed_erwin,
                                    target_fidelity)
        _revalidate(outcome, pdm_path, preprocessed_xml, model_name, report,
                   udp_pass_rate)
        preprocessed = True
        best_xml = preprocessed_xml

    # ── V3: the final validated erwin XML is the authority, measured LAST ─────
    validated = _validate_final(outcome, pdm_path, final_validated_xml, model_name,
                                udp_pass_rate)

    # ── Promotion gate, evaluated on whichever result V3 left in place ────────
    if require_final_xml and not validated:
        outcome.waiting_for_final_xml = True
        outcome.stage = STAGE_PREPROCESSED if preprocessed else STAGE_INITIAL
        outcome.messages.append(
            "WAITING_FOR_MANUAL_INPUT: no XML V3 export for this model"
            + (f" (looked for {final_validated_xml})" if final_validated_xml else "")
            + "; the promotion gate was not evaluated. Open erwinmodels/2_preprocessed/<model>.erwin in erwin, "
              "Save As XML into final_xml_models/pdm/ and rerun run_v3.py.")
        logger.warning("  %s", outcome.messages[-1])
        return _stamp(outcome, pd_model, best_xml)

    if _is_complete(outcome.final_result, target_fidelity):
        if validated:
            _promote_from_initial(outcome, final_validated_xml, initial_erwin,
                                  final_xml, final_erwin)
        elif preprocessed:
            _promote_after_preprocessing(outcome, outcome.preprocess_report,
                                         preprocessed_xml, preprocessed_erwin,
                                         final_xml, final_erwin,
                                         keep_preprocessed_copy)
        else:
            _promote_from_initial(outcome, initial_xml, initial_erwin,
                                  final_xml, final_erwin)
    else:
        _hold_for_review(outcome, target_fidelity,
                         preprocessed_xml if preprocessed else "",
                         preprocessed_erwin if preprocessed else "",
                         manual_review_dir)

    reported_xml = final_validated_xml if validated else best_xml
    # Two-band routing has just MOVED the preprocessed XML into the model's
    # manual_review_report folder, so the path we measured against no longer
    # exists; stamp the report from wherever the file actually is now.
    if not os.path.exists(reported_xml):
        for key in ("manual_review_xml", "final_xml", "preprocessed_xml"):
            moved = outcome.artifacts.get(key)
            if moved and os.path.exists(moved):
                reported_xml = moved
                break
    return _stamp(outcome, pd_model, reported_xml)


