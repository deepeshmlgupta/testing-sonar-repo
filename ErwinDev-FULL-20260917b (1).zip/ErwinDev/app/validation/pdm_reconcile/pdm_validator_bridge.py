"""
PDM Validator Bridge
====================
Exposes the existing, untouched PDM → erwin validator
(``pdm_reconcile/pdm_erwin_validator_Fixed/pdm_erwin_validator``) to the main
migration pipeline.

Why a bridge is needed
----------------------
The PDM validator is a self-contained tool: its modules import each other with
plain absolute names (``import config``, ``from comparator import compare``).
The LDM validator that ``app/main.py`` already loads has modules with the *same
names* (``config.py``, ``comparator.py``, ``report_generator.py``) and its folder
is on ``sys.path`` too.  Importing the PDM validator naively would either pick up
the LDM modules or poison ``sys.modules`` for the LDM side — silently corrupting
both validators.

This bridge loads the PDM validator inside a short-lived, isolated import window:

  1. remember the current ``sys.path`` / ``sys.modules`` state,
  2. put the validator folder first on ``sys.path`` and hide the conflicting
     top-level names,
  3. import the validator modules (their internal ``import config`` now resolves
     to *their own* files),
  4. re-register everything that was loaded from the validator folder under the
     ``pdm_validator.*`` namespace, then restore the original state exactly.

The validator's own source files are never modified, so
``python main.py`` inside the validator folder keeps working standalone.

Public API
----------
    parse_pdm(path)              -> dict   (PowerDesigner .pdm  -> model dict)
    parse_erwin(path)            -> dict   (erwin .xml          -> model dict)
    compare(pd_model, erwin)     -> ValidationResult
    config                       -> the validator's config module
    ValidationResult, Finding    -> the validator's dataclasses
"""

import logging
import os

from app.common.isolated_import import IsolatedLoader

logger = logging.getLogger(__name__)

# ─── LOCATION OF THE EXISTING VALIDATOR ───────────────────────────────────────
# The validator folder has lived under two names ("pdm_erwin_validator" in this
# repo; "pdm_erwin_validator_Fixed/pdm_erwin_validator" in the standalone drop).
# Probe the candidates so the bridge works in both layouts.
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_CANDIDATE_DIRS = (
    os.path.join(_THIS_DIR, "pdm_erwin_validator"),
    os.path.join(_THIS_DIR, "pdm_erwin_validator_Fixed", "pdm_erwin_validator"),
)
VALIDATOR_DIR = next((d for d in _CANDIDATE_DIRS if os.path.isdir(d)),
                     _CANDIDATE_DIRS[0])

# Top-level module names owned by the validator that clash with the LDM tool.
_OWNED_NAMES = (
    "data_type_mapper",
    "pd_parser",
    "erwin_parser",
    "comparator",
)

_ALIAS_PREFIX = "pdm_validator"
# Shares one process-wide import window with app/validation/udp_bridge.py.
_LOADER = IsolatedLoader(VALIDATOR_DIR, _OWNED_NAMES, _ALIAS_PREFIX, label="PDM validator")


def load():
    """Load (once) and return the validator's modules as a dict."""
    return _LOADER.load()


# ─── PUBLIC API ───────────────────────────────────────────────────────────────

def parse_pdm(path: str):
    """Parse a PowerDesigner .pdm file into the validator's model dict."""
    return load()["pd_parser"].parse_pdm(path)


def parse_erwin(path: str):
    """Parse an erwin XML export into the validator's model dict."""
    return load()["erwin_parser"].parse_erwin(path)


def compare(pd_model, erwin_model):
    """Reconcile a parsed PD model against a parsed erwin model."""
    return load()["comparator"].compare(pd_model, erwin_model)


def get_config():
    """The validator's config module (severity policy, thresholds, toggles)."""
    from app.config.validation_config import PDM_CONFIG
    return PDM_CONFIG


def get_result_classes():
    """(ValidationResult, Finding) dataclasses used by the validator."""
    comparator = load()["comparator"]
    return comparator.ValidationResult, comparator.Finding


def validate_pair(pdm_path: str, erwin_xml_path: str):
    """
    Validate one .pdm against one erwin .xml.

    Mirrors the validator's own ``validate_pair`` so a parse failure becomes an
    ERROR result instead of an exception that would stop the batch.
    """
    validation_result_cls, finding_cls = get_result_classes()
    try:
        return compare(parse_pdm(pdm_path), parse_erwin(erwin_xml_path))
    except Exception as exc:                                  # noqa: BLE001
        logger.error("PDM validation failed (%s vs %s): %s",
                     pdm_path, erwin_xml_path, exc)
        result = validation_result_cls(pd_file=pdm_path, erwin_file=erwin_xml_path,
                                       status="ERROR")
        result.add(finding_cls("EXCEPTION", "CRITICAL", message=str(exc)))
        result.compute_score()
        return result
