"""
UDP Tool Bridge
===============
Exposes the existing, untouched standalone UDP tool (``app/udp_tool``) to the
main migration pipeline, so ``app/main.py`` can run UDP extraction, mapping,
injection, reporting and comparison as one of its own phases instead of the
operator running ``app/udp_tool/batch_run.py`` separately.

Why a bridge is needed
----------------------
``app/udp_tool`` is a folder of scripts, not a package:

* it has no ``__init__.py``;
* its modules import each other by BARE name -- ``sow_classify`` does
  ``from pd_extract import Model``, and both ``udp_compare`` and ``erwin_load``
  do ``import udp_readback``.  Those names only resolve when the tool folder is
  first on ``sys.path``, which is exactly what launching each script through
  ``subprocess`` used to guarantee;
* ``erwin_load`` imports ``win32com.client`` at MODULE level and calls
  ``sys.exit(1)`` when pywin32 is missing, so merely importing it would kill a
  non-Windows pipeline run.

This bridge loads the safe modules inside a short-lived, isolated import window
-- the same technique ``pdm_validator_bridge`` already uses for the PDM
validator:

  1. remember the current ``sys.path`` / ``sys.modules`` state,
  2. put the tool folder first on ``sys.path`` and hide clashing top-level names,
  3. import the modules (their internal bare imports now resolve to their own
     files),
  4. re-register them under the ``udp_tool.*`` namespace, then restore the
     interpreter exactly as it was found.

``erwin_load`` is deliberately NEVER imported.  It is launched as a subprocess
with ``sys.executable``, which is the only way its module-level ``sys.exit`` can
be contained.

Nothing in ``app/udp_tool`` is modified, so ``python batch_run.py`` keeps working
standalone exactly as before.

Public API
----------
    available()                       -> bool    tool folder present and importable
    com_available()                   -> bool    pywin32 importable in this process
    classify(pd_path, workdir)        -> (dict, str)   Phase 1a: baseline + classification
    build_mapping(workdir, name, id)  -> (list, list)  Phase 1b: udp_schema + property_manifest
    inject(request)                   -> bool          Phase 2: COM injection (subprocess)
    migration_report(...)             -> str | None    Phase 3: UDP migration workbook
    compare(...)                      -> (result, str) Phase 4: SAP vs erwin read-back
"""

from __future__ import annotations

import importlib
import json
import logging
import os
import subprocess  # nosec B404 - launched only with sys.executable and a literal script path
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from app.common.isolated_import import IsolatedLoader

logger = logging.getLogger(__name__)

# ─── LOCATION OF THE STANDALONE TOOL ──────────────────────────────────────────
# app/validation/udp_bridge.py -> parents[1] is app/ -> app/udp_tool
TOOL_DIR = str(Path(__file__).resolve().parents[1] / "udp_tool")
INJECTOR_SCRIPT = os.path.join(TOOL_DIR, "erwin_load.py")

# Top-level module names owned by the tool.  They are hidden for the duration of
# the import so nothing else on sys.path can satisfy the tool's bare imports.
_OWNED_NAMES = (
    "pd_extract",
    "erwin_prepare",
    "sow_classify",
    "udp_readback",
    "udp_compare",
    "udp_report",
)

_ALIAS_PREFIX = "udp_tool"

# ─── ARTEFACT FILENAMES (shared with the standalone tool) ─────────────────────
BASELINE_DIRNAME = "baseline"
SCHEMA_FILENAME = "udp_schema.json"
MANIFEST_FILENAME = "property_manifest.json"
RESULTS_FILENAME = "injection_results.json"
COUNTS_FILENAME = "counts.json"
ENTITIES_FILENAME = "entities.json"
EXT_ATTRS_FILENAME = "extended_attributes.json"
# The workdir is already per model, so the classification does not need to
# repeat the (often 60+ character) model name. The old
# "classification_<model>.json" form pushed a OneDrive checkout past the
# Windows 260-character path limit and Phase D failed with FileNotFoundError.
# erwin_prepare.py already accepts either name; readers here do too.
CLASSIFICATION_FILENAME = "classification.json"

# Filtered copies of udp_schema.json / property_manifest.json actually handed
# to erwin_load.py -- see NON_INJECTABLE_UDPS below for why they differ from
# the full artefacts of the same name.
INJECTABLE_SCHEMA_FILENAME = "udp_schema.injectable.json"
INJECTABLE_MANIFEST_FILENAME = "property_manifest.injectable.json"

# ─── UDPs this tool tracks internally but never writes into erwin ────────────
# Pure PowerDesigner-side traceability rows erwin_prepare.STRUCTURAL adds for
# this tool's OWN reconciliation (which PD extract, which model, which GUID a
# value came from) -- they carry no business meaning and were never migrated
# SAP content, so a client reviewing erwin's UDP list should not see them
# mixed in with their actual business properties.
#
# Unlike PD_Code / PD_Attribute_Codes (read back by the CDM/LDM comparators to
# credit code preservation, see code_evidence.py / code_ledger.py) and the
# PD_Shortcut_* / PD_NameTerms / PD_CodeTerms rows (read back for the UDP
# fidelity score, see shortcut_udp.py), these three have NO read-back consumer
# anywhere in the framework -- nothing downstream ever looks for them in
# erwin's export -- so excluding them from injection costs nothing but the
# clutter.
#
# They are NOT removed from udp_schema.json / property_manifest.json (the
# full artefacts `migration_report()` reads): that workbook's source-quality
# checks -- e.g. "Missing PowerDesigner ObjectID" in udp_report.py -- are
# genuine, PD-side-only reconciliation value the client asked to keep. They
# are excluded only from what actually reaches erwin (`inject()`) and from
# what is compared back against erwin (`compare()`), because comparing a
# value that was deliberately never sent would just report it lost and
# corrupt the UDP pass rate for no reason.
NON_INJECTABLE_UDPS = frozenset({"PD_ObjectID", "PD_SourceExtraction", "PD_SourceModel"})


def _exclude_non_injectable(schema: List[dict], manifest: List[dict]
                            ) -> Tuple[List[dict], List[dict]]:
    """(schema, manifest) with the pure-traceability UDPs above removed."""
    schema = [row for row in schema if str(row.get("udp", "")) not in NON_INJECTABLE_UDPS]
    manifest = [row for row in manifest if str(row.get("udp", "")) not in NON_INJECTABLE_UDPS]
    return schema, manifest


def classification_path(workdir, model_name: str = "") -> Path:
    """The classification JSON for a model: the short name, or the legacy
    ``classification_<model>.json`` when only that one exists."""
    work = Path(workdir)
    short = work / CLASSIFICATION_FILENAME
    legacy = work / f"classification_{model_name}.json" if model_name else None
    if not short.exists() and legacy is not None and legacy.exists():
        return legacy
    return short

_ENCODING = "utf-8"


@dataclass
class InjectionRequest:
    """Everything ``erwin_load.py`` needs for one model."""

    erwin_in: str
    erwin_out: str
    schema_path: str
    manifest_path: str
    results_path: str
    name_style: str = "bare"
    timeout_seconds: int = 1800


# Shares one process-wide import window with pdm_validator_bridge (see
# app/common/isolated_import.py): two workers loading the two tools at the same
# moment used to erase each other's sys.path insertion mid-import.
_LOADER = IsolatedLoader(TOOL_DIR, _OWNED_NAMES, _ALIAS_PREFIX, label="UDP tool")


def load() -> Dict[str, Any]:
    """Load (once) and return the tool's modules as a dict."""
    return _LOADER.load()


def available() -> bool:
    """True when the UDP tool can be imported in this process."""
    try:
        load()
        return True
    except (ImportError, OSError) as exc:
        logger.warning("UDP tool unavailable: %s", exc)
        return False


def com_available() -> bool:
    """True when pywin32 is importable, i.e. COM injection can be attempted."""
    try:
        importlib.import_module("win32com.client")
        return True
    except ImportError:
        return False


def _read_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding=_ENCODING))
    except (OSError, ValueError) as exc:
        logger.debug("Could not read %s: %s", path, exc)
        return default


def _write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding=_ENCODING)


# ═════════════════════════════════════════════════════════════════════════════
#  Phase 1a — classify the SAP model and write its baseline
# ═════════════════════════════════════════════════════════════════════════════

def classify(pd_path: str, workdir: str) -> Tuple[dict, str]:
    """
    Run the tool's SOW classification, which also writes the extraction baseline.

    ``workdir`` is PER MODEL.  The standalone tool shares one ``baseline/``
    folder across every model in a batch, which is safe only because
    ``batch_run.py`` is strictly sequential; inside the pipeline's per-model loop
    that would build each manifest from the PREVIOUS model's baseline.  Giving
    each model its own working directory removes that coupling entirely.

    Returns (classification, path to the classification JSON).
    """
    modules = load()
    work = Path(workdir)
    work.mkdir(parents=True, exist_ok=True)

    classification = modules["sow_classify"].classify(Path(pd_path), outdir=work)
    out_path = work / CLASSIFICATION_FILENAME
    _write_json(out_path, classification)
    return classification, str(out_path)


# ═════════════════════════════════════════════════════════════════════════════
#  Phase 1b — UDP mapping: schema + property manifest
# ═════════════════════════════════════════════════════════════════════════════

def build_mapping(workdir: str, model_name: str, extraction_id: str,
                  pd_path: str = "", config=None) -> Tuple[List[dict], List[dict]]:
    """
    Turn the baseline into ``udp_schema.json`` and ``property_manifest.json``.

    Calls the tool's own ``build_udp_schema`` / ``build_manifest`` so the
    inference rules and the manifest shape stay identical to the standalone run,
    then APPENDS the shortcut rows (app/validation/shortcut_udp.py) when
    ``pd_path`` is given and UDP_TOOL_INCLUDE_SHORTCUTS is on.

    The shortcut rows are appended rather than merged in: they use their own
    PD_* UDP names, so they cannot collide with an extended-attribute UDP, and
    appending keeps the tool's own output byte-identical to a standalone run.

    Also writes the INJECTABLE_* files: the same schema/manifest with
    NON_INJECTABLE_UDPS removed (PD_ObjectID / PD_SourceExtraction /
    PD_SourceModel -- pure traceability, never meant to be a visible erwin
    UDP). ``inject()`` reads those; ``migration_report()`` still reads the
    full ``SCHEMA_FILENAME`` / ``MANIFEST_FILENAME`` so its source-quality
    checks are unaffected. Returns the FULL (schema, manifest).
    """
    modules = load()
    prepare = modules["erwin_prepare"]
    work = Path(workdir)
    baseline = work / BASELINE_DIRNAME

    profile = _read_json(baseline / EXT_ATTRS_FILENAME, {})
    entities = _read_json(baseline / ENTITIES_FILENAME, [])

    schema = prepare.build_udp_schema(profile)
    manifest = prepare.build_manifest(entities, schema, extraction_id, model_name)

    schema, manifest = _append_shortcut_rows(schema, manifest, pd_path, model_name, config)
    if getattr(config, "UDP_PRESERVE_PD_CODE", True) if config is not None else True:
        schema, manifest = _append_code_rows(schema, manifest)
        schema, manifest = _append_attribute_code_rows(
            schema, manifest, pd_path, model_name, config, work)

    _write_json(work / SCHEMA_FILENAME, schema)
    _write_json(work / MANIFEST_FILENAME, manifest)

    injectable_schema, injectable_manifest = _exclude_non_injectable(schema, manifest)
    _write_json(work / INJECTABLE_SCHEMA_FILENAME, injectable_schema)
    _write_json(work / INJECTABLE_MANIFEST_FILENAME, injectable_manifest)

    return schema, manifest



#: erwin's LOGICAL model has no Physical_Name, so an entity's PowerDesigner
#: Code has nowhere native to land and erwin's export reports Code == Name.
#: Carrying it as a UDP is the only way the technical name survives the
#: migration at all; without it the code is lost silently and the reconciler
#: can only report "matched on name, not on code".
UDP_PD_CODE = "PD_Code"


def _append_code_rows(schema: List[dict], manifest: List[dict]) -> Tuple[List[dict], List[dict]]:
    """
    Preserve each entity's PowerDesigner Code as a UDP.

    The manifest already carries ``entity_code`` on every row — it is written
    by the tool and then read by nobody (erwin_load resolves its target by
    entity NAME). So the value is already present and correct; it just never
    reached erwin. One row per entity whose code actually differs from its
    name: where they are equal there is nothing to preserve and a UDP would be
    noise.
    """
    by_entity = {}
    for row in manifest:
        name = str(row.get("entity_name", "") or "").strip()
        code = str(row.get("entity_code", "") or "").strip()
        if name and code and code.upper() != name.upper():
            by_entity.setdefault(name, code)
    if not by_entity:
        return schema, manifest

    if UDP_PD_CODE not in {str(r.get("udp", "")) for r in schema}:
        longest = max(len(c) for c in by_entity.values())
        schema = schema + [{
            "udp": UDP_PD_CODE, "type": "Text",
            "length": max(60, min(1024, longest + 40)),
            "value_list": None, "source_path": "", "coverage": "",
            "distinct_observed": "", "list_source": "",
            "purpose": "PowerDesigner Code (technical name). erwin's logical model "
                       "has no Physical_Name field, so the Code has no native home "
                       "and erwin reports Code == Name; this preserves it.",
        }]

    rows = [{"pd_object_id": "", "entity_name": name, "entity_code": code,
             "udp": UDP_PD_CODE, "value": code, "source_path": ""}
            for name, code in sorted(by_entity.items())]
    logger.info("Preserving %d PowerDesigner entity Code(s) as the %s UDP.",
                len(rows), UDP_PD_CODE)
    return schema, manifest + rows


def _append_attribute_code_rows(schema: List[dict], manifest: List[dict], pd_path: str,
                                model_name: str, config, workdir
                                ) -> Tuple[List[dict], List[dict]]:
    """
    Carry each entity's ATTRIBUTE codes as the PD_Attribute_Codes UDP.

    ``_append_code_rows`` above solves the ENTITY code. Attributes were the
    remaining hole: erwin's logical export has no Physical_Name on an attribute
    either, and ``erwin_load`` can only address an entity, so an attribute-level
    UDP had nowhere to be injected. The codes are therefore encoded into ONE
    entity-level UDP — the same transport, the same injection, the same
    read-back — with each entry carrying its declaration order and datatype
    fingerprint so nothing downstream ever resolves an attribute by name alone.

    The ledger that produced the payload is written beside the manifest, so
    what was preserved, what was skipped and WHY is auditable without erwin.

    Never raises: a ledger problem must not cost a model its extended-attribute
    migration.
    """
    if not pd_path:
        return schema, manifest
    if not (getattr(config, "UDP_PRESERVE_ATTRIBUTE_CODES", True) if config is not None else True):
        return schema, manifest
    try:
        from app.validation import code_ledger

        pd_model = _parse_pd_model(pd_path, config)
        if pd_model is None:
            return schema, manifest
        ledger = code_ledger.build(pd_model, model_name=model_name,
                                   model_type=_tier_of(pd_path), pd_path=pd_path)
        try:
            (Path(workdir) / "code_ledger.json").write_text(
                json.dumps(asdict(ledger), indent=2, default=str), encoding="utf-8")
        except (OSError, TypeError, ValueError) as exc:
            logger.warning("Could not write the code ledger beside the manifest: %s", exc)

        extra_schema, extra_manifest = code_ledger.udp_rows(ledger)
        if not extra_manifest:
            return schema, manifest
        known = {str(row.get("udp", "")) for row in schema}
        schema = schema + [row for row in extra_schema if str(row.get("udp", "")) not in known]
        return schema, manifest + extra_manifest
    except Exception as exc:                                   # noqa: BLE001
        logger.warning("Attribute code preservation skipped for %s: %s", model_name, exc)
        return schema, manifest


def _tier_of(pd_path: str) -> str:
    """The tier a SAP PD file belongs to, from its extension."""
    return {".cdm": "CDM", ".ldm": "LDM", ".pdm": "PDM"}.get(
        Path(pd_path).suffix.lower(), "")


def _parse_pd_model(pd_path: str, config):
    """
    The SAP PD model, parsed by the tier's OWN parser.

    Reusing the tier parser rather than adding a second reader of the
    PowerDesigner XML is the point: the ledger then describes exactly the
    objects the comparator reconciles, not a near-copy that can drift.
    """
    tier = _tier_of(pd_path)
    try:
        if tier == "CDM":
            from app.validation.cdm_reconcile.pd_cdm_parser import parse_cdm
            return parse_cdm(str(pd_path))
        if tier == "LDM":
            from app.validation.ldm_reconcile.pd_ldm_parser import parse_ldm
            return parse_ldm(str(pd_path))
    except Exception as exc:                                   # noqa: BLE001
        logger.warning("Could not parse %s for the code ledger: %s", pd_path, exc)
        return None
    # PDM columns are carried by the PDM engine's own comparison, which reads
    # Physical_Name on both sides; there is no missing-code problem to solve.
    logger.debug("No attribute code ledger for tier %r (%s).", tier, pd_path)
    return None


def _append_shortcut_rows(schema: List[dict], manifest: List[dict], pd_path: str,
                          model_name: str, config) -> Tuple[List[dict], List[dict]]:
    """
    Add the PowerDesigner shortcut / glossary UDPs. Never raises: a shortcut
    problem must not cost a model its extended-attribute migration.
    """
    if not pd_path:
        return schema, manifest
    include = getattr(config, "UDP_TOOL_INCLUDE_SHORTCUTS", True) if config is not None else True
    if not include:
        return schema, manifest
    try:
        from app.validation import shortcut_udp

        extra_schema, extra_manifest, census = shortcut_udp.build(pd_path, model_name, config)
    except Exception as exc:                                   # noqa: BLE001
        logger.warning("Shortcut UDP rows skipped for %s: %s", model_name, exc)
        return schema, manifest

    if census.error:
        logger.warning("Shortcut census for %s: %s", model_name, census.error)
        return schema, manifest
    if not extra_schema and not extra_manifest:
        return schema, manifest

    defined = {str(row.get("udp", "")) for row in schema}
    schema = schema + [row for row in extra_schema if str(row.get("udp", "")) not in defined]
    logger.info("Shortcut UDPs for %s: %s", model_name, census.summary_line())
    return schema, manifest + extra_manifest


# ═════════════════════════════════════════════════════════════════════════════
#  Phase 2 — COM injection (subprocess; never imported)
# ═════════════════════════════════════════════════════════════════════════════

def inject(request: InjectionRequest) -> bool:
    """
    Run ``erwin_load.py`` against one model.

    Launched as a subprocess because the injector imports pywin32 at module
    level and exits the interpreter when it is missing.  Returns True only when
    the injector completed AND wrote a fresh results file.  Never raises.
    """
    # erwin_load.py opens the input through PersistenceUnits.Add(), which
    # refuses a file carrying the Windows read-only attribute, and replaces the
    # output with os.remove(), which fails on a read-only target and is then
    # reported as "currently open or locked" — a message that sends the
    # operator hunting for a process when the real cause is one attribute bit.
    # Both ends are prepared here so the injector never meets either case.
    try:
        from app.erwin import windows_files

        states = [windows_files.prepare(request.erwin_in),
                  windows_files.prepare_target(request.erwin_out)]
        for state in states:
            for line in state.messages:
                logger.info("UDP injection: %s", line)
        blocked = windows_files.blocking_reason(states)
        if blocked:
            logger.warning("UDP injection cannot start: %s", blocked)
            return False
    except Exception as exc:                                   # noqa: BLE001
        logger.debug("File preparation skipped: %s", exc)

    results = Path(request.results_path)
    if results.exists():
        # An old successful run must not be mistaken for this one's evidence.
        try:
            results.unlink()
        except OSError as exc:
            logger.warning("Could not clear %s: %s", results, exc)

    command = [
        sys.executable, INJECTOR_SCRIPT,
        "--xml", request.erwin_in,
        "--manifest", request.manifest_path,
        "--schema", request.schema_path,
        "--out_erwin", request.erwin_out,
        "--results_json", request.results_path,
        "--udp_name_style", request.name_style,
    ]
    try:
        # nosec B603 - fixed executable, fixed script, no shell, arguments are
        # pipeline-generated paths rather than user input.
        completed = subprocess.run(  # nosec B603
            command, check=False, capture_output=True, text=True,
            timeout=request.timeout_seconds,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        logger.warning("UDP injection could not be started: %s", exc)
        return False

    if completed.returncode != 0:
        logger.warning("UDP injection exited with %s: %s",
                       completed.returncode, (completed.stdout or completed.stderr or "").strip())
    return results.exists()


# ═════════════════════════════════════════════════════════════════════════════
#  Phase 3 — UDP migration workbook
# ═════════════════════════════════════════════════════════════════════════════

def migration_report(model_name: str, workdir: str, sap_model: str,
                     erwin_out: str, outdir: str,
                     display_name: str = "") -> Optional[str]:
    """
    Build ``<display>_udp_migration_report.xlsx`` from the mapping artefacts
    and, when the injector produced one, the injection results.  Returns the
    path or None when there was nothing to report.

    ``model_name`` stays the pipeline key (workdir artefacts, legacy
    classification file); ``display_name`` (default: the same) is what the
    workbook is titled and named after — normally the short model name, e.g.
    ``real_estate`` rather than ``<hash>_<extraction id>_real_estate``.
    """
    modules = load()
    work = Path(workdir)
    baseline = work / BASELINE_DIRNAME

    manifest = _read_json(work / MANIFEST_FILENAME, [])
    schema = _read_json(work / SCHEMA_FILENAME, [])
    if not manifest and not schema:
        return None

    results_path = work / RESULTS_FILENAME
    results = _read_json(results_path, None) if results_path.exists() else None

    out_path = modules["udp_report"].build_report(
        display_name or model_name, manifest, schema, results,
        _read_json(classification_path(work, model_name), {}),
        _read_json(baseline / COUNTS_FILENAME, {}),
        _read_json(baseline / ENTITIES_FILENAME, []),
        sap_model, erwin_out, Path(outdir),
    )
    return str(out_path)


# ═════════════════════════════════════════════════════════════════════════════
#  Phase 4 — read erwin back and compare
# ═════════════════════════════════════════════════════════════════════════════

def compare(model_name: str, workdir: str, erwin_model: str, sap_model: str,
            model_type: str, outdir: str, method: str = "auto",
            display_name: str = "") -> Tuple[Any, Optional[str]]:
    """
    Compare the SAP manifest against the UDP values erwin actually holds, by
    reading the saved model back off disk.  Returns (ComparisonResult, path).
    ``display_name`` names the workbook (see migration_report).

    Uses the same NON_INJECTABLE_UDPS-filtered manifest/schema as ``inject()``:
    PD_ObjectID / PD_SourceExtraction / PD_SourceModel were deliberately never
    sent to erwin, so comparing them against what erwin holds would report
    every one of them MISSING and drag down the UDP pass rate for values this
    tool never intended to migrate in the first place.
    """
    modules = load()
    work = Path(workdir)
    manifest = _read_json(work / MANIFEST_FILENAME, [])
    schema = _read_json(work / SCHEMA_FILENAME, [])
    schema, manifest = _exclude_non_injectable(schema, manifest)

    return modules["udp_compare"].compare_model(
        display_name or model_name, manifest, schema, erwin_model,
        outdir=Path(outdir), method=method,
        sap_model=sap_model, model_type=model_type,
    )


__all__ = [
    "InjectionRequest", "TOOL_DIR", "INJECTOR_SCRIPT",
    "CLASSIFICATION_FILENAME", "classification_path",
    "available", "com_available", "load",
    "classify", "build_mapping", "inject", "migration_report", "compare",
]
