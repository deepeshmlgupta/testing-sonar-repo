"""
What became of an attribute's PowerDesigner Code — shared by CDM and LDM
=======================================================================

One implementation, because the CDM and LDM comparators must not be able to
give different answers about the same fact. Both call ``code_not_carried()``
when erwin carries no technical code of its own for a matched attribute.

The answer comes from the preservation ledger's OWN rules
(``app/validation/code_ledger.py``) — the same code that decides what is
encoded for injection into erwin. That is deliberate: the report can then never
claim a preservation the transport did not actually make, which is exactly what
the previous single message did. It said the Code was "preserved as the PD_Code
UDP" for every attribute, and for ATTRIBUTE codes that was never true: the
PD_Code UDP is written per ENTITY, and ``erwin_load`` cannot address anything
below an entity.

Four outcomes, each with a different remedy:

``PRESERVED``    encoded into the entity's PD_Attribute_Codes UDP for injection.
                 Still ``EXTERNAL_VERIFICATION_REQUIRED`` until a read-back on a
                 Windows host with erwin confirms it arrived — encoded is not
                 the same fact as delivered, and saying so is the difference
                 between evidence and a claim.
``AMBIGUOUS``    the attribute cannot be identified uniquely inside its entity
                 by anything but its name, so nothing is encoded. Attaching a
                 code by name alone could record it against a different
                 attribute, which is worse than not carrying it.
``NOT_PRESERVED``the Code equals the Name, so erwin's name already carries it.
``unknown``      the ledger could not be consulted for this model.
"""

from __future__ import annotations

import logging
from typing import Tuple

logger = logging.getLogger(__name__)


def ledger_status(pd_entity, pd_attr) -> Tuple[str, str, str]:
    """
    (status, identity basis, note) for one attribute.

    ('', '', '') means the ledger could not be consulted. That is "unknown",
    and every caller must treat it as such — never as "preserved".
    """
    if pd_entity is None or pd_attr is None:
        return "", "", ""
    try:
        from app.validation import code_ledger

        siblings = [attribute for attribute in (getattr(pd_entity, "attributes", None) or ())
                    if not getattr(attribute, "is_migrated", False)]
        record = code_ledger.AttributeCode(
            pd_entity_oid=str(getattr(pd_entity, "oid", "") or ""),
            pd_attr_oid=str(getattr(pd_attr, "oid", "") or ""),
            pd_attr_name=str(getattr(pd_attr, "name", "") or "").strip(),
            pd_attr_code=str(getattr(pd_attr, "code", "") or "").strip(),
            pd_attr_order=int(getattr(pd_attr, "order", 0) or 0),
            pd_data_type=code_ledger.type_fingerprint(pd_attr),
            identity_basis=code_ledger.identity_basis(pd_attr, siblings),
        )
        status, note = code_ledger.classify(record)
        return status, record.identity_basis, note
    except Exception as exc:                                   # noqa: BLE001
        logger.debug("Code ledger unavailable for %r: %s",
                     getattr(pd_attr, "name", "?"), exc)
        return "", "", ""


def code_not_carried(pd_entity, pd_attr) -> Tuple[str, str]:
    """(message suffix, remediation) for a CODE_NOT_CARRIED finding."""
    from app.validation import code_ledger

    status, basis, note = ledger_status(pd_entity, pd_attr)
    entity_name = str(getattr(pd_entity, "name", "") or "")

    if status == code_ledger.STATUS_PRESERVED:
        return (
            f"; carried into erwin as the {code_ledger.UDP_ATTRIBUTE_CODES} UDP on "
            f"entity '{entity_name}' (identified by {basis})",
            f"EXPECTED_TRANSFORMATION — erwin limitation, approved mapping: SAP PD "
            f"attribute Code -> {code_ledger.UDP_ATTRIBUTE_CODES} UDP. "
            f"{code_ledger.STATUS_EXTERNAL}: confirm the UDP is present on this "
            f"entity in erwin after Step 2. Until a read-back confirms it, the "
            f"code is encoded for transport, not proven to have arrived.")

    if status == code_ledger.STATUS_AMBIGUOUS:
        return (
            f"; NOT carried — {note}",
            "The attribute cannot be identified deterministically inside its "
            "entity, so its Code is not encoded for transport: attaching it by "
            "name alone could record it against a different attribute. Give the "
            "attribute a distinct name or data type, or record the Code in erwin "
            "by hand.")

    if status == code_ledger.STATUS_NOT_PRESERVED:
        return (f"; nothing to carry — {note}", "No action required.")

    return (
        "; whether the Code was carried could not be determined from this model",
        f"{code_ledger.STATUS_EXTERNAL}: check this model's code preservation "
        f"ledger (batch_summary/code_ledger/) and the erwin UDPs.")


__all__ = ["ledger_status", "code_not_carried"]
