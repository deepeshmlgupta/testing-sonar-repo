"""
Relationship Orientation Analyzer (Workstream 4)
==================================================
Direction-invariant analysis of a binary relationship: identifies whether two
relationships connect the same pair of entities in reversed order, and
whether their cardinalities remain equivalent once that reversal is accounted
for.

Works on any duck-typed relationship object exposing ``end1``/``end2``, each
with an ``entity`` and a ``cardinality`` attribute (both
``app.validation.ldm_reconcile.ldm_model.Relationship`` and the CDM
equivalent satisfy this without any import here).
"""

from typing import Any, FrozenSet


def entity_pair(rel: Any) -> FrozenSet[str]:
    """The two entities a relationship connects, independent of end order."""
    return frozenset({
        (getattr(rel.end1, "entity", "") or "").strip().upper(),
        (getattr(rel.end2, "entity", "") or "").strip().upper(),
    })


def is_reversed(rel_a: Any, rel_b: Any) -> bool:
    """
    True when ``rel_a`` and ``rel_b`` connect the same two entities but with
    end1/end2 swapped — the classic "Customer -> Order" vs "Order -> Customer"
    reversal — rather than being identical in orientation already.
    """
    a1 = (getattr(rel_a.end1, "entity", "") or "").strip().upper()
    a2 = (getattr(rel_a.end2, "entity", "") or "").strip().upper()
    b1 = (getattr(rel_b.end1, "entity", "") or "").strip().upper()
    b2 = (getattr(rel_b.end2, "entity", "") or "").strip().upper()
    if not (a1 and a2 and b1 and b2):
        return False
    same_order = a1 == b1 and a2 == b2
    reversed_order = a1 == b2 and a2 == b1
    return reversed_order and not same_order


def cardinality_equivalent_when_reversed(rel_a: Any, rel_b: Any) -> bool:
    """
    True when ``rel_b``'s cardinalities match ``rel_a``'s once the ends are
    crossed — i.e. the FK/participation semantics are unchanged, only the
    declared direction differs.
    """
    a1 = (getattr(rel_a.end1, "cardinality", "") or "").strip()
    a2 = (getattr(rel_a.end2, "cardinality", "") or "").strip()
    b1 = (getattr(rel_b.end1, "cardinality", "") or "").strip()
    b2 = (getattr(rel_b.end2, "cardinality", "") or "").strip()
    if not (a1 and a2 and b1 and b2):
        return False
    return a1 == b2 and a2 == b1
