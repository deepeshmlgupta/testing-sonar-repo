"""
Business Rule Expression Normalizer (Workstream 2)
====================================================
Renders a parsed business-rule AST (see ``business_rule_parser``) into a
canonical string so structurally different but semantically equivalent
expressions normalize to the same text:

    "Amount > 0"              == "0 < Amount"               (comparison mirrored)
    "Revenue = Sales - Returns" == "Sales - Returns = Revenue" (equation mirrored)
    "A and B"                 == "B and A"                  (logical operators commute)
    "Qty * Price"              == "Price * Qty"              (commutative arithmetic)

Non-commutative operators (``-``, ``/``) keep their operand order — only the
operators that are mathematically commutative, and equation/comparison
mirroring, are normalized.
"""

import ast
from typing import Optional

from app.validation.business_rule_parser import parse_expression

_COMMUTATIVE_BINOPS = (ast.Add, ast.Mult)
_MIRROR_COMPARE = {
    ast.Gt: ("<", True),    # a > b  ->  b < a
    ast.GtE: ("<=", True),  # a >= b ->  b <= a
    ast.Lt: ("<", False),
    ast.LtE: ("<=", False),
    ast.Eq: ("==", None),   # fully commutative — sort operands
    ast.NotEq: ("!=", None),
}

_BINOP_SYMBOLS = {
    ast.Add: "+", ast.Sub: "-", ast.Mult: "*", ast.Div: "/",
    ast.Mod: "%", ast.Pow: "**", ast.FloorDiv: "//",
}


def _render_constant(value) -> str:
    if isinstance(value, bool):
        return str(value).casefold()
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    if isinstance(value, str):
        return value.strip().casefold()
    return repr(value)


def _render(node: ast.AST) -> str:
    if isinstance(node, ast.Expression):
        return _render(node.body)

    if isinstance(node, ast.Constant):
        return _render_constant(node.value)

    if isinstance(node, ast.Name):
        return node.id.strip().casefold()

    if isinstance(node, ast.UnaryOp):
        operand = _render(node.operand)
        if isinstance(node.op, ast.USub):
            return f"-{operand}"
        if isinstance(node.op, ast.UAdd):
            return operand
        if isinstance(node.op, ast.Not):
            return f"not {operand}"
        return operand

    if isinstance(node, ast.BinOp):
        left, right = _render(node.left), _render(node.right)
        symbol = _BINOP_SYMBOLS.get(type(node.op), "?")
        if isinstance(node.op, _COMMUTATIVE_BINOPS):
            left, right = sorted((left, right))
        return f"{left} {symbol} {right}"

    if isinstance(node, ast.BoolOp):
        symbol = "and" if isinstance(node.op, ast.And) else "or"
        parts = sorted(_render(v) for v in node.values)
        return f" {symbol} ".join(parts)

    if isinstance(node, ast.Compare) and len(node.ops) == 1:
        left, right = _render(node.left), _render(node.comparators[0])
        op_type = type(node.ops[0])
        symbol, flip = _MIRROR_COMPARE.get(op_type, ("?", None))
        if flip is True:
            left, right = right, left
        elif flip is None:  # Eq / NotEq: fully commutative
            left, right = sorted((left, right))
        return f"{left} {symbol} {right}"

    if isinstance(node, ast.Compare):  # chained compare (a < b < c) — render in order
        parts = [_render(node.left)]
        for op, comparator in zip(node.ops, node.comparators):
            symbol, _ = _MIRROR_COMPARE.get(type(op), ("?", None))
            parts.append(symbol)
            parts.append(_render(comparator))
        return " ".join(parts)

    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
        args = ", ".join(_render(a) for a in node.args)
        return f"{node.func.id.strip().casefold()}({args})"

    return "?"


def normalize_ast(tree: ast.AST) -> str:
    """Render a parsed expression tree to its canonical comparison string."""
    return _render(tree)


def normalize_expression(text: str) -> Optional[str]:
    """
    Parse and normalize a business rule expression in one step.

    Returns ``None`` when the text cannot be parsed as a supported expression
    (the caller should then fall back to raw-text comparison).
    """
    tree = parse_expression(text)
    if tree is None:
        return None
    return normalize_ast(tree)
