"""
Deep External Shortcut Validation (Workstream 3)
==================================================
Extends the existing shortcut census (name/path only) with recursive
validation of the shortcut's target: entities, attributes, domains,
relationships and inheritance are compared when the external model can be
located, using the SAME parser functions the calling tier already has.

Tier-agnostic by design: ``parse_pd_fn``/``parse_erwin_fn`` are injected by
the caller (e.g. ``pd_ldm_parser.parse_ldm``/``erwin_ldm_parser.parse_erwin_ldm``
for LDM, the CDM equivalents for CDM) so this module has no import-time
dependency on any tier and cannot create a circular import.
"""

from dataclasses import dataclass
from typing import Any, Callable, Iterable, Optional

from app.validation.external_model_resolver import (
    resolve_external_erwin_xml,
    resolve_external_model,
)

STATUS_NOT_ATTEMPTED = "NOT_ATTEMPTED"
STATUS_RESOLVED = "RESOLVED"
STATUS_UNRESOLVED = "UNRESOLVED"
STATUS_ERROR = "ERROR"


@dataclass
class ShortcutValidationResult:
    shortcut_name:            str
    external_model_found:     bool = False
    external_object_match_pct: Optional[float] = None
    status:                   str = STATUS_NOT_ATTEMPTED
    detail:                   str = ""


def _entity_keys(model: Any) -> set:
    entities = getattr(model, "entities", None) or {}
    return set(entities.keys()) if hasattr(entities, "keys") else set()


def validate_shortcut(shortcut: dict, search_dirs: Iterable[str],
                      parse_pd_fn: Callable[[str], Any],
                      parse_erwin_fn: Callable[[str], Any]) -> ShortcutValidationResult:
    """
    Attempt deep validation of one shortcut's external target model.

    Returns a result with ``status``:
      RESOLVED    both the external PD model and its erwin export were found
                  and parsed; ``external_object_match_pct`` reports entity
                  overlap.
      UNRESOLVED  the target model (or its erwin export) could not be found
                  in ``search_dirs`` — reported as a WARNING by the caller,
                  never a failure, since the model may not be part of this batch.
      ERROR       the files were found but failed to parse.
    """
    name = shortcut.get("name") or shortcut.get("code") or "(unnamed)"
    target_model = shortcut.get("target_model", "")
    search_dirs = list(search_dirs)

    pd_path = resolve_external_model(target_model, search_dirs)
    if pd_path is None:
        return ShortcutValidationResult(
            shortcut_name=name, external_model_found=False, status=STATUS_UNRESOLVED,
            detail=f"External model '{target_model}' not found in the configured "
                   f"search paths — it may not be part of this migration batch.",
        )

    erwin_path = resolve_external_erwin_xml(target_model, search_dirs)
    if erwin_path is None:
        return ShortcutValidationResult(
            shortcut_name=name, external_model_found=True, status=STATUS_UNRESOLVED,
            detail=f"External PD model found ({pd_path}) but no erwin XML "
                   f"export was found for '{target_model}'.",
        )

    try:
        pd_model = parse_pd_fn(pd_path)
        erwin_model = parse_erwin_fn(erwin_path)
    except Exception as exc:                                    # noqa: BLE001
        return ShortcutValidationResult(
            shortcut_name=name, external_model_found=True, status=STATUS_ERROR,
            detail=f"Failed to parse external model '{target_model}': {exc}",
        )

    pd_entities = _entity_keys(pd_model)
    erwin_entities = _entity_keys(erwin_model)
    total = len(pd_entities)
    matched = len(pd_entities & erwin_entities)
    pct = round(100.0 * matched / total, 2) if total else None

    return ShortcutValidationResult(
        shortcut_name=name, external_model_found=True,
        external_object_match_pct=pct, status=STATUS_RESOLVED,
        detail=f"{matched}/{total} external entities matched by code between "
               f"'{target_model}' and its erwin export.",
    )
