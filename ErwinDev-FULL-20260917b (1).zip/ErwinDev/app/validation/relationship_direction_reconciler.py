"""
Relationship Direction Reconciler (Workstream 4)
==================================================
Pairs up relationships that a name/endpoint match missed only because their
end order is reversed, so "Customer -> Order" in SAP PD and "Order ->
Customer" in erwin are classified as ``Direction Reconciled`` instead of one
CRITICAL "missing" finding plus one WARNING "extra" finding.

Called AFTER the normal ``match_objects`` pass, on whatever it left unmatched
on each side — it never touches relationships that already matched.
"""

from dataclasses import dataclass, field
from typing import Any, List

from app.validation.relationship_orientation_analyzer import (
    cardinality_equivalent_when_reversed,
    is_reversed,
)


def _label(rel: Any) -> str:
    name = getattr(rel, "name", "") or getattr(rel, "code", "")
    e1 = getattr(rel.end1, "entity", "")
    e2 = getattr(rel.end2, "entity", "")
    pair = f"{e1} \u2194 {e2}"
    return f"{name} ({pair})" if name else pair


@dataclass
class DirectionReconciliation:
    pd_rel: Any
    erwin_rel: Any
    original_direction: str
    target_direction: str
    semantic_direction_match: bool


@dataclass
class DirectionReconciliationOutcome:
    reconciled:    List[DirectionReconciliation] = field(default_factory=list)
    still_missing: List[Any] = field(default_factory=list)   # PD-only, no reversal found
    still_extra:   List[Any] = field(default_factory=list)   # erwin-only, no reversal found


def reconcile_unmatched(pd_only: List[Any],
                        erwin_only: List[Any]) -> DirectionReconciliationOutcome:
    """
    Attempt to explain every PD-only / erwin-only relationship as a direction
    reversal of one on the other side, rather than a genuine add/drop.
    """
    outcome = DirectionReconciliationOutcome()
    consumed_erwin_ids = set()

    for pd_rel in pd_only:
        match = None
        for erwin_rel in erwin_only:
            if id(erwin_rel) in consumed_erwin_ids:
                continue
            if is_reversed(pd_rel, erwin_rel):
                match = erwin_rel
                break
        if match is None:
            outcome.still_missing.append(pd_rel)
            continue

        consumed_erwin_ids.add(id(match))
        outcome.reconciled.append(DirectionReconciliation(
            pd_rel=pd_rel, erwin_rel=match,
            original_direction=_label(pd_rel), target_direction=_label(match),
            semantic_direction_match=cardinality_equivalent_when_reversed(pd_rel, match),
        ))

    outcome.still_extra = [r for r in erwin_only if id(r) not in consumed_erwin_ids]
    return outcome
