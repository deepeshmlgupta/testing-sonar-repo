"""
Model Metadata Fallback Resolver (Task 4)
============================================
A PD model-level value (typically the model Code) is sometimes carried into
erwin under a different field rather than lost outright — most often the
erwin Model Name, occasionally a migrated UDP value. Reporting a hard
mismatch without checking those other locations turns a traceable rename
into a false "differs between the two tools" finding.

Fallback order:  Model Code  ->  erwin Model Name  ->  UDP value  ->
Custom Property value  ->  Not Found.
"""

from dataclasses import dataclass
from typing import Iterable

LOCATED_IN_MODEL_CODE = "Model Code"
LOCATED_IN_MODEL_NAME = "Model Name"
LOCATED_IN_UDP = "UDP"
LOCATED_IN_CUSTOM_PROPERTY = "Custom Property"
NOT_FOUND = "Not Found"


def _key(value: str) -> str:
    return "".join(ch for ch in (value or "").strip().lower() if ch.isalnum())


@dataclass
class ModelMetadataResolution:
    pd_value: str
    located: bool
    located_in: str
    matched_value: str = ""


def resolve_model_code(pd_code: str, erwin_code: str, erwin_name: str = "",
                       udp_candidates: Iterable[str] = (),
                       custom_property_candidates: Iterable[str] = (),
                       ) -> ModelMetadataResolution:
    """Locate a PD model code somewhere in erwin's metadata, in fallback order."""
    pd_key = _key(pd_code)
    if not pd_key:
        return ModelMetadataResolution(pd_value=pd_code or "", located=False, located_in=NOT_FOUND)

    if pd_key == _key(erwin_code):
        return ModelMetadataResolution(pd_code, True, LOCATED_IN_MODEL_CODE, erwin_code)
    if pd_key == _key(erwin_name):
        return ModelMetadataResolution(pd_code, True, LOCATED_IN_MODEL_NAME, erwin_name)
    for candidate in udp_candidates or ():
        if pd_key == _key(candidate):
            return ModelMetadataResolution(pd_code, True, LOCATED_IN_UDP, candidate)
    for candidate in custom_property_candidates or ():
        if pd_key == _key(candidate):
            return ModelMetadataResolution(pd_code, True, LOCATED_IN_CUSTOM_PROPERTY, candidate)
    return ModelMetadataResolution(pd_code, False, NOT_FOUND)
