"""
Hierarchical Subject Area / Package Reconciliation (Workstream 1)
===================================================================
Recursive package/subject-area tree comparison, additive to the existing
single-level ``parent`` name check in the CDM/LDM comparators.

Nothing here depends on ``ldm_model.Package`` or ``cdm_model.Package``
directly: any object exposing ``name``, ``code`` and ``parent`` (duck-typed)
can be reconciled, so the same module serves both tiers without coupling.

Usage
-----
    from app.validation.hierarchy_reconciler import reconcile

    outcome = reconcile(pd_model.packages, erwin_model.packages)
    print(outcome.fidelity_pct)
    for finding in outcome.findings:
        print(finding.status, finding.source_path, finding.target_path)

Disabled by default; callers gate this behind
``config.ENABLE_HIERARCHY_RECONCILIATION`` so behaviour is unchanged unless a
tier explicitly opts in.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence

MAX_DEPTH = 50  # guards against a cyclic parent chain in malformed source data


def _key(value: str) -> str:
    return (value or "").strip().casefold()


def _label(node: Any) -> str:
    return (getattr(node, "name", "") or getattr(node, "code", "") or "").strip()


@dataclass
class HierarchyFinding:
    """One reconciled (or unreconciled) package/subject-area node."""
    name:              str
    source_path:       str = ""
    target_path:       str = ""
    hierarchy_match:   bool = False
    missing_ancestor:  str = ""
    depth_difference:  int = 0
    status:            str = "MISSING_IN_TARGET"  # MATCHED | PATH_MISMATCH |
                                                  # MISSING_IN_TARGET | EXTRA_IN_TARGET


@dataclass
class HierarchyReconciliationResult:
    findings:      List[HierarchyFinding] = field(default_factory=list)
    fidelity_pct:  float = 100.0
    total_nodes:   int = 0
    matched_nodes: int = 0


def _build_path_index(nodes: Sequence[Any]) -> Dict[str, str]:
    """
    Map each node's normalized key -> its full ancestor path ("Business/Customer/Retail").

    Missing/unresolved ancestors are dropped from the path silently (they are
    reported separately as ``missing_ancestor`` for the affected node), so a
    broken parent link never raises.
    """
    by_key: Dict[str, Any] = {_key(_label(n)): n for n in nodes if _label(n)}
    paths: Dict[str, str] = {}

    def resolve(node_key: str, seen: Optional[set] = None) -> List[str]:
        if node_key not in by_key:
            return []
        if seen is None:
            seen = set()
        if node_key in seen or len(seen) >= MAX_DEPTH:
            return [_label(by_key[node_key])]  # cycle guard: stop recursing
        seen = seen | {node_key}
        node = by_key[node_key]
        parent_raw = (getattr(node, "parent", "") or "").strip()
        parent_key = _key(parent_raw)
        if not parent_key or parent_key == node_key:
            return [_label(node)]
        return resolve(parent_key, seen) + [_label(node)]

    for key in by_key:
        paths[key] = "/".join(resolve(key))
    return paths


def _first_missing_ancestor(source_path: str, target_path: str) -> str:
    """The shallowest ancestor present on the source path but absent from the target."""
    target_segments = set((target_path or "").split("/")) if target_path else set()
    for segment in (source_path or "").split("/"):
        if segment and segment not in target_segments:
            return segment
    return ""


def reconcile(source_nodes: Sequence[Any],
             target_nodes: Sequence[Any]) -> HierarchyReconciliationResult:
    """
    Recursively reconcile two package/subject-area trees.

    ``source_nodes``/``target_nodes`` are typically ``pd_model.packages`` and
    ``erwin_model.packages`` (or the CDM equivalent) — any sequence of objects
    exposing ``name``/``code``/``parent``.
    """
    result = HierarchyReconciliationResult()
    if not source_nodes and not target_nodes:
        return result

    source_paths = _build_path_index(source_nodes)
    target_paths = _build_path_index(target_nodes)

    source_by_key = {_key(_label(n)): n for n in source_nodes if _label(n)}
    target_by_key = {_key(_label(n)): n for n in target_nodes if _label(n)}

    result.total_nodes = len(source_by_key)

    for key, node in source_by_key.items():
        label = _label(node)
        source_path = source_paths.get(key, label)

        if key not in target_by_key:
            result.findings.append(HierarchyFinding(
                name=label, source_path=source_path, target_path="",
                hierarchy_match=False, missing_ancestor=label,
                depth_difference=len(source_path.split("/")),
                status="MISSING_IN_TARGET",
            ))
            continue

        target_path = target_paths.get(key, label)
        depth_diff = abs(len(source_path.split("/")) - len(target_path.split("/")))

        if source_path == target_path:
            result.matched_nodes += 1
            result.findings.append(HierarchyFinding(
                name=label, source_path=source_path, target_path=target_path,
                hierarchy_match=True, missing_ancestor="",
                depth_difference=0, status="MATCHED",
            ))
        else:
            result.findings.append(HierarchyFinding(
                name=label, source_path=source_path, target_path=target_path,
                hierarchy_match=False,
                missing_ancestor=_first_missing_ancestor(source_path, target_path),
                depth_difference=depth_diff, status="PATH_MISMATCH",
            ))

    for key, node in target_by_key.items():
        if key not in source_by_key:
            label = _label(node)
            result.findings.append(HierarchyFinding(
                name=label, source_path="", target_path=target_paths.get(key, label),
                hierarchy_match=False, missing_ancestor="",
                depth_difference=0, status="EXTRA_IN_TARGET",
            ))

    result.fidelity_pct = (
        round(100.0 * result.matched_nodes / result.total_nodes, 2)
        if result.total_nodes else 100.0
    )
    return result
