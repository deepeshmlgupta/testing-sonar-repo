"""
Business Rule Semantic Comparator (Workstream 2)
==================================================
Public entry point the CDM/LDM comparators call when
``config.ENABLE_RULE_SEMANTIC_VALIDATION`` is on and a raw-text business rule
expression comparison has already found a difference.

This module never raises: an expression that cannot be parsed simply reports
``semantic_match=False`` with a reason, so the caller can safely fall back to
its existing (pre-Workstream-2) text-mismatch finding unchanged.
"""

from dataclasses import dataclass

from app.validation.business_rule_normalizer import normalize_expression


def _syntactic_key(text: str) -> str:
    """Whitespace/case-insensitive key — mirrors normalizers.normalize_definition's intent."""
    return " ".join((text or "").split()).casefold()


@dataclass
class RuleComparisonResult:
    semantic_match:  bool = False
    syntactic_match: bool = False
    pd_normalized:   str = ""
    erwin_normalized: str = ""
    reason:          str = ""


def compare_rule_expressions(pd_expression: str, erwin_expression: str) -> RuleComparisonResult:
    """
    Compare two business rule expressions syntactically and semantically.

    ``semantic_match`` is only ever True when BOTH expressions parsed as
    supported arithmetic/comparison/logical expressions and their canonical
    forms are identical — e.g. "Amount > 0" and "0 < Amount".
    """
    syntactic_match = _syntactic_key(pd_expression) == _syntactic_key(erwin_expression)
    if syntactic_match:
        return RuleComparisonResult(
            semantic_match=True, syntactic_match=True,
            pd_normalized=pd_expression, erwin_normalized=erwin_expression,
            reason="Identical after whitespace/case normalization.",
        )

    pd_norm = normalize_expression(pd_expression)
    erwin_norm = normalize_expression(erwin_expression)

    if pd_norm is None or erwin_norm is None:
        return RuleComparisonResult(
            semantic_match=False, syntactic_match=False,
            pd_normalized=pd_norm or "", erwin_normalized=erwin_norm or "",
            reason="One or both expressions could not be parsed as a "
                   "supported arithmetic/comparison/logical expression.",
        )

    match = pd_norm == erwin_norm
    return RuleComparisonResult(
        semantic_match=match, syntactic_match=False,
        pd_normalized=pd_norm, erwin_normalized=erwin_norm,
        reason="Canonical forms are equivalent." if match
               else "Canonical forms differ — the rule's meaning changed.",
    )
