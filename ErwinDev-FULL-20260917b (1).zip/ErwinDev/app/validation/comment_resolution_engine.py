"""
Description-to-Note Resolution Engine (Task 5 / Task 6)
======================================================
Before declaring a SAP PD Description MISSING_IN_ERWIN (as an erwin Note —
the client-confirmed mapping, 2026-09-16), check the other fields the text
could legitimately have landed in — a preprocessing or export choice can put
it in Definition, a migrated UDP value, or another property text block
instead of the Notes field the primary check reads. Also classify *why* a
genuinely missing description is missing, so a findings sheet says more than
"gone".

Generic by design: the two positional arguments are simply "source text" and
"the primary target's text", so this module works unchanged regardless of
which specific PD/erwin field pairing calls it.
"""

import unicodedata
from dataclasses import dataclass

LOCATED_IN_NOTE = "Note"
LOCATED_IN_DEFINITION = "Definition"
LOCATED_IN_DESCRIPTION = "Description"
LOCATED_IN_UDP = "UDP"
LOCATED_IN_PROPERTY = "Property"
LOCATED_IN_NONE = "Not Found"

ROOT_CAUSE_MIGRATED = "COMMENT_MIGRATED"
ROOT_CAUSE_FOUND_IN_UDP = "COMMENT_FOUND_IN_UDP"
ROOT_CAUSE_DIFFERENT_PROPERTY = "COMMENT_IN_DIFFERENT_PROPERTY"
ROOT_CAUSE_TRUNCATED = "COMMENT_TRUNCATED"
ROOT_CAUSE_ENCODING_DIFFERENCE = "COMMENT_ENCODING_DIFFERENCE"
ROOT_CAUSE_WHITESPACE_ONLY = "COMMENT_WHITESPACE_ONLY"
ROOT_CAUSE_NOT_MIGRATED = "COMMENT_NOT_MIGRATED"

# A candidate whose overlap with the source is at least this fraction of the
# source's length is "the same text, evidently truncated" rather than an
# unrelated value that happens to share a prefix.
_TRUNCATION_OVERLAP_RATIO = 0.5


def _fold(text: str) -> str:
    """Strip accents/diacritics so an encoding-only difference does not read as a real change."""
    decomposed = unicodedata.normalize("NFKD", text)
    return "".join(ch for ch in decomposed if not unicodedata.combining(ch)).casefold()


@dataclass
class CommentResolution:
    located: bool
    located_in: str
    root_cause: str
    matched_value: str = ""


def _check_candidate(pd_text: str, label: str, candidate: str, cause: str):
    candidate_text = (candidate or "").strip()
    if not candidate_text:
        return None
    if candidate_text == pd_text:
        return CommentResolution(True, label, ROOT_CAUSE_MIGRATED if label == LOCATED_IN_NOTE else cause,
                                 candidate)
    if _fold(candidate_text) == _fold(pd_text):
        return CommentResolution(True, label, ROOT_CAUSE_ENCODING_DIFFERENCE, candidate)
    shorter, longer = sorted((candidate_text, pd_text), key=len)
    if longer.startswith(shorter) and len(shorter) >= len(longer) * _TRUNCATION_OVERLAP_RATIO:
        return CommentResolution(True, label, ROOT_CAUSE_TRUNCATED, candidate)
    return None


def classify(pd_text_in: str, erwin_note: str, *,
            definition: str = "", description: str = "",
            udp_value: str = "", property_text: str = "") -> CommentResolution:
    """
    Resolve one object's Description -> Note migration, falling back through
    Definition, UDP and other property text before concluding the text was
    genuinely not migrated. (Named generically — this also works for any
    other source-field -> Note check that wants the same fallback chain.)
    """
    pd_text = (pd_text_in or "").strip()
    if not pd_text:
        return CommentResolution(True, LOCATED_IN_NONE, "", "")

    note_text = (erwin_note or "").strip()
    if note_text:
        found = _check_candidate(pd_text, LOCATED_IN_NOTE, note_text, ROOT_CAUSE_MIGRATED)
        if found:
            return found

    for label, value, cause in (
        (LOCATED_IN_DEFINITION, definition, ROOT_CAUSE_DIFFERENT_PROPERTY),
        (LOCATED_IN_DESCRIPTION, description, ROOT_CAUSE_DIFFERENT_PROPERTY),
        (LOCATED_IN_UDP, udp_value, ROOT_CAUSE_FOUND_IN_UDP),
        (LOCATED_IN_PROPERTY, property_text, ROOT_CAUSE_DIFFERENT_PROPERTY),
    ):
        found = _check_candidate(pd_text, label, value, cause)
        if found:
            return found

    if not any(ch.strip() for ch in pd_text_in or ""):
        return CommentResolution(False, LOCATED_IN_NONE, ROOT_CAUSE_WHITESPACE_ONLY, "")

    return CommentResolution(False, LOCATED_IN_NONE, ROOT_CAUSE_NOT_MIGRATED, "")
