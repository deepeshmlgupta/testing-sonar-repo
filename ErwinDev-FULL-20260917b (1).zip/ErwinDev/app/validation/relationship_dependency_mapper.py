"""
Relationship Dependency Semantic Mapper (Task 1 / Task 2)
==========================================================
PowerDesigner and erwin describe the same existence-dependency concept with
different vocabulary:

    PowerDesigner   Dependent    <->  erwin   Identifying
    PowerDesigner   Independent  <->  erwin   Non-Identifying

Comparing the two raw booleans is already comparing the right underlying
concept, but reporting erwin's side back in PowerDesigner's own words
("Dependent"/"Independent") hides that vocabulary mapping from the reviewer
and gives no path to reconcile a relationship whose ends are legitimately
reversed. This module makes the mapping explicit, and — for Task 2 — retries
the comparison against the other erwin end before declaring a genuine
mismatch, so a direction reversal is classified as reconciled rather than a
dependency defect.
"""

from dataclasses import dataclass
from typing import Optional

PD_DEPENDENT = "Dependent"
PD_INDEPENDENT = "Independent"
ERWIN_IDENTIFYING = "Identifying"
ERWIN_NON_IDENTIFYING = "Non-Identifying"

STATUS_PASS = "PASS"
STATUS_DIRECTION_RECONCILED = "DIRECTION_RECONCILED"
STATUS_MISMATCH = "MISMATCH"


def pd_label(dependent: bool) -> str:
    return PD_DEPENDENT if dependent else PD_INDEPENDENT


def erwin_label(identifying: bool) -> str:
    return ERWIN_IDENTIFYING if identifying else ERWIN_NON_IDENTIFYING


@dataclass
class DependencyReconciliation:
    pd_label: str
    erwin_label: str
    semantically_equivalent: bool
    status: str
    message: str


def reconcile(pd_dependent: bool, erwin_identifying: bool, *,
             reversed_erwin_identifying: Optional[bool] = None) -> DependencyReconciliation:
    """
    Classify one relationship end's dependency pair under the PD<->erwin
    vocabulary mapping.

    ``reversed_erwin_identifying`` is the identifying flag erwin carries on
    the OTHER end of the same relationship (FK ownership / PK propagation
    read from the opposite direction). When the direct comparison mismatches
    but the reversed one agrees, the relationship is direction-reconcilable
    rather than genuinely different — the endpoint orientation, not the
    semantics, is what differs.
    """
    pd_dependent = bool(pd_dependent)
    erwin_identifying = bool(erwin_identifying)

    if pd_dependent == erwin_identifying:
        return DependencyReconciliation(
            pd_label=pd_label(pd_dependent), erwin_label=erwin_label(erwin_identifying),
            semantically_equivalent=True, status=STATUS_PASS,
            message="Dependency semantics equivalent",
        )

    if reversed_erwin_identifying is not None and pd_dependent == bool(reversed_erwin_identifying):
        return DependencyReconciliation(
            pd_label=pd_label(pd_dependent),
            erwin_label=erwin_label(bool(reversed_erwin_identifying)),
            semantically_equivalent=True, status=STATUS_DIRECTION_RECONCILED,
            message="Dependency semantics equivalent once FK ownership / PK "
                    "propagation is read from the other end — only the "
                    "endpoint orientation differs, not the business rule.",
        )

    return DependencyReconciliation(
        pd_label=pd_label(pd_dependent), erwin_label=erwin_label(erwin_identifying),
        semantically_equivalent=False, status=STATUS_MISMATCH,
        message="Existence dependency (identifying relationship) differs",
    )
