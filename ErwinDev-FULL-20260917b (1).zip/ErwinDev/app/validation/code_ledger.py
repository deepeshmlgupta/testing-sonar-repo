"""
Attribute Code Preservation Ledger
==================================

A deterministic, auditable record of what happened to every SAP PowerDesigner
attribute CODE, and the transport that actually carries those codes into erwin.

THE PROBLEM
-----------
erwin's conceptual/logical export has no ``Physical_Name`` property — verified
against both supplied exports, which contain zero of them. So an attribute's
PowerDesigner Code has no native field in erwin and is simply gone unless it is
carried some other way.

Entity codes were already solved: ``udp_bridge._append_code_rows`` writes one
``PD_Code`` UDP per entity, and ``app/udp_tool/erwin_load.py`` injects it by
resolving the target ENTITY by name. Attributes were not, and the reason is
structural: ``erwin_load`` can address an entity and nothing below it. It has
no way to say "this UDP belongs to attribute X of entity Y".

WHY NOT JUST CHANGE erwin_load
------------------------------
Because it is a Windows-only COM path against a licensed product that cannot be
exercised in CI, and because ``app/udp_tool`` is deliberately left byte-identical
to the standalone tool. Rewriting target resolution there would put the least
testable code in the framework on the critical path of every migration.

WHAT THIS MODULE DOES INSTEAD
-----------------------------
It uses the transport that already exists and already works. The attribute
codes of an entity are encoded into ONE entity-level UDP, ``PD_Attribute_Codes``,
which travels through the same manifest, the same ``erwin_load`` injection and
the same read-back verification as every other UDP. Nothing new has to be
trusted.

IDENTITY: NEVER BY NAME ALONE
-----------------------------
Every record is keyed by the PowerDesigner OBJECT ID of the attribute and of
its owning entity. Two attributes in different entities routinely share a name
("ID", "CODE", "NAME", "STATUS"); resolving on a bare name across a model is
how one attribute's code ends up recorded against another's. So:

* the LEDGER is keyed by ``(pd_entity_oid, pd_attr_oid)`` — globally unique
  within a PowerDesigner model, and stable across re-exports of that model;
* each encoded entry additionally carries the attribute's declaration ORDER and
  a DATATYPE fingerprint, so a reader resolving the entry against erwin has
  three independent signals (name, position, type) and can say which of them
  agreed. A single-signal match is recorded as ``AMBIGUOUS`` rather than
  silently accepted;
* an entity whose own identity cannot be established is not written at all. A
  guess is worse than a gap, because a gap is visible.

STATUSES
--------
``PRESERVED``                       encoded into the UDP payload for injection
``NOT_PRESERVED``                   code equals name, so there is nothing to carry
``AMBIGUOUS``                       the attribute could not be identified uniquely
``EXTERNAL_VERIFICATION_REQUIRED``  encoded, but no read-back has confirmed it
                                    reached erwin. Needs a Windows + erwin run.

The ledger is persisted per model with the SHA-256 of the SAP source it was
built from, so a record belonging to another model, or to a source that has
changed since, is refused rather than reused.

Nothing here scores anything. It records facts and carries values; the
comparator decides what they mean.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

SCHEMA_VERSION = 1
_SUBDIR = "code_ledger"

#: The entity-level UDP that carries its attributes' codes into erwin.
UDP_ATTRIBUTE_CODES = "PD_Attribute_Codes"

#: Field and record separators for the encoded payload. Chosen because neither
#: can occur in a PowerDesigner name or code, so decoding is unambiguous and
#: needs no escaping — and because both survive erwin's UDP text storage, which
#: the \x1F-delimited Note format does not.
RECORD_SEP = "|"
FIELD_SEP = "="
META_SEP = "~"

STATUS_PRESERVED = "PRESERVED"
STATUS_NOT_PRESERVED = "NOT_PRESERVED"
STATUS_AMBIGUOUS = "AMBIGUOUS"
STATUS_EXTERNAL = "EXTERNAL_VERIFICATION_REQUIRED"

#: Rejection reasons, mirroring udp_evidence so both stores refuse alike.
REJECT_ABSENT = "no ledger recorded for this model"
REJECT_SCHEMA = "ledger written by a different schema version"
REJECT_MODEL = "ledger belongs to a different model"
REJECT_SOURCE_CHANGED = "the SAP PD source has changed since the ledger was written"
REJECT_SOURCE_MISSING = "the SAP PD source the ledger was measured from is gone"

_UNSAFE = re.compile(r"[|=~\x00-\x1f]")


# ═════════════════════════════════════════════════════════════════════════════
#  Records
# ═════════════════════════════════════════════════════════════════════════════

@dataclass
class AttributeCode:
    """One SAP PD attribute's code, and what became of it."""

    pd_entity_oid: str = ""
    pd_entity_name: str = ""
    pd_entity_code: str = ""
    pd_attr_oid: str = ""
    pd_attr_name: str = ""
    pd_attr_code: str = ""
    pd_attr_order: int = 0
    pd_data_type: str = ""
    status: str = ""
    #: Which signals identify this attribute uniquely inside its entity.
    #: A record identified by name ALONE is never treated as resolved.
    identity_basis: str = ""
    note: str = ""

    def key(self) -> Tuple[str, str]:
        return (self.pd_entity_oid, self.pd_attr_oid)


@dataclass
class CodeLedger:
    """Every attribute code in one model, plus the provenance of the record."""

    schema_version: int = SCHEMA_VERSION
    model_name: str = ""
    model_type: str = ""
    pd_path: str = ""
    pd_sha256: str = ""
    pd_bytes: int = 0
    recorded_at: str = ""
    recorded_by: str = ""
    entities: int = 0
    attributes: int = 0
    records: List[AttributeCode] = field(default_factory=list)

    def by_status(self, status: str) -> List[AttributeCode]:
        return [record for record in self.records if record.status == status]

    def preserved(self) -> List[AttributeCode]:
        return self.by_status(STATUS_PRESERVED)

    def lookup(self, entity_oid: str, attr_oid: str) -> Optional[AttributeCode]:
        """Exact, id-based lookup. There is deliberately no lookup by name."""
        for record in self.records:
            if record.pd_entity_oid == entity_oid and record.pd_attr_oid == attr_oid:
                return record
        return None

    def summary(self) -> str:
        counts = {}
        for record in self.records:
            counts[record.status] = counts.get(record.status, 0) + 1
        parts = ", ".join(f"{status} {count}" for status, count in sorted(counts.items()))
        return (f"{self.attributes} attribute(s) across {self.entities} entit"
                f"{'y' if self.entities == 1 else 'ies'}: {parts or 'none'}")


# ═════════════════════════════════════════════════════════════════════════════
#  Building
# ═════════════════════════════════════════════════════════════════════════════

def _safe(value: str) -> str:
    """A value that cannot corrupt the encoded payload, or '' if it would."""
    text = str(value or "").strip()
    return "" if _UNSAFE.search(text) else text


def type_fingerprint(attribute) -> str:
    """
    A short, stable datatype signature used as a SECOND identity signal.

    Deliberately coarse — just the type family and any length — because the
    point is to distinguish two same-named attributes in one entity, not to
    validate the type. Type validation is the comparator's job.
    """
    data_type = str(getattr(attribute, "data_type", "") or "").strip().upper()
    length = str(getattr(attribute, "length", "") or "").strip()
    family = re.split(r"[\s(,]", data_type)[0] if data_type else ""
    return f"{family}{f'({length})' if family and length else ''}"


def identity_basis(attribute, siblings) -> str:
    """
    Which signals identify this attribute uniquely among its entity's own
    attributes. Returns a '+'-joined list, or '' when nothing does.

    Name is never sufficient on its own — it is reported as one signal among
    several, and a record whose only unique signal would be the name is marked
    AMBIGUOUS. Order is unique by construction within a well-formed entity and
    is what makes most records resolvable.
    """
    name_key = str(getattr(attribute, "name", "") or "").strip().upper()
    same_name = [other for other in siblings
                 if str(getattr(other, "name", "") or "").strip().upper() == name_key]
    signals = []
    if len(same_name) == 1:
        signals.append("name")
    fingerprint = type_fingerprint(attribute)
    if fingerprint and len([other for other in same_name
                            if type_fingerprint(other) == fingerprint]) == 1:
        signals.append("data_type")
    order = int(getattr(attribute, "order", 0) or 0)
    if len([other for other in siblings
            if int(getattr(other, "order", 0) or 0) == order]) == 1:
        signals.append("order")
    return "+".join(signals)


def _entity_is_identifiable(entity) -> bool:
    """An entity with no object id cannot anchor a deterministic record."""
    return bool(str(getattr(entity, "oid", "") or "").strip())


def _entities_of(pd_model) -> List[Any]:
    """
    The model's entities as a list, whether the parser exposes them as a list
    or (as both tier parsers do) as a dict keyed by object id.

    Iterating a dict yields its KEYS — plain strings — so a version of this
    that did not normalise silently recorded nothing at all while logging one
    "entity has no object id" warning per entity. The ledger looked empty and
    the comparator, which is handed real Entity objects, disagreed with it.
    """
    entities = getattr(pd_model, "entities", None)
    if isinstance(entities, dict):
        return list(entities.values())
    return list(entities or ())


def build(pd_model, model_name: str = "", model_type: str = "",
          pd_path: str = "") -> CodeLedger:
    """
    Build the ledger from an already-parsed SAP PD model.

    Takes the parsed model rather than a path so it reuses the tier's own
    parser — the same objects the comparator reconciles — instead of adding a
    second, drifting reader of the PowerDesigner XML.
    """
    ledger = CodeLedger(
        model_name=model_name or str(getattr(pd_model, "model_name", "") or ""),
        model_type=model_type,
        pd_path=str(pd_path or ""),
        recorded_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        recorded_by=_actor(),
    )
    if pd_path:
        ledger.pd_sha256 = sha256_of(pd_path)
        try:
            ledger.pd_bytes = os.path.getsize(pd_path)
        except OSError:
            ledger.pd_bytes = 0

    for entity in _entities_of(pd_model):
        if not _entity_is_identifiable(entity):
            logger.warning(
                "Entity %r has no object id; its attribute codes are NOT recorded in "
                "the preservation ledger. Resolving it by name would risk attaching "
                "one entity's codes to another.",
                getattr(entity, "name", "?"))
            continue
        ledger.entities += 1
        ledger.records.extend(_records_for(entity))

    ledger.attributes = len(ledger.records)
    logger.info("Code preservation ledger for %s: %s", ledger.model_name, ledger.summary())
    return ledger


def _records_for(entity) -> List[AttributeCode]:
    siblings = [attribute for attribute in (getattr(entity, "attributes", None) or ())
                if not getattr(attribute, "is_migrated", False)]
    records: List[AttributeCode] = []
    for attribute in siblings:
        name = str(getattr(attribute, "name", "") or "").strip()
        code = str(getattr(attribute, "code", "") or "").strip()
        record = AttributeCode(
            pd_entity_oid=str(getattr(entity, "oid", "") or ""),
            pd_entity_name=str(getattr(entity, "name", "") or ""),
            pd_entity_code=str(getattr(entity, "code", "") or ""),
            pd_attr_oid=str(getattr(attribute, "oid", "") or ""),
            pd_attr_name=name,
            pd_attr_code=code,
            pd_attr_order=int(getattr(attribute, "order", 0) or 0),
            pd_data_type=type_fingerprint(attribute),
            identity_basis=identity_basis(attribute, siblings),
        )
        record.status, record.note = classify(record)
        records.append(record)
    return records


def classify(record: AttributeCode) -> Tuple[str, str]:
    """The status of one record, and why."""
    if not record.pd_attr_oid:
        return (STATUS_AMBIGUOUS,
                "the attribute has no PowerDesigner object id, so it cannot be "
                "identified deterministically")
    if not record.pd_entity_oid:
        # build() refuses to record an entity with no object id. classify()
        # must refuse it too, or the comparator would report a preservation
        # for an attribute the ledger never wrote and erwin never received.
        return (STATUS_AMBIGUOUS,
                "the owning entity has no PowerDesigner object id, so this "
                "attribute's code cannot be anchored to a target entity")
    if not record.pd_attr_code or not record.pd_attr_name:
        return (STATUS_NOT_PRESERVED,
                "the attribute has no name or no code; there is nothing to carry")
    if record.pd_attr_code.upper() == record.pd_attr_name.upper():
        return (STATUS_NOT_PRESERVED,
                "the Code equals the Name, so erwin's name already carries it")
    basis = set((record.identity_basis or "").split("+")) - {""}
    if not basis or basis == {"name"}:
        return (STATUS_AMBIGUOUS,
                "the attribute is not uniquely identifiable within its entity by "
                "anything except its name; a name-only match is not accepted")
    if not _safe(record.pd_attr_name) or not _safe(record.pd_attr_code):
        return (STATUS_AMBIGUOUS,
                "the name or code contains a character the UDP payload cannot "
                "encode unambiguously; it is reported rather than mangled")
    return (STATUS_PRESERVED, "")


# ═════════════════════════════════════════════════════════════════════════════
#  Encoding — the transport erwin actually receives
# ═════════════════════════════════════════════════════════════════════════════

def encode(records: List[AttributeCode]) -> str:
    """
    One entity's PRESERVED records as a single UDP value.

        NAME=CODE~order~TYPE|NAME=CODE~order~TYPE

    Order and the type fingerprint travel WITH each entry precisely so that a
    reader never has to fall back to matching on the name alone. Entries are
    sorted by declaration order so the payload is byte-stable between runs of
    the same model — a value that changes without the model changing would make
    the read-back comparison meaningless.
    """
    entries = []
    for record in sorted(records, key=lambda item: (item.pd_attr_order, item.pd_attr_name)):
        if record.status != STATUS_PRESERVED:
            continue
        entries.append(
            f"{record.pd_attr_name}{FIELD_SEP}{record.pd_attr_code}"
            f"{META_SEP}{record.pd_attr_order}{META_SEP}{record.pd_data_type}")
    return RECORD_SEP.join(entries)


def decode(payload: str) -> List[Dict[str, Any]]:
    """
    Read an encoded payload back. Malformed entries are SKIPPED and logged,
    never guessed at: a half-understood entry is a wrong code attached to a
    real attribute, which is worse than a missing one.
    """
    out: List[Dict[str, Any]] = []
    for entry in str(payload or "").split(RECORD_SEP):
        entry = entry.strip()
        if not entry:
            continue
        if FIELD_SEP not in entry:
            logger.warning("Ignoring malformed %s entry (no '%s'): %r",
                           UDP_ATTRIBUTE_CODES, FIELD_SEP, entry[:80])
            continue
        name, _, remainder = entry.partition(FIELD_SEP)
        parts = remainder.split(META_SEP)
        code = parts[0] if parts else ""
        try:
            order = int(parts[1]) if len(parts) > 1 and parts[1] else 0
        except ValueError:
            order = 0
        out.append({
            "name": name.strip(),
            "code": code.strip(),
            "order": order,
            "data_type": parts[2].strip() if len(parts) > 2 else "",
        })
    return out


def udp_rows(ledger: CodeLedger) -> Tuple[List[dict], List[dict]]:
    """
    (schema rows, manifest rows) carrying this ledger into erwin.

    Entity-level, because that is the only granularity ``erwin_load`` can
    address. One row per entity that actually has something to preserve.
    """
    by_entity: Dict[str, List[AttributeCode]] = {}
    for record in ledger.preserved():
        by_entity.setdefault(record.pd_entity_name, []).append(record)
    if not by_entity:
        return [], []

    payloads = {name: encode(records) for name, records in by_entity.items()}
    payloads = {name: value for name, value in payloads.items() if value}
    if not payloads:
        return [], []

    longest = max(len(value) for value in payloads.values())
    schema = [{
        "udp": UDP_ATTRIBUTE_CODES,
        "type": "Text",
        "length": max(255, min(8000, longest + 64)),
        "value_list": None, "source_path": "", "coverage": "",
        "distinct_observed": "", "list_source": "",
        "purpose": "PowerDesigner ATTRIBUTE Codes for this entity, as "
                   "NAME=CODE~order~TYPE separated by '|'. erwin's logical model has "
                   "no Physical_Name on an attribute, so the technical names would "
                   "otherwise be lost. Carried at entity level because that is the "
                   "granularity erwin_load can address; order and type travel with "
                   "each entry so a reader never resolves on the name alone.",
    }]
    manifest = [{
        "pd_object_id": next((record.pd_entity_oid for record in by_entity[name]), ""),
        "entity_name": name,
        "entity_code": next((record.pd_entity_code for record in by_entity[name]), ""),
        "udp": UDP_ATTRIBUTE_CODES,
        "value": payload,
        "source_path": "",
    } for name, payload in sorted(payloads.items())]

    logger.info("Preserving %d attribute Code(s) across %d entit%s as the %s UDP.",
                sum(len(records) for records in by_entity.values()), len(manifest),
                "y" if len(manifest) == 1 else "ies", UDP_ATTRIBUTE_CODES)
    return schema, manifest


# ═════════════════════════════════════════════════════════════════════════════
#  Persistence
# ═════════════════════════════════════════════════════════════════════════════

def sha256_of(path) -> str:
    try:
        digest = hashlib.sha256()
        with open(path, "rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
        return digest.hexdigest()
    except OSError:
        return ""


def _actor() -> str:
    return os.environ.get("USERNAME") or os.environ.get("USER") or "unknown"


def ledger_dir(dirs, create: bool = True) -> Path:
    root = Path(dirs["summary"]) / _SUBDIR if isinstance(dirs, dict) and dirs.get("summary") \
        else Path(_SUBDIR)
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root


def path_for(dirs, model_name: str, create: bool = True) -> Path:
    return ledger_dir(dirs, create=create) / f"{model_name}.json"


def save(dirs, ledger: CodeLedger) -> Optional[Path]:
    """Persist the ledger. Never raises: a storage problem must not fail a run."""
    try:
        target = path_for(dirs, ledger.model_name)
        target.write_text(json.dumps(asdict(ledger), indent=2, default=str),
                          encoding="utf-8")
        logger.info("Code preservation ledger written to %s", target)
        return target
    except (OSError, TypeError, ValueError) as exc:
        logger.warning("Could not persist the code ledger for %s: %s",
                       ledger.model_name, exc)
        return None


def load(dirs, model_name: str) -> Optional[CodeLedger]:
    path = path_for(dirs, model_name, create=False)
    if not path.is_file():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8")) or {}
    except (OSError, ValueError) as exc:
        logger.warning("Code ledger for %s is unreadable (%s); treated as absent.",
                       model_name, exc)
        return None
    records = [AttributeCode(**row) for row in payload.pop("records", []) or []
               if isinstance(row, dict)]
    try:
        return CodeLedger(records=records, **payload)
    except TypeError as exc:
        logger.warning("Code ledger for %s has an unexpected shape (%s); treated "
                       "as absent.", model_name, exc)
        return None


def verify(ledger: Optional[CodeLedger], model_name: str,
           pd_path: Optional[str] = None) -> Tuple[Optional[CodeLedger], str]:
    """
    (ledger, "") when it may be used, or (None, reason) when it must not.

    Same refusal discipline as udp_evidence: wrong schema, wrong model or a
    changed source means the record is refused outright rather than used with
    a caveat.
    """
    if ledger is None:
        return None, REJECT_ABSENT
    if int(getattr(ledger, "schema_version", 0) or 0) != SCHEMA_VERSION:
        return None, REJECT_SCHEMA
    if model_name and ledger.model_name and ledger.model_name != model_name:
        return None, REJECT_MODEL
    if pd_path and ledger.pd_sha256:
        if not os.path.isfile(pd_path):
            return None, REJECT_SOURCE_MISSING
        if sha256_of(pd_path) != ledger.pd_sha256:
            return None, REJECT_SOURCE_CHANGED
    return ledger, ""


def for_model(dirs, model_name: str, pd_path: Optional[str] = None
              ) -> Tuple[Optional[CodeLedger], str]:
    """The verified ledger for a model, or (None, reason)."""
    if dirs is None or not model_name:
        return None, REJECT_ABSENT
    try:
        return verify(load(dirs, model_name), model_name, pd_path)
    except Exception as exc:                                   # noqa: BLE001
        logger.warning("Could not read the code ledger for %s: %s", model_name, exc)
        return None, REJECT_ABSENT


def as_report_rows(ledger: Optional[CodeLedger]) -> List[Tuple[Any, ...]]:
    """Ledger rows for a report sheet, newest schema first."""
    if ledger is None:
        return []
    return [(record.pd_entity_name, record.pd_attr_name, record.pd_attr_code,
             record.pd_attr_order, record.pd_data_type, record.identity_basis,
             record.status, record.note)
            for record in sorted(ledger.records,
                                 key=lambda item: (item.pd_entity_name,
                                                   item.pd_attr_order,
                                                   item.pd_attr_name))]


__all__ = [
    "SCHEMA_VERSION", "UDP_ATTRIBUTE_CODES", "RECORD_SEP", "FIELD_SEP", "META_SEP",
    "STATUS_PRESERVED", "STATUS_NOT_PRESERVED", "STATUS_AMBIGUOUS", "STATUS_EXTERNAL",
    "REJECT_ABSENT", "REJECT_SCHEMA", "REJECT_MODEL", "REJECT_SOURCE_CHANGED",
    "REJECT_SOURCE_MISSING", "AttributeCode", "CodeLedger", "build", "encode",
    "decode", "udp_rows", "sha256_of", "ledger_dir", "path_for", "save", "load",
    "verify", "for_model", "as_report_rows", "type_fingerprint",
    "identity_basis", "classify",
]
