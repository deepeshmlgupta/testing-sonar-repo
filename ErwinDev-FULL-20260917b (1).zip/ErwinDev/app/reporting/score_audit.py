"""
Score reconciliation — the fidelity number, reconstructed from the rows
======================================================================

A fidelity score that cannot be rebuilt from the report's own finding rows is
an assertion, not a measurement. This module rebuilds it and shows the working,
so a reviewer can check the number instead of trusting it.

It recomputes, from the SAME finding list the FINDINGS sheet prints:

    comparable = entities + attributes + relationships + identifiers +
                 inheritances   (all counted on the SAP PD side)
    penalty    = critical x w(CRITICAL) + warning x w(WARNING) + info x w(INFO)
    penalty    = min(penalty, comparable x FIDELITY_MAX_PENALTY_PER_OBJECT)
    structural = 100 x (1 - penalty / comparable)

and then the staged weighted mean the pipeline actually reports:

    overall    = SUM(component x weight) / SUM(weight of MEASURABLE components)

Two properties are the point of the sheet:

* Every severity is listed, including the ones that contribute NOTHING
  (VERIFIED, SOURCE_PRE_EXISTING, IGNORE). A reader can see exactly which rows
  were excluded from the penalty and why — the excluded rows stay visible in
  the report, so "not scored" can be audited rather than taken on trust.
* The recomputed structural number is printed NEXT TO the one the comparator
  reported, with an explicit AGREES / DISAGREES verdict. If scoring logic ever
  drifts from the rows it claims to summarise, the sheet says so in the
  deliverable itself rather than leaving it to be discovered.

Nothing here changes a score. It only re-derives and displays one.
"""

import logging
from collections import Counter
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

SHEET_SCORE_AUDIT = "SCORE_RECONCILIATION"

#: Severities that carry a penalty weight. Anything else is visible-but-unscored.
SCORING_SEVERITIES = ("CRITICAL", "WARNING", "INFO")

_DEFAULT_WEIGHTS = {"CRITICAL": 1.0, "WARNING": 0.35, "INFO": 0.05}

#: Why each non-scoring severity carries no weight. Printed in the sheet so the
#: exclusion is justified in the deliverable, not only in the source.
NON_SCORING_REASON = {
    "VERIFIED": "Evidence that the object migrated intact — a pass, not a defect.",
    "SOURCE_PRE_EXISTING": "Identical in BOTH models: the migration neither "
                           "caused it nor could fix it. Visible and actionable, "
                           "but not a migration defect.",
    "IGNORE": "Explicitly suppressed by configuration; the row is not emitted.",
}


def _counts_by_severity(findings) -> Counter:
    return Counter(getattr(f, "severity", "") or "" for f in findings or ())


def _counts_by_category(findings) -> Counter:
    return Counter(((getattr(f, "severity", "") or ""),
                    (getattr(f, "category", "") or getattr(f, "key", "") or ""))
                   for f in findings or ())


def comparable_objects(result) -> Tuple[int, str]:
    """
    The denominator, and the arithmetic that produced it, as text.

    Mirrors the comparators' own ``comparable`` expression. PDM counts tables /
    columns / foreign keys instead of entities / attributes / relationships, so
    both shapes are supported and whichever one the result exposes is used.
    """
    ldm_parts = (("entities", "entities_pd"), ("attributes", "attributes_pd"),
                 ("relationships", "relationships_pd"), ("identifiers", "identifiers_pd"),
                 ("inheritances", "inheritances_pd"))
    pdm_parts = (("tables", "tables_pd"), ("columns", "columns_pd"),
                 ("foreign keys", "fk_pd"))

    for parts in (ldm_parts, pdm_parts):
        present = [(label, int(getattr(result, attr, 0) or 0))
                   for label, attr in parts if hasattr(result, attr)]
        if present:
            total = sum(value for _, value in present)
            workings = " + ".join(f"{label} {value}" for label, value in present)
            return max(1, total), f"{workings} = {max(1, total)}"
    return 1, "no comparable objects exposed by the result — denominator floored at 1"


def weights_for(config) -> Dict[str, float]:
    configured = getattr(config, "FIDELITY_WEIGHTS", None) if config is not None else None
    if not isinstance(configured, dict) or not configured:
        return dict(_DEFAULT_WEIGHTS)
    return {name: float(value) for name, value in configured.items()}


def reconstruct(result, config=None) -> Dict[str, Any]:
    """
    Rebuild the structural score from the result's own findings.

    Returns a dict with the counts, the weights, the arithmetic as text, the
    recomputed score, the score the comparator reported, and whether they
    agree (to 0.01, the precision both are rounded to).
    """
    findings = list(getattr(result, "findings", None) or ())
    severities = _counts_by_severity(findings)
    weights = weights_for(config)
    comparable, comparable_workings = comparable_objects(result)

    terms: List[str] = []
    raw_penalty = 0.0
    for severity in SCORING_SEVERITIES:
        count = int(severities.get(severity, 0))
        weight = float(weights.get(severity, _DEFAULT_WEIGHTS.get(severity, 0.0)))
        raw_penalty += count * weight
        terms.append(f"{count} x {weight:g}")

    cap = getattr(config, "FIDELITY_MAX_PENALTY_PER_OBJECT", 1.0) if config is not None else 1.0
    ceiling = comparable * float(cap)
    penalty = min(raw_penalty, ceiling)
    recomputed = round(max(0.0, 100.0 * (1.0 - penalty / comparable)), 2)

    reported = getattr(result, "structural_fidelity_score", None)
    if reported is None:
        reported = getattr(result, "fidelity_score", None)

    agrees: Optional[bool] = None
    if reported is not None:
        agrees = abs(round(float(reported), 2) - recomputed) < 0.005

    return {
        "findings_total": len(findings),
        "severities": dict(severities),
        "categories": _counts_by_category(findings),
        "weights": weights,
        "comparable": comparable,
        "comparable_workings": comparable_workings,
        "penalty_terms": " + ".join(terms),
        "penalty_raw": round(raw_penalty, 4),
        "penalty_cap": round(ceiling, 4),
        "penalty_capped": raw_penalty > ceiling,
        "penalty": round(penalty, 4),
        "formula": (f"100 x (1 - {round(penalty, 4)} / {comparable})"),
        "recomputed": recomputed,
        "reported": None if reported is None else round(float(reported), 2),
        "agrees": agrees,
    }


def stage_workings(stage_score) -> List[Tuple[str, Any, Any, str]]:
    """
    (component, measured %, weight, note) rows for one StageScore, followed by
    the weighted-mean arithmetic. A component measured as None is shown as
    "not measured" with weight "dropped", which is what renormalisation means.
    """
    if stage_score is None:
        return []
    components = dict(getattr(stage_score, "components", {}) or {})
    weights = dict(getattr(stage_score, "weights", {}) or {})
    rows: List[Tuple[str, Any, Any, str]] = []
    for name, value in components.items():
        weight = weights.get(name)
        if value is None:
            rows.append((name, "not measured", "dropped",
                         "No evidence for this component; the remaining weights "
                         "are renormalised so its absence costs nothing."))
        elif weight is None:
            rows.append((name, round(float(value), 2), 0,
                         "Measured but carries weight 0 in this tier's "
                         "FIDELITY_STAGE_WEIGHTS — reported, never scored."))
        else:
            rows.append((name, round(float(value), 2), weight, ""))
    return rows


def stage_formula(stage_score) -> str:
    """The weighted mean, written out with the numbers substituted in."""
    if stage_score is None:
        return ""
    components = dict(getattr(stage_score, "components", {}) or {})
    weights = dict(getattr(stage_score, "weights", {}) or {})
    used = [(name, components[name], weight) for name, weight in weights.items()
            if components.get(name) is not None]
    if not used:
        return "No component could be measured; no weighted mean exists."
    numerator = " + ".join(f"{float(value):.2f} x {weight:g}" for _, value, weight in used)
    denominator = " + ".join(f"{weight:g}" for _, _, weight in used)
    total_weight = sum(weight for _, _, weight in used)
    total = sum(float(value) * weight for _, value, weight in used)
    return (f"({numerator}) / ({denominator}) = {total:.4f} / {total_weight:g} "
            f"= {round(total / total_weight, 2):.2f}")


def write_sheet(workbook, result, stage_score=None, config=None, index: int = 2) -> None:
    """
    Add the SCORE_RECONCILIATION sheet to an open workbook.

    Never raises: a reporting problem must not fail a pipeline run.
    """
    try:
        from openpyxl.styles import Alignment, Font, PatternFill

        audit = reconstruct(result, config)
        sheet = workbook.create_sheet(SHEET_SCORE_AUDIT, index)
        bold = Font(bold=True)
        head_fill = PatternFill("solid", fgColor="FFD9E1F2")

        sheet["A1"] = "Score reconciliation — the fidelity number rebuilt from the finding rows"
        sheet["A1"].font = Font(bold=True, size=14)
        sheet.merge_cells("A1:E1")
        sheet["A2"] = (
            "Every number below is recomputed from the rows on the FINDINGS sheet of this "
            "same workbook. If the recomputed structural score does not match the reported "
            "one, this sheet says so — the score is meant to be checkable, not taken on trust.")
        sheet["A2"].alignment = Alignment(wrap_text=True, vertical="top")
        sheet.merge_cells("A2:E2")
        sheet.row_dimensions[2].height = 42

        row = 4
        row = _write_severity_block(sheet, audit, row, bold, head_fill)
        row = _write_structural_block(sheet, audit, row, bold, head_fill)
        row = _write_stage_block(sheet, stage_score, row, bold, head_fill)
        _write_category_block(sheet, audit, row, bold, head_fill)

        for column, width in (("A", 30), ("B", 46), ("C", 16), ("D", 14), ("E", 60)):
            sheet.column_dimensions[column].width = width
    except Exception as exc:                                   # noqa: BLE001
        logger.warning("Score reconciliation sheet could not be written: %s", exc)


def _header(sheet, row: int, caption: str, bold, fill, span: int = 5) -> int:
    sheet.cell(row=row, column=1, value=caption).font = bold
    for column in range(1, span + 1):
        sheet.cell(row=row, column=column).fill = fill
    return row + 1


def _write_severity_block(sheet, audit, row: int, bold, fill) -> int:
    row = _header(sheet, row, "1. Findings by severity", bold, fill)
    for caption, column in (("Severity", 1), ("Count", 2), ("Penalty weight", 3),
                            ("Contributes to the score?", 4), ("Why", 5)):
        sheet.cell(row=row, column=column, value=caption).font = bold
    row += 1
    severities = audit["severities"]
    for severity in sorted(severities, key=lambda s: (s not in SCORING_SEVERITIES, s)):
        scoring = severity in SCORING_SEVERITIES
        sheet.cell(row=row, column=1, value=severity)
        sheet.cell(row=row, column=2, value=int(severities[severity]))
        sheet.cell(row=row, column=3,
                   value=audit["weights"].get(severity, 0.0) if scoring else 0.0)
        sheet.cell(row=row, column=4, value="YES" if scoring else "no — weight 0")
        sheet.cell(row=row, column=5,
                   value="" if scoring else NON_SCORING_REASON.get(
                       severity, "Not a penalty severity."))
        row += 1
    sheet.cell(row=row, column=1, value="TOTAL rows in this report").font = bold
    sheet.cell(row=row, column=2, value=audit["findings_total"]).font = bold
    return row + 2


def _write_structural_block(sheet, audit, row: int, bold, fill) -> int:
    row = _header(sheet, row, "2. Structural fidelity, recomputed", bold, fill)
    lines = [
        ("Comparable objects (denominator)", audit["comparable_workings"]),
        ("Penalty terms (count x weight)", audit["penalty_terms"]),
        ("Penalty, uncapped", audit["penalty_raw"]),
        ("Cap (comparable x FIDELITY_MAX_PENALTY_PER_OBJECT)", audit["penalty_cap"]),
        ("Penalty applied", f'{audit["penalty"]}'
                            f'{"  (capped)" if audit["penalty_capped"] else ""}'),
        ("Formula", audit["formula"]),
        ("RECOMPUTED structural fidelity", audit["recomputed"]),
        ("REPORTED structural fidelity", audit["reported"]),
    ]
    for caption, value in lines:
        sheet.cell(row=row, column=1, value=caption).font = bold
        sheet.cell(row=row, column=2, value=value)
        row += 1
    sheet.cell(row=row, column=1, value="Verdict").font = bold
    if audit["agrees"] is None:
        verdict = "NOT COMPARABLE — the result reported no structural score."
    elif audit["agrees"]:
        verdict = "AGREES — the reported score is exactly what these rows produce."
    else:
        verdict = ("DISAGREES — the reported score is NOT what these rows produce. "
                   "Treat the reported score as unverified and investigate the "
                   "scoring path before using this report.")
    sheet.cell(row=row, column=2, value=verdict).font = bold
    return row + 2


def _write_stage_block(sheet, stage_score, row: int, bold, fill) -> int:
    rows = stage_workings(stage_score)
    if not rows:
        return row
    row = _header(sheet, row,
                  f"3. Staged score ({getattr(stage_score, 'stage', '')}) — weighted mean",
                  bold, fill)
    for caption, column in (("Component", 1), ("Measured %", 2), ("Weight", 3), ("Note", 5)):
        sheet.cell(row=row, column=column, value=caption).font = bold
    row += 1
    for name, value, weight, note in rows:
        sheet.cell(row=row, column=1, value=name)
        sheet.cell(row=row, column=2, value=value)
        sheet.cell(row=row, column=3, value=weight)
        sheet.cell(row=row, column=5, value=note)
        row += 1
    sheet.cell(row=row, column=1, value="Formula").font = bold
    sheet.cell(row=row, column=2, value=stage_formula(stage_score))
    row += 1
    sheet.cell(row=row, column=1, value="REPORTED stage fidelity").font = bold
    sheet.cell(row=row, column=2, value=getattr(stage_score, "overall", None)).font = bold
    row += 1
    for note in getattr(stage_score, "notes", None) or ():
        sheet.cell(row=row, column=1, value="Note")
        sheet.cell(row=row, column=2, value=note)
        row += 1
    return row + 1


def _write_category_block(sheet, audit, row: int, bold, fill) -> int:
    row = _header(sheet, row, "4. Every finding category, scoring and non-scoring",
                  bold, fill)
    for caption, column in (("Severity", 1), ("Category", 2), ("Rows", 3),
                            ("Counted in the penalty?", 4)):
        sheet.cell(row=row, column=column, value=caption).font = bold
    row += 1
    for (severity, category), count in sorted(audit["categories"].items()):
        sheet.cell(row=row, column=1, value=severity)
        sheet.cell(row=row, column=2, value=category)
        sheet.cell(row=row, column=3, value=int(count))
        sheet.cell(row=row, column=4,
                   value="YES" if severity in SCORING_SEVERITIES else "no")
        row += 1
    return row


__all__ = ["SHEET_SCORE_AUDIT", "SCORING_SEVERITIES", "NON_SCORING_REASON",
           "comparable_objects", "weights_for", "reconstruct", "stage_workings",
           "stage_formula", "write_sheet"]
