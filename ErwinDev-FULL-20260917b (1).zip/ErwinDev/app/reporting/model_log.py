"""
Per-Model Migration Log
=========================
Extracted from app/main.py — writes the detailed per-model .log file that
documents pipeline phases, fidelity scores, matched artefacts, discrepancies
and the promotion verdict.
"""

import logging
import os
import shutil
from datetime import datetime
from pathlib import Path

from app.orchestration.model_record import DEST_MANUAL_REVIEW
from app.reporting import report_layout
from app.validation import fidelity_stages

logger = logging.getLogger(__name__)


def write_model_log(record, outdir) -> str:
    """
    Generate a detailed per-model log file documenting:
    - Model metadata and execution timestamp
    - Completed pipeline phases
    - Reconciled/verified objects and categories (what was done / succeeded)
    - Missing, extra, or mismatched objects (what was missing / not done / defects)
    - Fidelity scores, gate verdict, and recommended actions
    """
    os.makedirs(outdir, exist_ok=True)
    # Short name, for the same Windows MAX_PATH reason as the report workbooks.
    log_path = Path(outdir) / f"{report_layout.short_model_name(record.base_name)}_migration.log"

    result = record.result
    udp = record.udp_outcome
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    lines = []
    lines.append("=" * 80)
    lines.append(f"SAP PowerDesigner -> erwin Migration Log: {report_layout.short_model_name(record.base_name)}")
    if report_layout.short_model_name(record.base_name) != record.base_name:
        lines.append(f"Source file: {record.base_name}")
    lines.append(f"Model Type : {record.model_type}")
    lines.append(f"Timestamp  : {now_str}")
    lines.append(f"Status     : {record.status}")
    lines.append(f"Destination: {record.destination}")
    lines.append("=" * 80)
    lines.append("")

    # ── 1. PIPELINE EXECUTION SUMMARY ──
    lines.append("--- 1. PIPELINE EXECUTION SUMMARY ---")
    lines.append("  [✓] Phase A: Initial XML Discovery - OK")
    lines.append("  [✓] Phase B: Preprocessing & Comment Migration - Completed")
    lines.append("  [✓] Phase C: V1 Raw Gap Reconciliation - Completed")
    if udp is not None:
        lines.append(f"  [✓] Phase D: UDP Tool Mapping & Comparison - Stage: {getattr(udp, 'stage', 'N/A')}")
    else:
        lines.append("  [-] Phase D: UDP Tool Mapping - Skipped/Retained from disk")
    if record.final_xml:
        lines.append(f"  [✓] Phase E: V3 Final Reconciliation - Measured against {os.path.basename(record.final_xml)}")
    else:
        lines.append("  [!] Phase E: V3 Final Reconciliation - Fallback to 2_preprocessed XML")
    lines.append("")

    # ── 2. FIDELITY SCORECARD ──
    lines.append("--- 2. FIDELITY SCORECARD ---")
    lines.append(f"  Overall Fidelity Score       : {record.fidelity:.2f}%")
    if result is not None:
        struct_score = getattr(result, "structural_fidelity_score", None)
        doc_score = getattr(result, "documentation_fidelity_score", None)
        udp_score = getattr(result, "udp_fidelity_score", None)
        if struct_score is not None:
            lines.append(f"  Structural Fidelity Score    : {float(struct_score):.2f}%")
        if doc_score is not None:
            lines.append(f"  Documentation Fidelity Score : {float(doc_score):.2f}%")
        if udp_score is not None:
            lines.append(f"  UDP Fidelity Score           : {float(udp_score):.2f}%")
    for s_name in fidelity_stages.STAGES:
        val = record.stage(s_name)
        if val is not None:
            lines.append(f"  Stage {s_name} Fidelity              : {val:.2f}%")
    lines.append("")

    # ── 3. COMPLETED & MATCHED ARTIFACTS ──
    lines.append("--- 3. COMPLETED & MATCHED ARTIFACTS (WHAT IS DONE) ---")
    if record.model_type in ("LDM", "CDM") and result is not None:
        lines.append(f"  Entities       : {getattr(result, 'entities_matched', 0)} / {getattr(result, 'entities_pd', 0)} matched")
        lines.append(f"  Attributes     : {getattr(result, 'attributes_matched', 0)} / {getattr(result, 'attributes_pd', 0)} matched")
        lines.append(f"  Relationships  : {getattr(result, 'relationships_matched', 0)} / {getattr(result, 'relationships_pd', 0)} matched")
        lines.append(f"  Identifiers    : {getattr(result, 'identifiers_pd', 0)} in PD, {getattr(result, 'identifiers_erwin', 0)} in erwin")
        lines.append(f"  Domains        : {getattr(result, 'domains_pd', 0)} in PD, {getattr(result, 'domains_erwin', 0)} in erwin")
        lines.append(f"  Inheritances   : {getattr(result, 'inheritances_pd', 0)} in PD, {getattr(result, 'inheritances_erwin', 0)} in erwin")
        lines.append(f"  Shortcuts      : {getattr(result, 'shortcuts_pd', 0)} accounted for")
    elif record.model_type == "PDM" and result is not None:
        lines.append(f"  Tables         : {getattr(result, 'tables_matched', 0)} / {getattr(result, 'tables_pd', 0)} matched")
        lines.append(f"  Columns        : {getattr(result, 'columns_matched', 0)} / {getattr(result, 'columns_pd', 0)} matched")
        lines.append(f"  Foreign Keys   : {getattr(result, 'fk_matched', 0)} / {getattr(result, 'fk_pd', 0)} matched")
        lines.append(f"  Views          : {getattr(result, 'views_matched', 0)} / {getattr(result, 'views_pd', 0)} matched")
        lines.append(f"  Procedures     : {getattr(result, 'procedures_matched', 0)} / {getattr(result, 'procedures_pd', 0)} matched")
        lines.append(f"  Triggers       : {getattr(result, 'triggers_matched', 0)} / {getattr(result, 'triggers_pd', 0)} matched")

    verified_findings = [f for f in (getattr(result, 'findings', []) or []) if getattr(f, 'severity', '') == 'VERIFIED']
    if verified_findings:
        lines.append(f"  Verified Evidence Items ({len(verified_findings)}):")
        for f in verified_findings[:30]:
            obj_name = getattr(f, 'object_name', '') or getattr(f, 'table', '')
            mem = getattr(f, 'member', '') or getattr(f, 'column', '')
            target = f"{obj_name}.{mem}" if mem and obj_name else (obj_name or mem or "(model)")
            lines.append(f"    [VERIFIED] {getattr(f, 'category', '')}: {target} - {getattr(f, 'message', '')}")
        if len(verified_findings) > 30:
            lines.append(f"    ... and {len(verified_findings) - 30} additional verified items.")
    lines.append("")

    # ── 4. GAPS, DEFECTS & MISSING ARTIFACTS ──
    lines.append("--- 4. GAPS, DEFECTS & MISSING ARTIFACTS (WHAT WAS MISSING / NOT DONE) ---")
    findings = getattr(result, 'findings', []) or []
    crit = [f for f in findings if getattr(f, 'severity', '') == 'CRITICAL']
    warn = [f for f in findings if getattr(f, 'severity', '') == 'WARNING']
    info = [f for f in findings if getattr(f, 'severity', '') == 'INFO']

    lines.append(f"  Discrepancy Totals: {len(crit)} CRITICAL, {len(warn)} WARNING, {len(info)} INFO")

    if crit:
        lines.append("")
        lines.append("  [CRITICAL DISCREPANCIES]")
        for f in crit:
            obj_name = getattr(f, 'object_name', '') or getattr(f, 'table', '')
            mem = getattr(f, 'member', '') or getattr(f, 'column', '')
            target = f"{obj_name}.{mem}" if mem and obj_name else (obj_name or mem or "(model)")
            lines.append(f"    * Category : {getattr(f, 'category', '')}")
            lines.append(f"      Target   : {target}")
            lines.append(f"      Message  : {getattr(f, 'message', '')}")
            lines.append(f"      SAP PD   : {getattr(f, 'pd_value', '')}")
            lines.append(f"      erwin    : {getattr(f, 'erwin_value', '')}")
            remed = getattr(f, 'remediation', '')
            if remed:
                lines.append(f"      Action   : {remed}")

    if warn:
        lines.append("")
        lines.append(f"  [WARNING DISCREPANCIES ({len(warn)} items)]")
        for f in warn[:50]:
            obj_name = getattr(f, 'object_name', '') or getattr(f, 'table', '')
            mem = getattr(f, 'member', '') or getattr(f, 'column', '')
            target = f"{obj_name}.{mem}" if mem and obj_name else (obj_name or mem or "(model)")
            lines.append(f"    * Category : {getattr(f, 'category', '')}")
            lines.append(f"      Target   : {target}")
            lines.append(f"      Message  : {getattr(f, 'message', '')}")
            lines.append(f"      SAP PD   : {getattr(f, 'pd_value', '')}")
            lines.append(f"      erwin    : {getattr(f, 'erwin_value', '')}")
            remed = getattr(f, 'remediation', '')
            if remed:
                lines.append(f"      Action   : {remed}")
        if len(warn) > 50:
            lines.append(f"    ... and {len(warn) - 50} additional warnings in report.")

    if info:
        lines.append("")
        lines.append(f"  [INFO ITEMS ({len(info)} items)]")
        for f in info[:20]:
            obj_name = getattr(f, 'object_name', '') or getattr(f, 'table', '')
            mem = getattr(f, 'member', '') or getattr(f, 'column', '')
            target = f"{obj_name}.{mem}" if mem and obj_name else (obj_name or mem or "(model)")
            lines.append(f"    - {getattr(f, 'category', '')} ({target}): {getattr(f, 'message', '')}")
        if len(info) > 20:
            lines.append(f"    ... and {len(info) - 20} additional info items.")

    if not (crit or warn or info):
        lines.append("  No discrepancies found! 100% full fidelity achieved.")

    lines.append("")
    lines.append("--- 5. PROMOTION VERDICT & ACTION ITEMS ---")
    if record.status == "PASS":
        lines.append(f"  Verdict: PASSED promotion threshold. Promoted to {record.destination}.")
    else:
        lines.append(f"  Verdict: FAILED promotion threshold. Routed to {record.destination} for review.")
        lines.append(f"  Review Folder: {record.manual_review_dir()}")
    lines.append("=" * 80)

    content = "\n".join(lines) + "\n"
    with open(log_path, "w", encoding="utf-8") as f:
        f.write(content)

    # Also copy log to manual_review_dir if routed to manual review
    if record.destination == DEST_MANUAL_REVIEW:
        try:
            shutil.copy2(str(log_path), str(record.manual_review_dir() / log_path.name))
        except Exception as exc:
            logger.debug("Could not copy log to manual review: %s", exc)

    logger.info("Model execution log generated: %s", log_path)
    return str(log_path)
