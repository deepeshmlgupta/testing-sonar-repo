"""
V2 — UDP Mapping Report
=======================
The V2 workbook IS the udp_tool's own output: the Extended-Attributes-to-UDP
mapping, the definitions erwin accepted, the per-value reconciliation, the
exceptions, and the SAP-vs-erwin comparison. Nothing is recomputed here — the
sheets are copied out of

    <UDP_TOOL_REPORT_DIR>/<tier>/<model>_UDP_Migration_Report.xlsx
    <UDP_TOOL_REPORT_DIR>/<tier>/<model>_UDP_Comparison.xlsx

and renamed so they can sit beside the tier sheets in V3 without colliding
(report_layout.MIGRATION_SHEETS / COMPARISON_SHEETS), with every cross-sheet
formula repointed at the new names.

Two deliberate omissions:

* NO FIDELITY SCORE. V2 reports what was mapped and what erwin holds. The
  score belongs to V1 (the initial gap) and V3 (the final measured fidelity);
  printing a V2 number invited it to be read as the migration's verdict.
* NO OVERVIEW SHEET. The workbook is the udp_tool's sheets and nothing else.

Discovery is by name against the report folder, so a live Phase D run is not
required: workbooks produced on an earlier Windows/erwin run are picked up as
they stand. When Phase D did run in this process its own paths take precedence.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

from app.common.config_helpers import tier_config as _tier_config
from app.reporting import report_layout as layout

logger = logging.getLogger(__name__)


@dataclass
class V2ReportRequest:
    """Everything one UDP mapping report needs."""

    model_name: str
    model_type: str
    outdir: str
    result: Any = None               # the tier ValidationResult (identity only)
    udp_outcome: Any = None          # udp_flow.UdpStageOutcome, when Phase D ran
    filename: str = ""
    config: Any = None               # tier config, for the discovery settings


def source_workbooks(request: V2ReportRequest) -> tuple:
    """
    (migration_path, comparison_path) for one model.

    A live Phase D outcome wins; otherwise the report folder is searched. Either
    may come back empty — a model with no UDP workbook simply has no V2.
    """
    udp = request.udp_outcome
    migration = str(getattr(udp, "migration_report_path", "") or "")
    comparison = str(getattr(udp, "comparison_report_path", "") or "")

    if migration and not os.path.isfile(migration):
        migration = ""
    if comparison and not os.path.isfile(comparison):
        comparison = ""
    if migration and comparison:
        return migration, comparison

    found = layout.resolve_udp_workbooks(
        request.model_name, request.model_type,
        _tier_config(request.model_type, request.config))
    return migration or found["migration"], comparison or found["comparison"]


def default_filename(request: V2ReportRequest) -> str:
    return layout.report_name(request.model_name, layout.V2_SUFFIX)


def build_v2_report(request: V2ReportRequest) -> Optional[str]:
    """
    Build the UDP mapping report for one model.

    Returns the path, or None when no UDP workbook could be found. Never
    raises: a reporting problem must not fail an otherwise complete run.
    """
    try:
        migration, comparison = source_workbooks(request)
        if not migration and not comparison:
            logger.info("No UDP workbooks found for %s; V2 mapping report skipped.",
                        request.model_name)
            return None

        from openpyxl import Workbook
        workbook = Workbook()
        try:
            added = []
            added += layout.append_workbook(workbook, migration, layout.MIGRATION_SHEETS)
            added += layout.append_workbook(workbook, comparison, layout.COMPARISON_SHEETS)
            if not added:
                logger.warning("UDP workbooks for %s carried no recognised sheets; "
                               "V2 mapping report skipped.", request.model_name)
                return None

            # openpyxl seeds every new workbook with one empty sheet. It is
            # removed only once real sheets exist, because a workbook with no
            # sheets at all cannot be saved.
            default_sheet = workbook["Sheet"] if "Sheet" in workbook.sheetnames else None
            if default_sheet is not None:
                workbook.remove(default_sheet)

            outdir = Path(request.outdir)
            outdir.mkdir(parents=True, exist_ok=True)
            out_path = outdir / (request.filename or default_filename(request))
            workbook.save(str(out_path))
        finally:
            workbook.close()
        logger.info("V2 UDP mapping report written to %s (%d sheets)",
                    out_path, len(added))
        return str(out_path)
    except Exception as exc:                                   # noqa: BLE001
        logger.warning("V2 mapping report failed for %s: %s", request.model_name, exc)
        return None


__all__ = ["V2ReportRequest", "build_v2_report", "default_filename", "source_workbooks"]


