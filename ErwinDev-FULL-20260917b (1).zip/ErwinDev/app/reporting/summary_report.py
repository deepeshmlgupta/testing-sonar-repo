"""
Pass/Fail Summary Report
==========================
Extracted from app/main.py — builds one row of Pass_Fail_Summary.xlsx per
model and writes the workbook for the whole batch.
"""

import logging
import os
from pathlib import Path

from app.reporting import report_layout
from app.validation import fidelity_stages

logger = logging.getLogger(__name__)

SUMMARY_HEADERS = [
    "Model Name", "Model Type", "Complexity", "Status",
    "V1 Fidelity %", "V2 Fidelity %", "V3 Fidelity %",
    "Stage", "Notes",
    "Structural Fidelity %", "Documentation Fidelity %",
    "UDP Fidelity % (final XML)", "SAP PD UDPs", "erwin UDPs Matched",
    "UDP Migration Pass Rate %", "UDP Stage",
    "Final Validated XML",
    "Report Folder", "V1 Report", "V2 Report", "V3 Report", "Model Log",
]


def summary_row(record):
    """One row of Pass_Fail_Summary.xlsx, as plain values."""
    result = record.result
    udp = record.udp_outcome
    udp_score = getattr(result, "udp_fidelity_score", None)
    doc_score = getattr(result, "documentation_fidelity_score", None)
    pass_rate = getattr(udp, "pass_rate", None) if udp is not None else None
    notes = [getattr(result, "promotion_note", "")] + record.notes
    stages = [record.stage(name) for name in fidelity_stages.STAGES]
    na = "n/a"
    return [
        # The same short name the report folder and workbooks carry.
        report_layout.short_model_name(record.base_name),
        record.model_type,
        record.complexity,
        record.status,
        *[na if value is None else value for value in stages],
        record.destination,
        " | ".join(note for note in notes if note),
        getattr(result, "structural_fidelity_score", record.fidelity),
        na if doc_score is None else doc_score,
        na if udp_score is None else udp_score,
        int(getattr(result, "udp_total", 0) or 0),
        int(getattr(result, "udp_matched", 0) or 0),
        na if pass_rate is None else pass_rate,
        getattr(udp, "stage", na) if udp is not None else na,
        os.path.basename(record.final_xml) if record.final_xml else na,
        str(record.report_dir()),
        Path(record.v1_report_path).name if record.v1_report_path else "",
        Path(record.v2_report_path).name if record.v2_report_path else "",
        Path(record.v3_report_path).name if record.v3_report_path else "",
        Path(record.log_path).name if record.log_path else "",
    ]


def generate_summary_report(rows, summary_dir):
    """Write Pass_Fail_Summary.xlsx from the collected summary rows."""
    from openpyxl import Workbook
    from openpyxl.styles import Font

    rep_dir = Path(summary_dir) / "summary_report"
    os.makedirs(rep_dir, exist_ok=True)

    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = "Status Summary"
    worksheet.append(SUMMARY_HEADERS)
    for cell in worksheet[1]:
        cell.font = Font(bold=True)
    for row in rows:
        worksheet.append(row)
    worksheet.freeze_panes = "A2"
    worksheet.auto_filter.ref = (
        f"A1:{chr(ord('A') + len(SUMMARY_HEADERS) - 1)}{len(rows) + 1}"
        if len(SUMMARY_HEADERS) <= 26 else None)

    report_path = rep_dir / "Pass_Fail_Summary.xlsx"
    workbook.save(str(report_path))
    logger.info("Pass/Fail summary generated at: %s", report_path)
    print(f"\nSummary: {report_path}  ({len(rows)} model(s))")
