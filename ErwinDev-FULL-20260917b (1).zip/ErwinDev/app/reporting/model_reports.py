"""
Per-Model Report Generation (V1 / V2 / V3)
=============================================
Extracted from app/main.py — writes each tier's reconciliation workbook, the
V1/V2/V3 reports and the per-model execution log, then discards the interim
scratch workbook.
"""

import logging
import os
from pathlib import Path

from app.common.config_helpers import excluded_sheets, tier_config
from app.orchestration.directory_setup import SCRATCH_REPORT_DIR
from app.orchestration.model_record import DEST_MANUAL_REVIEW
from app.reporting import report_layout, v2_report, v3_report
from app.reporting.model_log import write_model_log
from app.validation import promotion_gate
from app.validation.cdm_reconcile import generate_report as generate_report_cdm
from app.validation.ldm_reconcile.report_generator import generate_report
from app.validation.pdm_reconcile import pdm_report_generator

logger = logging.getLogger(__name__)


def reconciliation_workbook(record, result, outdir, filename):
    """
    Write a reconciliation workbook with this tier's OWN generator, so the CDM
    workbook keeps its DESCRIPTION sheet, the PDM workbook its promotion stage,
    and so on.
    """
    if result is None or not getattr(result, "pd_file", ""):
        return ""
    os.makedirs(outdir, exist_ok=True)
    generators = {
        "CDM": generate_report_cdm,
        "LDM": generate_report,
        "PDM": pdm_report_generator.generate_report,
    }
    path = generators[record.model_type]([result], str(outdir), filename)
    return str(path or "")


def build_v1_report(record, outdir):
    """
    V1 - the INITIAL fidelity report: the source model reconciled against the
    raw erwin XML V1, before comments were injected and before any UDP was
    written. This is the report that shows the migration gaps. Unchanged.
    """
    if record.initial_result is None:
        logger.info("No V1 reconciliation for %s; initial report skipped.",
                    record.base_name)
        return ""
    path = reconciliation_workbook(
        record, record.initial_result, outdir,
        report_layout.report_name(record.base_name, report_layout.V1_SUFFIX))
    if path:
        logger.info("V1 initial fidelity report: %s", path)
    return path


def build_v2_report(record, outdir):
    """
    V2 - the UDP MAPPING report: the udp_tool's own workbooks, assembled. No
    fidelity score is shown here by design.
    """
    path = v2_report.build_v2_report(v2_report.V2ReportRequest(
        model_name=record.base_name,
        model_type=record.model_type,
        outdir=str(outdir),
        result=record.result,
        udp_outcome=record.udp_outcome,
        config=tier_config(record.model_type),
    ))
    if path:
        logger.info("V2 UDP mapping report: %s", path)
    return path or ""


def build_v3_report(record, outdir, dirs):
    """
    V3 - the FINAL fidelity report: the reconciliation against the final
    validated erwin XML, the V1->V2->V3 progression, and every sheet the V1
    and V2 reports carry.
    """
    if record.result is None:
        return ""

    interim = reconciliation_workbook(
        record, record.result, SCRATCH_REPORT_DIR,
        f"{record.base_name}_reconciliation.xlsx")
    if not interim:
        return ""

    try:
        path = v3_report.build_v3_report(v3_report.V3ReportRequest(
            result=record.result,
            tier_report_path=interim,
            outdir=str(outdir),
            model_name=record.base_name,
            model_type=record.model_type,
            status=record.status,
            destination=record.destination,
            udp_outcome=record.udp_outcome,
            v1_report_path=record.v1_report_path,
            v2_report_path=record.v2_report_path,
            config=tier_config(record.model_type),
            exclude_sheets=excluded_sheets(record.model_type),
            stage_notes=list(record.notes),
            # Artefact provenance: the report has to be able to say WHICH file
            # each stage was measured against, so a V3 measured against the
            # preprocessed XML by the FINAL_XML_FALLBACK_TO_PREPROCESSED path
            # cannot be captioned as a manually validated final export.
            artefacts=dict(getattr(record, "artefacts", None) or {}),
        ))
    finally:
        discard(interim)

    if not path:
        return ""
    logger.info("V3 final fidelity report: %s", path)

    # 3_final holds model files only (<model>.xml / .erwin); reports live
    # under app/reporting/<tier>_reports/<model>/.
    if record.destination == DEST_MANUAL_REVIEW:
        promotion_gate.publish(record.result, path,
                               destination=str(record.manual_review_dir()))
    return path


def discard(path):
    """Remove an interim workbook. A leftover file is not worth failing a run."""
    try:
        os.remove(path)
    except OSError as exc:
        logger.debug("Could not remove interim workbook %s: %s", path, exc)


def generate_model_reports(record, dirs):
    """
    Write one model's three reports and execution log, then release heavy objects.

    Called per model rather than once at the end of the batch, so a 100+ model
    run never holds more than one model's findings and parsed models in memory.
    """
    outdir = record.report_dir()
    record.v1_report_path = build_v1_report(record, outdir)
    record.v2_report_path = build_v2_report(record, outdir)
    record.v3_report_path = build_v3_report(record, outdir, dirs)
    record.log_path = write_model_log(record, outdir)

    print(f"\n  {record.base_name}  ->  {outdir}")
    for label, path in (("V1 initial fidelity", record.v1_report_path),
                        ("V2 UDP mapping", record.v2_report_path),
                        ("V3 final fidelity", record.v3_report_path),
                        ("Model log", record.log_path)):
        print(f"    {label:22} {Path(path).name if path else 'not generated'}")


def generate_detailed_reports(records, dirs):
    """Batch form of generate_model_reports, kept for external callers."""
    for record in records:
        generate_model_reports(record, dirs)
