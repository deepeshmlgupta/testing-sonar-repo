"""
Report Layout and Workbook Helpers
==================================
One place that decides WHERE a model's reports go and WHAT they are called, and
the openpyxl helpers the V2 and V3 builders share.

FOLDER LAYOUT
-------------
Every model gets its own folder inside its model type's existing reporting
folder, holding the three reports of the migration flow:

    app/reporting/cdm_reports/<short>/
        <short>_v1_fidelity_report.xlsx       SAP PD vs erwin XML V1
        <short>_v2_udp_mapping_report.xlsx    Extended Attributes -> UDPs
        <short>_v3_fidelity_report.xlsx       final, post-enrichment
        <short>_migration.log
        manual_review_report/                 created only when V3 < 90%
            <short>_v3_fidelity_report.xlsx
            <model>.xml   <model>.erwin

    <short> is short_model_name(<model>): the repository hash and extraction
    id are stripped ("…_46584675_airlines" -> "airlines") so the full path
    stays under the Windows 260-character limit.

    app/reporting/ldm_reports/<model>/   … same
    app/reporting/pdm_reports/<model>/   … same

A model that passes the gate is promoted to erwinmodels/3_final instead, and its
V3 report is copied there alongside it.

SHEET COPYING
-------------
The V2 and V3 builders both assemble a workbook from sheets written by other
generators.  Two things have to be handled or the result is silently wrong:

* Sheet names collide.  Both UDP workbooks contain a sheet called "Summary",
  and Excel sheet names are case-insensitive, so "Summary" also clashes with a
  tier report's "SUMMARY".  Every copied sheet is renamed.
* Renaming breaks formulas.  The UDP workbooks use cross-sheet formulas such as
  ``=COUNTIF('Value Reconciliation'!$C:$C,$A5)``.  Each copied formula has its
  sheet references rewritten to the new names, or the sheet renders #REF!.
"""

from __future__ import annotations

import logging
import os
import re
from copy import copy
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# ─── FOLDERS ──────────────────────────────────────────────────────────────────
REPORTING_ROOT = Path(__file__).resolve().parent
TIER_FOLDERS: Dict[str, str] = {
    "CDM": "cdm_reports",
    "LDM": "ldm_reports",
    "PDM": "pdm_reports",
}
MANUAL_REVIEW_DIRNAME = "manual_review_report"

# ─── REPORT NAMES ─────────────────────────────────────────────────────────────
# Kept deliberately short. Report paths on Windows are capped at 260 characters
# (MAX_PATH) unless long-path support is enabled, and a project checked out
# under OneDrive already spends ~120 of those on the base folder. The old
# "<hash>_<extraction>_<name>_V3_Final_Fidelity_Report.xlsx" names, with the
# same 66-character model name repeated in the folder, ran to 310+ and every
# V2/V3/log write failed with a misleading "No such file or directory".
V1_SUFFIX = "v1_fidelity_report"
V2_SUFFIX = "v2_udp_mapping_report"
V3_SUFFIX = "v3_fidelity_report"

# SAP PD repository extracts arrive as "<32-hex-hash>_<extraction id>_<name>";
# only <name> is meaningful to a reader, so the hash and id are dropped from
# report folders and file names. Anything not matching this shape is kept as is.
_EXTRACT_PREFIX = re.compile(r"^[0-9a-fA-F]{32}_\d+_(?=\S)")
# Hard cap on the model part of a report name, as a last line of defence for
# an estate whose plain model names are themselves very long.
MAX_SHORT_NAME = 60

# ─── SHEET RENAMING (source name -> name in the assembled workbook) ───────────
MIGRATION_SHEETS: Dict[str, str] = {
    "Summary": "UDP_MAPPING_SUMMARY",
    "UDP Definition": "UDP_DEFINITIONS",
    "Value Reconciliation": "UDP_VALUE_RECON",
    "Exceptions": "UDP_EXCEPTIONS",
}
COMPARISON_SHEETS: Dict[str, str] = {
    "Summary": "UDP_COMPARISON_SUMMARY",
    "UDP Comparison": "UDP_COMPARISON",
    "By UDP": "UDP_BY_UDP",
    "Diagnostics": "UDP_DIAGNOSTICS",
}

NOT_AVAILABLE = "n/a"
HEADER_FILL = "FF1F4E79"
HEADER_FONT_COLOR = "FFFFFFFF"
PASS_FILL = "FFC6EFCE"    # nosec B105 - an ARGB fill colour, not a credential
FAIL_FILL = "FFFFC7CE"    # nosec B105 - an ARGB fill colour, not a credential


# ═════════════════════════════════════════════════════════════════════════════
#  Paths
# ═════════════════════════════════════════════════════════════════════════════

def tier_dir(model_type: str) -> Path:
    """`app/reporting/<tier>_reports` for CDM, LDM or PDM."""
    folder = TIER_FOLDERS.get((model_type or "").upper())
    if folder is None:
        raise ValueError(f"Unknown model type: {model_type!r}")
    return REPORTING_ROOT / folder


def short_model_name(model_name: str) -> str:
    """
    The readable part of a model name, for folders and report file names.

        3eafce5dd91787f5f61afafbe5ffcf7d_46584675_modeling_and_simulation
            -> modeling_and_simulation
        airlines -> airlines

    The full name (with hash and extraction id) is still the pipeline's key
    for the SAP model, the erwin exports and the UDP workbooks; only what is
    written under app/reporting/ is shortened.
    """
    name = str(model_name or "").strip()
    short = _EXTRACT_PREFIX.sub("", name) or name
    if len(short) > MAX_SHORT_NAME:
        short = short[:MAX_SHORT_NAME].rstrip("_-. ")
    return short or name


def model_dir(model_type: str, model_name: str, create: bool = True) -> Path:
    """`app/reporting/<tier>_reports/<model>` — this model's own report folder."""
    path = tier_dir(model_type) / short_model_name(model_name)
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def manual_review_dir(model_type: str, model_name: str, create: bool = True) -> Path:
    """`…/<model>/manual_review_report` — where a sub-90% model is sent."""
    path = model_dir(model_type, model_name, create=create) / MANUAL_REVIEW_DIRNAME
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def report_name(model_name: str, suffix: str, score: float = None,
                status: str = "") -> str:
    """`<model>_<v1|v2|v3>_…_report[_<score>%][_<PASS|FAIL>].xlsx`, e.g.
    `airlines_v1_fidelity_report.xlsx` (see short_model_name)."""
    parts = [short_model_name(model_name), suffix]
    if score is not None:
        parts.append(f"{float(score):.1f}%")
    if status:
        parts.append(status.upper())
    return "_".join(parts) + ".xlsx"


# ═════════════════════════════════════════════════════════════════════════════
#  Workbook helpers
# ═════════════════════════════════════════════════════════════════════════════

def norm_key(text: str) -> str:
    """Punctuation- and case-insensitive comparison key for a model name."""
    return re.sub(r"[^0-9a-z]+", "", str(text or "").lower())


def load_name_map(path: str) -> Dict[str, str]:
    """
    Optional model -> workbook-basename map. JSON object or two-column CSV.

    Estates where the UDP workbook is not named after the source model (the
    shipped LDM is exported as "SUBSURFACE AND WELLS" while its source model is
    "03_Lubes_..."), can supply the mapping instead of renaming files.
    """
    if not path or not os.path.isfile(path):
        return {}
    try:
        if path.lower().endswith(".json"):
            import json
            with open(path, encoding="utf-8") as handle:
                raw = json.load(handle)
        else:
            import csv
            with open(path, encoding="utf-8", newline="") as handle:
                raw = {row[0]: row[1] for row in csv.reader(handle)
                       if row and len(row) > 1 and not row[0].startswith("#")}
        return {norm_key(key): str(value) for key, value in dict(raw).items()}
    except (OSError, ValueError, IndexError) as exc:
        logger.warning("Could not read name map %s: %s", path, exc)
        return {}


def resolve_workbook(model_name: str, roots, suffixes, name_map: str = "") -> str:
    """
    Find one already-generated workbook for a model, or "" when there is none.

    `roots` are searched in order; `suffixes` are the filename endings that
    identify the kind of workbook (e.g. "_UDP_Comparison"). Matching runs
    exact stem first, then the punctuation/case-insensitive key, then a unique
    prefix — so nothing about the naming convention is hard-coded and a batch
    of 100+ models resolves without per-model configuration.
    """
    mapped = load_name_map(name_map).get(norm_key(model_name), "")
    wanted = [str(mapped or model_name)]
    if mapped and mapped != model_name:
        wanted.append(model_name)
    # The udp_tool names its workbooks after the SHORT model name; workbooks
    # from earlier runs still carry the full <hash>_<id>_<name> stem, so both
    # are tried (exact stem first, in this order).
    short = short_model_name(model_name)
    if short and short not in wanted:
        wanted.insert(0 if not mapped else 1, short)
    tails = [str(s) for s in (suffixes or ()) if str(s)]
    if not tails:
        return ""

    for root in roots or ():
        directory = Path(str(root))
        if not directory.is_dir():
            continue
        candidates = sorted(directory.glob("*.xlsx"))
        if not candidates:
            continue
        for name in wanted:
            for tail in tails:
                target = norm_key(f"{name}{tail}")
                for path in candidates:
                    if norm_key(path.stem) == target:
                        return str(path)
        # Fall back to a UNIQUE prefix match, so "<model> v2_UDP_Comparison"
        # and similar hand-edited names still resolve. Ambiguity is refused
        # rather than guessed.
        for name in wanted:
            key = norm_key(name)
            for tail in tails:
                hits = [str(path) for path in candidates
                        if norm_key(path.stem).startswith(key)
                        and norm_key(path.stem).endswith(norm_key(tail))]
                if len(hits) == 1:
                    return hits[0]
                if len(hits) > 1:
                    logger.warning("%s matches %d workbooks in %s; skipping "
                                   "(add an entry to the name map to disambiguate)",
                                   name, len(hits), directory)
    return ""


def udp_report_roots(model_type: str, report_dir: str):
    """
    Where the udp_tool's workbooks are looked for, most specific first:
    `<report_dir>/<tier>` then `<report_dir>` itself.
    """
    base = Path(str(report_dir or ""))
    tier = str(model_type or "").lower()
    roots = []
    if tier:
        roots.append(base / tier)
    roots.append(base)
    return roots


def resolve_udp_workbooks(model_name: str, model_type: str, config=None) -> Dict[str, str]:
    """
    The udp_tool workbooks that supply the V2 content, as
    ``{"migration": path_or_empty, "comparison": path_or_empty}``.

    Read straight out of UDP_TOOL_REPORT_DIR, so V2/V3 can be rebuilt from
    workbooks the UDP tool produced on an earlier (Windows/erwin) run without
    Phase D having to execute again in this process.
    """
    def cfg(name, default):
        return getattr(config, name, default) if config is not None else default

    raw_dir = cfg("UDP_TOOL_REPORT_DIR", "")
    if not raw_dir:
        report_dir = str(REPORTING_ROOT.parent / "udp_tool" / "output_excel_reports")
    elif not os.path.isabs(str(raw_dir)):
        repo_root = REPORTING_ROOT.parent.parent
        report_dir = str(repo_root / raw_dir)
    else:
        report_dir = str(raw_dir)

    roots = udp_report_roots(model_type, report_dir)
    name_map = cfg("UDP_REPORT_MAP", "")
    return {
        "migration": resolve_workbook(
            model_name, roots, cfg("UDP_MIGRATION_REPORT_SUFFIXES",
                                   ("_UDP_Migration_Report",)), name_map),
        "comparison": resolve_workbook(
            model_name, roots, cfg("UDP_COMPARISON_REPORT_SUFFIXES",
                                   ("_UDP_Comparison",)), name_map),
    }


# Status vocabulary of the udp_tool's comparison sheet. Sourced from
# app/udp_tool/udp_compare.py (ST_PASS, ST_MISMATCH, ...) rather than retyped,
# and overridable from tier config so a udp_tool change does not need a code
# change here.
UDP_STATUS_PASS = "PASS"
UDP_STATUS_MISMATCH = "MISMATCH"
UDP_STATUS_MISSING = "MISSING"
UDP_STATUS_BLANK = "BLANK IN SAP"
UDP_STATUS_EXTRA = "EXTRA IN ERWIN"

# Sheet and column the counts are read from, by NAME not by index.
UDP_COMPARISON_SHEET = "UDP Comparison"
UDP_STATUS_HEADER = "Status"
# Header(s) of the column naming the owning entity on the comparison sheet
# (udp_compare.py writes "Entity Name"; older workbooks used "Entity").
UDP_ENTITY_HEADERS = ("Entity Name", "Entity")


UDP_SUMMARY_SHEET = "Summary"
UDP_VERDICT_LABEL = "Verdict"


def _summary_verdict(workbook) -> str:
    """The Verdict cell of the udp_tool's Summary sheet, '' when absent or a formula."""
    if UDP_SUMMARY_SHEET not in workbook.sheetnames:
        return ""
    for row in workbook[UDP_SUMMARY_SHEET].iter_rows(min_col=1, max_col=2, values_only=True):
        if row and str(row[0] or "").strip().lower() == UDP_VERDICT_LABEL.lower():
            value = row[1]
            return str(value).strip() if isinstance(value, str) and not value.startswith("=") else ""
    return ""


def udp_comparison_counts(path: str, sheet: str = UDP_COMPARISON_SHEET,
                          status_header: str = UDP_STATUS_HEADER) -> Optional[Dict[str, Any]]:
    """
    The udp_tool's own migration verdict, read straight off its workbook.

    Returns None when there is no workbook or no status column to read; never a
    guessed zero. Otherwise a dict of the status counts plus:

        comparable  PASS + MISMATCH + MISSING
        pass_rate   100 * PASS / comparable

    This is udp_compare's own definition (`ComparisonResult.comparable` /
    `.pass_rate`): BLANK IN SAP is excluded because there was nothing to
    migrate, and EXTRA IN ERWIN is not a source-side outcome. `comparable == 0`
    returns pass_rate None — nothing was measured, which is not the same as 0%.

    Why read the sheet rather than the Summary cells: the Summary is live
    COUNTIF formulas over this sheet, so counting the statuses directly is both
    the ground truth and independent of formula rewriting.

    The status column is located by its header text, so inserting a column in
    the udp_tool's report does not silently change what is counted.
    """
    if not path or not os.path.isfile(path):
        return None
    try:
        from openpyxl import load_workbook
        workbook = load_workbook(path, read_only=True, data_only=True)
    except (OSError, ValueError) as exc:
        logger.warning("Could not read UDP comparison workbook %s: %s", path, exc)
        return None

    try:
        if sheet not in workbook.sheetnames:
            logger.debug("%s has no '%s' sheet", path, sheet)
            return None
        # The udp_tool writes a LITERAL verdict on its Summary sheet when erwin
        # could not be read or the read-back failed its self-test (a live
        # formula otherwise). Such a workbook lists every value as MISSING, so
        # counting it would turn "nothing verified" into a measured 0%.
        verdict = _summary_verdict(workbook)
        if verdict and verdict.upper().startswith("NOT VERIFIED"):
            logger.warning("UDP comparison workbook %s carries the verdict %r; nothing was "
                           "measured, so no UDP pass rate is read from it.", path, verdict)
            return None
        worksheet = workbook[sheet]
        rows = worksheet.iter_rows(values_only=True)
        header = next(rows, None)
        if not header:
            return None
        wanted = norm_key(status_header)
        index = next((i for i, cell in enumerate(header)
                      if norm_key(str(cell or "")) == wanted), None)
        if index is None:
            logger.warning("%s!%s has no '%s' column; UDP counts not read",
                           path, sheet, status_header)
            return None

        # The entity column is optional: it lets the caller check that the
        # workbook actually describes THIS model (see
        # udp_helpers.udp_engine_pass_rate), which a stale workbook produced
        # for another model under the same name would otherwise fail silently.
        entity_wanted = {norm_key(name) for name in UDP_ENTITY_HEADERS}
        entity_index = next((i for i, cell in enumerate(header)
                             if norm_key(str(cell or "")) in entity_wanted), None)

        counts: Dict[str, int] = {}
        entities = set()
        for row in rows:
            if index >= len(row):
                continue
            status = str(row[index] or "").strip().upper()
            if status:
                counts[status] = counts.get(status, 0) + 1
            if entity_index is not None and entity_index < len(row):
                entity = norm_key(str(row[entity_index] or ""))
                if entity:
                    entities.add(entity)
    finally:
        workbook.close()

    comparable = (counts.get(UDP_STATUS_PASS, 0)
                  + counts.get(UDP_STATUS_MISMATCH, 0)
                  + counts.get(UDP_STATUS_MISSING, 0))
    return {
        "counts": counts,
        "passed": counts.get(UDP_STATUS_PASS, 0),
        "mismatch": counts.get(UDP_STATUS_MISMATCH, 0),
        "missing": counts.get(UDP_STATUS_MISSING, 0),
        "blank_in_pd": counts.get(UDP_STATUS_BLANK, 0),
        "extra_in_erwin": counts.get(UDP_STATUS_EXTRA, 0),
        "comparable": comparable,
        "pass_rate": (round(100.0 * counts.get(UDP_STATUS_PASS, 0) / comparable, 2)
                      if comparable else None),
        "source": path,
        "entities": entities,
    }


def rewrite_formula(text: str, renames: Dict[str, str]) -> str:
    """
    Repoint a formula's sheet references at the renamed sheets.

    Handles both the quoted form Excel uses for names containing spaces
    (`'Value Reconciliation'!`) and the bare form (`Exceptions!`).
    """
    for old, new in renames.items():
        text = text.replace(f"'{old}'!", f"{new}!")
        text = re.sub(rf"(?<![A-Za-z0-9_.'!]){re.escape(old)}!", f"{new}!", text)
    return text


def _copy_cell(source, target, renames: Dict[str, str]) -> None:
    value = source.value
    if isinstance(value, str) and value.startswith("="):
        value = rewrite_formula(value, renames)
    target.value = value
    if source.has_style:
        target.font = copy(source.font)
        target.fill = copy(source.fill)
        target.border = copy(source.border)
        target.alignment = copy(source.alignment)
        target.number_format = source.number_format
        target.protection = copy(source.protection)


# ─── FORMULA CACHING ──────────────────────────────────────────────────────────
# The udp_tool writes its Summary sheets as live COUNTIF/COUNTA formulas over
# its own detail sheets. openpyxl copies the formula but cannot store a cached
# result, so every one of those cells reads as empty on disk until Excel is
# opened and recalculates. Anything reading the workbook programmatically — or
# an Excel set to manual calculation — sees blanks where the UDP counts should
# be, which looks exactly like a wrong fidelity number.
#
# These helpers resolve the handful of aggregate functions the udp_tool
# actually uses, against the SOURCE workbook, and store the answer as the
# cell's cached value. Nothing is hard-coded about the counts: they are read
# out of the same rows the formula points at. Any formula this cannot resolve
# is copied through untouched, so a new formula shape degrades to today's
# behaviour rather than producing a wrong number.

_FN_RE = re.compile(r"^=\s*(COUNTIFS?|COUNTA|COUNTBLANK)\s*\((.*)\)\s*$", re.IGNORECASE)
_MAX_WRAP_RE = re.compile(r"^=\s*MAX\s*\(\s*0\s*,\s*(.+?)\s*-\s*(\d+)\s*\)\s*$", re.IGNORECASE)
_REF_RE = re.compile(r"^(?:'([^']+)'|([A-Za-z0-9_.]+))!(\$?[A-Z]{1,3}\$?\d*)(?::(\$?[A-Z]{1,3}\$?\d*))?$")


def _split_args(text: str) -> List[str]:
    """Split a formula argument list on top-level commas only."""
    args, depth, quoted, current = [], 0, False, []
    for char in text:
        if char == '"':
            quoted = not quoted
        if not quoted:
            if char == "(":
                depth += 1
            elif char == ")":
                depth -= 1
            elif char == "," and depth == 0:
                args.append("".join(current).strip())
                current = []
                continue
        current.append(char)
    if current:
        args.append("".join(current).strip())
    return args


def _column_index(ref: str) -> int:
    from openpyxl.utils import column_index_from_string
    return column_index_from_string("".join(c for c in ref if c.isalpha()))


def _row_index(ref: str):
    digits = "".join(c for c in ref if c.isdigit())
    return int(digits) if digits else None


def _resolve_range(source_wb, reference: str):
    """The cell values a range reference points at, or None when unresolvable."""
    match = _REF_RE.match(reference.strip())
    if not match:
        return None
    sheet_name = (match.group(1) or match.group(2) or "").strip()
    if sheet_name not in source_wb.sheetnames:
        return None
    worksheet = source_wb[sheet_name]
    start, end = match.group(3), match.group(4) or match.group(3)
    first_col, last_col = _column_index(start), _column_index(end)
    first_row = _row_index(start) or 1
    last_row = _row_index(end) or worksheet.max_row
    last_row = min(last_row, worksheet.max_row or 1)
    values = []
    for row in worksheet.iter_rows(min_row=first_row, max_row=max(first_row, last_row),
                                   min_col=first_col, max_col=last_col,
                                   values_only=True):
        values.extend(row)
    return values


_LOCAL_CELL_RE = re.compile(r"^\$?[A-Z]{1,3}\$?\d+$")


def _resolve_criterion(criterion: str, source_wb, sheet_name: str) -> str:
    """
    A COUNTIF criterion is either a quoted literal ("PASS") or a cell
    reference ($A2, or 'Sheet'!$A2) whose *value* is the criterion.  The
    udp_tool's "By UDP" rollup uses the latter shape, so resolve it against
    the source workbook; otherwise the literal text "$A2" matches nothing and
    every per-UDP count caches as 0 ("Nothing to migrate").
    """
    text = criterion.strip()
    if text.startswith('"'):
        return text
    ref = text
    if _LOCAL_CELL_RE.match(ref) and sheet_name:
        ref = f"'{sheet_name}'!{ref}"
    if source_wb is not None and _REF_RE.match(ref):
        values = _resolve_range(source_wb, ref)
        if values:
            return '"' + ("" if values[0] is None else str(values[0])) + '"'
    return text


def _matches_criterion(value, criterion: str) -> bool:
    """Excel COUNTIF text criterion: exact, or a single trailing wildcard."""
    wanted = criterion.strip().strip('"')
    text = "" if value is None else str(value)
    if wanted.endswith("*"):
        return text.upper().startswith(wanted[:-1].upper())
    return text.strip().upper() == wanted.upper()


def _evaluate_aggregate(formula: str, source_wb, sheet_name: str = ""):
    """
    COUNTIF / COUNTIFS / COUNTA / COUNTBLANK, optionally wrapped in
    MAX(0, ... - n) as the udp_tool writes its header-excluding counts.
    Returns None when the formula is not one of those shapes.
    """
    offset = 0
    wrapped = _MAX_WRAP_RE.match(formula)
    if wrapped:
        formula, offset = "=" + wrapped.group(1), int(wrapped.group(2))

    match = _FN_RE.match(formula)
    if not match:
        return None
    name, args = match.group(1).upper(), _split_args(match.group(2))
    if not args:
        return None

    if name in ("COUNTA", "COUNTBLANK"):
        values = _resolve_range(source_wb, args[0])
        if values is None:
            return None
        blank = sum(1 for v in values if v is None or str(v).strip() == "")
        total = len(values) - blank if name == "COUNTA" else blank
        return max(0, total - offset)

    # COUNTIF(range, criterion) / COUNTIFS(range, criterion, range, criterion, …)
    if len(args) < 2 or len(args) % 2:
        return None
    pairs = []
    for index in range(0, len(args), 2):
        values = _resolve_range(source_wb, args[index])
        if values is None:
            return None
        pairs.append((values, _resolve_criterion(args[index + 1], source_wb, sheet_name)))
    length = min(len(values) for values, _ in pairs)
    hits = sum(1 for position in range(length)
               if all(_matches_criterion(values[position], criterion)
                      for values, criterion in pairs))
    return max(0, hits - offset)


def cache_formula_values(target_ws, source_ws, source_wb) -> int:
    """
    Store a cached result for every aggregate formula copied into `target_ws`.

    openpyxl has no separate cached-value slot, so the resolved number replaces
    the formula. The formula's own comment column still documents what was
    counted, and `fullCalcOnLoad` (set by `mark_for_recalculation`) keeps any
    formula this could not resolve correct the moment Excel opens the file.

    Returns how many cells were resolved.
    """
    resolved = 0
    for row in source_ws.iter_rows():
        for cell in row:
            if not isinstance(cell.value, str) or not cell.value.startswith("="):
                continue
            try:
                value = _evaluate_aggregate(cell.value, source_wb, source_ws.title)
            except Exception as exc:                           # noqa: BLE001
                logger.debug("Could not evaluate %s: %s", cell.value, exc)
                value = None
            if value is None:
                continue
            target_ws.cell(row=cell.row, column=cell.column).value = value
            resolved += 1
    return resolved


def mark_for_recalculation(workbook) -> None:
    """
    Ask Excel to recalculate on open, so any formula left unresolved by
    `cache_formula_values` still shows a correct number to a human reader.
    """
    try:
        workbook.calculation.fullCalcOnLoad = True
    except AttributeError as exc:
        logger.debug("Workbook has no calculation properties: %s", exc)


def copy_sheet(source_ws, workbook, title: str, renames: Dict[str, str],
               source_wb=None) -> None:
    """Copy one worksheet's values, styles and layout into `workbook`."""
    target_ws = workbook.create_sheet(title)

    for row in source_ws.iter_rows():
        for cell in row:
            _copy_cell(cell, target_ws.cell(row=cell.row, column=cell.column), renames)

    for key, dimension in source_ws.column_dimensions.items():
        target_ws.column_dimensions[key].width = dimension.width
        target_ws.column_dimensions[key].hidden = dimension.hidden
    for key, dimension in source_ws.row_dimensions.items():
        target_ws.row_dimensions[key].height = dimension.height

    for merged in source_ws.merged_cells.ranges:
        target_ws.merge_cells(str(merged))

    target_ws.freeze_panes = source_ws.freeze_panes
    if source_ws.auto_filter.ref:
        target_ws.auto_filter.ref = source_ws.auto_filter.ref
    target_ws.sheet_view.showGridLines = source_ws.sheet_view.showGridLines

    # Resolve the copied COUNTIF/COUNTA aggregates so the sheet reads correctly
    # on disk, not only after Excel has recalculated it.
    if source_wb is not None:
        cached = cache_formula_values(target_ws, source_ws, source_wb)
        if cached:
            logger.debug("Cached %d formula value(s) on %s", cached, title)


def append_workbook(workbook, source_path: str, mapping: Dict[str, str]) -> List[str]:
    """Copy the mapped sheets of one workbook in. Returns the titles added."""
    if not source_path or not os.path.isfile(source_path):
        return []
    try:
        from openpyxl import load_workbook
        source = load_workbook(source_path)
    except (OSError, ValueError) as exc:
        logger.warning("Could not read workbook %s: %s", source_path, exc)
        return []

    added: List[str] = []
    try:
        for name in source.sheetnames:
            title = mapping.get(name)
            if not title or title in workbook.sheetnames:
                continue
            copy_sheet(source[name], workbook, title, mapping, source_wb=source)
            added.append(title)
    finally:
        source.close()
    if added:
        mark_for_recalculation(workbook)
    return added


def drop_sheets(workbook, titles) -> List[str]:
    """
    Remove sheets an assembled report must not carry (UDP_DETAIL by default).
    Matching is case-insensitive, because Excel sheet names are.
    """
    wanted = {str(title).strip().upper() for title in (titles or ())}
    removed = []
    for name in workbook.sheetnames:
        if name.strip().upper() in wanted:
            del workbook[name]
            removed.append(name)
    return removed


def write_key_value_sheet(workbook, title: str, heading: str, subtitle: str,
                          rows, highlight_label: str = "", highlight_pass: bool = True,
                          index: int = 0) -> None:
    """
    Write a Measure / Value / Source sheet — the shape both the V2 and the V3
    overview use. `rows` is an iterable of (label, value, note).
    """
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    worksheet = workbook.create_sheet(title, index)
    worksheet["A1"] = heading
    worksheet["A1"].font = Font(bold=True, size=14)
    worksheet.merge_cells("A1:C1")
    worksheet["A2"] = subtitle
    worksheet["A2"].alignment = Alignment(wrap_text=True, vertical="top")
    worksheet.merge_cells("A2:C2")
    worksheet.row_dimensions[2].height = 30

    header_fill = PatternFill("solid", fgColor=HEADER_FILL)
    header_font = Font(bold=True, color=HEADER_FONT_COLOR)
    for column, caption in enumerate(("Measure", "Value", "Where it comes from"), start=1):
        cell = worksheet.cell(4, column, caption)
        cell.fill, cell.font = header_fill, header_font

    row_no = 5
    for label, value, note in rows:
        worksheet.cell(row_no, 1, label).font = Font(bold=bool(label) and not note)
        cell = worksheet.cell(row_no, 2, value)
        cell.alignment = Alignment(wrap_text=True, vertical="top")
        worksheet.cell(row_no, 3, note).alignment = Alignment(wrap_text=True, vertical="top")
        if highlight_label and label == highlight_label:
            cell.font = Font(bold=True)
            cell.fill = PatternFill("solid",
                                    fgColor=PASS_FILL if highlight_pass else FAIL_FILL)
        row_no += 1

    for index_, width in enumerate((38, 62, 70), start=1):
        worksheet.column_dimensions[get_column_letter(index_)].width = width
    worksheet.freeze_panes = "A5"


__all__ = [
    "udp_comparison_counts", "UDP_COMPARISON_SHEET", "UDP_STATUS_HEADER",
    "REPORTING_ROOT", "TIER_FOLDERS", "MANUAL_REVIEW_DIRNAME",
    "V1_SUFFIX", "V2_SUFFIX", "V3_SUFFIX", "short_model_name", "MAX_SHORT_NAME",
    "MIGRATION_SHEETS", "COMPARISON_SHEETS", "NOT_AVAILABLE",
    "tier_dir", "model_dir", "manual_review_dir", "report_name",
    "rewrite_formula", "copy_sheet", "append_workbook", "drop_sheets",
    "write_key_value_sheet",
]

