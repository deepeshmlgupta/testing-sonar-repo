"""
V3 — Final Fidelity Report
==========================
The V3 workbook is the whole migration in one file: the SAP PD model
reconciled against its FINAL, manually validated erwin XML export, plus every
sheet the V1 and V2 reports carry.

    <V1 sheets>            SUMMARY, DASHBOARD, FINDINGS, ENTITY_MATRIX /
                           AS_IMPORTED + TABLE_MATRIX, RELATIONSHIPS,
                           CATEGORY_ANALYSIS, DESCRIPTION, CONFIG, <model>
                           — written by the tier's own generator, against the
                             final validated XML
    FIDELITY_PROGRESSION   V1 -> V2 -> V3 with the component behind each stage,
                           the verdict, and the gate note
    <V2 sheets>            UDP_MAPPING_SUMMARY, UDP_DEFINITIONS,
                           UDP_VALUE_RECON, UDP_EXCEPTIONS,
                           UDP_COMPARISON_SUMMARY, UDP_COMPARISON,
                           UDP_BY_UDP, UDP_DIAGNOSTICS
                           — the udp_tool's own workbooks, renamed, formulas
                             repointed

There is no UDP_RECONCILIATION sheet (removed; it is not built by V2 either)
and no V3_OVERVIEW sheet — what the latter used to carry has moved to
FIDELITY_PROGRESSION, so the fidelity progression is a first-class sheet a
reviewer can filter, not a key/value dump.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, List, Optional, Tuple

from app.reporting import report_layout as layout
from app.reporting import score_audit, v2_report

logger = logging.getLogger(__name__)

SHEET_PROGRESSION = "FIDELITY_PROGRESSION"

# Sheets an assembled V3 must never carry. The two overview sheets are no
# longer produced at all, and UDP_RECONCILIATION moved to the V2 report
# (app/reporting/v2_report.py); they stay listed so a workbook assembled from
# an older report cannot reintroduce them.
DEFAULT_EXCLUDE_SHEETS = ("V3_OVERVIEW", "V2_OVERVIEW", "UDP_RECONCILIATION")

MIGRATION_SHEETS = layout.MIGRATION_SHEETS
COMPARISON_SHEETS = layout.COMPARISON_SHEETS


@dataclass
class V3ReportRequest:
    """Everything one final report needs."""

    result: Any                      # the tier ValidationResult, scored at V3
    tier_report_path: str            # workbook written by the tier generator
    outdir: str
    model_name: str = ""
    model_type: str = ""
    status: str = ""                 # PASS | FAIL
    destination: str = ""
    udp_outcome: Any = None          # udp_flow.UdpStageOutcome, when Phase D ran
    v1_report_path: str = ""
    v2_report_path: str = ""
    filename: str = ""
    config: Any = None               # tier config, for the discovery settings
    exclude_sheets: tuple = DEFAULT_EXCLUDE_SHEETS
    stage_notes: List[str] = field(default_factory=list)
    artefacts: dict = field(default_factory=dict)   # record.artefacts, for provenance

    def artefact_note(self, key: str, default: str = "") -> str:
        """One artefact provenance note ('existing', 'fallback (...)', ...)."""
        try:
            return str((self.artefacts or {}).get(key, default) or default)
        except Exception:                                      # noqa: BLE001
            return default


# ═════════════════════════════════════════════════════════════════════════════
#  FIDELITY_PROGRESSION
# ═════════════════════════════════════════════════════════════════════════════

def _percent(value) -> Any:
    return layout.NOT_AVAILABLE if value is None else round(float(value), 2)


def _udp_attr(udp, name: str, default: Any = None) -> Any:
    return default if udp is None else getattr(udp, name, default)


def _reliability(udp) -> str:
    reliable = _udp_attr(udp, "readback_reliable", None)
    return layout.NOT_AVAILABLE if reliable is None else ("Yes" if reliable else "No")


_STAGE_SOURCES = {
    "V1": "SAP PD vs the initial erwin XML export — before comments, UDPs, "
          "tags or shortcuts were migrated",
    "V2": "SAP PD vs the preprocessed erwin XML — Comments/Notes injected "
          "(CDM/LDM) or structural remediation applied (PDM)",
    "V3": "SAP PD vs the FINAL manually validated erwin XML — every construct "
          "the earlier stages were missing is now present and measured",
}


def _measurable(stage_score) -> frozenset:
    """Which components this stage actually measured."""
    components = getattr(stage_score, "components", None) or {}
    return frozenset(name for name, value in components.items() if value is not None)


def _v3_source_caption(request: V3ReportRequest) -> str:
    """
    What V3 was ACTUALLY compared against.

    The fixed caption said "the FINAL manually validated erwin XML" for every
    run. When FINAL_XML_FALLBACK_TO_PREPROCESSED is on — and it defaults to
    TRUE in app/config/settings.py, while every call site passes False and
    every docstring says it is off — no such export exists and V3 is measured
    against the SAME commented XML as V2. The sheet then showed a V3 row
    identical to V2 and captioned it as a manually validated final export,
    which is the one thing a reader of this sheet must not be misled about.
    """
    how = str(request.artefact_note("xml_v3_how"))
    if how.startswith("fallback"):
        return ("FALLBACK — no manually validated erwin XML V3 exists for this "
                "model. V3 was measured against the SAME preprocessed XML as V2 "
                "(FINAL_XML_FALLBACK_TO_PREPROCESSED is enabled), so the V3 row "
                "repeats V2 and is NOT evidence about the final erwin model. "
                "stage_state records V3_XML_EXPORT as WAITING_FOR_MANUAL_INPUT.")
    return _STAGE_SOURCES.get("V3", "")


def _progression_rows(request: V3ReportRequest) -> List[Tuple[Any, ...]]:
    """One row per measured stage, with the components behind it."""
    from app.validation import fidelity_stages

    result = request.result
    history = fidelity_stages.history(result)
    rows: List[Tuple[Any, ...]] = []
    previous = None
    previous_components = None
    for stage in fidelity_stages.STAGES:
        stage_score = history.get(stage)
        if stage_score is None:
            rows.append((stage, layout.NOT_AVAILABLE, "", "", "", "", "",
                         "Not measured for this model", _STAGE_SOURCES.get(stage, "")))
            continue
        overall = round(stage_score.overall, 2)
        # A delta only means "the migration improved" when both stages were
        # scored on the SAME components. When one stage drops a component it
        # could not measure, the weights are renormalised and part of the
        # change comes from the basis, not from the model — so say so rather
        # than presenting a number that mixes the two.
        components_here = _measurable(stage_score)
        if previous is None:
            delta = layout.NOT_AVAILABLE
        elif previous_components is not None and components_here != previous_components:
            delta = (f"{round(overall - previous, 2)} (not directly comparable — "
                     f"different components measured)")
        else:
            delta = round(overall - previous, 2)
        components = stage_score.components
        rows.append((
            stage,
            overall,
            delta,
            _percent(components.get(fidelity_stages.COMPONENT_STRUCTURAL)),
            _percent(components.get(fidelity_stages.COMPONENT_DOCUMENTATION)),
            _percent(components.get(fidelity_stages.COMPONENT_UDP)),
            _percent(components.get(fidelity_stages.COMPONENT_SHORTCUTS)),
            " ".join(stage_score.notes) or "",
            _v3_source_caption(request) if stage == "V3" else _STAGE_SOURCES.get(stage, ""),
        ))
        previous = overall
        previous_components = components_here
    return rows


def _write_progression(workbook, request: V3ReportRequest, index: int = 1) -> None:
    """
    The V1 -> V2 -> V3 table, the component breakdown, and the verdict.

    This is where the improvement is shown: one row per stage, the change from
    the stage before it, and the component that produced the change.
    """
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    result = request.result
    udp = request.udp_outcome
    worksheet = workbook.create_sheet(SHEET_PROGRESSION, index)

    worksheet["A1"] = "Fidelity progression — V1 to V3"
    worksheet["A1"].font = Font(bold=True, size=14)
    worksheet.merge_cells("A1:I1")
    worksheet["A2"] = (
        "Every stage is measured against a different erwin artefact and "
        "recomputed in full; nothing is carried forward. A component with "
        "nothing to measure for this model is dropped and the remaining "
        "weights are renormalised, so the model is never penalised for "
        "metadata it never had.")
    worksheet["A2"].alignment = Alignment(wrap_text=True, vertical="top")
    worksheet.merge_cells("A2:I2")
    worksheet.row_dimensions[2].height = 44

    headers = ("Stage", "Fidelity %", "Change", "Structural %", "Documentation %",
               "UDP %", "Shortcuts %", "Notes", "What was compared")
    header_fill = PatternFill("solid", fgColor=layout.HEADER_FILL)
    header_font = Font(bold=True, color=layout.HEADER_FONT_COLOR)
    for column, caption in enumerate(headers, start=1):
        cell = worksheet.cell(4, column, caption)
        cell.fill, cell.font = header_fill, header_font
        cell.alignment = Alignment(wrap_text=True, vertical="center")

    row_no = 5
    for values in _progression_rows(request):
        for column, value in enumerate(values, start=1):
            cell = worksheet.cell(row_no, column, value)
            cell.alignment = Alignment(wrap_text=True, vertical="top")
        if values[0] == "V3":
            for column in range(1, len(headers) + 1):
                worksheet.cell(row_no, column).font = Font(bold=True)
        row_no += 1

    status = (request.status or getattr(result, "status", "") or "").upper()
    passed = status == "PASS"
    row_no += 1
    verdict = [
        ("Model", getattr(result, "pd_model", "") or request.model_name, ""),
        ("Model type", request.model_type or "", ""),
        ("SAP PD file", os.path.basename(str(getattr(result, "pd_file", "") or "")), ""),
        ("Final validated erwin XML",
         os.path.basename(str(getattr(result, "erwin_file", "") or "")),
         "The V3 comparison target"),
        ("", "", ""),
        ("Status", status or layout.NOT_AVAILABLE, "Promotion gate verdict"),
        ("Destination", request.destination or "", ""),
        ("Gate note", getattr(result, "promotion_note", "") or "", ""),
        ("", "", ""),
        ("Errors (CRITICAL)", getattr(result, "critical_count", 0), ""),
        ("Warnings", getattr(result, "warning_count", 0), ""),
        ("Information", getattr(result, "info_count", 0), ""),
        ("", "", ""),
        ("UDP stage", _udp_attr(udp, "stage", layout.NOT_AVAILABLE),
         "SKIPPED / EXTRACTED / INJECTED / COMPARED / FAILED"),
        ("UDP read-back reliable", _reliability(udp),
         "An unreliable read-back is reported as 'not measured', never as 0%"),
        ("V1 report", os.path.basename(request.v1_report_path) or layout.NOT_AVAILABLE, ""),
        ("V2 report", os.path.basename(request.v2_report_path) or layout.NOT_AVAILABLE, ""),
    ]
    for note in request.stage_notes:
        verdict.append(("Note", note, ""))

    for label, value, note in verdict:
        worksheet.cell(row_no, 1, label).font = Font(bold=bool(label))
        cell = worksheet.cell(row_no, 2, value)
        cell.alignment = Alignment(wrap_text=True, vertical="top")
        if label == "Status":
            cell.font = Font(bold=True)
            cell.fill = PatternFill(
                "solid", fgColor=layout.PASS_FILL if passed else layout.FAIL_FILL)
        worksheet.cell(row_no, 3, note).alignment = Alignment(wrap_text=True,
                                                              vertical="top")
        row_no += 1

    for column, width in enumerate((26, 16, 12, 15, 17, 12, 14, 46, 56), start=1):
        worksheet.column_dimensions[get_column_letter(column)].width = width
    worksheet.freeze_panes = "A5"


# ═════════════════════════════════════════════════════════════════════════════
#  Assembly
# ═════════════════════════════════════════════════════════════════════════════

def default_filename(request: V3ReportRequest) -> str:
    """`<model>_V3_Final_Fidelity_Report.xlsx`."""
    model_name = request.model_name or Path(
        str(getattr(request.result, "pd_file", "") or "model")).stem
    return layout.report_name(model_name, layout.V3_SUFFIX)


def _write_score_audit(workbook, request: V3ReportRequest, index: int = 2) -> None:
    """Add the SCORE_RECONCILIATION sheet for the stage this report reports."""
    from app.validation import fidelity_stages

    history = fidelity_stages.history(request.result)
    stage_score = history.get(fidelity_stages.STAGE_V3) or history.get(fidelity_stages.STAGE_V2)
    score_audit.write_sheet(workbook, request.result, stage_score,
                            request.config, index=index)


def build_v3_report(request: V3ReportRequest) -> Optional[str]:
    """
    Build the final report for one model: the tier (V1-shaped) sheets against
    the final validated XML, the progression sheet, and the udp_tool (V2)
    sheets. UDP_RECONCILIATION is not built here — it lives in the V2 report
    only (app/reporting/v2_report.py) and is not copied into V3.

    Returns the path, or None when the tier report is missing or the workbook
    could not be written. Never raises: a reporting problem must not fail an
    otherwise complete pipeline run.
    """
    try:
        if not request.tier_report_path or not os.path.isfile(request.tier_report_path):
            logger.warning("No tier report to consolidate for %s",
                           getattr(request.result, "pd_model", "?"))
            return None

        from openpyxl import load_workbook
        workbook = load_workbook(request.tier_report_path)
        try:
            dropped = layout.drop_sheets(workbook, request.exclude_sheets)
            if dropped:
                logger.info("V3 report excludes %s", ", ".join(dropped))

            _write_progression(workbook, request, index=1)
            # The score, rebuilt from this workbook's own FINDINGS rows, with
            # an explicit AGREES/DISAGREES verdict. Without it the fidelity
            # number is an assertion a reviewer has to take on trust; with it,
            # the arithmetic and every excluded row are in the deliverable.
            _write_score_audit(workbook, request, index=2)

            migration, comparison = v2_report.source_workbooks(
                v2_report.V2ReportRequest(
                    model_name=request.model_name,
                    model_type=request.model_type,
                    outdir=request.outdir,
                    result=request.result,
                    udp_outcome=request.udp_outcome,
                    config=request.config))
            added = layout.append_workbook(workbook, migration, MIGRATION_SHEETS)
            added += layout.append_workbook(workbook, comparison, COMPARISON_SHEETS)
            if not added:
                logger.info("No udp_tool sheets available for %s; V3 carries the "
                            "tier sheets only.", request.model_name)

            outdir = Path(request.outdir)
            outdir.mkdir(parents=True, exist_ok=True)
            out_path = outdir / (request.filename or default_filename(request))
            workbook.save(str(out_path))
        finally:
            workbook.close()
        logger.info("V3 report written to %s", out_path)
        return str(out_path)
    except Exception as exc:                                   # noqa: BLE001
        logger.warning("V3 report failed for %s: %s",
                       getattr(request.result, "pd_file", "?"), exc)
        return None


__all__ = ["V3ReportRequest", "build_v3_report", "default_filename",
           "SHEET_PROGRESSION", "MIGRATION_SHEETS",
           "COMPARISON_SHEETS", "DEFAULT_EXCLUDE_SHEETS"]



