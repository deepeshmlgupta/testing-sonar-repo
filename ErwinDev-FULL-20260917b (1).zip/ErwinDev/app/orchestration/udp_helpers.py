"""
UDP Phase & Reconciliation Helpers
====================================
Extracted from app/main.py — Phase D (UDP extraction/mapping/comparison),
the tier-dispatching reconciliation call, and the V3 UDP-override decision.
"""

import logging
import os
from pathlib import Path

from app.common.config_helpers import tier_config, udp_reports_dir
from app.orchestration import stage_state, udp_evidence
from app.orchestration.directory_setup import stage_file
from app.reporting import report_layout
from app.validation import fidelity_stages, udp_flow
from app.validation.cdm_reconcile import compare as compare_cdm
from app.validation.cdm_reconcile import parse_cdm
from app.validation.cdm_reconcile import parse_erwin as parse_erwin_cdm
from app.validation.ldm_reconcile.comparator import compare
from app.validation.ldm_reconcile.erwin_ldm_parser import parse_erwin_ldm
from app.validation.ldm_reconcile.pd_ldm_parser import parse_ldm

logger = logging.getLogger(__name__)


def run_udp_phase(model_path, base_name, model_type, dirs, erwin_in="", erwin_out=""):
    """
    Phase D - the UDP engine: classify, map SAP Extended Attributes to erwin
    UDPs, inject, report and read the enriched model back.

    Returns a UdpStageOutcome. Never raises: udp_flow records every failure on
    the outcome, so a UDP problem cannot fail an otherwise complete run. When
    the phase is disabled the udp_tool's existing workbooks are still used for
    V2 and V3 — they are read from disk, not regenerated here.
    """
    print(f"\n--- Step 2: UDP extraction / mapping / injection / comparison for {base_name} ---")
    reports_dir = Path(dirs["udp_reports"]) / model_type.lower() if isinstance(dirs, dict) and dirs.get("udp_reports") \
        else udp_reports_dir(model_type)
    workdir = str(Path(dirs["udp_work"]) / report_layout.short_model_name(base_name)) \
        if isinstance(dirs, dict) and dirs.get("udp_work") else ""
    outcome = udp_flow.run_udp_flow(udp_flow.UdpFlowRequest(
        pd_path=str(Path(model_path).resolve()),
        model_name=base_name,
        model_type=model_type,
        reports_dir=str(reports_dir),
        erwin_in=str(erwin_in or ""),
        erwin_out=str(erwin_out or stage_file(dirs, "preprocessed", base_name, ".erwin")),
        workdir=workdir,
    ))
    print(f"  -> UDP stage: {outcome.stage}. {outcome.summary_line()}")

    # Persist the verified read-back so V3 — a different process, often a
    # different day — can carry it forward. erwin's XML export does not carry
    # UDPs, so the .erwin read-back is the only evidence V3 can have, and it
    # has to outlive this process. Only a real Step 2 run writes evidence.
    try:
        udp_evidence.record(dirs, base_name, model_type, outcome, model_path)
    except Exception as exc:                                   # noqa: BLE001
        logger.warning("Could not record UDP evidence for %s: %s", base_name, exc)

    # The attribute code preservation ledger: which SAP PD attribute codes were
    # encoded for injection, which could not be identified deterministically,
    # and why. Persisted beside the UDP evidence so what the report claims about
    # code preservation can be checked against the record that drove it.
    _record_code_ledger(dirs, base_name, model_type, model_path)
    return outcome


def _record_code_ledger(dirs, base_name: str, model_type: str, model_path) -> None:
    """Build and persist the code ledger. Never raises."""
    try:
        from app.validation import code_ledger

        if str(model_type or "").upper() not in ("CDM", "LDM"):
            return          # PDM columns carry Physical_Name natively
        if str(model_type).upper() == "CDM":
            from app.validation.cdm_reconcile.pd_cdm_parser import parse_cdm as parse
        else:
            from app.validation.ldm_reconcile.pd_ldm_parser import parse_ldm as parse
        ledger = code_ledger.build(parse(str(Path(model_path).resolve())),
                                   model_name=base_name, model_type=model_type,
                                   pd_path=str(Path(model_path).resolve()))
        code_ledger.save(dirs, ledger)
    except Exception as exc:                                   # noqa: BLE001
        logger.warning("Could not record the code ledger for %s: %s", base_name, exc)


def reconcile(model_path, erwin_xml, model_type):
    """Parse both sides and reconcile them with the engine for this tier."""
    file_path_str = str(Path(model_path).resolve())
    if model_type == "CDM":
        return compare_cdm(parse_cdm(file_path_str), parse_erwin_cdm(str(erwin_xml)))
    return compare(parse_ldm(file_path_str), parse_erwin_ldm(str(erwin_xml)))


def erwin_xml_carries_udps(result) -> bool:
    """
    Does the erwin XML measured actually carry THE MIGRATED UDPs?

    This is a property of the TARGET side, and it decides whether that XML is
    allowed to overrule the UDP engine's read-back of the .erwin model itself.
    Two defects have been fixed here, in order:

    1. Testing ``result.udp_total`` (the SOURCE count) meant a model with 219
       PD UDPs and an export carrying none read as "the XML measured it".
    2. Testing ``udp_values_erwin`` alone — any value at all — was the same
       mistake one level down. On real_estate the validated export carried 105
       UDP values, none of which corresponded to a SAP PD UDP: 0 matched, 0
       UDP DEFINITIONS, and all 105 classified "extra in erwin". That was
       enough to make the XML authoritative, so the engine's verified 99.88%
       read-back of the actual .erwin model was discarded and V3 scored the
       UDP component 0% — reporting a total loss of 1156 values that had in
       fact migrated, and making V3 (73.69%) look 25 points WORSE than V2
       (98.66%) when nothing about the migration had changed between them.

    A pile of unrelated values is not evidence that the export carries the
    migration. Real evidence is that the export holds UDPs the SAP side can be
    matched against: at least one MATCHED value, or a UDP dictionary
    (definitions) for the comparison to have had something to look for.
    """
    # One predicate, shared with the scorer (fidelity_stages), so the two can
    # never disagree about the same file.
    if fidelity_stages.erwin_side_carries_udps(result):
        return True

    fidelity = getattr(result, "udp_fidelity", None)
    values = int(getattr(fidelity, "udp_values_erwin", 0) or 0) if fidelity is not None else 0
    if values:
        logger.warning(
            "The erwin export holds %d UDP value(s) but none of them correspond to a "
            "SAP PD UDP (0 matched, 0 UDP definitions). The export is therefore NOT "
            "treated as evidence about UDP migration; the engine's read-back of the "
            ".erwin model is used instead.", values)
    return False


def _result_entity_keys(result):
    """Normalised names and codes of the SAP PD entities a result reconciled."""
    keys = set()
    for record in getattr(result, "entity_records", None) or ():
        for value in (getattr(record, "pd_name", ""), getattr(record, "pd_code", "")):
            key = report_layout.norm_key(value)
            if key:
                keys.add(key)
    return keys


def workbook_belongs_to_model(counts, result) -> bool:
    """
    Does a udp_tool comparison workbook read off disk describe the model the
    result reconciled?

    The standalone udp_tool writes its workbooks under the model NAME, so a
    workbook produced for a different model (or by a run whose shared
    baseline folder was overwritten by a parallel model — the Vessel LDM
    picked up 373 values belonging to a Sanctions model that way) is found
    under the right filename but describes the wrong entities.  Its 0% pass
    rate then becomes the V2/V3 UDP component.  When both sides expose entity
    names and NONE of the workbook's entities exist in the reconciled model,
    the workbook is rejected; when either side is silent, it is trusted.
    """
    workbook_entities = set(counts.get("entities") or ())
    model_entities = _result_entity_keys(result)
    if not workbook_entities or not model_entities:
        return True
    return bool(workbook_entities & model_entities)


def udp_engine_pass_rate(model_name, model_type, udp_outcome=None, result=None,
                         dirs=None, pd_path=None):
    """
    The UDP engine's measured pass rate, or None when nothing was measured.

    Three sources, in order of how much they can be trusted:

    1. A LIVE Phase D outcome from this process.
    2. The PERSISTED evidence Step 2 wrote (app/orchestration/udp_evidence.py):
       machine-readable, records the .erwin and SAP files it was measured from
       with their SHA-256, and is refused outright when the SAP source has
       changed since or the record belongs to another model. This is what lets
       run_v3.py — a separate process, often a separate day — carry forward a
       read-back that erwin's XML export cannot express.
    3. The udp_tool's comparison WORKBOOK, for runs that predate the evidence
       file, guarded only by whether its entity names exist in this model
       (workbook_belongs_to_model).

    None at every step means "not measured", never 0%.
    """
    live = getattr(udp_outcome, "pass_rate", None) if udp_outcome is not None else None
    if live is not None:
        return live
    if udp_outcome is not None and getattr(udp_outcome, "comparison_result", None) is not None:
        # The phase DID compare in this run and could not support a verdict
        # (erwin unreadable / read-back unreliable). The workbook it just wrote
        # carries the same unverifiable rows as MISSING, so reading it back
        # would turn "nothing verified" into a measured 0% — exactly the
        # inflation/deflation the None is there to prevent. Nothing measured.
        logger.info("UDP phase for %s produced no verdict (%s); UDP component is n/a "
                    "rather than read from the workbook it wrote.",
                    model_name, getattr(udp_outcome, "verdict", ""))
        return None
    # Persisted evidence from Step 2 wins over the workbook: it is
    # machine-readable, it records the artefacts it was measured from, and it
    # is refused outright when the SAP source has changed since or it was
    # written for another model (app/orchestration/udp_evidence.py). The
    # workbook is kept below as the fallback for runs that predate it.
    if dirs is not None:
        rate, reason = udp_evidence.pass_rate_for(dirs, model_name, model_type, pd_path)
        if rate is not None:
            return rate
        if reason and reason != udp_evidence.REJECT_ABSENT:
            logger.info("UDP evidence for %s not used (%s); falling back to the workbook.",
                        model_name, reason)

    found = report_layout.resolve_udp_workbooks(
        model_name, model_type, tier_config(model_type))
    counts = report_layout.udp_comparison_counts(found.get("comparison", ""))
    if counts is None:
        return None
    if result is not None and not workbook_belongs_to_model(counts, result):
        logger.warning(
            "UDP comparison workbook %s names %d entit%s, none of which exist in "
            "%s; it was produced for a different model and is ignored. Re-run "
            "the UDP phase for this model to regenerate it.",
            os.path.basename(str(counts.get("source", ""))),
            len(counts.get("entities") or ()),
            "y" if len(counts.get("entities") or ()) == 1 else "ies", model_name)
        return None
    logger.info("UDP engine verdict for %s read from %s: %s/%s comparable "
                "(pass rate %s)", model_name, os.path.basename(str(counts.get("source", ""))),
                counts.get("passed"), counts.get("comparable"), counts.get("pass_rate"))
    return counts.get("pass_rate")


def udp_stage_override(result, udp_outcome, model_name="", model_type="",
                       dirs=None, pd_path=None):
    """
    The UDP number a stage should use, or None to let its own XML comparison
    stand. Shared by V2 and V3: when the erwin XML that stage measured
    carries UDPs it is the authority; when it carries none, that XML cannot
    speak to whether UDPs migrated, so the engine's read-back is the
    remaining evidence. Without this same rule applied to both stages, V2
    (measured against 2_preprocessed/xml) and V3 (measured against the final
    validated XML) can disagree even though the underlying migration is
    identical, simply because the two files carry UDPs differently.
    """
    if erwin_xml_carries_udps(result):
        return None

    name = model_name or getattr(result, "pd_model", "")
    rate = udp_engine_pass_rate(name, model_type, udp_outcome, result=result,
                                dirs=dirs, pd_path=pd_path)
    if rate is not None:
        return rate

    # No UDP evidence exists from ANY source, and we have just established
    # that the XML being scored carries none either. Returning None here let
    # the stage fall back to that XML's own comparison, which reports 0% —
    # a MEASURED total loss — for a model whose UDPs simply have not been
    # injected yet. On both supplied LDMs that put a hard 75% ceiling on V1
    # and V2 (structural 100.00 + documentation 100.00 + udp 0.00 = 75.00)
    # while stage_state recorded the UDP stage as WAITING_FOR_MANUAL_INPUT in
    # the same run. The score said "measured, everything lost"; the state file
    # said "has not run". Both cannot be true.
    #
    # Deliberately narrow: the sentinel is returned only on the RECORDED fact
    # that the UDP stage has not executed for this model. Once it has run,
    # whatever it measured stands — including 0% — so a genuine injection
    # failure is still scored as the loss it is.
    if _udp_stage_not_executed(dirs, name):
        return fidelity_stages.UDP_NOT_MEASURED
    return None


def _udp_stage_not_executed(dirs, model_name: str) -> bool:
    """
    Has the UDP stage demonstrably NOT run for this model?

    True only for a recorded WAITING_FOR_MANUAL_INPUT (or no record at all,
    which is the same fact before the first run writes one). Any other status
    — AUTOMATED, VALIDATED, FAILED — means the stage DID execute, and its
    measurement must stand whatever it says.
    """
    if dirs is None or not model_name:
        return False
    try:
        status = stage_state.stage_status(dirs, model_name, stage_state.STAGE_UDP)
    except Exception as exc:                                   # noqa: BLE001
        logger.debug("Could not read the UDP stage status for %s: %s", model_name, exc)
        return False
    return status in ("", stage_state.STATUS_WAITING)
