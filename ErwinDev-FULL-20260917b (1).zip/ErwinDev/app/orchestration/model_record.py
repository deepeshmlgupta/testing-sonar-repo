"""
Model Record
=============
Extracted from app/main.py — the per-model data carrier that flows from
reconciliation through routing to reporting, plus the promotion destination
constants every workflow/reporting module reads.
"""

from dataclasses import dataclass, field
from typing import Any, List

from app.common.config_helpers import get_setting as _get_setting
from app.orchestration.stage_paths import FINAL_DIRNAME as DEST_FINAL
from app.orchestration.stage_paths import PREPROCESSED_DIRNAME as DEST_PREPROCESSED  # noqa: F401
from app.reporting import report_layout
from app.validation import fidelity_stages, promotion_gate

COMPLEXITY_SIMPLE = "SIMPLE"
COMPLEXITY_MEDIUM = "MEDIUM"
COMPLEXITY_COMPLEX = "COMPLEX"
COMPLEXITY_UNKNOWN = "UNKNOWN"


def source_counts(result) -> dict:
    """SAP PD-side object counts of a reconciliation result (CDM/LDM or PDM vocabulary)."""
    def first(*names):
        for name in names:
            value = getattr(result, name, None)
            if value is not None:
                return int(value or 0)
        return 0
    if result is None:
        return {"objects": 0, "members": 0, "relationships": 0}
    return {
        "objects": first("entities_pd", "tables_pd"),
        "members": first("attributes_pd", "columns_pd"),
        "relationships": first("relationships_pd", "fk_pd"),
    }


def classify_complexity(result_or_counts) -> str:
    """
    SIMPLE / MEDIUM / COMPLEX from the source model's own size — a triage label
    only; it never changes how a model is validated or scored. Thresholds live
    in settings (COMPLEXITY_*). UNKNOWN when nothing was counted.
    """
    from app.common.config_helpers import get_setting
    counts = result_or_counts if isinstance(result_or_counts, dict) else source_counts(result_or_counts)
    objects, members = int(counts.get("objects", 0)), int(counts.get("members", 0))
    if objects == 0 and members == 0:
        return COMPLEXITY_UNKNOWN
    if objects <= int(get_setting("COMPLEXITY_SIMPLE_MAX_OBJECTS", 25)) \
            and members <= int(get_setting("COMPLEXITY_SIMPLE_MAX_MEMBERS", 200)):
        return COMPLEXITY_SIMPLE
    if objects <= int(get_setting("COMPLEXITY_MEDIUM_MAX_OBJECTS", 100)) \
            and members <= int(get_setting("COMPLEXITY_MEDIUM_MAX_MEMBERS", 1000)):
        return COMPLEXITY_MEDIUM
    return COMPLEXITY_COMPLEX


# Destination folder names. DEST_FINAL / DEST_PREPROCESSED are imported above as
# aliases of the canonical stage names, so a renamed stage folder stays
# consistent between routing and the paths actually written.
DEST_MANUAL_REVIEW = str(_get_setting("MANUAL_REVIEW_DIR", "manual_review"))
DEST_REJECTED = str(_get_setting("REJECTED_SUBDIR", "rejected"))


@dataclass
class ModelRecord:
    """One processed model, from reconciliation through to its three reports."""

    base_name: str
    model_type: str
    result: Any = None           # the V3 result — against the FINAL validated XML
    initial_result: Any = None   # the V1 reconciliation, against the raw export
    v2_result: Any = None        # the V2 reconciliation, against 2_preprocessed
    udp_outcome: Any = None
    final_xml: str = ""
    v1_report_path: str = ""
    v2_report_path: str = ""
    v3_report_path: str = ""
    log_path: str = ""
    destination: str = ""
    notes: List[str] = field(default_factory=list)
    artefacts: dict = field(default_factory=dict)   # stage key -> path (six-artefact layout)

    @property
    def status(self):
        """
        The PASS/FAIL verdict of the promotion gate.

        The gate is the authority for the threshold rule, so the destination it
        chose decides. Falling back on the comparator's own status matters for
        PDM: its ValidationResult reports WARN whenever any warning finding
        exists, which would contradict a model the gate promoted at 99%.
        """
        if getattr(self.result, "status", "") == "ERROR":
            return "ERROR"
        if self.destination == DEST_FINAL:
            return promotion_gate.BAND_PASS
        if self.destination in (DEST_MANUAL_REVIEW, DEST_REJECTED):
            return promotion_gate.BAND_FAIL
        return str(getattr(self.result, "status", "ERROR"))

    @property
    def fidelity(self):
        return float(getattr(self.result, "fidelity_score", 0.0) or 0.0)

    @property
    def complexity(self) -> str:
        """SIMPLE / MEDIUM / COMPLEX of the source model (see classify_complexity)."""
        for source in (self.initial_result, self.v2_result, self.result):
            label = classify_complexity(source)
            if label != COMPLEXITY_UNKNOWN:
                return label
        return COMPLEXITY_UNKNOWN

    def report_dir(self):
        return report_layout.model_dir(self.model_type, self.base_name)

    def manual_review_dir(self):
        return report_layout.manual_review_dir(self.model_type, self.base_name)

    def stage(self, name):
        """The overall score recorded at V1, V2 or V3, or None."""
        for source in (self.result, self.v2_result, self.initial_result):
            if source is None:
                continue
            value = fidelity_stages.stage_value(source, name)
            if value is not None:
                return value
        return None

    def release(self):
        """
        Drop everything the summary row does not need.

        Findings lists, parsed source models, documentation rows and UDP detail
        are the bulk of a result's memory. Releasing them the moment the three
        reports are on disk is what keeps a 100+ model batch flat.
        """
        for result in (self.initial_result, self.v2_result, self.result):
            if result is None:
                continue
            for attribute in ("findings", "documentation_rows", "entity_records",
                              "relationship_records", "domain_records",
                              "inheritance_records", "source_models",
                              "initial_result", "preprocess_report", "udp_fidelity"):
                try:
                    setattr(result, attribute, [] if attribute.endswith("s")
                            and attribute != "source_models" else None)
                except (AttributeError, TypeError):
                    pass
        outcome = self.udp_outcome
        if outcome is not None:
            try:
                outcome.comparison_result = None
            except AttributeError:
                pass
        self.initial_result = None
        self.v2_result = None
