"""
Stage Paths
===========
One place that knows where each migration artefact of a model lives, so no
workflow, runner or report assembles paths by hand.

The layout follows the ACTUAL operating flow. The two erwin-side conversions
are automated only when erwin COM is on the host (see app/erwin/erwin_converter.py);
otherwise they are manual hand-offs, and the pipeline says exactly what to do.

    key         artefact                                  where
    --------    ----------------------------------------  --------------------------------------------
    xml_v1      erwin's XML export of the imported model  erwinmodels/1_initial/<model>.xml     (manual)
    xml_v2      Step 1: PD comments injected as Notes     erwinmodels/2_preprocessed/<model>.xml (run_v1)
    erwin_v1    the .erwin handed to the UDP tool         app/udp_tool/input_erwin_models/<model>.erwin (auto | manual)
    erwin_v2    Step 2: UDP-enriched .erwin               erwinmodels/2_preprocessed/<model>.erwin (run_udp)
    xml_v3      erwin's XML export of the enriched model  final_xml_models/<tier>/<model>.xml   (auto | manual)
    erwin_v3    gate PASS output                          erwinmodels/3_final/<model>.erwin     (run_v3)

WHAT ``2_preprocessed/`` HOLDS, AND WHY IT HOLDS TWO THINGS
-----------------------------------------------------------
The folder is named after the PHASE, not the file type, and the phase produces
one artefact per step in two different formats:

    2_preprocessed/<model>.xml     XML V2     Step 1 output — the erwin XML with
                                              PD Comments injected as erwin Notes.
                                              Written by run_v1.py. INPUT to Step 2.
    2_preprocessed/<model>.erwin   .ERWIN V2  Step 2 output — the erwin binary with
                                              SAP extended attributes injected as
                                              erwin UDPs. Written by run_udp.py.

They are two ends of the same enrichment, so they share a folder; the extension
is the discriminator and the code never refers to either by folder alone.
Throughout this codebase "XML V2" always means the .xml and ".ERWIN V2" always
means the .erwin — never "the preprocessed model", which is ambiguous.
``.ERWIN V1`` (the un-enriched binary Step 2 consumes) deliberately lives
elsewhere, in the UDP tool's own input folder, so an input can never be
confused with an output or overwritten by one.

The stage folders are FLAT: no xml/ erwin/ json/ sub-folders. ``expected()``
returns where the pipeline writes (or expects the operator to place) an
artefact; ``find()`` returns where an INPUT artefact actually is, checking the
expected location first, then the shared tree of an isolated run, then — for
the three artefacts a PERSON names by hand (``erwin_v1``, ``erwin_v2``,
``xml_v3``) — the tier sub-folder and the short model name (``_alternates``),
then, when LEGACY_STAGE_FALLBACK is on, the folders older layouts used
(``1_initial/xml``, ``1_initial/erwin``, ``2_preprocessed/erwin``, and the
six-folder ``1_xml_v1 … 6_erwin_v3`` names), so a run laid out the old way
still resolves.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, Iterable, List, Optional

from app.common.config_helpers import get_setting

logger = logging.getLogger(__name__)

STAGE_KEYS = ("xml_v1", "xml_v2", "erwin_v1", "erwin_v2", "xml_v3", "erwin_v3")

_SUFFIX = {
    "xml_v1": ".xml", "xml_v2": ".xml", "xml_v3": ".xml",
    "erwin_v1": ".erwin", "erwin_v2": ".erwin", "erwin_v3": ".erwin",
}

# Flat stage folders under erwinmodels/. This module owns the mapping, but the
# NAMES themselves come from settings so a deployment can rename a stage folder
# in one place; the defaults are the values these constants have always had.
INITIAL_DIRNAME = str(get_setting("STAGE_INITIAL_DIRNAME", "1_initial"))
PREPROCESSED_DIRNAME = str(get_setting("STAGE_PREPROCESSED_DIRNAME", "2_preprocessed"))
FINAL_DIRNAME = str(get_setting("STAGE_FINAL_DIRNAME", "3_final"))

# Folder names of the retired six-folder layout, searched only as legacy input
# locations. settings.STAGE_FOLDERS is the overridable copy of this map; fall
# back to the historical names when it is absent or incomplete.
_SIX_FOLDER_DEFAULTS = {
    "xml_v1": "1_xml_v1", "xml_v2": "2_xml_v2", "erwin_v1": "3_erwin_v1",
    "erwin_v2": "4_erwin_v2", "xml_v3": "5_xml_v3", "erwin_v3": "6_erwin_v3",
}
_SIX_FOLDER_NAMES = {
    key: str(dict(get_setting("STAGE_FOLDERS", {})).get(key) or default)
    for key, default in _SIX_FOLDER_DEFAULTS.items()
}

# Where a model type's manual XML V3 export is expected below FINAL_XML_DIR.
TIER_SUBFOLDER = {"CDM": "cdm", "LDM": "ldm", "PDM": "pdm"}

# Keys whose file a PERSON produces and names by hand. Only these get the
# tolerant lookup below (tier sub-folder, short model name); the pipeline's own
# outputs are always found at exactly the path the pipeline wrote them to.
_HANDOFF_KEYS = ("erwin_v1", "erwin_v2", "xml_v3")

# Keys whose file may still be named with the raw SAP-extract hash prefix once
# directory_setup normalization is in play — which is ALL of them, and that is
# deliberate.
#
# Normalization changes the model's KEY (``<32-hex>_<extraction id>_<name>`` ->
# ``<extraction id>_<name>``). Two classes of file can then be sitting on disk
# under the old name:
#
#   * the hand-offs a PERSON saves (xml_v1, erwin_v1, xml_v3) — named by erwin
#     or by the SAP extract, not by the pipeline;
#   * the pipeline's OWN earlier outputs (xml_v2, erwin_v2, erwin_v3) — written
#     by a run that happened BEFORE normalization was switched on.
#
# The second class was originally left out, on the reasoning that "the
# pipeline's own outputs are already written with the model's name". That holds
# for a fresh tree and fails for every existing one: the UDP-enriched
# erwinmodels/2_preprocessed/<model>.erwin (erwin_v2) stopped resolving, the
# read-back fell through to the UN-enriched app/udp_tool/input_erwin_models
# copy (erwin_v1, which DID have the fallback), and every migrated value was
# reported MISSING — 0 PASS / 1794 MISSING against a model that had actually
# migrated 1779/1781.
#
# Collision is not a concern here: _HASH_PREFIX strips ONLY the 32-hex hash and
# keeps the extraction id, so two different extracts of the same model normalize
# to two different names. (report_layout.short_model_name strips the extraction
# id as well and would collide — it is not used for this.)
#
# expected() is still tried first in candidates(), so a correctly-named file
# always wins and this fallback only fires for a pre-normalization tree.
_HASH_FALLBACK_KEYS = STAGE_KEYS


def _short_name(model_name: str) -> str:
    """``real_estate`` for ``<hash>_<extraction id>_real_estate``; '' when unchanged."""
    try:
        from app.reporting.report_layout import short_model_name
        short = short_model_name(model_name) or ""
    except Exception:                                          # noqa: BLE001
        return ""
    return short if short and short != model_name else ""


def _udp_input_dir() -> Path:
    from app.orchestration.directory_setup import UDP_INPUT_MODELS_DIR
    return Path(UDP_INPUT_MODELS_DIR)


def stage_folders(erwin_out: Path, final_xml_dir: Optional[Path] = None,
                  udp_input_dir: Optional[Path] = None) -> Dict[str, Path]:
    """
    Absolute stage folders for one erwinmodels root::

        xml_v1/erwin_v1-legacy -> 1_initial, xml_v2/erwin_v2 -> 2_preprocessed,
        erwin_v3 -> 3_final, erwin_v1 -> udp_tool/input_erwin_models,
        xml_v3 -> FINAL_XML_DIR
    """
    erwin_out = Path(erwin_out)
    final_xml = Path(final_xml_dir) if final_xml_dir is not None else Path(
        str(get_setting("FINAL_XML_DIR", erwin_out.parent / "final_xml_models")))
    udp_in = Path(udp_input_dir) if udp_input_dir is not None else _udp_input_dir()
    return {
        "xml_v1": erwin_out / INITIAL_DIRNAME,
        "xml_v2": erwin_out / PREPROCESSED_DIRNAME,
        "erwin_v1": udp_in,
        "erwin_v2": erwin_out / PREPROCESSED_DIRNAME,
        "xml_v3": final_xml,
        "erwin_v3": erwin_out / FINAL_DIRNAME,
    }


class StagePaths:
    """Artefact locations for one run's directory tree (``dirs`` from setup_directories)."""

    def __init__(self, dirs: Dict[str, Path], model_type: str = ""):
        self.dirs = dirs
        self.model_type = (model_type or "").upper()
        stages = dirs.get("stages")
        if not isinstance(stages, dict) or set(stages) != set(STAGE_KEYS):
            # Fall back to the configured erwin output root, never to the
            # process CWD: a run launched from a different folder would
            # otherwise resolve every stage path against wherever the operator
            # happened to be standing.
            root = (Path(dirs["initial"]).parent if "initial" in dirs
                    else Path(str(get_setting("OUTPUT_DIR", Path(str(get_setting("BASE_DIR", "."))) /
                                              str(get_setting("ERWIN_MODELS_DIRNAME", "erwinmodels"))))))
            stages = stage_folders(root, dirs.get("final_xml"), dirs.get("udp_input"))
        self.stages: Dict[str, Path] = stages
        self.legacy = bool(get_setting("LEGACY_STAGE_FALLBACK", True))

    # ── expected locations (where things are written / must be placed) ────────

    def folder(self, key: str) -> Path:
        if key == "xml_v3" and self.model_type in TIER_SUBFOLDER:
            return self.stages[key] / TIER_SUBFOLDER[self.model_type]
        return self.stages[key]

    def expected(self, key: str, model_name: str) -> Path:
        return self.folder(key) / f"{model_name}{_SUFFIX[key]}"

    def xml_v1(self, name: str) -> Path:   return self.expected("xml_v1", name)
    def xml_v2(self, name: str) -> Path:   return self.expected("xml_v2", name)
    def erwin_v1(self, name: str) -> Path: return self.expected("erwin_v1", name)
    def erwin_v2(self, name: str) -> Path: return self.expected("erwin_v2", name)
    def xml_v3(self, name: str) -> Path:   return self.expected("xml_v3", name)
    def erwin_v3(self, name: str) -> Path: return self.expected("erwin_v3", name)

    # ── other places the same INPUT artefact may legitimately be ──────────────

    def _shared(self, key: str, name: str) -> List[Path]:
        """
        An isolated run writes to its own session folder but still accepts the
        operator's inputs (XML V1, the handed-off .erwin, the XML V3 export)
        dropped into the SHARED tree — the operator exporting from erwin cannot
        know the session folder in advance.
        """
        if key not in ("xml_v1", "erwin_v1", "erwin_v2", "xml_v3"):
            return []
        out: List[Path] = []
        shared = self.dirs.get("shared_stages")
        if isinstance(shared, dict) and key in shared:
            folder = Path(shared[key])
            if key == "xml_v3" and self.model_type in TIER_SUBFOLDER:
                out.append(folder / TIER_SUBFOLDER[self.model_type] / f"{name}{_SUFFIX[key]}")
            out.append(folder / f"{name}{_SUFFIX[key]}")
        return out

    def _legacy(self, key: str, name: str) -> List[Path]:
        if not self.legacy:
            return []
        suffix = _SUFFIX[key]
        out: List[Path] = []
        roots = [Path(self.dirs["initial"]).parent] if "initial" in self.dirs else []
        shared = self.dirs.get("shared_stages")
        if isinstance(shared, dict) and "xml_v1" in shared:
            roots.append(Path(shared["xml_v1"]).parent)
        for root in roots:
            # the retired six-folder layout
            out.append(root / _SIX_FOLDER_NAMES[key] / f"{name}{suffix}")
            # the pre-flat xml/ erwin/ sub-folders
            if key == "xml_v1":
                out.append(root / INITIAL_DIRNAME / "xml" / f"{name}.xml")
            elif key == "xml_v2":
                out.append(root / PREPROCESSED_DIRNAME / "xml" / f"{name}.xml")
            elif key == "erwin_v1":
                out.append(root / INITIAL_DIRNAME / f"{name}.erwin")
                out.append(root / INITIAL_DIRNAME / "erwin" / f"{name}.erwin")
            elif key == "erwin_v2":
                out.append(root / PREPROCESSED_DIRNAME / "erwin" / f"{name}.erwin")
            elif key == "erwin_v3":
                out.append(root / FINAL_DIRNAME / "erwin" / f"{name}.erwin")
        if key == "xml_v3":
            base = self.stages["xml_v3"]
            out.append(base / f"{name}.xml")                       # flat FINAL_XML_DIR
            if base.is_dir():
                out.extend(sorted(child / f"{name}.xml" for child in base.iterdir() if child.is_dir()))
        seen, unique = set(), []
        for path in out:
            if path != self.expected(key, name) and path not in seen:
                seen.add(path)
                unique.append(path)
        return unique

    def _alternates(self, key: str, name: str) -> List[Path]:
        """
        The places a PERSON plausibly puts a hand-made artefact, as opposed to
        the exact path the pipeline asks for.

        Two real-world mismatches are covered, both of which used to leave a
        correctly handed-off .erwin invisible and Step 2 stuck at EXTRACTED:

        * TIER SUB-FOLDER. ``mirror_models_to_udp_input`` fills
          ``input_erwin_models/{cdm,ldm,pdm}/`` with the SAP sources, so an
          operator saving the .erwin naturally drops it into the tier folder
          beside them — while ``expected()`` looked only at the flat root.
        * SHORT MODEL NAME. Every report is titled ``real_estate``; the
          pipeline key is ``<hash>_<extraction id>_real_estate``. A file named
          after the model as the operator sees it is accepted, and the run says
          so, because silently not finding it is worse than resolving it.

        Lower priority than ``expected()`` and the shared tree, so a file in
        the canonical place always wins and nothing that resolves today moves.
        """
        if key not in _HANDOFF_KEYS:
            return []
        suffix = _SUFFIX[key]
        short = _short_name(name) if bool(get_setting("SHORT_NAME_HANDOFF_FALLBACK", True)) else ""
        names = [name] + ([short] if short else [])

        folders: List[Path] = [self.folder(key)]
        if self.model_type in TIER_SUBFOLDER:
            tier = TIER_SUBFOLDER[self.model_type]
            # erwin_v1 lives in the UDP tool's input folder, which is mirrored
            # per tier; xml_v3's own folder is already the tier folder, so its
            # PARENT is the flat spelling to try as well.
            folders.append(self.stages[key] / tier)
            folders.append(self.stages[key])
        shared = self.dirs.get("shared_stages")
        if isinstance(shared, dict) and key in shared:
            folders.append(Path(shared[key]))
            if self.model_type in TIER_SUBFOLDER:
                folders.append(Path(shared[key]) / TIER_SUBFOLDER[self.model_type])

        out: List[Path] = []
        for folder in folders:
            for candidate_name in names:
                out.append(Path(folder) / f"{candidate_name}{suffix}")
        return out


    def _hash_normalized(self, key: str, name: str) -> List[Path]:
        """
        A file still named with its raw SAP-extract hash prefix
        (``<32-hex>_<name><suffix>``) instead of the model's normalized name —
        mirrored into a ``normalized/`` sub-folder beside it (original left in
        place) via ``directory_setup.normalize_named_file``, and returned as a
        candidate.

        This covers both the artefacts a PERSON saves by hand and the
        pipeline's own outputs written before normalization was switched on;
        see _HASH_FALLBACK_KEYS for why both classes need it.
        """
        if key not in _HASH_FALLBACK_KEYS:
            return []
        from app.orchestration.directory_setup import _HASH_PREFIX, normalize_named_file
        suffix = _SUFFIX[key]
        target_name = f"{name}{suffix}"
        folders = [self.folder(key)]
        if self.model_type in TIER_SUBFOLDER:
            folders.append(self.stages[key] / TIER_SUBFOLDER[self.model_type])
        out: List[Path] = []
        for folder in folders:
            folder = Path(folder)
            if not folder.is_dir():
                continue
            for candidate in folder.glob(f"*{suffix}"):
                if candidate.name != target_name and _HASH_PREFIX.sub("", candidate.name) == target_name:
                    out.append(normalize_named_file(candidate))
        return out

    def candidates(self, key: str, name: str) -> List[Path]:
        """Every location an input artefact may legitimately be found, in priority order."""
        ordered = ([self.expected(key, name)] + self._shared(key, name)
                   + self._hash_normalized(key, name)
                   + self._alternates(key, name) + self._legacy(key, name))
        seen, unique = set(), []
        for path in ordered:
            if path not in seen:
                seen.add(path)
                unique.append(path)
        return unique

    def find(self, key: str, name: str) -> Optional[Path]:
        expected = self.expected(key, name)
        for candidate in self.candidates(key, name):
            if candidate.is_file():
                if candidate != expected and candidate.stem != name:
                    # Resolved by the short model name: say so, because two
                    # extracts of the same model share it and the wrong file
                    # would be scored silently otherwise.
                    logger.warning(
                        "%s for %s resolved by short name at %s (expected %s). "
                        "Rename it to the full model name if this is not the right file.",
                        key, name, candidate, expected)
                return candidate
        return None

    def find_xml_v1(self, name: str) -> Optional[Path]:   return self.find("xml_v1", name)
    def find_xml_v2(self, name: str) -> Optional[Path]:   return self.find("xml_v2", name)
    def find_erwin_v1(self, name: str) -> Optional[Path]: return self.find("erwin_v1", name)
    def find_erwin_v2(self, name: str) -> Optional[Path]: return self.find("erwin_v2", name)
    def find_xml_v3(self, name: str) -> Optional[Path]:   return self.find("xml_v3", name)

    def describe(self, key: str, name: str) -> str:
        """Where an artefact was looked for, for skip reasons."""
        others = self._shared(key, name) + self._legacy(key, name)
        text = str(self.expected(key, name))
        if others:
            text += f" (and {len(others)} other location{'s' if len(others) != 1 else ''})"
        return text

    def ensure_folders(self, keys: Iterable[str] = ("xml_v1", "xml_v2", "erwin_v3")) -> None:
        """Create the pipeline's OWN stage folders (never the operator's input folders)."""
        for key in keys:
            self.folder(key).mkdir(parents=True, exist_ok=True)


__all__ = ["StagePaths", "STAGE_KEYS", "stage_folders", "TIER_SUBFOLDER",
           "INITIAL_DIRNAME", "PREPROCESSED_DIRNAME", "FINAL_DIRNAME"]
