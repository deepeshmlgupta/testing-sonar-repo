"""
Batch Runner
=============
Runs the per-model pipeline (workflow dispatch + reporting) for every
discovered model, either sequentially or across a thread pool, and collects
the summary rows for the batch.

Threading contract
------------------
* One model per task; a task touches only files named after its own model
  (stage artefacts, ``data/udp/<model>/``, ``app/reporting/<tier>/<short>/``).
  ``concurrency.preflight`` rejects any two models that would break that rule
  before the pool starts.
* Shared files (the JSONL ledger, Pass_Fail_Summary) are appended under
  ``session_manager.file_lock`` or written once by the main thread afterwards.
* The main thread waits with a timeout. If nothing completes for
  ``BATCH_STALL_TIMEOUT_SECONDS`` it logs every worker's stack
  (``concurrency.stall_report``) and keeps waiting; ``BATCH_ABORT_ON_STALL``
  turns that into a hard stop so a wedged erwin session cannot pin a scheduled
  job forever.
"""

from __future__ import annotations

import logging
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait

from app.common.config_helpers import get_setting
from app.orchestration import concurrency, pipeline_ledger
from app.orchestration.directory_setup import MODEL_TYPE_BY_SUFFIX
from app.reporting.model_reports import generate_model_reports
from app.reporting.summary_report import summary_row
from app.workflows.conceptual_workflow import process_conceptual_model
from app.workflows.pdm_workflow import process_pdm_model

logger = logging.getLogger(__name__)

DEFAULT_STALL_TIMEOUT_SECONDS = 1800


def process_single_model_worker(task):
    """Worker task for running migration pipeline on a single model."""
    index, total, model, dirs, release = task[:5]
    session_context = task[5] if len(task) > 5 else None
    base_name = model.stem
    model_type = MODEL_TYPE_BY_SUFFIX.get(model.suffix.lower(), "LDM")
    print(f"\n{'=' * 60}\n--- [{index}/{total}] {model_type}: {model.name} "
          f"---\n{'=' * 60}")

    try:
        if model_type == "PDM":
            record = process_pdm_model(model, base_name, dirs, session_context)
        else:
            record = process_conceptual_model(model, base_name, model_type, dirs, session_context)
    except Exception as exc:                               # noqa: BLE001
        logger.exception("Pipeline failed for %s: %s", model.resolve(), exc)
        return index, None, None

    if not record:
        return index, None, None

    s_row = None
    try:
        generate_model_reports(record, dirs)
        s_row = summary_row(record)
    except Exception as exc:                               # noqa: BLE001
        logger.exception("Reporting failed for %s: %s", base_name, exc)
    finally:
        # Ledger line after the reports so it can cite their paths; before
        # release() so the stage scores it records are still on the result.
        pipeline_ledger.record_model(record, dirs, getattr(record, "artefacts", {}) or {},
                                     session_context=session_context)
        if release:
            record.release()

    return index, record, s_row


def _run_threaded(tasks, max_workers, stall_timeout, abort_on_stall):
    """Drive the pool with a stall watchdog; returns {index: summary_row}."""
    summary_map = {}
    with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="model") as executor:
        pending = {executor.submit(process_single_model_worker, task): task for task in tasks}
        while pending:
            done, _ = wait(pending, timeout=stall_timeout or None, return_when=FIRST_COMPLETED)
            if not done:
                names = [pending[f][2].name for f in pending]
                report = concurrency.stall_report(names, stall_timeout)
                logger.error(report)
                print(report)
                if abort_on_stall:
                    # Threads cannot be killed; cancel what has not started and
                    # let the interpreter exit unblock the rest.
                    for future in pending:
                        future.cancel()
                    raise TimeoutError(
                        f"batch stalled for {stall_timeout}s on {', '.join(names)}")
                continue
            for future in done:
                task = pending.pop(future)
                try:
                    idx, _record, s_row = future.result()
                    if s_row:
                        summary_map[idx] = s_row
                except Exception as exc:                   # noqa: BLE001
                    logger.exception("Model worker execution failed for %s: %s", task[2].name, exc)
    return summary_map


def run_batch(models, dirs, release, max_workers, session_context=None):
    """
    Process every model, sequentially or across a thread pool, and return the
    collected summary rows in stable (original) model order.

    Runs ``concurrency.preflight`` first: colliding models are skipped (and
    reported at the end of the run like a missing export), never run.
    """
    max_workers = max(1, int(max_workers or 1))
    check = concurrency.preflight(models, dirs, max_workers)
    concurrency.report_preflight(check)
    models = check.ok
    total = len(models)
    tasks = [(index, total, model, dirs, release, session_context)
             for index, model in enumerate(models, start=1)]

    if max_workers > 1 and total > 1:
        stall_timeout = float(get_setting("BATCH_STALL_TIMEOUT_SECONDS", DEFAULT_STALL_TIMEOUT_SECONDS) or 0)
        abort_on_stall = bool(get_setting("BATCH_ABORT_ON_STALL", False))
        print(f"Running multithreaded pipeline with {max_workers} worker threads for {total} model(s)...")
        summary_map = _run_threaded(tasks, max_workers, stall_timeout, abort_on_stall)
        return [summary_map[idx] for idx in sorted(summary_map)]

    summary_rows = []
    for task in tasks:
        _idx, _record, s_row = process_single_model_worker(task)
        if s_row:
            summary_rows.append(s_row)
    return summary_rows


__all__ = ["run_batch", "process_single_model_worker", "DEFAULT_STALL_TIMEOUT_SECONDS"]
