"""
Stage State
============
Minimal cross-process persistence so V1, the UDP phase and V3 can run as
three separate script invocations — with manual steps (erwin export review,
UDP sign-off, final XML validation) happening between them — without ever
re-measuring a stage that already ran.

Two things are stored per model, in ``batch_summary/stage_state/<model>.json``:

* what V3 genuinely needs back — the V1 report's path (so the V3 workbook can
  reference it) and the V1 StageScore (so the V1->V2->V3 progression can still
  be shown). Findings and parsed models are deliberately NOT persisted here;
  they belong to one process's memory, not to disk.
* the MANUAL HAND-OFF ledger of the model: because no automated erwin bridge
  exists, two artefacts are produced by a person (the .erwin handed to the UDP
  tool, the XML exported from the enriched .erwin). Every stage records what it
  validated, what it is waiting for and what the operator must do next, with the
  artefact's path, size, mtime and SHA-256 so a stale or wrong file can be told
  apart from the one that was scored.

Stage status vocabulary (``STATUS_*``):

    AUTOMATED                  the framework produced this artefact itself
    MANUAL                     a person must produce this artefact
    WAITING_FOR_MANUAL_INPUT   the manual artefact is not there yet
    VALIDATED                  the artefact was found, checked and accepted
    FAILED                     the artefact was found but rejected (or the stage failed)
    READY_FOR_NEXT_STAGE       this stage is complete; the next script may run
"""

import hashlib
import json
import logging
import os
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from app.validation.fidelity_stages import STAGE_V1, StageScore

logger = logging.getLogger(__name__)

_SUBDIR = "stage_state"

STATUS_AUTOMATED = "AUTOMATED"
STATUS_MANUAL = "MANUAL"
STATUS_WAITING = "WAITING_FOR_MANUAL_INPUT"
STATUS_VALIDATED = "VALIDATED"
STATUS_FAILED = "FAILED"
STATUS_READY = "READY_FOR_NEXT_STAGE"
STATUSES = (STATUS_AUTOMATED, STATUS_MANUAL, STATUS_WAITING, STATUS_VALIDATED, STATUS_FAILED, STATUS_READY)

# The pipeline stages, in order, and which of them are manual hand-offs.
STAGE_V1_XML = "V1_XML"                   # manual: erwin export of the imported model
STAGE_V1_FIDELITY = "V1_FIDELITY"         # automated
STAGE_XML_V2 = "COMMENTS_TO_NOTES"        # automated (Step 1)
STAGE_ERWIN_HANDOFF = "ERWIN_HANDOFF"     # manual: .erwin copied to udp_tool/input_erwin_models
STAGE_UDP = "UDP"                         # automated (Step 2)
STAGE_V3_XML = "V3_XML_EXPORT"            # manual: erwin export of the enriched model
STAGE_V3_FIDELITY = "V3_FIDELITY"         # automated
MANUAL_STAGES = (STAGE_V1_XML, STAGE_ERWIN_HANDOFF, STAGE_V3_XML)

# What the operator must do to unblock each manual stage.
NEXT_ACTION = {
    STAGE_V1_XML: "Open the model in erwin Data Modeler, Save As XML, and place it as erwinmodels/1_initial/<model>.xml.",
    STAGE_ERWIN_HANDOFF: ("Open erwinmodels/2_preprocessed/<model>.xml (comments injected) in erwin, save it as "
                          "<model>.erwin and copy it to app/udp_tool/input_erwin_models/<model>.erwin; then run run_udp.py."),
    STAGE_V3_XML: ("Open erwinmodels/2_preprocessed/<model>.erwin (UDP-enriched) in erwin, Save As XML and place it as "
                   "final_xml_models/<cdm|ldm|pdm>/<model>.xml; then run run_v3.py."),
}


def artifact_record(path, kind: str = "", parent: str = "") -> Dict[str, Any]:
    """
    Identity of one artefact: path, kind, size, mtime, SHA-256 and the artefact
    it was derived from — enough to prove which file a stage scored and to spot
    an input that changed under a later stage. Never raises.
    """
    record: Dict[str, Any] = {"path": str(path) if path else "", "kind": kind, "parent": parent,
                              "exists": False, "size": 0, "mtime": "", "sha256": ""}
    try:
        p = Path(str(path))
        if path and p.is_file():
            stat = p.stat()
            digest = hashlib.sha256()
            with p.open("rb") as handle:
                for chunk in iter(lambda: handle.read(1 << 20), b""):
                    digest.update(chunk)
            record.update(exists=True, size=stat.st_size,
                          mtime=datetime.fromtimestamp(stat.st_mtime, timezone.utc).isoformat(timespec="seconds"),
                          sha256=digest.hexdigest())
    except OSError as exc:
        logger.debug("Could not fingerprint %s: %s", path, exc)
    return record


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _load(dirs, base_name: str) -> Dict[str, Any]:
    path = _path(dirs, base_name)
    if not path.is_file():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8")) or {}
    except (OSError, ValueError) as exc:
        logger.warning("Could not read stage state for %s: %s", base_name, exc)
        return {}


def _save(dirs, base_name: str, payload: Dict[str, Any]) -> None:
    try:
        _path(dirs, base_name).write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
    except OSError as exc:
        logger.warning("Could not persist stage state for %s: %s", base_name, exc)


def record_stage(dirs, base_name: str, stage: str, status: str, *, model_type: str = "",
                 artifact=None, artifact_kind: str = "", parent: str = "", message: str = "",
                 next_action: str = "", complexity: str = "", extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Append one hand-off / stage event to the model's state file and return it.
    The latest event per stage is also kept in ``stages[stage]`` so a reader
    can see the current status of every stage at a glance.
    """
    if status not in STATUSES:
        raise ValueError(f"unknown stage status {status!r}; expected one of {STATUSES}")
    payload = _load(dirs, base_name)
    event = {
        "stage": stage,
        "status": status,
        "manual": stage in MANUAL_STAGES,
        "model": base_name,
        "model_type": model_type or payload.get("model_type", ""),
        "complexity": complexity or payload.get("complexity", ""),
        "timestamp": _now(),
        "user": os.environ.get("USERNAME") or os.environ.get("USER") or "",
        "artifact": artifact_record(artifact, artifact_kind, parent) if artifact else None,
        "message": message,
        "next_action": next_action or (NEXT_ACTION.get(stage, "") if status == STATUS_WAITING else ""),
    }
    if extra:
        event.update(extra)
    payload.setdefault("model", base_name)
    if model_type:
        payload["model_type"] = model_type
    if complexity:
        payload["complexity"] = complexity
    payload.setdefault("events", []).append(event)
    payload.setdefault("stages", {})[stage] = event
    _save(dirs, base_name, payload)
    return event


def stage_status(dirs, base_name: str, stage: str) -> str:
    """The latest recorded status of ``stage`` for this model, or ''."""
    return str((_load(dirs, base_name).get("stages") or {}).get(stage, {}).get("status", ""))


def history(dirs, base_name: str) -> List[Dict[str, Any]]:
    """Every recorded stage event for this model, oldest first."""
    return list(_load(dirs, base_name).get("events") or [])


def pending_actions(dirs, base_name: str) -> List[str]:
    """What the operator must do next for this model (one line per waiting manual stage)."""
    stages = _load(dirs, base_name).get("stages") or {}
    return [f"{name}: {event.get('next_action') or 'manual input required'}"
            for name, event in stages.items() if event.get("status") == STATUS_WAITING]


def _path(dirs, base_name: str) -> Path:
    root = Path(dirs["summary"]) / _SUBDIR
    root.mkdir(parents=True, exist_ok=True)
    return root / f"{base_name}.json"


def save_v1(dirs, base_name: str, v1_report_path: str,
           stage_score: Optional[StageScore]) -> None:
    """Persist V1's report path and StageScore for a later V3 run to read back."""
    payload = _load(dirs, base_name)
    payload["v1_report_path"] = v1_report_path or ""
    payload["stage_score"] = asdict(stage_score) if stage_score is not None else None
    _save(dirs, base_name, payload)


def load_v1(dirs, base_name: str) -> Tuple[str, Optional[StageScore]]:
    """
    The V1 report path and StageScore saved by ``save_v1``, or ("", None) when
    V1 has not been run yet (or its state file could not be read).
    """
    payload = _load(dirs, base_name)
    if not payload:
        return "", None

    raw_score = payload.get("stage_score")
    stage_score = StageScore(**raw_score) if raw_score else None
    return str(payload.get("v1_report_path") or ""), stage_score


def carry_v1_into(result, base_name: str, dirs) -> None:
    """
    Stamp a persisted V1 StageScore onto ``result.stage_scores[STAGE_V1]`` so
    the V1->V2->V3 progression still shows even though V1 ran as a separate
    process. A no-op when V1 was never run or its state is unreadable.
    """
    _, stage_score = load_v1(dirs, base_name)
    if stage_score is None or result is None:
        return
    try:
        history = getattr(result, "stage_scores", None)
        if not isinstance(history, dict):
            history = {}
        history.setdefault(STAGE_V1, stage_score)
        result.stage_scores = history
    except AttributeError as exc:
        logger.debug("Could not stamp persisted V1 history onto result: %s", exc)
