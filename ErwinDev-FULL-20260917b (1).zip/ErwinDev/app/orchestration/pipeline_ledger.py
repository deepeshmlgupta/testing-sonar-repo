"""
Pipeline Ledger
===============
One JSON line per model per run, appended by the pipeline itself to
``batch_summary/audit/pipeline_ledger.jsonl`` (session-scoped when session
isolation is on).

Until now only the standalone ``run_all_reports.bat`` -> ``migration_audit.py``
wrote any ledger, so a plain ``python -m app.main`` left no record of which
XML V3 was scored, whether .ERWIN V1 / XML V3 were produced by erwin or by
hand, or where .ERWIN V3 went. Those are exactly the facts an erwin Mart
publish (and a Collibra / BizzDesign hand-off) will need to cite.

Never raises: a ledger problem is logged and the run continues.
"""

from __future__ import annotations

import logging
import os
import platform
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

from app.common.config_helpers import get_setting
from app.validation import fidelity_stages

logger = logging.getLogger(__name__)

_RUN_ID = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + f"-{os.getpid()}"


def run_id() -> str:
    """Identifier shared by every ledger line this process writes."""
    return _RUN_ID


def ledger_path(dirs: Dict[str, Path], session_context=None) -> Path:
    audit = Path(dirs["summary"]) / "audit"
    suffix = getattr(session_context, "session_suffix", "") if session_context is not None else ""
    # An isolated run already has a session-scoped batch_summary; only a
    # shared-layout run with a session identity needs the per-session subfolder.
    if suffix and suffix not in Path(dirs["summary"]).parts:
        audit = audit / suffix
    return audit / str(get_setting("PIPELINE_LEDGER_FILENAME", "pipeline_ledger.jsonl"))


def _stage_row(result, stage: str) -> Optional[Dict[str, Any]]:
    score = fidelity_stages.history(result).get(stage) if result is not None else None
    if score is None:
        return None
    return {
        "overall": score.overall,
        "structural": score.component(fidelity_stages.COMPONENT_STRUCTURAL),
        "documentation": score.component(fidelity_stages.COMPONENT_DOCUMENTATION),
        "udp": score.component(fidelity_stages.COMPONENT_UDP),
    }


def _str(path) -> str:
    return str(path) if path else ""


def _artefact_hashes(artefacts) -> Dict[str, Dict[str, Any]]:
    from app.orchestration.stage_state import artifact_record
    out: Dict[str, Dict[str, Any]] = {}
    for key, value in (artefacts or {}).items():
        if key.endswith("_how") or not value:
            continue
        rec = artifact_record(value, kind=key)
        if rec["exists"]:
            out[key] = {"sha256": rec["sha256"], "size": rec["size"], "mtime": rec["mtime"]}
    return out


def build_entry(record, artefacts: Dict[str, Any], stage_notes=None) -> Dict[str, Any]:
    """The ledger line for one processed model."""
    result = record.result
    entry: Dict[str, Any] = {
        "run_id": run_id(),
        "timestamp": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "host": platform.node(),
        "user": os.environ.get("USERNAME") or os.environ.get("USER") or "",
        "model": record.base_name,
        "model_type": record.model_type,
        "complexity": getattr(record, "complexity", ""),
        "status": record.status,
        "destination": record.destination,
        "fidelity_v3": record.fidelity,
        "stages": {
            stage: _stage_row(result, stage) for stage in fidelity_stages.STAGES
        },
        "findings": {
            "critical": int(getattr(result, "critical_count", 0) or 0),
            "warning": int(getattr(result, "warning_count", 0) or 0),
            "info": int(getattr(result, "info_count", 0) or 0),
        },
        "artefacts": {key: _str(value) for key, value in (artefacts or {}).items()
                      if not key.endswith("_how")},
        "artefact_origin": {key[:-4]: value for key, value in (artefacts or {}).items()
                            if key.endswith("_how")},
        # lineage evidence: size + SHA-256 of every artefact that exists, so a later
        # reader can prove which files this verdict was computed from
        "artefact_hashes": _artefact_hashes(artefacts),
        "udp_stage": getattr(record.udp_outcome, "stage", "") if record.udp_outcome else "",
        "udp_pass_rate": getattr(record.udp_outcome, "pass_rate", None) if record.udp_outcome else None,
        "reports": {
            "v1": _str(record.v1_report_path),
            "v2": _str(record.v2_report_path),
            "v3": _str(record.v3_report_path),
            "log": _str(record.log_path),
        },
        "notes": list(stage_notes or record.notes or []),
        "gate_note": str(getattr(result, "promotion_note", "") or ""),
    }
    return entry


def record_model(record, dirs: Dict[str, Path], artefacts: Dict[str, Any],
                 session_context=None, stage_notes=None) -> str:
    """Append this model's line. Returns the ledger path written to, or ''."""
    if not bool(get_setting("PIPELINE_LEDGER_ENABLED", True)):
        return ""
    try:
        from app.utils.session_manager import append_jsonl_line_safely
        path = ledger_path(dirs, session_context)
        append_jsonl_line_safely(path, build_entry(record, artefacts, stage_notes))
        return str(path)
    except Exception as exc:                                   # noqa: BLE001
        logger.warning("Pipeline ledger entry for %s not written: %s", record.base_name, exc)
        return ""


def record_skip(dirs: Dict[str, Path], model_name: str, model_type: str, reason: str,
                session_context=None) -> str:
    """Record a model the pipeline could not process (missing XML V1 / XML V3 …)."""
    if not bool(get_setting("PIPELINE_LEDGER_ENABLED", True)):
        return ""
    try:
        from app.utils.session_manager import append_jsonl_line_safely
        path = ledger_path(dirs, session_context)
        append_jsonl_line_safely(path, {
            "run_id": run_id(),
            "timestamp": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "host": platform.node(),
            "model": model_name,
            "model_type": model_type,
            "status": "SKIPPED",
            "reason": reason,
        })
        return str(path)
    except Exception as exc:                                   # noqa: BLE001
        logger.warning("Pipeline ledger skip entry for %s not written: %s", model_name, exc)
        return ""


__all__ = ["record_model", "record_skip", "build_entry", "ledger_path", "run_id"]
