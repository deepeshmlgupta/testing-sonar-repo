"""
Run Context — one run's identity and output roots
=================================================
Every entry point (``app.main``, ``run_v1``, ``run_udp``, ``run_v3``) starts by
building a :class:`RunContext`. It answers two questions the rest of the code
should never have to work out for itself:

1. **Who is running, and is this run isolated?**
   With ``ENABLE_SESSION_ISOLATION`` (or ``--isolate``) every *output* of the
   run lands under one session folder:

       <SESSIONS_DIR>/<user>_<YYYYMMDD_HHMMSS>_<uuid8>/
           erwinmodels/          stage artefacts (XML V2, .ERWIN V1/V2/V3, …)
           reports/              <tier>_reports/<model>/ V1–V3 workbooks + log
           batch_summary/        Pass_Fail_Summary.xlsx, audit/pipeline_ledger.jsonl
           data/udp/             UDP tool per-model workdirs
           data/interim_reports/ scratch workbooks (deleted after V3)
           udp_reports/          UDP tool workbooks per tier

   Two people (or two scheduled jobs) can therefore run the same checkout at
   the same time without touching each other's files. *Inputs* stay shared:
   ``sappdmodels/``, ``final_xml_models/`` and the shared ``erwinmodels/``
   stage folders, which the isolated run still searches for XML V1 / .ERWIN
   exports dropped there by hand (see StagePaths shared fallbacks).

   A forced ``--session-id`` (or ``FORCE_SESSION_ID``) makes the three split
   entry points reuse one session folder across three processes.

2. **Which command-line overrides apply?**
   ``parse_args`` / ``apply_overrides`` turn flags into ``settings`` attributes
   so every module keeps reading configuration the one way it already does
   (``get_setting``); nothing downstream knows a CLI exists.
"""

from __future__ import annotations

import argparse
import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Optional, Sequence

from app.common.config_helpers import get_setting
from app.config import settings

logger = logging.getLogger(__name__)


@dataclass
class RunContext:
    """Identity + output roots for one run."""

    isolated: bool
    session_context: Any = None
    roots: Dict[str, Path] = field(default_factory=dict)

    @property
    def session_suffix(self) -> str:
        return getattr(self.session_context, "session_suffix", "") if self.session_context else ""

    def describe(self) -> str:
        if not self.isolated:
            return "shared layout (session isolation off)"
        return f"session {self.session_suffix} -> {self.roots.get('session', '')}"


def default_roots(base_dir: Optional[Path] = None) -> Dict[str, Path]:
    """The non-isolated layout: every root exactly where it has always been."""
    base = Path(base_dir or settings.BASE_DIR)
    return {
        "erwin_out": Path(str(get_setting("OUTPUT_DIR", base / "erwinmodels"))),
        "summary": Path(str(get_setting("SUMMARY_DIR", base / "batch_summary"))),
        "reports_root": Path(str(get_setting("REPORTING_ROOT", base / "app" / "reporting"))),
        "udp_work": Path(str(get_setting("UDP_TOOL_WORKDIR_ROOT", base / "data" / "udp"))),
        "udp_reports": Path(str(get_setting("UDP_TOOL_REPORT_ROOT",
                                            base / "app" / "udp_tool" / "output_excel_reports"))),
        "scratch": Path(str(get_setting("SCRATCH_REPORT_DIR", base / "data" / "interim_reports"))),
        "manual_review": base / "manual_review_reports",
    }


def session_roots(session_dir: Path) -> Dict[str, Path]:
    """The isolated layout: everything under one session folder."""
    session_dir = Path(session_dir)
    return {
        "session": session_dir,
        "erwin_out": session_dir / "erwinmodels",
        "summary": session_dir / "batch_summary",
        "reports_root": session_dir / "reports",
        "udp_work": session_dir / "data" / "udp",
        "udp_reports": session_dir / "udp_reports",
        "scratch": session_dir / "data" / "interim_reports",
        "manual_review": session_dir / "manual_review_reports",
    }


def build_run_context(isolate: Optional[bool] = None, user: str = "",
                      session_id: str = "") -> RunContext:
    """
    Resolve the run's identity and roots. ``isolate=None`` follows
    ``ENABLE_SESSION_ISOLATION``; an explicit bool (from ``--isolate`` /
    ``--no-isolate``) wins.
    """
    if isolate is None:
        isolate = bool(get_setting("ENABLE_SESSION_ISOLATION", False))
    if not isolate:
        return RunContext(isolated=False, roots=default_roots())

    from app.utils.session_manager import SessionContext
    sessions_dir = Path(str(get_setting("SESSIONS_DIR", Path(settings.BASE_DIR) / "sessions")))
    ctx = SessionContext(str(sessions_dir), auto_create=True, user=user, session_id=session_id)
    roots = session_roots(ctx.session_output_dir)
    for path in roots.values():
        path.mkdir(parents=True, exist_ok=True)
    logger.info("Session isolation on: %s", ctx.session_output_dir)
    return RunContext(isolated=True, session_context=ctx, roots=roots)


# ═════════════════════════════════════════════════════════════════════════════
#  Command line
# ═════════════════════════════════════════════════════════════════════════════

def build_parser(prog: str, description: str) -> argparse.ArgumentParser:
    """The flags every entry point shares. Defaults come from settings / env."""
    parser = argparse.ArgumentParser(prog=prog, description=description,
                                     formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    run = parser.add_argument_group("run")
    run.add_argument("--workers", type=int, default=None, metavar="N",
                     help="parallel worker threads (settings.MAX_WORKERS; 1 = sequential)")
    run.add_argument("--max-models", type=int, default=None, metavar="N",
                     help="process at most N models (0 = all; settings.MAX_MODELS_PER_RUN)")
    run.add_argument("--stall-timeout", type=float, default=None, metavar="SECONDS",
                     help="watchdog: dump worker stacks when nothing finishes for this long (0 = off)")
    run.add_argument("--abort-on-stall", action="store_true", default=None,
                     help="stop the run when the stall watchdog fires instead of waiting")
    run.add_argument("--no-mirror", action="store_true",
                     help="do not copy SAP models into app/udp_tool/input_erwin_models/{cdm,ldm,pdm}")
    run.add_argument("--log-level", default=None, choices=("DEBUG", "INFO", "WARNING", "ERROR"))

    users = parser.add_argument_group("multi-user")
    iso = users.add_mutually_exclusive_group()
    iso.add_argument("--isolate", dest="isolate", action="store_true", default=None,
                     help="write every output under sessions/<user>_<session>/ (safe for concurrent runs)")
    iso.add_argument("--no-isolate", dest="isolate", action="store_false",
                     help="use the shared layout even if ENABLE_SESSION_ISOLATION is set")
    users.add_argument("--user", default="", help="identity for the session folder (default: OS user)")
    users.add_argument("--session-id", default="",
                       help="reuse an existing session id (lets run_v1/run_udp/run_v3 share one folder)")
    return parser


def apply_overrides(args: argparse.Namespace) -> None:
    """Push CLI values into ``settings`` so ``get_setting`` sees them everywhere."""
    mapping = {
        "workers": "MAX_WORKERS",
        "max_models": "MAX_MODELS_PER_RUN",
        "stall_timeout": "BATCH_STALL_TIMEOUT_SECONDS",
        "abort_on_stall": "BATCH_ABORT_ON_STALL",
        "log_level": "LOG_LEVEL",
    }
    for attr, name in mapping.items():
        value = getattr(args, attr, None)
        if value is not None:
            setattr(settings, name, value)
    if getattr(args, "no_mirror", False):
        settings.MIRROR_MODELS_TO_UDP_INPUT = False
    if getattr(args, "isolate", None) is not None:
        settings.ENABLE_SESSION_ISOLATION = bool(args.isolate)
    if getattr(args, "user", ""):
        settings.FORCE_USERNAME = args.user
    if getattr(args, "session_id", ""):
        settings.FORCE_SESSION_ID = args.session_id
    if getattr(args, "log_level", None):
        logging.getLogger().setLevel(getattr(logging, args.log_level))


def start_run(prog: str, description: str, argv: Optional[Sequence[str]] = None) -> RunContext:
    """Parse the command line, apply overrides, build and announce the run context."""
    args = build_parser(prog, description).parse_args(argv)
    apply_overrides(args)
    context = build_run_context(args.isolate, user=args.user, session_id=args.session_id)
    print(f"Run: {context.describe()}  |  workers={get_setting('MAX_WORKERS', 1)}  "
          f"|  pid={os.getpid()}")
    return context


__all__ = [
    "RunContext", "build_run_context", "default_roots", "session_roots",
    "build_parser", "apply_overrides", "start_run",
]
