"""
UDP Evidence — the verified read-back, carried forward to V3
============================================================
erwin's XML export does not carry UDPs. They are injected into the ``.erwin``
binary, and erwin's Save-As-XML drops them: on real_estate the validated export
held 1156 SAP UDP values' worth of nothing, and the 105 UDP values it did carry
corresponded to no SAP UDP at all. So the artefact V3 measures physically
cannot show whether the UDPs migrated.

The evidence that CAN show it is the UDP engine's read-back of the ``.erwin``
model itself, performed by ``run_udp.py`` at Step 2. That runs in a different
process, often on a different day, so it has to be persisted. This module is
that persistence, and it is deliberately NOT a report:

* **Machine-readable.** One JSON document per model under
  ``batch_summary/udp_evidence/<model>.json``. Not an Excel workbook — the
  previous carry-forward re-read the udp_tool's ``.xlsx``, which meant the
  score depended on a presentation artefact and on matching entity names out of
  it.
* **Independently auditable.** It records WHAT was measured (the ``.erwin``
  file and its SHA-256), HOW (read-back method and whether the decoder rated
  its own read reliable), the raw counts behind the rate, and WHERE the human
  readable workbook is. A reviewer can re-derive the number or reject it.
* **Falsifiable.** It records the identity of the SAP source it was measured
  against — path, size and SHA-256, plus the extraction id. ``load_verified``
  refuses evidence whose source no longer matches, so a stale or wrong-model
  record can never quietly become a score.
* **Never synthetic.** Nothing here writes to a model file, invents a UDP
  value, or fabricates a workbook so that scoring succeeds. When there is no
  trustworthy evidence the answer is ``None`` — "not measured" — which the
  fidelity engine already knows how to drop from the weighting.

The rule V3 applies, unchanged from ``udp_helpers.udp_stage_override``:

    the V3 XML carries SAP-corresponding UDPs  -> score the XML
    it does not                                -> use this evidence
    neither                                    -> not measured
"""

from __future__ import annotations

import getpass
import hashlib
import json
import logging
import os
import socket
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

logger = logging.getLogger(__name__)

_SUBDIR = "udp_evidence"

#: Bumped when the document shape changes incompatibly. Evidence written by an
#: older schema is rejected rather than half-read.
SCHEMA_VERSION = 1

#: How long a read-back stays usable when the artefacts still match. 0 disables
#: the age check; the hash checks are the real guard, this is belt and braces.
DEFAULT_MAX_AGE_DAYS = 0

_HASH_CHUNK = 1 << 20

# Why a stored record was refused. Reported, never silently swallowed.
REJECT_ABSENT = "no UDP evidence recorded for this model"
REJECT_SCHEMA = "recorded by an incompatible schema version"
REJECT_MODEL = "recorded for a different model"
REJECT_SOURCE_CHANGED = "the SAP PD source has changed since the UDP run"
REJECT_UNVERIFIABLE = ("the record carries no source digest, or the source could "
                       "not be hashed now, so staleness cannot be checked")
REJECT_SOURCE_MISSING = "the SAP PD source it was measured against is gone"
REJECT_UNRELIABLE = "the erwin read-back was not reliable"
REJECT_NOT_MEASURED = "the UDP run produced no verdict"
REJECT_STALE = "the evidence is older than the configured maximum age"


def sha256_of(path) -> str:
    """SHA-256 of a file, or '' when it cannot be read. Never raises."""
    try:
        digest = hashlib.sha256()
        with open(path, "rb") as handle:
            for chunk in iter(lambda: handle.read(_HASH_CHUNK), b""):
                digest.update(chunk)
        return digest.hexdigest()
    except OSError as exc:
        logger.debug("Could not hash %s: %s", path, exc)
        return ""


@dataclass
class UdpEvidence:
    """One model's verified UDP read-back, and everything needed to trust it."""

    # identity
    model_name: str = ""
    model_type: str = ""
    extraction_id: str = ""

    # the verdict
    pass_rate: Optional[float] = None
    passed: int = 0
    comparable: int = 0
    mismatch: int = 0
    missing: int = 0
    verdict: str = ""

    # how it was obtained
    readback_method: str = ""
    readback_reliable: Optional[bool] = None
    udp_stage: str = ""

    # what it was measured FROM — the falsifiability record
    pd_path: str = ""
    pd_sha256: str = ""
    pd_bytes: int = 0
    erwin_path: str = ""
    erwin_sha256: str = ""
    erwin_bytes: int = 0
    manifest_path: str = ""
    manifest_sha256: str = ""
    comparison_report: str = ""
    migration_report: str = ""

    # provenance
    recorded_at: str = ""
    recorded_by: str = ""
    recorded_on: str = ""
    schema_version: int = SCHEMA_VERSION
    messages: list = field(default_factory=list)

    @property
    def measured(self) -> bool:
        return self.pass_rate is not None and self.comparable > 0

    def summary(self) -> str:
        if not self.measured:
            return f"{self.model_name}: no UDP verdict recorded"
        return (f"{self.model_name}: {self.passed}/{self.comparable} UDP values verified "
                f"in the .erwin model ({self.pass_rate:.2f}%), read back by "
                f"{self.readback_method or 'unknown method'} on {self.recorded_at}")


# ═════════════════════════════════════════════════════════════════════════════
#  Storage
# ═════════════════════════════════════════════════════════════════════════════

def evidence_dir(dirs, create: bool = True) -> Path:
    """
    Where the per-model evidence records live.

    ``create`` defaults to True for the existing callers, but the READ path
    passes False. It used to create the folder unconditionally, so merely
    ASKING whether a model had evidence left a directory behind — and when
    ``dirs`` carried no ``summary`` key the fallback ``Path(_SUBDIR)`` is
    relative, so the folder appeared wherever the process happened to be
    running, including a repository root. A read must not write.
    """
    root = Path(dirs["summary"]) / _SUBDIR if isinstance(dirs, dict) and dirs.get("summary") \
        else Path(_SUBDIR)
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root


def path_for(dirs, model_name: str, create: bool = True) -> Path:
    return evidence_dir(dirs, create=create) / f"{model_name}.json"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _who() -> Tuple[str, str]:
    try:
        user = getpass.getuser()
    except Exception:                                          # noqa: BLE001
        user = os.environ.get("USER") or os.environ.get("USERNAME") or "unknown"
    try:
        host = socket.gethostname()
    except Exception:                                          # noqa: BLE001
        host = "unknown"
    return user, host


def _stamp_source(evidence: UdpEvidence, pd_path) -> None:
    """Record the SAP source this rate was measured against, for staleness."""
    if not pd_path:
        return
    path = Path(str(pd_path))
    if not path.is_file():
        return
    evidence.pd_path = str(path)
    evidence.pd_sha256 = sha256_of(path)
    evidence.pd_bytes = path.stat().st_size


def _stamp_artefacts(evidence: UdpEvidence, outcome) -> None:
    """Record the .erwin actually read back, and the manifest injected into it."""
    evidence.manifest_path = str(getattr(outcome, "manifest_path", "") or "")
    if evidence.manifest_path and Path(evidence.manifest_path).is_file():
        evidence.manifest_sha256 = sha256_of(evidence.manifest_path)

    erwin_read = str(getattr(outcome, "erwin_read", "") or "")
    if erwin_read and Path(erwin_read).is_file():
        evidence.erwin_path = erwin_read
        evidence.erwin_sha256 = sha256_of(erwin_read)
        evidence.erwin_bytes = Path(erwin_read).stat().st_size


def _stamp_counts(evidence: UdpEvidence, outcome) -> None:
    """The raw counts behind the rate, so a reviewer can re-derive it."""
    result = getattr(outcome, "comparison_result", None)
    if result is None:
        return
    evidence.comparable = int(getattr(result, "comparable", 0) or 0)
    counts = getattr(result, "counts", None) or {}
    try:
        evidence.passed = int(counts.get("PASS", 0) or 0)
        evidence.mismatch = int(counts.get("MISMATCH", 0) or 0)
        evidence.missing = int(counts.get("MISSING", 0) or 0)
    except AttributeError:
        return
    if not evidence.passed and evidence.pass_rate is not None and evidence.comparable:
        # Derive from the rate when the counter keys differ, so the stored
        # record can never be internally inconsistent with itself.
        evidence.passed = int(round(evidence.comparable * evidence.pass_rate / 100.0))


def build(model_name: str, model_type: str, outcome, pd_path,
          extraction_id: str = "") -> UdpEvidence:
    """
    Turn a Phase D outcome into an evidence record. Reads no configuration and
    writes nothing, so it is safe to call and inspect in isolation.
    """
    evidence = UdpEvidence(model_name=model_name, model_type=(model_type or "").upper(),
                           extraction_id=str(extraction_id or ""))
    user, host = _who()
    evidence.recorded_at, evidence.recorded_by, evidence.recorded_on = _now(), user, host
    _stamp_source(evidence, pd_path)

    if outcome is None:
        evidence.messages.append("no UDP outcome to record")
        return evidence

    evidence.udp_stage = str(getattr(outcome, "stage", "") or "")
    evidence.verdict = str(getattr(outcome, "verdict", "") or "")
    evidence.readback_method = str(getattr(outcome, "readback_method", "") or "")
    evidence.readback_reliable = getattr(outcome, "readback_reliable", None)
    evidence.pass_rate = getattr(outcome, "pass_rate", None)
    evidence.comparison_report = str(getattr(outcome, "comparison_report_path", "") or "")
    evidence.migration_report = str(getattr(outcome, "migration_report_path", "") or "")
    _stamp_artefacts(evidence, outcome)
    _stamp_counts(evidence, outcome)
    return evidence


def record(dirs, model_name: str, model_type: str, outcome, pd_path,
           extraction_id: str = "") -> Optional[UdpEvidence]:
    """
    Persist the verified read-back for one model. Never raises: failing to
    write evidence must not fail a migration that otherwise worked.

    Called from the UDP phase, so only a real Step 2 run writes evidence — a
    V3-only run reads it and never creates it.
    """
    evidence = build(model_name, model_type, outcome, pd_path, extraction_id)
    if not evidence.measured:
        # Deliberately still written: "the UDP phase ran and produced no
        # verdict" is itself auditable, and it stops an older, now-superseded
        # record from being reused after a failed re-run.
        logger.info("UDP evidence for %s records no verdict (%s).",
                    model_name, evidence.verdict or evidence.udp_stage or "unknown")
    try:
        target = path_for(dirs, model_name)
        target.write_text(json.dumps(asdict(evidence), indent=2, default=str),
                          encoding="utf-8")
        logger.info("UDP evidence written to %s — %s", target, evidence.summary())
    except (OSError, TypeError, ValueError) as exc:
        logger.warning("Could not persist UDP evidence for %s: %s", model_name, exc)
        return evidence
    return evidence


def load(dirs, model_name: str) -> Optional[UdpEvidence]:
    """The stored record for a model, unverified, or None."""
    path = path_for(dirs, model_name, create=False)
    if not path.is_file():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8")) or {}
    except (OSError, ValueError) as exc:
        logger.warning("Could not read UDP evidence at %s: %s", path, exc)
        return None
    known = {f for f in UdpEvidence.__dataclass_fields__}       # noqa: SLF001
    return UdpEvidence(**{k: v for k, v in payload.items() if k in known})


# ═════════════════════════════════════════════════════════════════════════════
#  Verification — the reason a record may NOT be used
# ═════════════════════════════════════════════════════════════════════════════

def _check_identity(evidence: UdpEvidence, model_name: str, model_type: str) -> str:
    """Wrong model, wrong tier, or a shape this code cannot read."""
    if int(evidence.schema_version or 0) != SCHEMA_VERSION:
        return REJECT_SCHEMA
    if evidence.model_name and evidence.model_name != model_name:
        return f"{REJECT_MODEL} ({evidence.model_name})"
    if model_type and evidence.model_type and evidence.model_type != (model_type or "").upper():
        return f"{REJECT_MODEL} (tier {evidence.model_type})"
    return ""


def _check_verdict(evidence: UdpEvidence) -> str:
    """The run has to have actually measured something it trusted."""
    if not evidence.measured:
        return REJECT_NOT_MEASURED
    if evidence.readback_reliable is False:
        return REJECT_UNRELIABLE
    return ""


def _check_source(evidence: UdpEvidence, pd_path) -> str:
    """
    The SAP source is what the UDP values came FROM. If it changed, the
    manifest that was injected no longer describes it and the rate is stale.
    Size is checked before the hash because it rejects the common case without
    reading a megabyte.
    """
    if pd_path is None:
        return ""
    if not evidence.pd_sha256:
        # The record carries no digest, so staleness CANNOT be checked. This
        # used to return "" — no rejection — which meant a disk error while
        # hashing (sha256_of returns "" on OSError) silently switched the
        # staleness guard off and let an arbitrarily old record be used. An
        # unverifiable record is refused, not trusted.
        return REJECT_UNVERIFIABLE
    current = Path(str(pd_path))
    if not current.is_file():
        return REJECT_SOURCE_MISSING
    if current.stat().st_size != evidence.pd_bytes:
        return REJECT_SOURCE_CHANGED
    digest = sha256_of(current)
    if not digest:
        # Could not hash the source NOW, so the comparison cannot be made.
        return REJECT_UNVERIFIABLE
    if digest != evidence.pd_sha256:
        return REJECT_SOURCE_CHANGED
    return ""


def _check_age(evidence: UdpEvidence, max_age_days: Optional[int]) -> str:
    limit = DEFAULT_MAX_AGE_DAYS if max_age_days is None else int(max_age_days)
    if limit <= 0 or not evidence.recorded_at:
        return ""
    try:
        recorded = datetime.fromisoformat(evidence.recorded_at)
    except ValueError:
        return ""
    if recorded.tzinfo is None:
        recorded = recorded.replace(tzinfo=timezone.utc)
    return REJECT_STALE if (datetime.now(timezone.utc) - recorded).days > limit else ""


def verify(evidence: Optional[UdpEvidence], model_name: str, model_type: str = "",
           pd_path=None, max_age_days: Optional[int] = None) -> Tuple[bool, str]:
    """
    May this evidence be used as the UDP score for this model, right now?

    Returns (ok, reason). Every rejection names itself so the run can say why
    the UDP component is n/a instead of the operator finding a silent zero.
    """
    if evidence is None:
        return False, REJECT_ABSENT
    for reason in (_check_identity(evidence, model_name, model_type),
                   _check_verdict(evidence),
                   _check_source(evidence, pd_path),
                   _check_age(evidence, max_age_days)):
        if reason:
            return False, reason
    return True, ""


def load_verified(dirs, model_name: str, model_type: str = "", pd_path=None,
                  max_age_days: Optional[int] = None
                  ) -> Tuple[Optional[UdpEvidence], str]:
    """
    The usable evidence for a model, or (None, reason). The single call a
    scoring path should make.
    """
    evidence = load(dirs, model_name)
    ok, reason = verify(evidence, model_name, model_type, pd_path, max_age_days)
    if not ok:
        if reason != REJECT_ABSENT:
            logger.warning("Stored UDP evidence for %s was refused: %s", model_name, reason)
        return None, reason
    return evidence, ""


def pass_rate_for(dirs, model_name: str, model_type: str = "", pd_path=None,
                  max_age_days: Optional[int] = None) -> Tuple[Optional[float], str]:
    """The verified pass rate to carry into V3, or (None, why not)."""
    evidence, reason = load_verified(dirs, model_name, model_type, pd_path, max_age_days)
    if evidence is None:
        return None, reason
    logger.info("V3 UDP component carried forward from Step 2: %s", evidence.summary())
    return evidence.pass_rate, ""


def as_report_rows(evidence: Optional[UdpEvidence], reason: str = "") -> Dict[str, Any]:
    """The audit trail a report can print without reaching into the dataclass."""
    if evidence is None:
        return {"available": False, "reason": reason or REJECT_ABSENT}
    return {
        "available": True,
        "pass_rate": evidence.pass_rate,
        "passed": evidence.passed,
        "comparable": evidence.comparable,
        "mismatch": evidence.mismatch,
        "missing": evidence.missing,
        "readback_method": evidence.readback_method,
        "readback_reliable": evidence.readback_reliable,
        "erwin_model": evidence.erwin_path,
        "erwin_sha256": evidence.erwin_sha256,
        "sap_model": evidence.pd_path,
        "sap_sha256": evidence.pd_sha256,
        "comparison_report": evidence.comparison_report,
        "recorded_at": evidence.recorded_at,
        "recorded_by": f"{evidence.recorded_by}@{evidence.recorded_on}",
    }


__all__ = ["UdpEvidence", "SCHEMA_VERSION", "DEFAULT_MAX_AGE_DAYS",
           "build", "record", "load", "load_verified", "verify",
           "pass_rate_for", "as_report_rows", "sha256_of", "path_for", "evidence_dir",
           "REJECT_ABSENT", "REJECT_SCHEMA", "REJECT_MODEL", "REJECT_SOURCE_CHANGED",
           "REJECT_SOURCE_MISSING", "REJECT_UNVERIFIABLE", "REJECT_UNRELIABLE", "REJECT_NOT_MEASURED",
           "REJECT_STALE"]
