"""
Concurrency Support
===================
Everything the threaded batch needs besides the pool itself:

* skipped-model tracking — one consolidated end-of-run summary instead of
  interleaved per-model messages;
* ``preflight`` — the checks that must pass BEFORE workers start. A thread pool
  cannot deadlock on Python locks in this pipeline (see the audit below), but
  it can stall or corrupt output when two models write the same files or when
  a lock file is already held by another run. Those are caught here, once, on
  the whole batch, so nothing is discovered half-way through a 100-model run;
* ``stall_report`` — a diagnostic dump of every worker's current stack when the
  pool has produced nothing within ``BATCH_STALL_TIMEOUT_SECONDS``.

Lock-ordering audit (why the pool cannot deadlock)
--------------------------------------------------
Only four locks exist in the process and none is ever held while acquiring
another:

  concurrency._skip_lock            in-memory list append; leaf.
  isolated_import.IMPORT_LOCK       RLock around a tool import window; only the
                                    tool's own modules are imported under it.
  session_manager.file_lock         OS lock on ``<file>.lock`` for ledger /
                                    JSONL appends; acquired with a timeout and
                                    released in ``finally``; leaf.
  ThreadPoolExecutor internals      stdlib; the main thread only waits on
                                    futures, it never holds a pipeline lock
                                    while doing so.

External waits (erwin COM, ``subprocess`` for the injector and converter) all
carry timeouts (``UDP_TOOL_TIMEOUT_SECONDS``, ``ERWIN_CONVERT_TIMEOUT``), so a
hung erwin cannot hold a worker forever either.
"""

from __future__ import annotations

import logging
import sys
import threading
import traceback
from collections import defaultdict
from pathlib import Path
from typing import Dict, Iterable, List

logger = logging.getLogger(__name__)

_skip_lock = threading.Lock()
_skipped_models: List[str] = []


def record_skipped_model(reason: str) -> None:
    with _skip_lock:
        _skipped_models.append(reason)


def clear_skipped_models() -> None:
    with _skip_lock:
        _skipped_models.clear()


def get_skipped_models() -> List[str]:
    with _skip_lock:
        return list(_skipped_models)


# ═════════════════════════════════════════════════════════════════════════════
#  Pre-flight
# ═════════════════════════════════════════════════════════════════════════════

class PreflightResult:
    """What ``preflight`` found. ``ok`` is the list of models safe to run."""

    def __init__(self):
        self.ok: List[Path] = []
        self.rejected: Dict[Path, str] = {}
        self.warnings: List[str] = []

    @property
    def clean(self) -> bool:
        return not self.rejected


def _short_name(model: Path) -> str:
    try:
        from app.reporting.report_layout import short_model_name
        return short_model_name(model.stem)
    except Exception:                                          # noqa: BLE001
        return model.stem


def preflight(models: Iterable[Path], dirs: Dict[str, Path], max_workers: int = 1,
              lock_probe_timeout: float = 2.0) -> PreflightResult:
    """
    Check a batch before any worker starts.

    1. Two models with the same stem (``x.ldm`` + ``x.cdm``) would share every
       stage artefact, UDP workdir and report folder; run in parallel they
       overwrite each other. The first (in discovery order) is kept, the rest
       are rejected with a reason the operator can act on.
    2. Two models whose SHORT names coincide (different repository hashes,
       same readable name) would share a report folder. Rejected likewise.
    3. Every output root the run will write to must be creatable/writable;
       a read-only OneDrive placeholder or a permission problem fails fast.
    4. The shared ledger lock must be acquirable within ``lock_probe_timeout``
       seconds. A stale ``.lock`` from a killed run does not block (the lock is
       advisory and released with the process) but a live one from another
       user's run is reported, so the operator knows both runs will queue on
       ledger writes rather than deadlock.

    Never raises; everything is reported on the result.
    """
    result = PreflightResult()
    models = [Path(m) for m in models]

    by_stem: Dict[str, List[Path]] = defaultdict(list)
    by_short: Dict[str, List[Path]] = defaultdict(list)
    for model in models:
        by_stem[model.stem].append(model)
        by_short[_short_name(model)].append(model)

    for stem, group in by_stem.items():
        for dup in group[1:]:
            result.rejected[dup] = (
                f"shares the model name '{stem}' with {group[0].name}; both would write the "
                "same stage artefacts, UDP workdir and reports. Rename one of the files.")
    for short, group in by_short.items():
        survivors = [m for m in group if m not in result.rejected]
        for dup in survivors[1:]:
            result.rejected[dup] = (
                f"its report folder name '{short}' collides with {survivors[0].name}; "
                "rename one of the files so the readable part of the name differs.")

    result.ok = [m for m in models if m not in result.rejected]

    # Output roots: create and probe once, not once per worker.
    for key in ("summary", "final_xml", "initial", "preprocessed", "final"):
        root = dirs.get(key)
        if root is None:
            continue
        try:
            Path(root).mkdir(parents=True, exist_ok=True)
            probe = Path(root) / ".write_probe"
            probe.write_text("", encoding="utf-8")
            probe.unlink()
        except OSError as exc:
            result.warnings.append(f"output folder {root} is not writable: {exc}")
    stages = dirs.get("stages")
    if isinstance(stages, dict):
        for key, root in stages.items():
            try:
                Path(root).mkdir(parents=True, exist_ok=True)
            except OSError as exc:
                result.warnings.append(f"stage folder {key} at {root} cannot be created: {exc}")

    # Ledger lock probe.
    summary = dirs.get("summary")
    if summary is not None and max_workers >= 1:
        try:
            from app.utils.session_manager import file_lock, lock_is_held
            ledger = Path(summary) / "audit" / "pipeline_ledger.jsonl"
            ledger.parent.mkdir(parents=True, exist_ok=True)
            if lock_is_held(ledger, timeout=lock_probe_timeout):
                result.warnings.append(
                    f"another run currently holds the ledger lock on {ledger}; this run will "
                    "queue behind it on every ledger write (no deadlock, but slower).")
            else:
                with file_lock(ledger, timeout=lock_probe_timeout):
                    pass
        except Exception as exc:                               # noqa: BLE001
            result.warnings.append(f"ledger lock probe failed: {exc}")

    if max_workers > 1 and len(result.ok) > 1:
        result.warnings.append(
            f"{len(result.ok)} model(s) across {min(max_workers, len(result.ok))} worker threads; "
            "stall watchdog armed.")
    return result


def report_preflight(result: PreflightResult) -> None:
    """Print + log the preflight outcome and record rejections as skipped models."""
    for model, reason in result.rejected.items():
        message = f"{model.name}: {reason}"
        logger.error("Pre-flight rejected %s", message)
        print(f"  ! pre-flight rejected {message}")
        record_skipped_model(f"{model.stem}: pre-flight — {reason}")
    for warning in result.warnings:
        logger.warning("Pre-flight: %s", warning)
        print(f"  - pre-flight: {warning}")


# ═════════════════════════════════════════════════════════════════════════════
#  Stall diagnostics
# ═════════════════════════════════════════════════════════════════════════════

def stall_report(pending: Iterable[str], seconds: float) -> str:
    """
    Text dump of every live thread's stack, headed by the models still pending.
    Used when the pool has produced no completed future for ``seconds``; it is
    logged (not raised) so the operator can see WHERE each worker is — waiting
    on erwin COM, on a lock, on a subprocess — instead of a silent hang.
    """
    lines = [f"No model finished in {seconds:.0f}s; still pending: {', '.join(pending) or '-'}"]
    names = {t.ident: t.name for t in threading.enumerate()}
    for ident, frame in sys._current_frames().items():        # noqa: SLF001
        name = names.get(ident, str(ident))
        if name == "MainThread":
            continue
        lines.append(f"--- thread {name} ---")
        lines.extend(line.rstrip() for line in traceback.format_stack(frame)[-6:])
    return "\n".join(lines)


__all__ = [
    "record_skipped_model", "clear_skipped_models", "get_skipped_models",
    "PreflightResult", "preflight", "report_preflight", "stall_report",
]
