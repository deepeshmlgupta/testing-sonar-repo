"""
run_v3.py
===========
Stage 3 of the split pipeline — Fidelity V2, Fidelity V3, the gate and the
batch summary:

    erwinmodels/2_preprocessed/<model>.xml       Step 1 output (run_v1.py)     -> Fidelity V2
    final_xml_models/<tier>/<model>.xml          MANUAL: erwin's XML export of
                                                 erwinmodels/2_preprocessed/<model>.erwin
                                                                               -> Fidelity V3
    gate (>= threshold)                          -> erwinmodels/3_final/<model>.xml (+ .erwin)

The V3 report shows V1 (read back from run_v1.py's stage state), the UDP
verdict (read from run_udp.py's workbooks), V3 and the combined score, whose
formula is documented in fidelity_stages. Nothing is re-measured that already
ran, and nothing is exported from erwin here: a model without its XML V3 is a
HARD STOP recorded as WAITING_FOR_MANUAL_INPUT (FINAL_XML_FALLBACK_TO_PREPROCESSED=true
turns that into a clearly labelled dry run). An XML V3 that does not describe
the model (no entity/table in common with the SAP source) is refused.

Usage:
    python -m app.run_v3 [--isolate] [--user NAME] [--session-id ID]
"""

import logging
import os
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.common.config_helpers import get_setting
from app.config.settings import LOG_LEVEL
from app.orchestration import concurrency, pipeline_ledger, stage_state
from app.orchestration.directory_setup import MODEL_TYPE_BY_SUFFIX, find_models, setup_directories
from app.orchestration.model_record import DEST_MANUAL_REVIEW, ModelRecord
from app.orchestration.run_context import start_run
from app.orchestration.stage_paths import StagePaths
from app.orchestration.udp_helpers import udp_stage_override
from app.reporting.model_log import write_model_log
from app.reporting.model_reports import build_v2_report, build_v3_report
from app.reporting.summary_report import generate_summary_report, summary_row
from app.validation import fidelity_stages
from app.workflows.conceptual_workflow import inject_comments, locate_xml_v1, locate_xml_v3, measure_v2, measure_v3
from app.workflows.pdm_workflow import process_pdm_model
from app.workflows.promotion_routing import route_model

logging.basicConfig(
    level=getattr(logging, str(LOG_LEVEL).upper(), logging.WARNING),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


def _process_conceptual(model_path, base_name, model_type, dirs, session_context=None):
    stages = StagePaths(dirs, model_type)
    record = ModelRecord(base_name=base_name, model_type=model_type)

    xml_v1 = locate_xml_v1(stages, base_name, model_type, dirs)
    if xml_v1 is None:
        pipeline_ledger.record_skip(dirs, base_name, model_type,
                                    f"XML V1 not found or invalid at {stages.describe('xml_v1', base_name)}; "
                                    "run run_v1.py first", session_context=session_context)
        return None
    record.artefacts["source_model"] = str(model_path)
    record.artefacts["xml_v1"] = str(xml_v1)
    record.artefacts["xml_v1_how"] = "manual"
    record.v1_report_path, _ = stage_state.load_v1(dirs, base_name)
    if not record.v1_report_path:
        print("  -> note: no V1 state from run_v1.py; the progression sheet will start at V2.")

    # Step 1 output is reused when present (it is what the operator loaded into erwin).
    xml_v2 = stages.find_xml_v2(base_name) or inject_comments(record, model_path, xml_v1, stages, dirs)
    record.artefacts.setdefault("xml_v2", str(xml_v2))
    record.artefacts.setdefault("xml_v2_how", "existing")
    erwin_v2 = stages.find_erwin_v2(base_name)
    if erwin_v2 is not None:
        record.artefacts["erwin_v2"] = str(erwin_v2)

    # No live UDP outcome in this process: udp_stage_override reads the verdict
    # run_udp.py left in the udp_tool's workbooks (only if they name this model).
    record.udp_outcome = None
    measure_v2(record, model_path, xml_v2, dirs)
    stage_state.carry_v1_into(record.v2_result, base_name, dirs)

    xml_v3 = locate_xml_v3(record, stages, dirs)
    if xml_v3 is None:
        if get_setting("FINAL_XML_FALLBACK_TO_PREPROCESSED", False):
            # Say it out loud. This is a DRY RUN: the "V3" number below is the
            # V2 artefact measured a second time. The flag is off by default
            # (app/config/settings.py) precisely so this can only happen when
            # somebody asked for it.
            print(f"  -> FALLBACK: no manually validated XML V3 for {base_name}. "
                  f"V3 is being measured against the SAME preprocessed XML as V2 "
                  f"(FINAL_XML_FALLBACK_TO_PREPROCESSED is on). The V3 number is "
                  f"NOT evidence about the final erwin model.")
            logger.warning("V3 for %s measured against the preprocessed XML "
                           "(FINAL_XML_FALLBACK_TO_PREPROCESSED); no manual XML V3 exists.",
                           base_name)
            record.result = record.v2_result
            record.artefacts["xml_v3"] = str(xml_v2)
            record.artefacts["xml_v3_how"] = "fallback (commented XML)"
            record.notes.append(
                "V3 measured against the preprocessed XML (fallback). This is NOT "
                "final validation and the model was NOT promoted.")
            fidelity_stages.apply(record.result, fidelity_stages.STAGE_V3,
                                  udp_override=udp_stage_override(record.result, None, base_name, model_type,
                                                                  dirs=dirs, pd_path=model_path),
                                  model_type=model_type)
            # NOT promoted. route_model would copy this model into
            # erwinmodels/3_final/ on a passing score — and 3_final means
            # "validated against the final erwin export", which by definition
            # has not happened here. Promoting a fallback measurement would
            # also make the NEXT run discover that promoted copy as an XML V3
            # and measure V3 against the framework's own output, which is how a
            # self-confirming score is built. The stage state already records
            # V3_XML_EXPORT as WAITING_FOR_MANUAL_INPUT; it stays that way.
            # `status` is derived from `destination`, so routing it to manual
            # review is what makes the verdict FAIL — correct here, because the
            # model has NOT passed final validation; it has not had any.
            record.destination = DEST_MANUAL_REVIEW
            return record
        pipeline_ledger.record_skip(dirs, base_name, model_type,
                                    f"XML V3 not found at {stages.describe('xml_v3', base_name)}",
                                    session_context=session_context)
        return None

    if not measure_v3(record, model_path, xml_v3, dirs):
        pipeline_ledger.record_skip(dirs, base_name, model_type,
                                    f"XML V3 {xml_v3} does not describe this model", session_context=session_context)
        return None
    stage_state.carry_v1_into(record.result, base_name, dirs)

    route_model(record, xml_v3, dirs, stages=stages, erwin_source=erwin_v2)
    return record


def _process_pdm(model_path, base_name, dirs, session_context=None):
    record = process_pdm_model(model_path, base_name, dirs, session_context, run_udp=False)
    if record is None:
        return None
    record.v1_report_path, _ = stage_state.load_v1(dirs, base_name)
    stage_state.carry_v1_into(record.result, base_name, dirs)
    return record


def process_model(model_path, base_name, model_type, dirs, session_context=None):
    if model_type == "PDM":
        record = _process_pdm(model_path, base_name, dirs, session_context)
    else:
        record = _process_conceptual(model_path, base_name, model_type, dirs, session_context)
    if record is None:
        for line in stage_state.pending_actions(dirs, base_name):
            print(f"  -> NEXT (manual): {line}")
        return None

    outdir = record.report_dir()
    record.v2_report_path = build_v2_report(record, outdir)
    record.v3_report_path = build_v3_report(record, outdir, dirs)
    record.log_path = write_model_log(record, outdir)
    pipeline_ledger.record_model(record, dirs, record.artefacts, session_context=session_context)

    print(f"\n  {record.base_name}  ->  {outdir}")
    for label, path in (("V2 UDP mapping", record.v2_report_path),
                        ("V3 final fidelity", record.v3_report_path),
                        ("Model log", record.log_path)):
        print(f"    {label:22} {Path(path).name if path else 'not generated'}")
    return record


def main(argv=None):
    print("\nStage 3/3 — V2 + V3 (final fidelity), gate and summary\n")
    concurrency.clear_skipped_models()

    run = start_run("python -m app.run_v3", "Stage 3/3 - V2 + V3 fidelity, gate and summary.", argv)
    dirs = setup_directories(run)
    models = find_models(dirs)
    if not models:
        print(f"No models found under {get_setting('SAMPLES_DIR', '')}.")
        return []

    print(f"Found {len(models)} model(s) to process.")
    summary_rows, records = [], []
    for index, model in enumerate(models, start=1):
        base_name = model.stem
        model_type = MODEL_TYPE_BY_SUFFIX.get(model.suffix.lower(), "LDM")
        print(f"\n{'=' * 60}\n--- [{index}/{len(models)}] {model_type}: {model.name} ---\n{'=' * 60}")
        try:
            record = process_model(model, base_name, model_type, dirs, run.session_context)
            if record is not None:
                records.append(record)
                summary_rows.append(summary_row(record))
        except Exception as exc:                               # noqa: BLE001
            logger.exception("V3 stage failed for %s: %s", model.resolve(), exc)
            stage_state.record_stage(dirs, base_name, stage_state.STAGE_V3_FIDELITY, stage_state.STATUS_FAILED,
                                     model_type=model_type, message=f"{type(exc).__name__}: {exc}")

    if summary_rows:
        generate_summary_report(summary_rows, dirs["summary"])

    skipped = concurrency.get_skipped_models()
    if skipped:
        print(f"\n{len(skipped)} model(s) not scored (waiting for a manual step or rejected):")
        for reason in skipped:
            print(f"  - {reason}")

    print("\nStage 3/3 complete. Pipeline finished.\n")
    return records


if __name__ == "__main__":  # pragma: no cover
    main()
