"""
run_udp.py
============
Stage 2 of the split pipeline — Step 2 of the migration flow (the UDP tool):

    .ERWIN V1  app/udp_tool/input_erwin_models/<model>.erwin
               made from XML V2 (erwinmodels/2_preprocessed/<model>.xml) by erwin
      -> classify -> map SAP extended attributes -> inject as erwin UDPs (erwin COM, Windows)
    .ERWIN V2  erwinmodels/2_preprocessed/<model>.erwin
               the UDP-enriched model — the input is never overwritten
      -> UDP migration report + read-back comparison report

NOTE ON 2_preprocessed/: it holds TWO artefacts and the extension tells them
apart — <model>.xml is XML V2 (Step 1's output, this stage's input) and
<model>.erwin is .ERWIN V2 (this stage's output). .ERWIN V1, the un-enriched
binary this stage consumes, lives in the UDP tool's input folder instead.

Obtaining the two erwin artefacts goes through app/erwin/erwin_handoff.py:

  * erwin COM on this host (Windows + erwin Data Modeler + pywin32): the .erwin
    is converted from XML V2 and the UDPs are injected, with no operator step.
  * no erwin COM, someone at the terminal: the run prints exactly what to save
    and where, writes the same text beside the target as a .HOWTO.txt, and
    waits at a prompt until it is done.
  * no erwin COM, nobody watching (scheduled run, worker thread, piped stdin):
    the model is recorded WAITING_FOR_MANUAL_INPUT with those instructions in
    the message, and the batch carries on.

Extraction and mapping reports are produced either way, so the mapping can be
reviewed while an erwin step is still pending. When .ERWIN V2 exists, the next
step is recorded: export it as XML V3 into final_xml_models/<tier>/ for run_v3.py.

Usage:
    python -m app.run_udp [--isolate] [--user NAME] [--session-id ID]
"""

import logging
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.common.config_helpers import get_setting
from app.config.settings import LOG_LEVEL
from app.orchestration import concurrency, stage_state
from app.orchestration.directory_setup import MODEL_TYPE_BY_SUFFIX, find_models, setup_directories
from app.orchestration.model_record import ModelRecord
from app.orchestration.run_context import start_run
from app.orchestration.stage_paths import StagePaths
from app.workflows.conceptual_workflow import run_step2

logging.basicConfig(
    level=getattr(logging, str(LOG_LEVEL).upper(), logging.WARNING),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


def process_model(model_path, base_name, model_type, dirs):
    stages = StagePaths(dirs, model_type)
    record = ModelRecord(base_name=base_name, model_type=model_type)
    xml_v2 = stages.find_xml_v2(base_name)
    if xml_v2 is not None:
        record.artefacts["xml_v2"] = str(xml_v2)
    elif stage_state.stage_status(dirs, base_name, stage_state.STAGE_XML_V2) != stage_state.STATUS_READY:
        print(f"  -> note: Step 1 output {stages.xml_v2(base_name)} not found; run run_v1.py first "
              f"(the UDP phase still runs on the handed-off .erwin if there is one).")

    outcome = run_step2(record, model_path, stages, dirs)
    if stages.find_erwin_v1(base_name) is None:
        concurrency.record_skipped_model(
            f"{base_name} ({model_type}): no .erwin handed off at {stages.describe('erwin_v1', base_name)}")
    for line in stage_state.pending_actions(dirs, base_name):
        print(f"  -> NEXT (manual): {line}")
    return record, outcome


def main(argv=None):
    print("\nStage 2/3 — UDP extraction / mapping / injection / comparison\n")
    concurrency.clear_skipped_models()

    run = start_run("python -m app.run_udp", "Stage 2/3 - UDP extraction / mapping / injection.", argv)
    dirs = setup_directories(run)
    models = find_models(dirs, mirror=True)
    if not models:
        print(f"No models found under {get_setting('SAMPLES_DIR', '')}.")
        return []

    print(f"Found {len(models)} model(s) to process.")
    results = []
    for index, model in enumerate(models, start=1):
        base_name = model.stem
        model_type = MODEL_TYPE_BY_SUFFIX.get(model.suffix.lower(), "LDM")
        print(f"\n{'=' * 60}\n--- [{index}/{len(models)}] {model_type}: {model.name} ---\n{'=' * 60}")
        try:
            results.append(process_model(model, base_name, model_type, dirs))
        except Exception as exc:                               # noqa: BLE001
            logger.exception("UDP stage failed for %s: %s", model.resolve(), exc)
            stage_state.record_stage(dirs, base_name, stage_state.STAGE_UDP, stage_state.STATUS_FAILED,
                                     model_type=model_type, message=f"{type(exc).__name__}: {exc}")

    skipped = concurrency.get_skipped_models()
    if skipped:
        print(f"\n{len(skipped)} model(s) waiting for the manual .erwin hand-off:")
        for reason in skipped:
            print(f"  - {reason}")

    print("\nStage 2/3 complete. NEXT: open .ERWIN V2 (erwinmodels/2_preprocessed/<model>.erwin — "
          "the .erwin, not the .xml beside it) in erwin, Save As XML into "
          "final_xml_models/<cdm|ldm|pdm>/<model>.xml, then run run_v3.py.\n")
    return results


if __name__ == "__main__":  # pragma: no cover
    main()
