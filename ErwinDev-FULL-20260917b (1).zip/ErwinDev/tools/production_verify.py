"""
Production verification sweep
=============================

Runs every model this checkout can actually measure and reports, for each one,
the facts a production sign-off depends on:

* the structural score, RECOMPUTED from the finding rows and checked against
  the one the comparator reported (AGREES / DISAGREES);
* the severity mix, separating rows that SCORE from rows that are visible but
  weighted at zero — so a score cannot improve by findings quietly disappearing;
* whether any component is NOT MEASURED, and whether anything turned a
  not-measured component into a zero;
* the attribute code preservation ledger: how many codes are encoded for
  transport, how many could not be identified deterministically, and why;
* which extended-property checks did not run because the erwin element name
  was absent (EXTERNAL_VERIFICATION_REQUIRED).

Coverage is stated honestly. The two real models are both LDM; CDM and PDM are
exercised against the synthetic fixtures in tests/fixtures_extended.py, which
are hand-written XML in PowerDesigner's and erwin's vocabularies, not exports
from the real tools. Every CDM and PDM line in the output is therefore labelled
TEST_DATA_GAP: the code path is verified, the erwin vocabulary is not.

    python -m tools.production_verify
    python -m tools.production_verify --json
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
import tempfile
from collections import Counter
from pathlib import Path
from typing import Any, Dict, List, Optional

REPO = Path(__file__).resolve().parents[1]
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))

from app.reporting import score_audit  # noqa: E402
from app.validation import code_ledger, fidelity_stages  # noqa: E402

RULE = "=" * 78

REAL_LDM = {
    "real_estate": (
        "sappdmodels/ldm/4d95b17a5883fbeb69fb9088bf1767c1_46007266_real_estate.ldm",
        "erwinmodels/2_preprocessed/4d95b17a5883fbeb69fb9088bf1767c1_46007266_real_estate.xml"),
    "modeling_and_simulation": (
        "sappdmodels/ldm/3eafce5dd91787f5f61afafbe5ffcf7d_46584675_modeling_and_simulation.ldm",
        "erwinmodels/2_preprocessed/3eafce5dd91787f5f61afafbe5ffcf7d_46584675_modeling_and_simulation.xml"),
}

SCORING = set(score_audit.SCORING_SEVERITIES)


def _say(text: str = "") -> None:
    print(text, flush=True)


# ═════════════════════════════════════════════════════════════════════════════
#  Reconciliation
# ═════════════════════════════════════════════════════════════════════════════

def _reconcile(tier: str, pd_path: str, erwin_path: str):
    if tier == "CDM":
        from app.validation.cdm_reconcile import compare, parse_cdm, parse_erwin
        return compare(parse_cdm(pd_path), parse_erwin(erwin_path))
    if tier == "LDM":
        from app.validation.ldm_reconcile.comparator import compare
        from app.validation.ldm_reconcile.erwin_ldm_parser import parse_erwin_ldm
        from app.validation.ldm_reconcile.pd_ldm_parser import parse_ldm
        return compare(parse_ldm(pd_path), parse_erwin_ldm(erwin_path))
    from app.validation.pdm_reconcile.pdm_validator_bridge import validate_pair
    return validate_pair(pd_path, erwin_path)


def _tier_config(tier: str):
    from app.common.config_helpers import tier_config
    return tier_config(tier)


def _ledger_for(tier: str, pd_path: str, name: str) -> Optional[code_ledger.CodeLedger]:
    if tier == "PDM":
        return None          # PDM columns carry Physical_Name natively
    try:
        if tier == "CDM":
            from app.validation.cdm_reconcile.pd_cdm_parser import parse_cdm as parse
        else:
            from app.validation.ldm_reconcile.pd_ldm_parser import parse_ldm as parse
        return code_ledger.build(parse(pd_path), model_name=name,
                                 model_type=tier, pd_path=pd_path)
    except Exception as exc:                                   # noqa: BLE001
        _say(f"    (code ledger unavailable: {exc})")
        return None


def check_model(tier: str, name: str, pd_path: str, erwin_path: str,
                evidence: str) -> Dict[str, Any]:
    row: Dict[str, Any] = {"tier": tier, "model": name, "evidence": evidence}
    result = _reconcile(tier, pd_path, erwin_path)
    config = _tier_config(tier)

    audit = score_audit.reconstruct(result, config)
    row.update(
        findings=audit["findings_total"],
        comparable=audit["comparable"],
        penalty=audit["penalty"],
        recomputed=audit["recomputed"],
        reported=audit["reported"],
        agrees=audit["agrees"],
        severities=audit["severities"],
    )

    scoring = {s: n for s, n in audit["severities"].items() if s in SCORING}
    row["scoring_rows"] = sum(scoring.values())
    row["visible_unscored_rows"] = audit["findings_total"] - row["scoring_rows"]

    stage = fidelity_stages.score(result, fidelity_stages.STAGE_V2, None, tier, config)
    row["stage_overall"] = stage.overall
    row["components"] = {k: v for k, v in stage.components.items()
                         if k in fidelity_stages.DEFAULT_WEIGHTS}
    row["not_measured"] = sorted(k for k, v in row["components"].items() if v is None)

    unverified = [f for f in getattr(result, "findings", []) or []
                  if getattr(f, "category", "") == "ERWIN_TAG_UNVERIFIED"]
    row["external_verification_required"] = len(unverified)

    ledger = _ledger_for(tier, pd_path, name)
    if ledger is not None:
        counts = Counter(record.status for record in ledger.records)
        row["ledger"] = {
            "attributes": ledger.attributes,
            "preserved": counts.get(code_ledger.STATUS_PRESERVED, 0),
            "nothing_to_carry": counts.get(code_ledger.STATUS_NOT_PRESERVED, 0),
            "ambiguous": counts.get(code_ledger.STATUS_AMBIGUOUS, 0),
        }
        schema, manifest = code_ledger.udp_rows(ledger)
        row["ledger"]["udp_entities"] = len(manifest)
        row["ledger"]["round_trip_ok"] = _round_trip_ok(ledger, manifest)
    return row


def _round_trip_ok(ledger: code_ledger.CodeLedger, manifest: List[dict]) -> bool:
    """Every encoded payload decodes back to exactly what went in."""
    for entry in manifest:
        expected = [r for r in ledger.preserved()
                    if r.pd_entity_name == entry["entity_name"]]
        decoded = code_ledger.decode(entry["value"])
        if len(decoded) != len(expected):
            return False
        by_name = {r.pd_attr_name: r for r in expected}
        for item in decoded:
            record = by_name.get(item["name"])
            if record is None or record.pd_attr_code != item["code"] \
                    or record.pd_attr_order != item["order"]:
                return False
    return True


# ═════════════════════════════════════════════════════════════════════════════
#  Fixtures
# ═════════════════════════════════════════════════════════════════════════════

def _fixture_models(scratch: Path) -> List[Dict[str, str]]:
    """The synthetic CDM/LDM/PDM pairs, written to disk so the parsers can read them."""
    try:
        from tests import fixtures_extended as fx
    except Exception as exc:                                   # noqa: BLE001
        _say(f"  (synthetic fixtures unavailable: {exc})")
        return []

    written = []
    plan = (
        # The CDM engine is exercised against the LDM fixture pair, which is
        # what tests/coverage_probe.py does: PowerDesigner's conceptual and
        # logical XML share a vocabulary, so the CDM parser reads it. That
        # verifies the CDM CODE PATH; it does not verify erwin's conceptual
        # export vocabulary, which no sample in this checkout contains.
        ("CDM", "fixture_cdm", fx.PD_LDM_FULL, fx.ERWIN_LDM_FULL, ".cdm"),
        ("LDM", "fixture_ldm", fx.PD_LDM_FULL, fx.ERWIN_LDM_FULL, ".ldm"),
        ("PDM", "fixture_pdm", fx.PD_PDM_FULL, fx.ERWIN_PDM_FULL, ".pdm"),
    )
    for tier, name, pd_xml, erwin_xml, suffix in plan:
        pd_path = scratch / f"{name}{suffix}"
        erwin_path = scratch / f"{name}_erwin.xml"
        pd_path.write_text(pd_xml, encoding="utf-8")
        erwin_path.write_text(erwin_xml, encoding="utf-8")
        written.append({"tier": tier, "name": name,
                        "pd": str(pd_path), "erwin": str(erwin_path)})
    return written


# ═════════════════════════════════════════════════════════════════════════════
#  Reporting
# ═════════════════════════════════════════════════════════════════════════════

def _print_row(row: Dict[str, Any]) -> None:
    verdict = {True: "AGREES", False: "DISAGREES", None: "n/a"}[row["agrees"]]
    _say(f"\n  {row['tier']}  {row['model']}   [{row['evidence']}]")
    _say(f"    structural   recomputed {row['recomputed']}  reported {row['reported']}"
         f"   -> {verdict}")
    _say(f"    arithmetic   penalty {row['penalty']} / comparable {row['comparable']}")
    _say(f"    findings     {row['findings']} total = {row['scoring_rows']} scoring "
         f"+ {row['visible_unscored_rows']} visible-but-unscored")
    _say(f"    severities   {dict(sorted(row['severities'].items()))}")
    components = ", ".join(
        f"{k}={'NOT MEASURED' if v is None else v}" for k, v in sorted(row["components"].items()))
    _say(f"    stage V2     {row['stage_overall']}  ({components})")
    if row["not_measured"]:
        _say(f"    not measured {', '.join(row['not_measured'])}  "
             f"-> dropped and weights renormalised, NOT scored as 0%")
    if row["external_verification_required"]:
        _say(f"    EXTERNAL_VERIFICATION_REQUIRED: {row['external_verification_required']} "
             f"check group(s) did not run (erwin element name absent)")
    ledger = row.get("ledger")
    if ledger:
        _say(f"    code ledger  {ledger['attributes']} attribute(s): "
             f"{ledger['preserved']} encoded for transport across "
             f"{ledger['udp_entities']} entity UDP(s), "
             f"{ledger['nothing_to_carry']} nothing to carry, "
             f"{ledger['ambiguous']} ambiguous"
             f"   round-trip {'OK' if ledger['round_trip_ok'] else 'FAILED'}")


def _verdict(rows: List[Dict[str, Any]]) -> int:
    _say(f"\n{RULE}\nVERDICT\n{RULE}")
    disagreements = [r for r in rows if r["agrees"] is False]
    zeroed = [r for r in rows
              if any(r["components"].get(k) == 0.0 for k in r["not_measured"])]
    broken_ledgers = [r for r in rows
                      if r.get("ledger") and not r["ledger"]["round_trip_ok"]]

    if disagreements:
        _say("  FAIL: a reported score is not what its own finding rows produce:")
        for row in disagreements:
            _say(f"    {row['tier']} {row['model']}: "
                 f"reported {row['reported']}, rows produce {row['recomputed']}")
    else:
        _say(f"  OK: every reported structural score ({len(rows)} model(s)) is "
             f"exactly what its finding rows produce.")

    if zeroed:
        _say("  FAIL: a NOT MEASURED component was scored as 0%.")
    else:
        _say("  OK: no NOT MEASURED component was scored as 0%.")

    if broken_ledgers:
        _say("  FAIL: a code ledger payload did not survive the round trip.")
    else:
        _say("  OK: every code ledger payload decodes back to what went in.")

    real = [r for r in rows if r["evidence"] == "REAL"]
    synthetic = [r for r in rows if r["evidence"] != "REAL"]
    _say(f"\n  Evidence: {len(real)} model(s) from REAL SAP PD + erwin exports "
         f"(all LDM); {len(synthetic)} from SYNTHETIC fixtures.")
    _say("  TEST_DATA_GAP: no real CDM or PDM model pair exists in this checkout, "
         "so every CDM and PDM result above verifies the code path only — not "
         "erwin's conceptual or physical export vocabulary.")
    return 1 if (disagreements or zeroed or broken_ledgers) else 0


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Production verification sweep.")
    parser.add_argument("--json", action="store_true", help="emit the rows as JSON")
    args = parser.parse_args(argv)
    logging.disable(logging.WARNING)

    _say(f"{RULE}\nProduction verification — real models and synthetic fixtures\n{RULE}")
    rows: List[Dict[str, Any]] = []

    _say("\nREAL MODELS (SAP PD source + erwin export)")
    for name, (pd_rel, erwin_rel) in sorted(REAL_LDM.items()):
        pd_path, erwin_path = REPO / pd_rel, REPO / erwin_rel
        if not (pd_path.is_file() and erwin_path.is_file()):
            _say(f"  {name}: MISSING — {pd_path if not pd_path.is_file() else erwin_path}")
            continue
        row = check_model("LDM", name, str(pd_path), str(erwin_path), "REAL")
        rows.append(row)
        _print_row(row)

    _say(f"\n{RULE}\nSYNTHETIC FIXTURES (TEST_DATA_GAP — code path only)\n{RULE}")
    with tempfile.TemporaryDirectory(prefix="prodverify_") as tmp:
        for spec in _fixture_models(Path(tmp)):
            try:
                row = check_model(spec["tier"], spec["name"], spec["pd"],
                                  spec["erwin"], "SYNTHETIC")
            except Exception as exc:                           # noqa: BLE001
                _say(f"\n  {spec['tier']}  {spec['name']}: FAILED TO RUN — {exc}")
                rows.append({"tier": spec["tier"], "model": spec["name"],
                             "evidence": "SYNTHETIC", "agrees": False,
                             "reported": None, "recomputed": None,
                             "components": {}, "not_measured": [],
                             "severities": {}, "findings": 0, "scoring_rows": 0,
                             "visible_unscored_rows": 0, "comparable": 0,
                             "penalty": 0, "external_verification_required": 0})
                continue
            rows.append(row)
            _print_row(row)

    code = _verdict(rows)
    if args.json:
        _say("\n" + json.dumps(rows, indent=2, default=str))
    return code


if __name__ == "__main__":
    sys.exit(main())
