"""
erwinDMAPI -MitiLoad probe — DIAGNOSTIC ONLY
============================================

Answers one question with evidence instead of assumption:

    Does erwin's own bulk migrator (erwinDMAPI.exe -MitiLoad) carry the SAP
    PowerDesigner Comments and Extended Attributes that the MANUAL erwin
    import drops?

Why it matters. On the two real LDM models this framework measures, V1 —
SAP PD against the erwin XML produced by the manual import — reports a
documentation component of 2.08 % and 0.00 %, and a UDP component of 0 %.
That is the manual import losing essentially all the business documentation,
and it is the entire reason Step 1 (Comments -> Notes) and Step 2 (Extended
Attributes -> UDPs) exist.

erwin's documented bulk migrator claims to map Extended Attributes and
Stereotypes to UDPs natively and to extract "data types and comments". If
that is true for real models, large parts of Steps 1 and 2 become
unnecessary. If it is not, they stay. Nobody should guess which — this
script produces the .erwin files so the framework can MEASURE it.

WHAT THIS SCRIPT DOES
---------------------
1. Finds erwinDMAPI.exe and checks it accepts -MitiLoad.
2. COPIES the SAP PD models into a scratch folder. It never runs the
   converter against sappdmodels/ directly: -MitiLoad writes its output and
   its _ERR1.txt logs NEXT TO the source files, and the source models are
   the one thing in this repository that cannot be regenerated.
3. Runs `erwinDMAPI.exe -MitiLoad <scratch> -<tier>` once per tier.
4. Reports the exit code, every .erwin produced, and the FULL contents of
   every _ERR1.txt — erwin's own list of what it skipped, remapped or
   flagged. That log is the migrator's own admission of loss and is worth
   reading line by line.

It writes nothing into sappdmodels/, erwinmodels/ or the reports tree, and
it changes no framework behaviour. Windows + an erwin DM installation are
required; on any other platform it says so and exits.

USAGE
-----
    python -m tools.mitiload_probe                     # all tiers found
    python -m tools.mitiload_probe --tier ldm
    python -m tools.mitiload_probe --erwin-dir "C:\\Program Files\\erwin\\Data Modeler r10"
    python -m tools.mitiload_probe --keep              # leave the scratch folder

WHAT TO DO WITH THE RESULT
--------------------------
The script prints the next steps. In short: open each produced .erwin in
erwin, save it as XML, drop that XML into erwinmodels/1_initial/ under the
model's existing file name, and run run_v1.py. Compare the documentation and
UDP components against the current V1 baseline. That comparison — not this
script — is the answer.
"""

from __future__ import annotations

import argparse
import os
import platform
import shutil
import subprocess  # nosec B404 - runs a named, operator-supplied erwin executable
import sys
import tempfile
from pathlib import Path
from typing import Dict, List, Optional, Tuple

REPO = Path(__file__).resolve().parents[1]
PD_ROOT = REPO / "sappdmodels"

TIERS = ("cdm", "ldm", "pdm")
SUFFIX = {"cdm": ".cdm", "ldm": ".ldm", "pdm": ".pdm"}

#: Documented default; the doc page shows r10 while the bookshelf is 15.0, so
#: several releases are tried and --erwin-dir overrides all of them.
DEFAULT_ERWIN_DIRS = (
    r"C:\Program Files\erwin\Data Modeler r10",
    r"C:\Program Files\erwin\Data Modeler r9",
    r"C:\Program Files (x86)\erwin\Data Modeler r10",
    r"C:\Program Files (x86)\erwin\Data Modeler r9",
    r"C:\Program Files\erwin\Data Modeler",
)
EXE_NAME = "erwinDMAPI.exe"

_RULE = "=" * 78


def _say(text: str = "") -> None:
    print(text, flush=True)


def find_erwin_api(explicit: str = "") -> Optional[Path]:
    """The erwinDMAPI.exe to use, or None."""
    candidates: List[Path] = []
    if explicit:
        given = Path(explicit)
        candidates.append(given if given.name.lower() == EXE_NAME.lower() else given / EXE_NAME)
    env = os.environ.get("ERWIN_DM_DIR", "")
    if env:
        candidates.append(Path(env) / EXE_NAME)
    candidates.extend(Path(folder) / EXE_NAME for folder in DEFAULT_ERWIN_DIRS)

    for candidate in candidates:
        try:
            if candidate.is_file():
                return candidate
        except OSError:
            continue
    return None


def models_for(tier: str) -> List[Path]:
    folder = PD_ROOT / tier
    if not folder.is_dir():
        return []
    return sorted(path for path in folder.iterdir()
                  if path.is_file() and path.suffix.lower() == SUFFIX[tier])


def _stage(tier: str, models: List[Path], scratch: Path) -> Path:
    """
    Copy the tier's models into their own scratch folder.

    One folder per tier because -MitiLoad takes a folder and a single tier
    switch, and because the documented shortcut-resolution failure happens
    when cross-referenced models are NOT migrated together — so every model
    of a tier goes in one folder, deliberately.
    """
    target = scratch / tier
    target.mkdir(parents=True, exist_ok=True)
    for model in models:
        shutil.copy2(model, target / model.name)
    return target


def run_mitiload(exe: Path, folder: Path, tier: str, timeout: int) -> Tuple[int, str]:
    """Run the converter. Returns (exit code, combined output)."""
    command = [str(exe), "-MitiLoad", str(folder), f"-{tier}"]
    _say(f"  $ {' '.join(command)}")
    try:
        completed = subprocess.run(  # nosec B603 - fixed argv, no shell, operator-supplied exe
            command, capture_output=True, text=True, timeout=timeout,
            cwd=str(exe.parent), check=False)
    except subprocess.TimeoutExpired:
        return 124, f"timed out after {timeout}s"
    except OSError as exc:
        return 126, f"could not start {exe.name}: {exc}"
    output = ((completed.stdout or "") + (completed.stderr or "")).strip()
    return completed.returncode, output


def _report_outputs(folder: Path, before: Dict[str, float]) -> List[Path]:
    """Every .erwin in the folder that was not there before the run."""
    produced = []
    for path in sorted(folder.iterdir()):
        if path.suffix.lower() != ".erwin":
            continue
        if path.name in before:
            continue
        produced.append(path)
    return produced


def _dump_error_logs(folder: Path) -> int:
    """
    Print every _ERR1.txt in full. Returns how many were found.

    These are not incidental. erwin's own documentation says to review them
    for "objects that were skipped, remapped, or flagged during conversion",
    which makes them the migrator's own statement of what it did not carry.
    A clean exit code with a populated _ERR1.txt is NOT a clean migration.
    """
    logs = sorted(path for path in folder.iterdir()
                  if path.is_file() and path.name.upper().endswith("_ERR1.TXT"))
    if not logs:
        _say("  no _ERR1.txt conversion logs were written")
        return 0
    for log in logs:
        _say(f"\n  --- {log.name} " + "-" * max(0, 60 - len(log.name)))
        try:
            text = log.read_text(encoding="utf-8", errors="replace").strip()
        except OSError as exc:
            _say(f"    (could not read: {exc})")
            continue
        if not text:
            _say("    (empty — nothing was flagged for this model)")
            continue
        for line in text.splitlines():
            _say(f"    {line}")
    return len(logs)


def probe_tier(exe: Path, tier: str, scratch: Path, timeout: int) -> Dict[str, object]:
    models = models_for(tier)
    result: Dict[str, object] = {"tier": tier, "models": len(models), "ran": False}
    if not models:
        _say(f"\n{tier.upper()}: no {SUFFIX[tier]} models in {PD_ROOT / tier} — skipped")
        return result

    _say(f"\n{_RULE}\n{tier.upper()}: {len(models)} model(s)\n{_RULE}")
    folder = _stage(tier, models, scratch)
    _say(f"  staged into {folder}")
    before = {path.name: 0.0 for path in folder.iterdir()}

    code, output = run_mitiload(exe, folder, tier, timeout)
    result["ran"] = True
    result["exit_code"] = code
    _say(f"  exit code: {code}" + ("  (erwin documents 0 as success)" if code == 0 else ""))
    if output:
        _say("  output:")
        for line in output.splitlines()[:40]:
            _say(f"    {line}")

    produced = _report_outputs(folder, before)
    result["produced"] = [path.name for path in produced]
    _say(f"\n  .erwin files produced: {len(produced)}")
    for path in produced:
        _say(f"    {path.name}  ({path.stat().st_size:,} bytes)")
    if not produced:
        _say("    NONE — the converter did not write a model for this tier.")

    _say("\n  erwin's own conversion log(s):")
    result["logs"] = _dump_error_logs(folder)
    return result


def _next_steps(results: List[Dict[str, object]], scratch: Path) -> None:
    produced_any = any(entry.get("produced") for entry in results)
    _say(f"\n{_RULE}\nWHAT TO DO NEXT\n{_RULE}")
    if not produced_any:
        _say(
            "No .erwin model was produced, so there is nothing to measure yet.\n"
            "Check, in this order:\n"
            "  1. the exit codes and output above;\n"
            "  2. that this erwin build's erwinDMAPI.exe supports -MitiLoad\n"
            "     (it is documented for the SAP PowerDesigner migration feature;\n"
            "     older builds may not have it);\n"
            "  3. that you are running from an elevated prompt with write access\n"
            "     to the staging folder.")
        return
    _say(
        "The point of this probe is the MEASUREMENT, not the files. For each\n"
        "model produced above:\n"
        "\n"
        "  1. Open it in erwin Data Modeler and confirm it opens cleanly.\n"
        "  2. File > Save As > XML, using the model's EXISTING file name.\n"
        "  3. Put that XML in erwinmodels/1_initial/<model>.xml — keeping a copy\n"
        "     of the current one first, it is the manual-import baseline.\n"
        "  4. Run:  python -m app.run_v1\n"
        "\n"
        "Then compare the V1 line against the current baseline:\n"
        "\n"
        "    modeling_and_simulation   structural 75.89   documentation  2.08\n"
        "    real_estate               structural 82.94   documentation  0.00\n"
        "\n"
        "  * documentation rises sharply  -> -MitiLoad carries the PD Comments\n"
        "    that the manual import drops, and Step 1 can be reconsidered.\n"
        "  * the UDP component becomes measurable -> it carries Extended\n"
        "    Attributes as UDPs natively, and part of Step 2 can be too.\n"
        "  * neither moves -> -MitiLoad is a faster route to the SAME .erwin,\n"
        "    which is still worth having: it replaces the manual handoff that\n"
        "    stage_state currently records as WAITING_FOR_MANUAL_INPUT.\n"
        "\n"
        "Read the _ERR1.txt contents above either way. A zero exit code with a\n"
        "populated conversion log is not a clean migration, and those lines are\n"
        "the migrator naming what it dropped.")
    _say(f"\nStaging folder kept at: {scratch}")


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description="Probe erwinDMAPI.exe -MitiLoad against this repository's SAP PD models.")
    parser.add_argument("--tier", choices=TIERS, action="append", dest="tiers",
                        help="probe one tier (repeatable); default is every tier with models")
    parser.add_argument("--erwin-dir", default="",
                        help=r'erwin DM install folder, e.g. "C:\Program Files\erwin\Data Modeler r10"')
    parser.add_argument("--timeout", type=int, default=1800,
                        help="seconds to allow per tier (default 1800)")
    parser.add_argument("--keep", action="store_true",
                        help="keep the staging folder (default: keep it anyway, since the "
                             ".erwin files produced are the point)")
    args = parser.parse_args(argv)

    _say(f"{_RULE}\nerwinDMAPI -MitiLoad probe — diagnostic only, writes nothing into\n"
         f"sappdmodels/, erwinmodels/ or the reports tree.\n{_RULE}")

    if platform.system() != "Windows":
        _say(f"\nThis host is {platform.system()}, and erwinDMAPI.exe is a Windows\n"
             "executable that needs a local erwin Data Modeler installation.\n"
             "Run this on the machine where erwin is installed.")
        return 3

    exe = find_erwin_api(args.erwin_dir)
    if exe is None:
        _say("\nerwinDMAPI.exe not found. Looked in:")
        for folder in DEFAULT_ERWIN_DIRS:
            _say(f"    {folder}")
        _say('\nPass the install folder explicitly:\n'
             r'    python -m tools.mitiload_probe --erwin-dir "C:\Program Files\erwin\Data Modeler r10"')
        return 4
    _say(f"\nerwinDMAPI.exe: {exe}")

    if not PD_ROOT.is_dir():
        _say(f"\nNo SAP PD models: {PD_ROOT} does not exist.")
        return 5

    tiers = args.tiers or [tier for tier in TIERS if models_for(tier)]
    if not tiers:
        _say(f"\nNo .cdm / .ldm / .pdm models under {PD_ROOT}.")
        return 5

    scratch = Path(tempfile.mkdtemp(prefix="mitiload_probe_"))
    _say(f"staging folder: {scratch}")
    results = [probe_tier(exe, tier, scratch, args.timeout) for tier in tiers]
    _next_steps(results, scratch)

    failed = [entry for entry in results
              if entry.get("ran") and entry.get("exit_code") not in (0, None)]
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
