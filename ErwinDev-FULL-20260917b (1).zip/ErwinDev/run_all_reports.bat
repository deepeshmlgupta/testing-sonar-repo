@echo off
REM ==========================================================================
REM  run_all_reports.bat — run the full migration pipeline and every report.
REM
REM  Order matters:
REM    1. python -m app.main [flags]     pipeline: validation reports per model
REM                                      type + Pass_Fail_Summary.xlsx
REM    2. migration_audit.py             provenance audit LAST, so its ledger
REM                                      sees everything the others produced
REM
REM  Run it from the project root (the folder containing this file).
REM  Any arguments are passed to app.main, e.g.
REM    run_all_reports.bat --isolate --workers 2
REM    run_all_reports.bat --isolate --user alice --session-id sprint12
REM ==========================================================================
cd /d "%~dp0"

REM Activate virtual environment if present
if exist ".venv\Scripts\activate.bat" (
    call .venv\Scripts\activate.bat
)

echo.
echo [1/2] Pipeline (validation reports)...
python -m app.main %*
if errorlevel 1 echo    ^> pipeline reported failures - see output above.

echo.
echo [2/2] Provenance audit...
python -m app.reporting.migration_audit

echo.
echo ==========================================================================
echo  All reports generated:
echo    app\reporting\{ldm,cdm,pdm}_reports\[model]\[model]_v1_fidelity_report.xlsx
echo                                            [model]_v2_udp_mapping_report.xlsx
echo                                            [model]_v3_fidelity_report.xlsx
echo                                            [model]_migration.log
echo    batch_summary\summary_report\Pass_Fail_Summary.xlsx
echo    batch_summary\audit\pipeline_ledger.jsonl, migration_audit_report.xlsx
echo  (with --isolate everything lands under sessions\[user]_[session]\ instead)
echo ==========================================================================
pause
