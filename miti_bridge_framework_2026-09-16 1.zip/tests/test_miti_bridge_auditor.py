"""
Unit tests for MIT Bridge Auditor.

Tests preservation metrics calculation, verdict logic, and audit orchestration.
"""

import json
import tempfile
from dataclasses import asdict
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from app.validation.miti_bridge_auditor import (
    MitiAuditResult,
    audit_miti_import,
    file_hash,
)


class TestFileHash:
    """Test file hashing for lineage verification."""

    def test_hash_computation(self):
        """Compute SHA-256 hash of a test file."""
        with tempfile.NamedTemporaryFile(delete=False) as tmp:
            tmp.write(b"test content")
            tmp.flush()
            tmp_path = tmp.name

        try:
            hash_val = file_hash(tmp_path, algo="sha256")
            assert len(hash_val) == 64  # SHA-256 is 64 hex chars
            assert hash_val.isalnum()

            # Hash should be deterministic
            hash_val2 = file_hash(tmp_path, algo="sha256")
            assert hash_val == hash_val2
        finally:
            Path(tmp_path).unlink()

    def test_hash_missing_file(self):
        """Gracefully handle missing files."""
        hash_val = file_hash("/nonexistent/file.xml")
        assert hash_val == ""


class TestMitiAuditResult:
    """Test audit result dataclass and methods."""

    def test_audit_result_creation(self):
        """Create and populate audit result."""
        result = MitiAuditResult(
            model_name="airlines",
            model_type="LDM",
        )
        assert result.model_name == "airlines"
        assert result.model_type == "LDM"
        assert result.verdict == "UNKNOWN"
        assert result.issues == []
        assert result.warnings == []

    def test_summary_format(self):
        """Summary string includes all metrics."""
        result = MitiAuditResult(
            model_name="airlines",
            model_type="LDM",
        )
        result.comment_preservation_pct = 98.5
        result.udp_preservation_pct = 97.0
        result.entity_preservation_pct = 99.8
        result.relationship_preservation_pct = 99.5
        result.verdict = "PASS"

        summary = result.summary()
        assert "airlines" in summary
        assert "PASS" in summary
        assert "98" in summary  # comment pct

    def test_to_dict_serialization(self):
        """Convert audit result to dict for JSON."""
        result = MitiAuditResult(
            model_name="airlines",
            model_type="LDM",
        )
        result.comment_preservation_pct = 98.5
        result.verdict = "PASS"

        result_dict = result.to_dict()
        assert result_dict["model_name"] == "airlines"
        assert result_dict["comment_preservation"]["pct"] == 98.5
        assert result_dict["verdict"] == "PASS"

        # Should be JSON-serializable
        json_str = json.dumps(result_dict)
        assert "airlines" in json_str


class TestPreservationMetrics:
    """Test preservation percentage calculations."""

    def test_preservation_100_percent(self):
        """All objects preserved → 100%."""
        result = MitiAuditResult("test", "LDM")
        result.comment_count_pd = 10
        result.comment_count_erwin = 10

        from app.validation.miti_bridge_auditor import _compute_preservation_metrics
        _compute_preservation_metrics(result)

        assert result.comment_preservation_pct == 100.0

    def test_preservation_50_percent(self):
        """Half preserved → 50%."""
        result = MitiAuditResult("test", "LDM")
        result.entity_count_pd = 100
        result.entity_count_erwin = 50

        from app.validation.miti_bridge_auditor import _compute_preservation_metrics
        _compute_preservation_metrics(result)

        assert result.entity_preservation_pct == 50.0

    def test_preservation_zero_pd_objects(self):
        """Zero baseline → 0% (avoid division by zero)."""
        result = MitiAuditResult("test", "LDM")
        result.udp_count_pd = 0
        result.udp_count_erwin = 0

        from app.validation.miti_bridge_auditor import _compute_preservation_metrics
        _compute_preservation_metrics(result)

        # Should not raise; stays at default 0
        assert result.udp_preservation_pct == 0.0

    def test_preservation_fractional(self):
        """Fractional percentages calculated correctly."""
        result = MitiAuditResult("test", "LDM")
        result.relationship_count_pd = 3
        result.relationship_count_erwin = 2

        from app.validation.miti_bridge_auditor import _compute_preservation_metrics
        _compute_preservation_metrics(result)

        # 2/3 * 100 ≈ 66.67
        assert 66.0 <= result.relationship_preservation_pct <= 67.0


class TestVerdictLogic:
    """Test PASS/WARN/FAIL verdict determination."""

    def test_verdict_pass(self):
        """All metrics >= threshold → PASS."""
        result = MitiAuditResult("test", "LDM")
        result.comment_preservation_pct = 95.0
        result.udp_preservation_pct = 95.0
        result.entity_preservation_pct = 99.0
        result.relationship_preservation_pct = 99.0

        from app.validation.miti_bridge_auditor import _set_verdict
        _set_verdict(result)

        assert result.verdict == "PASS"

    def test_verdict_warn_below_threshold(self):
        """Below threshold without issues → WARN."""
        result = MitiAuditResult("test", "LDM")
        result.comment_preservation_pct = 90.0  # Below 95%
        result.udp_preservation_pct = 95.0
        result.entity_preservation_pct = 99.0
        result.relationship_preservation_pct = 99.0

        from app.validation.miti_bridge_auditor import _set_verdict
        _set_verdict(result)

        assert result.verdict == "WARN"

    def test_verdict_fail_with_issues(self):
        """Any issues → FAIL."""
        result = MitiAuditResult("test", "LDM")
        result.comment_preservation_pct = 98.0
        result.udp_preservation_pct = 98.0
        result.entity_preservation_pct = 98.0
        result.relationship_preservation_pct = 98.0
        result.issues.append("Missing relationship: order_items -> products")

        from app.validation.miti_bridge_auditor import _set_verdict
        _set_verdict(result)

        assert result.verdict == "FAIL"

    def test_verdict_warn_with_warnings(self):
        """Warnings (no issues) → WARN."""
        result = MitiAuditResult("test", "LDM")
        result.comment_preservation_pct = 95.0
        result.udp_preservation_pct = 95.0
        result.entity_preservation_pct = 99.0
        result.relationship_preservation_pct = 99.0
        result.warnings.append("UDP 'custom_field' type mismatch: text vs numeric")

        from app.validation.miti_bridge_auditor import _set_verdict
        _set_verdict(result)

        assert result.verdict == "WARN"


class TestAuditOrchestration:
    """Test end-to-end audit workflow."""

    @patch("app.validation.miti_bridge_auditor._audit_pd_source")
    @patch("app.validation.miti_bridge_auditor._audit_miti_output")
    def test_audit_full_flow(self, mock_audit_output, mock_audit_pd):
        """Full audit orchestration."""
        # Setup mocks
        def set_pd_counts(path, result, model_type):
            result.entity_count_pd = 100
            result.comment_count_pd = 50
            result.udp_count_pd = 20
            result.relationship_count_pd = 30

        def set_output_counts(path, result, model_type):
            result.entity_count_erwin = 100
            result.comment_count_erwin = 49
            result.udp_count_erwin = 19
            result.relationship_count_erwin = 30

        mock_audit_pd.side_effect = set_pd_counts
        mock_audit_output.side_effect = set_output_counts

        with tempfile.TemporaryDirectory() as tmpdir:
            # Create dummy files
            pd_file = Path(tmpdir) / "test.ldm"
            output_file = Path(tmpdir) / "test.xml"
            pd_file.touch()
            output_file.touch()

            result = audit_miti_import(
                str(pd_file),
                str(output_file),
                "test_model",
                "LDM",
            )

            assert result.model_name == "test_model"
            assert result.entity_count_pd == 100
            assert result.entity_count_erwin == 100
            # Comments lost 1/50 = 98%
            assert 97.0 <= result.comment_preservation_pct <= 98.0
            # Should be WARN (comments below 95%)
            assert result.verdict in ("WARN", "PASS")

    def test_audit_missing_files(self):
        """Gracefully handle missing source or output files."""
        result = audit_miti_import(
            "/nonexistent/source.ldm",
            "/nonexistent/output.xml",
            "test",
            "LDM",
        )
        assert result.verdict == "FAIL"
        assert any("hash" in str(issue).lower() for issue in result.issues)


class TestAuditIntegration:
    """Integration tests with reconciliation results."""

    def test_audit_with_reconciliation(self):
        """Integrate reconciliation findings into audit."""
        result = MitiAuditResult("test", "LDM")

        # Mock reconciliation result
        mock_rec = MagicMock()
        mock_rec.findings = [
            MagicMock(
                severity="CRITICAL",
                category="MISSING_RELATIONSHIP",
                message="relationship_xy not found",
            ),
            MagicMock(
                severity="WARNING",
                category="TYPE_MISMATCH",
                message="column_abc type differs",
            ),
        ]

        from app.validation.miti_bridge_auditor import _audit_reconciliation
        _audit_reconciliation(mock_rec, result)

        assert len(result.issues) == 1
        assert "MISSING_RELATIONSHIP" in result.issues[0]
        assert len(result.warnings) == 1
        assert "TYPE_MISMATCH" in result.warnings[0]

    def test_audit_reconciliation_no_findings(self):
        """Handle reconciliation result with no findings."""
        result = MitiAuditResult("test", "LDM")
        mock_rec = MagicMock()
        mock_rec.findings = None

        from app.validation.miti_bridge_auditor import _audit_reconciliation
        _audit_reconciliation(mock_rec, result)

        # Should not crash
        assert result.issues == []
        assert result.warnings == []


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
