# MIT Bridge Integration Framework

## Overview

This document describes the hybrid MIT Bridge integration that enables the erwin migration pipeline to work **with** MIT Bridge (when licensed) while preserving all existing reconciliation, validation, and verification functionality.

**Key Principle:** Nothing is lost. MIT Bridge becomes an optional upstream import layer, feeding its output into the existing validation pipeline that continues to verify, audit, and report on data fidelity.

---

## What is MIT Bridge?

MIT Bridge is erwin's built-in import tool for SAP PowerDesigner models. When available (new license), it can automatically import `.cdm`, `.ldm`, and `.pdm` files into erwin XML format.

**Without this integration:**
- Requires manual export from erwin into the stage folders
- Limited to the existing UDP injection and validation pipeline

**With this integration:**
- Automatic import when MIT Bridge is licensed
- Audit output against original source for preservation metrics
- Chain into existing pipeline for validation
- Generate comparison reports showing before/after fidelity

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│ SAP PowerDesigner Models (sappdmodels/{cdm,ldm,pdm})        │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼ (when MITI_BRIDGE_LICENSED=true)
          ┌──────────────────────────┐
          │   MIT Bridge Import      │
          │ (COM-based, Windows)     │
          └──────────────┬───────────┘
                         │
                         ▼
        ┌────────────────────────────────────────┐
        │ MIT Bridge Output (erwin XML)          │
        │ erwinmodels/1_initial/<model>.xml      │
        └────────────────┬───────────────────────┘
                         │
                         ▼
        ┌────────────────────────────────────────┐
        │ MIT Bridge Audit & Validation          │
        │ - File hashes (lineage)                │
        │ - Preservation metrics                 │
        │ (comments, UDPs, entities, etc)        │
        │ - Issues, warnings, verdict            │
        └────────────────┬───────────────────────┘
                         │
                         ▼
        ┌────────────────────────────────────────┐
        │ Existing Validation Pipeline           │
        │ - Comment injection (XML V2)           │
        │ - UDP extraction & injection           │
        │ - PDM preprocessing                    │
        │ - V1/V2/V3 reconciliation             │
        │ - Promotion gate                       │
        └────────────────┬───────────────────────┘
                         │
                         ▼
        ┌────────────────────────────────────────┐
        │ Reports & Audit Trail                  │
        │ - V1 initial fidelity                  │
        │ - V2 UDP mapping                       │
        │ - V3 final fidelity                    │
        │ - MIT Bridge comparison (new)          │
        │ - JSON audit report (new)              │
        └────────────────────────────────────────┘
```

---

## Configuration

### Environment Variables

Set these to enable and configure MIT Bridge integration:

```bash
# Enable MIT Bridge (requires valid license)
export MITI_BRIDGE_LICENSED=true

# Auto-invoke MIT Bridge for import (false = expect pre-imported XML)
export MITI_BRIDGE_AUTO_IMPORT=true

# Output format: "xml" (default) or "erwin"
export MITI_BRIDGE_OUTPUT_FORMAT=xml

# Timeout per model import (seconds)
export MITI_BRIDGE_TIMEOUT_SECONDS=300

# Write comparison reports (JSON + Excel)
export MITI_BRIDGE_AUDIT_REPORTS=true
```

### In Code

See `app/config/settings.py` for the corresponding settings:

```python
MITI_BRIDGE_LICENSED          # bool (default: False)
MITI_BRIDGE_AUTO_IMPORT       # bool (default: True)
MITI_BRIDGE_OUTPUT_FORMAT     # str (default: "xml")
MITI_BRIDGE_TIMEOUT_SECONDS   # int (default: 300)
MITI_BRIDGE_AUDIT_REPORTS     # bool (default: True)
```

---

## Core Modules

### 1. `app/validation/miti_bridge_auditor.py`

**Purpose:** Audit MIT Bridge import output against the original PD source.

**Key Components:**

- **`MitiAuditResult`** — Dataclass tracking:
  - File integrity (SHA-256 hashes for lineage)
  - Preservation metrics:
    - `comment_preservation_pct` — % of PD comments preserved in erwin
    - `udp_preservation_pct` — % of extended attributes preserved
    - `entity_preservation_pct` — % of entities/tables preserved
    - `relationship_preservation_pct` — % of relationships/FKs preserved
  - Findings: `issues` (CRITICAL), `warnings` (non-blocking)
  - Verdict: `PASS` | `WARN` | `FAIL`

- **`audit_miti_import()`** — Main orchestration:
  1. Compute file hashes for lineage traceability
  2. Parse PD source for baseline counts
  3. Parse MIT Bridge output and compare
  4. Integrate reconciliation results (if available)
  5. Compute preservation percentages
  6. Set verdict (thresholds: comments ≥95%, UDPs ≥95%, entities ≥99%, relationships ≥99%)

- **Helper Functions:**
  - `_audit_pd_source()` — Extract counts from original PD XML
  - `_audit_miti_output()` — Extract counts from MIT Bridge XML
  - `_audit_reconciliation()` — Integrate pipeline findings
  - `_compute_preservation_metrics()` — Calculate percentages
  - `_set_verdict()` — Determine PASS/WARN/FAIL

**Usage:**

```python
from app.validation.miti_bridge_auditor import audit_miti_import

result = audit_miti_import(
    pd_source_path="/path/to/model.ldm",
    miti_output_path="/path/to/model.xml",
    model_name="airlines",
    model_type="LDM",
    reconciliation_result=None  # optional
)

print(result.summary())  # [PASS] airlines: Comments 98% | UDPs 97% | ...
```

### 2. `app/orchestration/run_with_miti.py`

**Purpose:** Orchestrate full MIT Bridge migration workflow.

**Key Components:**

- **`MitiBridgeContext`** — Holds state for a migration run:
  - Configuration (licensed, auto_import, format, timeout)
  - List of audit results
  - Audit timestamp

- **`check_miti_availability()`** — Verify license and pywin32:
  ```python
  is_available, reason = check_miti_availability()
  if not is_available:
      logger.warning("MIT Bridge: %s", reason)
  ```

- **`invoke_miti_bridge()`** — Call erwin COM to import a model:
  ```python
  success, error = invoke_miti_bridge(
      pd_model_path="/path/to/model.ldm",
      output_path="/path/to/model.xml",
      model_type="LDM",
      timeout_seconds=300
  )
  ```
  *(Currently stubbed; awaits COM implementation)*

- **`run_miti_migration()`** — Batch orchestration:
  1. Check MIT Bridge availability
  2. Discover SAP PD models
  3. Invoke MIT Bridge for each (if auto_import=true)
  4. Audit each output
  5. Return populated MitiBridgeContext

- **`write_audit_report()`** — Write JSON audit report:
  ```python
  context = run_miti_migration(...)
  report_path = write_audit_report(context, output_dir="audit_reports")
  ```

### 3. `app/reporting/miti_comparison_report.py`

**Purpose:** Generate side-by-side comparison reports.

**Key Components:**

- **`MitiComparisonReport`** — Per-model comparison:
  ```python
  report = MitiComparisonReport("airlines", "LDM")
  report.set_audit_result(audit_result)
  excel_path = report.to_excel("airlines_comparison.xlsx")
  json_path = report.to_json("airlines_comparison.json")
  ```

- **`generate_miti_comparison_reports()`** — Batch reporter:
  ```python
  paths = generate_miti_comparison_reports(
      audit_results=[result1, result2, ...],
      output_dir="reports",
      report_formats=["excel", "json"]
  )
  ```

**Report Contents:**

- **Excel Workbook** (`MITI Audit` sheet):
  - Audit timestamp & verdict
  - File integrity (hashes, paths)
  - Preservation metrics (color-coded by percentage)
  - Issues & warnings

- **JSON Report**:
  - Complete audit result object
  - Reconciliation findings (if integrated)
  - Machine-readable for downstream systems

---

## Integration Points

### Entry Point: `app/main.py`

When `MITI_BRIDGE_LICENSED=true`, the pipeline can optionally invoke MIT Bridge:

```python
from app.orchestration.run_with_miti import run_miti_migration

# Before normal pipeline starts
if get_setting("MITI_BRIDGE_LICENSED"):
    context = run_miti_migration(
        pd_source_dir=str(dirs["ldm"]),  # or cdm/pdm
        output_dir=str(dirs["initial"]),
        miti_config={
            "licensed": True,
            "auto_import": get_setting("MITI_BRIDGE_AUTO_IMPORT"),
            "output_format": get_setting("MITI_BRIDGE_OUTPUT_FORMAT"),
            "timeout_seconds": get_setting("MITI_BRIDGE_TIMEOUT_SECONDS"),
        }
    )
    
    # Write audit report
    from app.reporting.miti_comparison_report import generate_miti_comparison_reports
    if get_setting("MITI_BRIDGE_AUDIT_REPORTS"):
        generate_miti_comparison_reports(
            context.audit_results,
            output_dir=str(dirs["summary"])
        )
```

### Existing Pipeline Unchanged

The rest of the pipeline processes MIT Bridge output exactly as it would any manually-exported erwin XML:

```
MIT Bridge Output (XML V1) → Comment Injection (XML V2) → UDP Enrichment → ... → Reports
```

All V1, V2, V3 reports continue as before. MIT Bridge audit results are **added alongside**, not replacing.

---

## Verdict Logic

MIT Bridge output is deemed:

- **PASS** if ALL metrics ≥ threshold:
  - Comments ≥ 95%
  - UDPs ≥ 95%
  - Entities ≥ 99%
  - Relationships ≥ 99%

- **WARN** if no critical issues but some metrics below threshold

- **FAIL** if any critical issues found (structural loss)

---

## Audit Trail & Lineage

Every audit includes:

1. **SHA-256 Hashes**
   - Source PD file hash
   - MIT Bridge output file hash
   - Establishes lineage: "This V1 came from that PD import"

2. **Preservation Metrics**
   - Baseline counts from PD (entities, comments, UDPs, relationships)
   - Actual counts in erwin output
   - Calculated preservation percentages

3. **Findings**
   - Issues (CRITICAL) — structural loss
   - Warnings (INFO/WARNING) — data gaps, conversion notes

4. **Verdict**
   - Machine-readable outcome for automation
   - Basis for promotion gate decisions

---

## Workflow Example

### Scenario: New License, Run with MIT Bridge

1. **Setup:**
   ```bash
   export MITI_BRIDGE_LICENSED=true
   export MITI_BRIDGE_AUTO_IMPORT=true
   ```

2. **Place SAP PD models:**
   ```
   sappdmodels/
     ldm/
       airlines.ldm
       hotels.ldm
   ```

3. **Run pipeline:**
   ```bash
   python -m app.main
   ```

4. **What happens:**
   - MIT Bridge auto-imports each `.ldm` → `erwinmodels/1_initial/<model>.xml`
   - Audit verifies each import against original source
   - JSON audit report written to `batch_summary/audit/miti_audit_report.json`
   - Comparison reports written to `batch_summary/miti_comparison/<model>.{xlsx,json}`
   - Pipeline continues with comment injection, UDP enrichment, etc.
   - Final V3 reports show both MIT Bridge audit + pipeline validation

5. **Outputs:**
   ```
   batch_summary/
     audit/
       miti_audit_report.json              # Batch audit summary
     miti_comparison/
       airlines_LDM_comparison.xlsx        # Per-model Excel report
       airlines_LDM_comparison.json        # Per-model JSON report
       hotels_LDM_comparison.xlsx
       hotels_LDM_comparison.json
   
   app/reporting/
     ldm_reports/
       airlines/
         airlines_V1_initial_fidelity.xlsx   # Standard pipeline reports
         airlines_V2_udp_mapping.xlsx
         airlines_V3_final_fidelity.xlsx
         airlines_audit.log
       hotels/
         ...
   ```

---

## Fallback: No License / Pre-Imported XML

If `MITI_BRIDGE_LICENSED=false` or erwin COM is unavailable:

1. Pipeline skips MIT Bridge
2. Looks for manually exported XML in `erwinmodels/1_initial/`
3. Proceeds normally through comment injection, UDP enrichment, etc.
4. No MIT Bridge audit reports generated

This ensures the pipeline always works, with or without MIT Bridge.

---

## Extensibility

### Adding More Audit Checks

Extend `app/validation/miti_bridge_auditor.py`:

```python
def _audit_custom_metric(pd_path: str, result: MitiAuditResult, model_type: str) -> None:
    """Check a custom migration concern."""
    # Parse, count, compare
    result.custom_preservation_pct = (actual_count / baseline_count * 100)
```

### Custom Comparison Reports

Extend `app/reporting/miti_comparison_report.py`:

```python
class MitiComparisonReport:
    def to_html(self, output_path: str) -> str:
        """Generate interactive HTML dashboard."""
        ...
```

### Integration with External Systems

The JSON audit reports can feed into:
- Data governance portals (Collibra, Alation)
- Marting publishing pipelines
- BI & analytics platforms
- Custom dashboards

---

## Testing

### Unit Tests

Test auditor against sample PD/erwin pairs:

```python
from app.validation.miti_bridge_auditor import audit_miti_import

def test_audit_pass_case():
    result = audit_miti_import(
        pd_source_path="test/data/sample_airlines.ldm",
        miti_output_path="test/data/sample_airlines_v1.xml",
        model_name="airlines",
        model_type="LDM"
    )
    assert result.verdict == "PASS"
    assert result.entity_preservation_pct >= 99
```

### Integration Tests

Test full pipeline with MIT Bridge:

```bash
export MITI_BRIDGE_LICENSED=false  # Use pre-imported XML
python -m app.main  # Should work identically to before
```

---

## FAQ

**Q: Will MIT Bridge replace the existing UDP pipeline?**
A: No. MIT Bridge becomes an optional upstream layer. All existing validation continues.

**Q: What if MIT Bridge import fails?**
A: The framework logs the error and allows manual fallback (operator places XML in 1_initial/).

**Q: How do I know if data was lost in the import?**
A: Check the MIT Bridge audit report:
   - Preservation metrics show %
   - Issues list structural losses
   - Verdict (PASS/WARN/FAIL) summarizes

**Q: Can I mix MIT Bridge imports with manual exports?**
A: Yes. The pipeline accepts either. Place pre-exported XML alongside MIT Bridge outputs.

**Q: Does this change the promotion gate logic?**
A: No. The gate still uses the V3 reconciliation score. MIT Bridge audit is informational.

---

## Support & Debugging

### Enable Debug Logging

```bash
export LOG_LEVEL=DEBUG
python -m app.main
```

### Audit Report Format

See `batch_summary/audit/miti_audit_report.json`:

```json
{
  "audit_timestamp": "2026-09-16T10:30:00",
  "miti_config": {
    "licensed": true,
    "auto_import": true,
    "output_format": "xml",
    "timeout_seconds": 300
  },
  "results": [
    {
      "model_name": "airlines",
      "model_type": "LDM",
      "verdict": "PASS",
      "comment_preservation_pct": 98.5,
      "udp_preservation_pct": 97.0,
      "entity_preservation_pct": 99.8,
      "relationship_preservation_pct": 99.5,
      "issues": [],
      "warnings": ["UDP: vendor_id not found in erwin"]
    }
  ],
  "summary": {
    "total_models": 2,
    "passed": 2,
    "warned": 0,
    "failed": 0
  }
}
```

---

## See Also

- `app/validation/miti_bridge_auditor.py` — Audit implementation
- `app/orchestration/run_with_miti.py` — Orchestration entry point
- `app/reporting/miti_comparison_report.py` — Report generation
- `app/config/settings.py` — Configuration reference
