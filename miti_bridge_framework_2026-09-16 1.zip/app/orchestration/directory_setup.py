"""
Directory Setup & Model Discovery
===================================
Extracted from app/main.py — creates the run's directory tree (auto-creating
anything missing, never recreating what already exists) and discovers every
SAP PD model to process.
"""

import logging
import os
import shutil
import stat
from pathlib import Path

from app.common.config_helpers import get_setting
from app.config import settings
from app.orchestration import stage_paths
from app.reporting import report_layout

logger = logging.getLogger(__name__)

# Interim reconciliation workbooks are written here and removed once the V3
# report has been assembled, so a model's folder holds exactly V1, V2 and V3.
SCRATCH_REPORT_DIR = Path(os.path.join(settings.BASE_DIR, "data", "interim_reports"))

MODEL_TYPE_BY_SUFFIX = {".cdm": "CDM", ".ldm": "LDM", ".pdm": "PDM"}

# Every SAP PD model dropped into sappdmodels/{cdm,ldm,pdm} is mirrored here,
# under the same tier folder, so the UDP tool has its own copy of the source
# model next to the .erwin binaries it works on:
#
#     sappdmodels/ldm/airlines.ldm  ->  app/udp_tool/input_erwin_models/ldm/airlines.ldm
#
# The .erwin binaries the STANDALONE tool scans live directly in
# input_erwin_models/ (a non-recursive *.erwin glob), so the tier sub-folders
# never collide with them. The PIPELINE additionally accepts a handed-off
# .erwin inside the tier sub-folder, because that is where an operator who is
# looking at the mirrored sources naturally saves it (stage_paths._alternates).
UDP_INPUT_MODELS_DIR = Path(os.path.join(settings.BASE_DIR, "app", "udp_tool", "input_erwin_models"))

# Where the standalone tool (app/udp_tool/batch_run.py) writes its enriched
# binaries. The pipeline writes to erwinmodels/2_preprocessed instead, but it
# READS this folder back (UDP_TOOL_ERWIN_READBACK_DIRS), so it is created up
# front rather than left as a configured path that does not exist.
UDP_OUTPUT_MODELS_DIR = Path(os.path.join(settings.BASE_DIR, "app", "udp_tool", "output_erwin_models"))

# Where the STANDALONE tool (app/udp_tool/batch_run.py) looks for the SAP PD
# source that pairs with each .erwin it finds. The pipeline does not use it —
# it reads sappdmodels/ directly — but batch_run.py stops with
# "Please paste the original SAP model into input_sap_models" when it is
# missing, and a folder an operator is told to paste into has to EXIST. It was
# the one udp_tool input folder nothing created.
UDP_INPUT_SAP_DIR = Path(os.path.join(settings.BASE_DIR, "app", "udp_tool", "input_sap_models"))


def _ensure_writable(folder_path):
    """
    Remove read-only attribute from folder on Windows, or set write permissions
    on Unix/Linux. This ensures the pipeline can write to input/output folders.

    On Windows: removes FILE_ATTRIBUTE_READONLY.
    On Unix: adds user write permission if missing.

    Never raises; logs warnings if permission changes fail (folder may still be
    readable/usable).
    """
    try:
        folder_path = Path(folder_path)
        if not folder_path.exists():
            return

        # Windows: remove read-only attribute
        if os.name == "nt":
            try:
                current_mode = os.stat(folder_path).st_mode
                # Remove read-only flag and ensure write permission
                os.chmod(folder_path, current_mode | stat.S_IWUSR | stat.S_IWGRP)
                logger.debug("Removed read-only attribute from %s", folder_path)
            except (OSError, PermissionError) as e:
                logger.warning("Could not change folder permissions on %s: %s", folder_path, e)
        else:
            # Unix/Linux: ensure user has write permission
            try:
                current_mode = os.stat(folder_path).st_mode
                os.chmod(folder_path, current_mode | stat.S_IWUSR)
                logger.debug("Ensured write permission for %s", folder_path)
            except (OSError, PermissionError) as e:
                logger.warning("Could not change folder permissions on %s: %s", folder_path, e)
    except Exception as e:  # noqa: BLE001
        logger.debug("Unexpected error ensuring writable on %s: %s", folder_path, e)


def _roots_for(context):
    """
    Output roots for this run.

    ``context`` may be a ``run_context.RunContext`` (carries ``roots``), a legacy
    ``session_manager.SessionContext`` (honoured when ENABLE_SESSION_ISOLATION
    is on), or None (the shared layout).
    """
    from app.orchestration import run_context as rc

    roots = getattr(context, "roots", None)
    session_context = getattr(context, "session_context", None)
    if isinstance(roots, dict):
        return dict(roots), session_context
    if context is not None and hasattr(context, "session_output_dir") \
            and get_setting("ENABLE_SESSION_ISOLATION", False):
        roots = rc.session_roots(Path(context.session_output_dir))
        return roots, context
    return rc.default_roots(), None


def setup_directories(context=None):
    """
    Create and return the directories the run needs. Auto-creates any missing
    OUTPUT directory; never creates the operator's input folders' contents.

    ``context`` is the ``RunContext`` from ``run_context.start_run`` (or a legacy
    ``SessionContext``). With session isolation on, every output root —
    erwinmodels stages, reports, batch summary + ledger, UDP work dirs and
    workbooks, scratch — lands under ``sessions/<user>_<id>/``; inputs
    (sappdmodels, the shared erwinmodels/1_initial exports, the handed-off
    .erwin files and the XML V3 exports) stay shared.
    """
    roots, session_context = _roots_for(context)

    samples = Path(str(get_setting("SAMPLES_DIR", os.path.join(settings.BASE_DIR, "sappdmodels"))))
    final_xml_dir = Path(str(get_setting("FINAL_XML_DIR", os.path.join(settings.BASE_DIR, "final_xml_models"))))
    shared_erwin_out = Path(str(get_setting("OUTPUT_DIR", os.path.join(settings.BASE_DIR, "erwinmodels"))))
    erwin_out = Path(roots.get("erwin_out", shared_erwin_out))
    summary_dir = Path(roots.get("summary", os.path.join(settings.BASE_DIR, "batch_summary")))
    reports_root = Path(roots.get("reports_root", os.path.join(settings.BASE_DIR, "app", "reporting")))
    scratch = Path(roots.get("scratch", SCRATCH_REPORT_DIR))
    udp_work = Path(roots.get("udp_work", os.path.join(settings.BASE_DIR, "data", "udp")))
    udp_reports = Path(roots.get("udp_reports", os.path.join(settings.BASE_DIR, "app", "udp_tool", "output_excel_reports")))
    manual_review_root = Path(roots.get("manual_review", os.path.join(settings.BASE_DIR, "manual_review_reports")))

    # Standard allowed folders (shared)
    logs_dir = Path(os.path.join(settings.BASE_DIR, "logs"))
    reports_dir = Path(os.path.join(settings.BASE_DIR, "reports"))
    outputs_dir = Path(os.path.join(settings.BASE_DIR, "outputs"))
    temp_dir = Path(os.path.join(settings.BASE_DIR, "temp"))

    # The report layer resolves every workbook path from REPORTING_ROOT.
    report_layout.REPORTING_ROOT = reports_root

    dirs = {
        "ldm": samples / "ldm",
        "cdm": samples / "cdm",
        "pdm": samples / "pdm",
        "initial": erwin_out / stage_paths.INITIAL_DIRNAME,
        "preprocessed": erwin_out / stage_paths.PREPROCESSED_DIRNAME,
        "final": erwin_out / stage_paths.FINAL_DIRNAME,
        "final_xml": final_xml_dir,
        "udp_input": UDP_INPUT_MODELS_DIR,
        "udp_input_sap": UDP_INPUT_SAP_DIR,
        "udp_output": UDP_OUTPUT_MODELS_DIR,
        "summary": summary_dir,
        "reports_root": reports_root,
        "scratch": scratch,
        "udp_work": udp_work,
        "udp_reports": udp_reports,
        "manual_review": manual_review_root,
        "logs": logs_dir,
        "reports": reports_dir,
        "outputs": outputs_dir,
        "temp": temp_dir,
        "session_context": session_context,
    }
    dirs["stages"] = stage_paths.stage_folders(erwin_out, final_xml_dir, UDP_INPUT_MODELS_DIR)
    if erwin_out != shared_erwin_out:
        # Isolated run: the operator's inputs are still looked up in the shared tree.
        dirs["shared_initial"] = shared_erwin_out / stage_paths.INITIAL_DIRNAME
        dirs["shared_preprocessed"] = shared_erwin_out / stage_paths.PREPROCESSED_DIRNAME
        dirs["shared_stages"] = stage_paths.stage_folders(shared_erwin_out, final_xml_dir, UDP_INPUT_MODELS_DIR)
        logger.info("Session isolation: outputs under %s", roots.get("session", erwin_out.parent))

    # Ensure all required directories exist (only created if missing)
    for path in (dirs["ldm"], dirs["cdm"], dirs["pdm"],
                 dirs["logs"], dirs["reports"], dirs["outputs"], dirs["temp"],
                 dirs["summary"] / "summary_report", dirs["summary"] / "audit",
                 dirs["final_xml"], dirs["udp_input"], dirs["udp_input_sap"],
                 dirs["udp_output"], dirs["udp_reports"], scratch, udp_work, manual_review_root):
        os.makedirs(path, exist_ok=True)

    # The TIER sub-folders of input_erwin_models. They were created only as a
    # side effect of mirror_models_to_udp_input, so with mirroring off — or
    # before the first run — the operator was told to drop the handed-off
    # .erwin into app/udp_tool/input_erwin_models/<tier>/ and found no such
    # folder. stage_paths._alternates looks there, so it has to exist whether
    # or not anything was mirrored into it.
    for tier_name in ("cdm", "ldm", "pdm"):
        os.makedirs(dirs["udp_input"] / tier_name, exist_ok=True)

    # Ensure input_erwin_models is writable (fix Windows read-only attribute)
    _ensure_writable(dirs["udp_input"])

    # The TIER sub-folders of input_sap_models. The UDP tool needs the source
    # SAP PD models organized by tier (cdm/ldm/pdm) alongside the erwin binaries
    # it enriches.
    for tier_name in ("cdm", "ldm", "pdm"):
        os.makedirs(dirs["udp_input_sap"] / tier_name, exist_ok=True)

    # Ensure input_sap_models is writable (fix Windows read-only attribute)
    _ensure_writable(dirs["udp_input_sap"])

    # The three erwin stages are FLAT folders: erwinmodels/1_initial,
    # 2_preprocessed and 3_final each hold <model>.xml (and <model>.erwin)
    # directly — no xml/erwin/json/reports sub-folders.  Empty sub-folders
    # left behind by the older layout are removed so the tree stays exactly
    # three folders; a sub-folder that still holds files is left alone and
    # reported, because those files are the operator's.
    for key in ("initial", "preprocessed", "final"):
        os.makedirs(dirs[key], exist_ok=True)
        _tidy_legacy_stage_subfolders(dirs[key])

    for tier_name in ("cdm", "ldm", "pdm"):
        os.makedirs(dirs["final_xml"] / tier_name, exist_ok=True)
        os.makedirs(udp_reports / tier_name, exist_ok=True)
    for tier_name in report_layout.TIER_FOLDERS:
        os.makedirs(report_layout.tier_dir(tier_name), exist_ok=True)

    return dirs


LEGACY_STAGE_SUBFOLDERS = ("xml", "erwin", "json", "reports")


def _tidy_legacy_stage_subfolders(stage_dir) -> None:
    """
    Remove the empty ``xml/ erwin/ json/ reports/`` sub-folders the pre-flat
    layout created under a stage folder.  A sub-folder that still contains
    files is never touched: it is logged with the hint to move the files up
    one level (the pipeline still finds them there through the legacy lookup).
    """
    stage_dir = Path(stage_dir)
    for name in LEGACY_STAGE_SUBFOLDERS:
        sub = stage_dir / name
        if not sub.is_dir():
            continue
        try:
            entries = [p for p in sub.iterdir() if p.name != ".gitkeep"]
            if entries:
                logger.warning("%s still holds %d file(s) from the old layout; move them "
                               "into %s (the stage folders are flat now).",
                               sub, len(entries), stage_dir)
                continue
            for keep in sub.glob(".gitkeep"):
                keep.unlink()
            sub.rmdir()
            logger.info("Removed empty legacy sub-folder %s", sub)
        except OSError as exc:                                 # noqa: BLE001
            logger.debug("Could not tidy %s: %s", sub, exc)


def stage_file(dirs, stage: str, base_name: str, ext: str) -> Path:
    """
    ``erwinmodels/<stage>/<base_name><ext>`` — the ONE place the stage layout
    is defined.  ``stage`` is "initial" | "preprocessed" | "final"; ``ext`` is
    ".xml" or ".erwin".  The stage folders are flat.
    """
    if not ext.startswith("."):
        ext = "." + ext
    return Path(dirs[stage]) / f"{base_name}{ext}"


def find_models(dirs, mirror: bool = False):
    """
    Every SAP PD model to process, in a stable order (LDM, CDM, PDM; sorted
    within a tier). ``mirror=True`` also refreshes the UDP tool's copy of each
    model (see mirror_models_to_udp_input) when MIRROR_MODELS_TO_UDP_INPUT is on.
    """
    models = []
    for suffix, key in ((".ldm", "ldm"), (".cdm", "cdm"), (".pdm", "pdm")):
        models.extend(sorted(Path(dirs[key]).glob(f"*{suffix}")))
    limit = int(get_setting("MAX_MODELS_PER_RUN", 0) or 0)
    models = models[:limit] if limit > 0 else models
    if mirror and get_setting("MIRROR_MODELS_TO_UDP_INPUT", True):
        mirror_models_to_udp_input(models)
    return models


def _copy_is_current(source: Path, target: Path) -> bool:
    """True when `target` exists and is at least as new (and as large) as `source`."""
    try:
        src, dst = source.stat(), target.stat()
    except OSError:
        return False
    return dst.st_mtime >= src.st_mtime and dst.st_size == src.st_size


def mirror_models_to_udp_input(models, target_root=None):
    """
    Copy every discovered SAP PD model into
    ``app/udp_tool/input_erwin_models/<cdm|ldm|pdm>/<name>.<ext>``.

    The tier folder is taken from the file's own extension (.cdm/.ldm/.pdm),
    so a model is categorised correctly wherever it was discovered. A copy is
    (re)written only when it is missing or older than its source, so a batch
    re-run costs one stat() per model. Never raises: a copy that cannot be made
    is logged and the pipeline carries on, because this mirror is a convenience
    for the UDP tool, not an input the validation depends on.

    Returns the list of copies written or refreshed in this call.
    """
    root = Path(target_root) if target_root is not None else UDP_INPUT_MODELS_DIR
    written = []
    for model in models or ():
        source = Path(model)
        tier = MODEL_TYPE_BY_SUFFIX.get(source.suffix.lower())
        if tier is None:
            logger.debug("Not a SAP PD model, not mirrored: %s", source)
            continue
        target = root / tier.lower() / source.name
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            if _copy_is_current(source, target):
                continue
            shutil.copy2(str(source), str(target))     # keeps the source mtime
            written.append(target)
            logger.info("Mirrored %s -> %s", source.name, target)
        except OSError as exc:
            logger.warning("Could not mirror %s to %s: %s", source, target, exc)
    return written

