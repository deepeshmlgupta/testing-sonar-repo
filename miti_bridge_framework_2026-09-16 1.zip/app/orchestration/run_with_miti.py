"""
MIT Bridge Integration Entry Point
====================================
Orchestrates erwin migration when MIT Bridge is available and licensed.

Flow:
  1. Execute MIT Bridge import (SAP PD → erwin XML)
  2. Validate import fidelity against original PD source
  3. Feed output into existing validation/reconciliation pipeline
  4. Generate comparison reports (V1 initial, V2 UDP mapping, V3 final + MIT Bridge audit)
  5. Record audit trail with preservation metrics and verdict

This preserves all existing functionality while adding MIT Bridge as an upstream
import layer, so nothing is lost in the migration.
"""

from __future__ import annotations

import json
import logging
import os
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from app.common.config_helpers import get_setting
from app.orchestration import directory_setup
from app.validation.miti_bridge_auditor import (
    MitiAuditResult,
    audit_miti_import,
)

logger = logging.getLogger(__name__)


class MitiBridgeContext:
    """Context for a MIT Bridge migration run."""

    def __init__(self, pd_source_dir: str, miti_config: Optional[Dict] = None):
        """
        Initialize MIT Bridge context.

        Args:
            pd_source_dir: Path to directory containing SAP PD models (.cdm/.ldm/.pdm)
            miti_config: Optional dict with keys:
                - licensed: bool (True if MIT Bridge is available)
                - auto_import: bool (True to invoke MIT Bridge; False to use pre-imported)
                - output_format: "xml" or "erwin" (default: "xml")
                - timeout_seconds: int (default: 300)
        """
        self.pd_source_dir = Path(pd_source_dir)
        self.miti_config = miti_config or {}
        self.licensed = self.miti_config.get("licensed", False)
        self.auto_import = self.miti_config.get("auto_import", False)
        self.output_format = self.miti_config.get("output_format", "xml")
        self.timeout_seconds = self.miti_config.get("timeout_seconds", 300)

        # Audit results tracking
        self.audit_results: List[MitiAuditResult] = []
        self.audit_timestamp = datetime.utcnow().isoformat()

    def summary(self) -> str:
        """Summary of MIT Bridge context."""
        return (
            f"MitiBridgeContext(licensed={self.licensed}, "
            f"auto_import={self.auto_import}, "
            f"results={len(self.audit_results)})"
        )


def check_miti_availability() -> Tuple[bool, str]:
    """
    Check if MIT Bridge is available and licensed.

    Returns:
        (is_available, reason_if_not)
    """
    miti_licensed = get_setting("MITI_BRIDGE_LICENSED", False)
    if not miti_licensed:
        return False, "MIT Bridge license not enabled (MITI_BRIDGE_LICENSED=False)"

    try:
        import win32com.client  # noqa: F401
    except ImportError:
        return False, "pywin32 not installed (required for MIT Bridge COM access)"

    return True, ""


def invoke_miti_bridge(
    pd_model_path: str,
    output_path: str,
    model_type: str,
    timeout_seconds: int = 300,
) -> Tuple[bool, str]:
    """
    Invoke MIT Bridge to import a SAP PD model into erwin.

    This is a placeholder that shows the integration point. In production, this
    would call erwin's COM interface to execute MIT Bridge.

    Args:
        pd_model_path: Path to SAP PD model (.cdm/.ldm/.pdm)
        output_path: Where to write erwin output (.xml or .erwin)
        model_type: "CDM", "LDM", or "PDM"
        timeout_seconds: Timeout for import operation

    Returns:
        (success, error_message)
    """
    logger.info(
        "MIT Bridge import: %s (%s) → %s",
        Path(pd_model_path).name,
        model_type,
        output_path,
    )

    # TODO: Implement COM-based MIT Bridge invocation
    # For now, this is stubbed with logging for framework verification
    try:
        if not os.path.exists(pd_model_path):
            return False, f"PD source not found: {pd_model_path}"

        logger.info("MIT Bridge import staged (stub): awaiting COM implementation")
        return True, ""

    except Exception as e:  # noqa: BLE001
        return False, f"MIT Bridge invocation failed: {type(e).__name__}: {e}"


def run_miti_migration(
    pd_source_dir: str,
    output_dir: str,
    miti_config: Optional[Dict] = None,
    reconciliation_pipeline=None,
) -> MitiBridgeContext:
    """
    Execute full MIT Bridge migration with validation.

    Args:
        pd_source_dir: Path to SAP PD models
        output_dir: Where to write outputs (erwin XML, reports, audits)
        miti_config: MIT Bridge configuration (see MitiBridgeContext)
        reconciliation_pipeline: Optional existing validation pipeline to chain into

    Returns:
        MitiBridgeContext with audit results
    """
    context = MitiBridgeContext(pd_source_dir, miti_config)

    # Check license
    is_available, reason = check_miti_availability()
    if not is_available:
        logger.warning("MIT Bridge not available: %s", reason)
        if not context.auto_import:
            logger.info("Proceeding with pre-imported erwin models")
            return context
        return context

    logger.info("MIT Bridge available and licensed; proceeding with auto-import")

    # Discover PD models
    pd_models = sorted(Path(pd_source_dir).glob("**/*.[cdlp]dm"))
    if not pd_models:
        logger.warning("No SAP PD models found in %s", pd_source_dir)
        return context

    os.makedirs(output_dir, exist_ok=True)

    # Process each model
    for pd_path in pd_models:
        model_type = directory_setup.MODEL_TYPE_BY_SUFFIX.get(pd_path.suffix.lower())
        if model_type is None:
            logger.debug("Not a SAP PD model: %s", pd_path)
            continue

        model_name = pd_path.stem
        output_path = Path(output_dir) / f"{model_name}.xml"

        # Invoke MIT Bridge
        if context.auto_import:
            success, error = invoke_miti_bridge(
                str(pd_path),
                str(output_path),
                model_type,
                context.timeout_seconds,
            )
            if not success:
                logger.error("MIT Bridge import failed for %s: %s", model_name, error)
                continue

        # Audit the import
        if output_path.exists():
            audit_result = audit_miti_import(
                str(pd_path),
                str(output_path),
                model_name,
                model_type,
                reconciliation_result=None,
            )
            context.audit_results.append(audit_result)
            logger.info("Audit: %s", audit_result.summary())
        else:
            logger.warning("MIT Bridge output not found: %s", output_path)

    return context


def write_audit_report(
    context: MitiBridgeContext, output_dir: str, filename: str = "miti_audit_report.json"
) -> str:
    """
    Write MIT Bridge audit results to JSON report.

    Args:
        context: MitiBridgeContext with completed audit_results
        output_dir: Directory for report output
        filename: Report filename

    Returns:
        Path to written report
    """
    os.makedirs(output_dir, exist_ok=True)
    report_path = Path(output_dir) / filename

    report = {
        "audit_timestamp": context.audit_timestamp,
        "miti_config": context.miti_config,
        "results": [asdict(r) for r in context.audit_results],
        "summary": {
            "total_models": len(context.audit_results),
            "passed": sum(1 for r in context.audit_results if r.verdict == "PASS"),
            "warned": sum(1 for r in context.audit_results if r.verdict == "WARN"),
            "failed": sum(1 for r in context.audit_results if r.verdict == "FAIL"),
        },
    }

    with open(report_path, "w") as f:
        json.dump(report, f, indent=2)

    logger.info("Audit report written: %s", report_path)
    return str(report_path)


__all__ = [
    "MitiBridgeContext",
    "check_miti_availability",
    "invoke_miti_bridge",
    "run_miti_migration",
    "write_audit_report",
]
