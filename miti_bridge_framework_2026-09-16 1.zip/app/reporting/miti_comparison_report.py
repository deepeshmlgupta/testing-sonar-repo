"""
MIT Bridge Comparison Reports
==============================
Generates side-by-side comparison reports showing what MIT Bridge preserved
vs. what the existing validation pipeline found. Integrates audit results
into V1/V2/V3 reports.

Reports show:
  - File integrity verification (SHA-256 hashes)
  - Preservation metrics (comments, UDPs, entities, relationships)
  - Audit findings (issues, warnings, verdict)
  - Fidelity score trending (V1 initial → V3 final)
"""

from __future__ import annotations

import json
import logging
from dataclasses import asdict
from pathlib import Path
from typing import Dict, List, Optional

try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    HAS_OPENPYXL = True
except ImportError:
    HAS_OPENPYXL = False

logger = logging.getLogger(__name__)


class MitiComparisonReport:
    """Generates comparison reports for MIT Bridge audit results."""

    def __init__(self, model_name: str, model_type: str):
        """Initialize comparison report."""
        self.model_name = model_name
        self.model_type = model_type
        self.audit_result = None
        self.reconciliation_result = None

    def set_audit_result(self, audit_result) -> None:
        """Set MIT Bridge audit result."""
        self.audit_result = audit_result

    def set_reconciliation_result(self, reconciliation_result) -> None:
        """Set reconciliation pipeline result."""
        self.reconciliation_result = reconciliation_result

    def _metric_row(
        self,
        ws,
        row: int,
        metric_name: str,
        pd_count: int,
        erwin_count: int,
        pct: float,
        status: str = "",
    ) -> int:
        """
        Write a metric row to worksheet.

        Returns: next row number
        """
        ws[f"A{row}"] = metric_name
        ws[f"B{row}"] = pd_count
        ws[f"C{row}"] = erwin_count
        ws[f"D{row}"] = f"{pct:.1f}%"

        # Color-code by preservation percentage
        if pct >= 99:
            fill = PatternFill(start_color="90EE90", end_color="90EE90", fill_type="solid")
        elif pct >= 95:
            fill = PatternFill(start_color="FFFFE0", end_color="FFFFE0", fill_type="solid")
        elif pct >= 80:
            fill = PatternFill(start_color="FFD700", end_color="FFD700", fill_type="solid")
        else:
            fill = PatternFill(start_color="FFB6C6", end_color="FFB6C6", fill_type="solid")

        for col in ["A", "B", "C", "D"]:
            ws[f"{col}{row}"].fill = fill

        return row + 1

    def to_excel(self, output_path: str) -> str:
        """
        Write comparison report to Excel workbook.

        Args:
            output_path: Where to write the .xlsx file

        Returns:
            Path to written file
        """
        if not HAS_OPENPYXL:
            logger.warning("openpyxl not available; Excel report skipped")
            return ""

        wb = Workbook()
        ws = wb.active
        ws.title = "MITI Audit"

        # Header
        ws["A1"] = "MIT Bridge Audit Report"
        ws["A1"].font = Font(bold=True, size=14)
        ws.merge_cells("A1:D1")

        ws["A2"] = f"Model: {self.model_name} ({self.model_type})"
        ws["A2"].font = Font(bold=True, size=11)
        ws.merge_cells("A2:D2")

        # Metadata
        row = 4
        ws[f"A{row}"] = "Audit Timestamp"
        ws[f"B{row}"] = getattr(self.audit_result, "audit_timestamp", "")
        row += 1

        ws[f"A{row}"] = "Verdict"
        verdict = getattr(self.audit_result, "verdict", "UNKNOWN")
        ws[f"B{row}"] = verdict
        if verdict == "PASS":
            ws[f"B{row}"].font = Font(bold=True, color="008000")
        elif verdict == "FAIL":
            ws[f"B{row}"].font = Font(bold=True, color="FF0000")
        else:
            ws[f"B{row}"].font = Font(bold=True, color="FF8800")
        row += 2

        # File integrity
        ws[f"A{row}"] = "File Integrity"
        ws[f"A{row}"].font = Font(bold=True)
        row += 1

        ws[f"A{row}"] = "PD Source"
        ws[f"B{row}"] = getattr(self.audit_result, "source_pd_path", "")
        row += 1

        ws[f"A{row}"] = "  Hash (SHA-256)"
        ws[f"B{row}"] = getattr(self.audit_result, "source_pd_hash", "")[:16] + "..."
        row += 1

        ws[f"A{row}"] = "MIT Bridge Output"
        ws[f"B{row}"] = getattr(self.audit_result, "miti_output_path", "")
        row += 1

        ws[f"A{row}"] = "  Hash (SHA-256)"
        ws[f"B{row}"] = getattr(self.audit_result, "miti_output_hash", "")[:16] + "..."
        row += 2

        # Preservation metrics
        ws[f"A{row}"] = "Preservation Metrics"
        ws[f"A{row}"].font = Font(bold=True)
        ws[f"B{row}"] = "PD Count"
        ws[f"C{row}"] = "Erwin Count"
        ws[f"D{row}"] = "Preservation %"
        for col in ["A", "B", "C", "D"]:
            ws[f"{col}{row}"].font = Font(bold=True)
        row += 1

        if self.audit_result:
            row = self._metric_row(
                ws,
                row,
                "Comments",
                self.audit_result.comment_count_pd,
                self.audit_result.comment_count_erwin,
                self.audit_result.comment_preservation_pct,
            )

            row = self._metric_row(
                ws,
                row,
                "Extended Attributes (UDPs)",
                self.audit_result.udp_count_pd,
                self.audit_result.udp_count_erwin,
                self.audit_result.udp_preservation_pct,
            )

            row = self._metric_row(
                ws,
                row,
                "Entities/Tables",
                self.audit_result.entity_count_pd,
                self.audit_result.entity_count_erwin,
                self.audit_result.entity_preservation_pct,
            )

            row = self._metric_row(
                ws,
                row,
                "Relationships/FKs",
                self.audit_result.relationship_count_pd,
                self.audit_result.relationship_count_erwin,
                self.audit_result.relationship_preservation_pct,
            )

        row += 1

        # Issues and warnings
        if self.audit_result and (self.audit_result.issues or self.audit_result.warnings):
            ws[f"A{row}"] = "Findings"
            ws[f"A{row}"].font = Font(bold=True)
            row += 1

            if self.audit_result.issues:
                ws[f"A{row}"] = "Issues"
                ws[f"A{row}"].font = Font(bold=True, color="FF0000")
                row += 1
                for issue in self.audit_result.issues:
                    ws[f"A{row}"] = issue
                    row += 1
                row += 1

            if self.audit_result.warnings:
                ws[f"A{row}"] = "Warnings"
                ws[f"A{row}"].font = Font(bold=True, color="FF8800")
                row += 1
                for warning in self.audit_result.warnings:
                    ws[f"A{row}"] = warning
                    row += 1

        # Adjust column widths
        ws.column_dimensions["A"].width = 30
        ws.column_dimensions["B"].width = 40
        ws.column_dimensions["C"].width = 15
        ws.column_dimensions["D"].width = 15

        # Save
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        wb.save(output_path)
        logger.info("Comparison report written: %s", output_path)
        return output_path

    def to_json(self, output_path: str) -> str:
        """
        Write comparison report to JSON.

        Args:
            output_path: Where to write the .json file

        Returns:
            Path to written file
        """
        report = {
            "model_name": self.model_name,
            "model_type": self.model_type,
            "audit_result": asdict(self.audit_result) if self.audit_result else None,
            "reconciliation_result": asdict(self.reconciliation_result)
            if self.reconciliation_result and hasattr(self.reconciliation_result, "__dataclass_fields__")
            else None,
        }

        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w") as f:
            json.dump(report, f, indent=2, default=str)

        logger.info("Comparison report (JSON) written: %s", output_path)
        return output_path


def generate_miti_comparison_reports(
    audit_results: List,
    output_dir: str,
    report_formats: Optional[List[str]] = None,
) -> Dict[str, str]:
    """
    Generate comparison reports for all audited models.

    Args:
        audit_results: List of MitiAuditResult objects
        output_dir: Directory for report output
        report_formats: List of formats ("excel", "json", or both)

    Returns:
        Dict mapping model_name -> report_path
    """
    if report_formats is None:
        report_formats = ["excel", "json"]

    Path(output_dir).mkdir(parents=True, exist_ok=True)
    report_paths = {}

    for audit_result in audit_results or []:
        report = MitiComparisonReport(audit_result.model_name, audit_result.model_type)
        report.set_audit_result(audit_result)

        model_key = f"{audit_result.model_name}_{audit_result.model_type}"

        if "excel" in report_formats:
            excel_path = report.to_excel(
                str(Path(output_dir) / f"{model_key}_comparison.xlsx")
            )
            if excel_path:
                report_paths[f"{model_key}_excel"] = excel_path

        if "json" in report_formats:
            json_path = report.to_json(
                str(Path(output_dir) / f"{model_key}_comparison.json")
            )
            if json_path:
                report_paths[f"{model_key}_json"] = json_path

    return report_paths


__all__ = [
    "MitiComparisonReport",
    "generate_miti_comparison_reports",
]
