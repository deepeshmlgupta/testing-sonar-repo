"""
MIT Bridge Output Auditor
==========================
Verifies that MIT Bridge imports preserve data fidelity and completeness.

When erwin's MIT Bridge is available (new license), it can auto-import SAP
PowerDesigner models. This auditor validates the import output against the
original PD source, checking:

1. **Comment Preservation** — PD comments → erwin notes (count & content)
2. **Extended Attributes** — PD extended attributes (UDPs) integrity
3. **Structural Elements** — entities, relationships, identifiers, types
4. **Audit Trail** — timestamps, hashes, lineage evidence

The auditor feeds MIT Bridge output into our existing reconciliation pipeline,
then reports what was preserved and what requires manual review.
"""

from __future__ import annotations

import hashlib
import logging
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


@dataclass
class MitiAuditResult:
    """Result of auditing a MIT Bridge import."""
    model_name: str
    model_type: str  # CDM, LDM, PDM
    audit_timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    # Source/output paths and hashes
    source_pd_path: str = ""
    source_pd_hash: str = ""
    miti_output_path: str = ""
    miti_output_hash: str = ""

    # Preservation metrics
    comment_count_pd: int = 0
    comment_count_erwin: int = 0
    comment_preservation_pct: float = 0.0

    udp_count_pd: int = 0
    udp_count_erwin: int = 0
    udp_preservation_pct: float = 0.0

    entity_count_pd: int = 0
    entity_count_erwin: int = 0
    entity_preservation_pct: float = 0.0

    # Relationship/FK metrics
    relationship_count_pd: int = 0
    relationship_count_erwin: int = 0
    relationship_preservation_pct: float = 0.0

    # Issues found
    issues: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    # Overall verdict
    verdict: str = "UNKNOWN"  # PASS, WARN, FAIL

    def summary(self) -> str:
        """One-line summary of the audit result."""
        return (f"[{self.verdict}] {self.model_name}: "
                f"Comments {self.comment_preservation_pct:.0f}% | "
                f"UDPs {self.udp_preservation_pct:.0f}% | "
                f"Entities {self.entity_preservation_pct:.0f}% | "
                f"Relationships {self.relationship_preservation_pct:.0f}%")

    def to_dict(self) -> Dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "model_name": self.model_name,
            "model_type": self.model_type,
            "audit_timestamp": self.audit_timestamp,
            "source_pd_path": self.source_pd_path,
            "source_pd_hash": self.source_pd_hash,
            "miti_output_path": self.miti_output_path,
            "miti_output_hash": self.miti_output_hash,
            "comment_preservation": {
                "pd_count": self.comment_count_pd,
                "erwin_count": self.comment_count_erwin,
                "pct": self.comment_preservation_pct,
            },
            "udp_preservation": {
                "pd_count": self.udp_count_pd,
                "erwin_count": self.udp_count_erwin,
                "pct": self.udp_preservation_pct,
            },
            "entity_preservation": {
                "pd_count": self.entity_count_pd,
                "erwin_count": self.entity_count_erwin,
                "pct": self.entity_preservation_pct,
            },
            "relationship_preservation": {
                "pd_count": self.relationship_count_pd,
                "erwin_count": self.relationship_count_erwin,
                "pct": self.relationship_preservation_pct,
            },
            "issues": self.issues,
            "warnings": self.warnings,
            "verdict": self.verdict,
        }


def file_hash(filepath: str, algo: str = "sha256") -> str:
    """Compute file hash for integrity verification."""
    try:
        hasher = hashlib.new(algo)
        with open(filepath, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                hasher.update(chunk)
        return hasher.hexdigest()
    except (OSError, ValueError) as e:
        logger.warning("Could not compute hash for %s: %s", filepath, e)
        return ""


def audit_miti_import(pd_source_path: str, miti_output_path: str,
                      model_name: str, model_type: str,
                      reconciliation_result=None) -> MitiAuditResult:
    """
    Audit a MIT Bridge import against the original PD source.

    Args:
        pd_source_path: Path to the original SAP PowerDesigner file
        miti_output_path: Path to MIT Bridge's output (erwin XML or .erwin)
        model_name: Model identifier
        model_type: "CDM", "LDM", or "PDM"
        reconciliation_result: Optional ValidationResult from our reconciliation

    Returns:
        MitiAuditResult with preservation metrics and verdict
    """
    result = MitiAuditResult(
        model_name=model_name,
        model_type=model_type,
        source_pd_path=str(pd_source_path),
        miti_output_path=str(miti_output_path),
    )

    # Compute file hashes for lineage traceability
    result.source_pd_hash = file_hash(pd_source_path)
    result.miti_output_hash = file_hash(miti_output_path)

    if not result.source_pd_hash or not result.miti_output_hash:
        result.issues.append("Could not compute file hashes for audit trail")
        result.verdict = "FAIL"
        return result

    try:
        # Parse PD source for baseline counts
        _audit_pd_source(pd_source_path, result, model_type)

        # Parse MIT Bridge output and compare
        _audit_miti_output(miti_output_path, result, model_type)

        # Use reconciliation results if available
        if reconciliation_result is not None:
            _audit_reconciliation(reconciliation_result, result)

        # Compute preservation percentages
        _compute_preservation_metrics(result)

        # Determine verdict
        _set_verdict(result)

        logger.info("Audit complete: %s", result.summary())

    except Exception as e:  # noqa: BLE001
        logger.exception("Audit failed for %s: %s", model_name, e)
        result.issues.append(f"Audit exception: {type(e).__name__}: {e}")
        result.verdict = "FAIL"

    return result


def _audit_pd_source(pd_path: str, result: MitiAuditResult, model_type: str) -> None:
    """Extract baseline counts from original PD source."""
    try:
        from lxml import etree

        tree = etree.parse(pd_path)
        root = tree.getroot()

        # Count comments by model type
        if model_type in ("CDM", "LDM"):
            # Entities with comments
            entities = root.xpath("//o:Entity", namespaces={"o": "http://powerdesigner.net/core"})
            result.entity_count_pd = len(entities)
            result.comment_count_pd = len([e for e in entities
                                          if e.get("Comment") or e.get("CommentText")])
        elif model_type == "PDM":
            # Tables with comments
            tables = root.xpath("//o:Table", namespaces={"o": "http://powerdesigner.net/core"})
            result.entity_count_pd = len(tables)
            result.comment_count_pd = len([t for t in tables
                                          if t.get("Comment") or t.get("CommentText")])

        # Count extended attributes (UDPs)
        ext_attrs = root.xpath("//o:ExtendedAttribute", namespaces={"o": "http://powerdesigner.net/core"})
        result.udp_count_pd = len(ext_attrs)

        # Count relationships/FKs
        if model_type in ("CDM", "LDM"):
            rels = root.xpath("//o:Relationship", namespaces={"o": "http://powerdesigner.net/core"})
            result.relationship_count_pd = len(rels)
        elif model_type == "PDM":
            refs = root.xpath("//o:Reference", namespaces={"o": "http://powerdesigner.net/core"})
            result.relationship_count_pd = len(refs)

        logger.debug("PD source baseline: %d entities, %d comments, %d UDPs, %d relationships",
                    result.entity_count_pd, result.comment_count_pd,
                    result.udp_count_pd, result.relationship_count_pd)

    except Exception as e:  # noqa: BLE001
        logger.warning("Could not parse PD source for audit: %s", e)
        result.warnings.append(f"PD parse failed: {type(e).__name__}")


def _audit_miti_output(output_path: str, result: MitiAuditResult, model_type: str) -> None:
    """Audit MIT Bridge output (erwin XML) against baseline."""
    try:
        from lxml import etree

        # Determine if it's XML or .erwin (binary)
        if output_path.lower().endswith(".xml"):
            tree = etree.parse(output_path)
            root = tree.getroot()

            # Count entities/tables with notes
            entities = root.xpath("//Entity | //Table", namespaces={})
            result.entity_count_erwin = len(entities)

            # Count notes (erwin Notes field)
            notes = root.xpath("//Note_List/Note", namespaces={})
            result.comment_count_erwin = len(notes)

            # Count UDP values
            udp_props = root.xpath("//*[starts-with(local-name(), 'UDP:')]", namespaces={})
            result.udp_count_erwin = len(udp_props)

            # Count relationships/references
            if model_type in ("CDM", "LDM"):
                rels = root.xpath("//Relationship", namespaces={})
                result.relationship_count_erwin = len(rels)
            elif model_type == "PDM":
                refs = root.xpath("//Reference", namespaces={})
                result.relationship_count_erwin = len(refs)

            logger.debug("MITI output: %d entities, %d notes, %d UDPs, %d relationships",
                        result.entity_count_erwin, result.comment_count_erwin,
                        result.udp_count_erwin, result.relationship_count_erwin)

        elif output_path.lower().endswith(".erwin"):
            result.warnings.append(".erwin binary format: detailed audit requires erwin COM access")
            # Could add COM-based audit here if pywin32 is available

    except Exception as e:  # noqa: BLE001
        logger.warning("Could not parse MITI output for audit: %s", e)
        result.warnings.append(f"MITI output parse failed: {type(e).__name__}")


def _audit_reconciliation(rec_result, result: MitiAuditResult) -> None:
    """Use reconciliation results to augment audit findings."""
    try:
        if hasattr(rec_result, "findings") and rec_result.findings:
            # Count critical/warning findings that might indicate loss
            for finding in rec_result.findings:
                if finding.severity == "CRITICAL" and "MISSING" in finding.category:
                    result.issues.append(
                        f"{finding.category}: {finding.message}")
                elif finding.severity in ("WARNING", "INFO"):
                    result.warnings.append(
                        f"{finding.category}: {finding.message}")
    except Exception as e:  # noqa: BLE001
        logger.debug("Could not process reconciliation results: %s", e)


def _compute_preservation_metrics(result: MitiAuditResult) -> None:
    """Compute preservation percentages."""
    if result.comment_count_pd > 0:
        result.comment_preservation_pct = (result.comment_count_erwin /
                                          result.comment_count_pd * 100)

    if result.udp_count_pd > 0:
        result.udp_preservation_pct = (result.udp_count_erwin /
                                      result.udp_count_pd * 100)

    if result.entity_count_pd > 0:
        result.entity_preservation_pct = (result.entity_count_erwin /
                                         result.entity_count_pd * 100)

    if result.relationship_count_pd > 0:
        result.relationship_preservation_pct = (result.relationship_count_erwin /
                                               result.relationship_count_pd * 100)


def _set_verdict(result: MitiAuditResult) -> None:
    """Determine overall audit verdict."""
    if result.issues:
        result.verdict = "FAIL"
    elif result.warnings:
        result.verdict = "WARN"
    elif (result.comment_preservation_pct >= 95 and
          result.udp_preservation_pct >= 95 and
          result.entity_preservation_pct >= 99 and
          result.relationship_preservation_pct >= 99):
        result.verdict = "PASS"
    else:
        result.verdict = "WARN"


__all__ = ["MitiAuditResult", "audit_miti_import", "file_hash"]
